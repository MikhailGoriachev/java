package org.itstep.pd011;

// приклаоные запросы к нескольким таблицам
// итоговые запросы
public class Queries {
}
