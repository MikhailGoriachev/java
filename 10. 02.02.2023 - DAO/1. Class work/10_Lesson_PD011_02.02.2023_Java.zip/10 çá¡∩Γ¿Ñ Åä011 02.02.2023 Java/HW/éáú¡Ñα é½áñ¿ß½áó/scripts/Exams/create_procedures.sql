use exam_results_goriachev;

-- 1. Хранимая функция 	
-- Выбирает информацию об абитуриентах с заданной фамилией, серией/номером паспорта

delimiter $$

drop procedure if exists query01_proc$$

create procedure query01_proc(in surname varchar(45), in passport varchar(20))
begin
    select
        *
    from
        students_view
    where
        students_view.passport like passport and students_view.surname like surname;

end$$

delimiter ;


-- 2. Хранимая функция	
-- Выбирает информацию об экзаменах, которые были приняты экзаменатором с заданной фамилией

delimiter $$

drop procedure if exists query02_proc$$

create procedure query02_proc(in surname varchar(45))
begin
    select * from exams_view where exams_view.examiner_surname like surname;
end$$

delimiter ;

-- 3. Хранимая функция	
-- Выбирает информацию об экзаменах, сданных абитуриентом с заданным номером/серией паспорта

delimiter $$

drop procedure if exists query03_proc$$

create procedure query03_proc(in passport varchar(20))
begin
    select
        *
    from
        exams_view
    where exams_view.student_passport like passport;
end$$

delimiter ;

-- 4. Хранимая функция	
-- Выбирает информацию об абитуриенте с заданным номером/серией паспорта. 

delimiter $$

drop procedure if exists query04_proc$$

create procedure query04_proc(passport nvarchar(20))
begin
    select *
    from
        students_view
    where
            students_view.passport like passport;
end$$

delimiter ;

-- 5. Хранимая функция


delimiter $$

drop procedure if exists query05_proc$$

create procedure query05_proc()
begin
    select
        *,
        exams_view.examiner_payment * 0.13                                  as tax,
        exams_view.examiner_payment - (exams_view.examiner_payment * 0.13) as salary
    from exams_view
    order by exams_view.id;
end$$

delimiter ;

-- 6. Хранимая функция


delimiter $$

drop procedure if exists query06_proc$$

create procedure query06_proc()
begin
    select
        students_view.year_of_birth,
        count(students_view.id) as amount

    from
        students_view
    group by
        students_view.year_of_birth;
end$$

delimiter ;

-- 7. Хранимая функция	
-- Выполняет группировку по полю Дата сдачи экзамена в таблице ЭКЗАМЕНЫ.
-- Для каждой даты определяет среднее значения по полю Оценка

delimiter $$

drop procedure if exists query07_proc$$

create procedure query07_proc()
begin
    select
        exams_view.pass_date,
        count(*) as amount,
        avg(exams_view.grade) as avg_grade

    from
        exams_view
    group by
        exams_view.pass_date;
end$$

delimiter ;


-- 8. Хранимая функция. Добавление записи об экзамене

delimiter $$

drop procedure if exists query08_proc$$

create procedure query08_proc(IN idSubject int, IN idExaminer int, IN idStudent int,
                                                    IN examDate varchar(10), IN examGrade int)
begin
    insert into
        exams(id_subject, id_examiner, id_student, date, grade)
    values
        (idSubject,idExaminer,idStudent,examDate,examGrade);
end $$

delimiter ;

-- 9. Хранимая функция. Редактирования записи

delimiter $$

drop procedure if exists query09_proc$$

-- Редактируем запись об экзамене для конкретного студента. Студента находим по паспорту

create procedure query09_proc(in examGrade int, in examDate varchar(15),in idExaminer int, in passport varchar(20))
begin
    update
        exams
    set
        grade = examGrade,
        date = examDate,
        id_examiner = idExaminer
    where
         (select students_view.id
             from
                 students_view
             where
                 students_view.passport like passport limit 1) = exams.id_student;
end $$

delimiter ;

-- 10. Хранимая функция. Удаление записи об экзамене

delimiter $$

drop procedure if exists query10_proc$$

create procedure query10_proc()
begin

end $$

delimiter ;
