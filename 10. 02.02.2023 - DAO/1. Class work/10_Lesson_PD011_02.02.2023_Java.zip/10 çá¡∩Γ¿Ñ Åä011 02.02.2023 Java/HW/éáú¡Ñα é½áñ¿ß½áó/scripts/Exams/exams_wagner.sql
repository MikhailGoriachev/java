CREATE DATABASE  IF NOT EXISTS `exams_wagner` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `exams_wagner`;
-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: exams_wagner
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `examiners`
--

DROP TABLE IF EXISTS `examiners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `examiners` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_person` int NOT NULL,
  `exam_fee` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_exams_persons_idx` (`id_person`),
  CONSTRAINT `fk_examiners_people` FOREIGN KEY (`id_person`) REFERENCES persons (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `examiners`
--

LOCK TABLES `examiners` WRITE;
/*!40000 ALTER TABLE `examiners` DISABLE KEYS */;
INSERT INTO `examiners` VALUES (1,1,300),(2,2,450),(3,3,730),(4,4,680),(5,5,320),(6,1,300),(7,2,450),(8,3,730),(9,4,680),(10,5,320);
/*!40000 ALTER TABLE `examiners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `examiners_view`
--

DROP TABLE IF EXISTS `examiners_view`;
/*!50001 DROP VIEW IF EXISTS `examiners_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `examiners_view` AS SELECT 
 1 AS `id`,
 1 AS `last_name`,
 1 AS `first_name`,
 1 AS `patronymic`,
 1 AS `exam_fee`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exams`
--

DROP TABLE IF EXISTS `exams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exams` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_subject` int NOT NULL,
  `id_examiner` int NOT NULL,
  `id_student` int NOT NULL,
  `date` date DEFAULT NULL,
  `grade` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_exams_subjects_idx` (`id_subject`),
  KEY `fk_exams_examiners_idx` (`id_examiner`),
  KEY `fk_exams_students_idx` (`id_student`),
  CONSTRAINT `fk_exams_examiners` FOREIGN KEY (`id_examiner`) REFERENCES `examiners` (`id`),
  CONSTRAINT `fk_exams_students` FOREIGN KEY (`id_student`) REFERENCES `students` (`id`),
  CONSTRAINT `fk_exams_subjects` FOREIGN KEY (`id_subject`) REFERENCES `subjects` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exams`
--

LOCK TABLES `exams` WRITE;
/*!40000 ALTER TABLE `exams` DISABLE KEYS */;
INSERT INTO `exams` VALUES (1,2,1,15,'2020-12-01',4),(2,1,2,14,'2020-12-03',3),(3,3,3,13,'2020-10-15',5),(4,4,4,12,'2020-11-24',4),(5,2,2,11,'2020-10-15',2),(6,5,2,10,'2020-12-15',4),(7,7,5,10,'2020-12-15',5),(8,9,8,9,'2020-09-25',4),(9,4,6,8,'2020-12-20',3),(10,6,2,7,'2020-11-18',5),(11,5,2,6,'2020-12-09',4),(12,3,3,5,'2020-12-01',2);
/*!40000 ALTER TABLE `exams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `exams_view`
--

DROP TABLE IF EXISTS `exams_view`;
/*!50001 DROP VIEW IF EXISTS `exams_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `exams_view` AS SELECT 
 1 AS `id`,
 1 AS `subject_name`,
 1 AS `examiner_name`,
 1 AS `examiner_surname`,
 1 AS `examiner_patronymic`,
 1 AS `examiner_payment`,
 1 AS `student_name`,
 1 AS `student_surname`,
 1 AS `student_patronymic`,
 1 AS `student_address`,
 1 AS `student_birth_date`,
 1 AS `student_passport`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `people`
--

DROP TABLE IF EXISTS persons;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `people` (
  `id` int NOT NULL AUTO_INCREMENT,
  `last_name` varchar(45) NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `patronymic` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `people`
--

LOCK TABLES persons WRITE;
/*!40000 ALTER TABLE persons DISABLE KEYS */;
INSERT INTO persons VALUES (1,'Денисов','Юстиниан','Митрофанович'),(2,'Новиков','Мирон','Богуславович'),(3,'Филиппов','Кондратий','Николаевич'),(4,'Савин','Геннадий','Филатович'),(5,'Лукин','Корнелий','Проклович'),(6,'Никитин','Семен','Григорьевич'),(7,'Соловьёв','Филипп','Альбертович'),(8,'Ширяев','Родион','Донатович'),(9,'Тихонов','Ипполит','Дамирович'),(10,'Одинцов','Аполлон','Тимофеевич'),(11,'Денисов','Юстиниан','Митрофанович'),(12,'Новиков','Мирон','Богуславович'),(13,'Филиппов','Кондратий','Николаевич'),(14,'Савин','Геннадий','Филатович'),(15,'Лукин','Корнелий','Проклович'),(16,'Никитин','Семен','Григорьевич'),(17,'Соловьёв','Филипп','Альбертович'),(18,'Ширяев','Родион','Донатович'),(19,'Тихонов','Ипполит','Дамирович'),(20,'Одинцов','Аполлон','Тимофеевич');
/*!40000 ALTER TABLE persons ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_person` int NOT NULL,
  `address` varchar(160) NOT NULL,
  `year_of_birth` int NOT NULL,
  `passport` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `passport_UNIQUE` (`passport`),
  KEY `fk_stundets_people_idx` (`id_person`),
  CONSTRAINT `fk_stundets_people` FOREIGN KEY (`id_person`) REFERENCES persons (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,6,'г.Донецк, ул.Ильича, 18/3',1990,'44773328'),(2,7,'г.Донецк, ул.Артёма, 3/12',1996,'33790923'),(3,8,'г.Донецк, ул.Петровского, 64/8',1998,'13721490'),(4,9,'г.Донецк, ул.Крамарчука, 32/4',1993,'29770384'),(5,10,'г.Донецк, ул.Ильича, 12/6',1994,'94535144'),(6,11,'г.Донецк, ул.Крамарчука, 53/1',1990,'17134204'),(7,12,'г.Донецк, ул.Артёма, 78/5',2002,'60796113'),(8,13,'г.Донецк, ул.Петровского, 43/23',2003,'81483503'),(9,14,'г.Донецк, ул.Артёма, 12/65',1994,'80847926'),(10,15,'г.Донецк, ул.Петровского, 48/4',1994,'34754110'),(11,16,'г.Донецк, ул.Ильича, 46/45',1999,'12930653'),(12,17,'г.Донецк, ул.Петровского, 56/34',1999,'68446173'),(13,18,'г.Донецк, ул.Крамарчука, 34/12',2000,'66546237'),(14,19,'г.Донецк, ул.Артёма, 65/4',2000,'56123465'),(15,20,'г.Донецк, ул.Ильича, 23/23',1999,'13653354');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `students_view`
--

DROP TABLE IF EXISTS `students_view`;
/*!50001 DROP VIEW IF EXISTS `students_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `students_view` AS SELECT 
 1 AS `id`,
 1 AS `last_name`,
 1 AS `first_name`,
 1 AS `patronymic`,
 1 AS `address`,
 1 AS `year_of_birth`,
 1 AS `passport`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `subjects`
--

DROP TABLE IF EXISTS `subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subjects` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subjects`
--

LOCK TABLES `subjects` WRITE;
/*!40000 ALTER TABLE `subjects` DISABLE KEYS */;
INSERT INTO `subjects` VALUES (1,'философия'),(2,'математика'),(3,'программирование'),(4,'литература'),(5,'физика'),(6,'алгебра'),(7,'геометрия'),(8,'астрономия'),(9,'история'),(10,'системное администрирование');
/*!40000 ALTER TABLE `subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `examiners_view`
--

/*!50001 DROP VIEW IF EXISTS `examiners_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `examiners_view` AS select `examiners`.`id` AS `id`,`people`.`last_name` AS `last_name`,`people`.`first_name` AS `first_name`,`people`.`patronymic` AS `patronymic`,`examiners`.`exam_fee` AS `exam_fee` from (`examiners` join persons on((`examiners`.`id_person` = `people`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `exams_view`
--

/*!50001 DROP VIEW IF EXISTS `exams_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `exams_view` AS select `exams`.`id` AS `id`,`subjects`.`name` AS `subject_name`,`ev`.`first_name` AS `examiner_name`,`ev`.`last_name` AS `examiner_surname`,`ev`.`patronymic` AS `examiner_patronymic`,`ev`.`exam_fee` AS `examiner_payment`,`students_view`.`first_name` AS `student_name`,`students_view`.`last_name` AS `student_surname`,`students_view`.`patronymic` AS `student_patronymic`,`students_view`.`address` AS `student_address`,`students_view`.`year_of_birth` AS `student_birth_date`,`students_view`.`passport` AS `student_passport` from (((`exams` join `subjects` on((`exams`.`id_subject` = `subjects`.`id`))) join `students_view` on((`exams`.`id_student` = `students_view`.`id`))) join `examiners_view` `ev` on((`exams`.`id_examiner` = `ev`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `students_view`
--

/*!50001 DROP VIEW IF EXISTS `students_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `students_view` AS select `students`.`id` AS `id`,`people`.`last_name` AS `last_name`,`people`.`first_name` AS `first_name`,`people`.`patronymic` AS `patronymic`,`students`.`address` AS `address`,`students`.`year_of_birth` AS `year_of_birth`,`students`.`passport` AS `passport` from (`students` join persons on((`students`.`id_person` = `people`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-02 11:26:08
