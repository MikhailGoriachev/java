
-- создание представления экзаменов
create or replace view exams_view as
select
    exams.id,
    subjects.`name` as subject_name,
    exams.date as pass_date,

    ev.name as examiner_name,
    ev.surname as examiner_surname,
    ev.patronymic as examiner_patronymic,
    ev.payment as examiner_payment,

    students_view.name as student_name,
    students_view.surname as student_surname,
    students_view.patronymic as student_patronymic,
    students_view.address as student_address,
    students_view.year_of_birth as student_birth_date,
    students_view.passport as student_passport,

    exams.grade
from
    exams join subjects  on exams.id_subject = subjects.id
          join students_view on exams.id_student = students_view.id
          join examiners_view ev on exams.id_examiner = ev.id;

-- Представление таблицы студентов
create or replace view students_view as
select
    students.id,

    p.first_name as name,
    p.last_name as surname,
    p.patronymic as patronymic,

    students.address,
    students.year_of_birth,
    students.passport
from
    students join persons p on students.id_person = p.id

-- Представление таблицы экзаменов
create or replace view examiners_view as
select
    examiners.id,

    p.first_name as name,
    p.last_name as surname,
    p.patronymic as patronymic,

    examiners.exam_fee as payment
from
    examiners join persons p on examiners.id_person = p.id