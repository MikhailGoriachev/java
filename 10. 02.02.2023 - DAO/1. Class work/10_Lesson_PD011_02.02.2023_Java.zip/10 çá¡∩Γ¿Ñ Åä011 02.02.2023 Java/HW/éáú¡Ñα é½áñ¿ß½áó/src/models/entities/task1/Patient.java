package models.entities.task1;

import java.sql.Date;

public record Patient(int id,
                      String surname,
                      String name,
                      String patronymic,
                      String date,
                      String address,
                      String passport
) {

    //Заголовок таблицы
    public static String HEADER =
            "<th>ID</th>" +
            "<th>Фамилия  пациента</th>" +
            "<th>Имя пациента</th>" +
            "<th>Отчество пациента</th>" +
            "<th>Адрес пациента</th>" +
            "<th>Дата рождения</th>" +
            "<th>Паспорт пациента</th>" +
            "</tr>";

    //Строка таблицы
    public  String toTableRow (){
        return String.format("<tr>" +
                        "<td> %1$d </td>" +
                        "<td> %2$s </td>" +
                        "<td> %3$s </td>" +
                        "<td> %4$s </td>" +
                        "<td> %5$s </td>" +
                        "<td> %6$s </td>" +
                        "<td> %7$s </td>" +
                        "</tr>",
                id,
                surname, name, patronymic,address, date, passport);
    };

}
