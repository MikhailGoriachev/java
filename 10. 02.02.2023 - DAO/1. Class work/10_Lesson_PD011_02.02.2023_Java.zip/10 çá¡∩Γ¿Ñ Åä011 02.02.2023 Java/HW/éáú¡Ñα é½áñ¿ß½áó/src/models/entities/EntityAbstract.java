package models.entities;

public abstract class EntityAbstract {

    //Заголовк таблицы
    public static String header;

    //Доп. информация
    public static String info ;

    //Вывод в строку таблицы
    public abstract String toTableRow();
}
