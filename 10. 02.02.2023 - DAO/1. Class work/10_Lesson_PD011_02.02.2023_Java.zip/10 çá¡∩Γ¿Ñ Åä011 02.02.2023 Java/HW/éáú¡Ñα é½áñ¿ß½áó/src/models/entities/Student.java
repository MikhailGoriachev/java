package models.entities;

public class Student {
}
