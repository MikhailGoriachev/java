package models.entities.task1;

public record Doctor(
        int id,
        String surname,
        String name,
        String patronymic,
        String speciality,
        double percent) {

    //Заголовок таблицы
    public static String HEADER ="<tr>" +
                    "<th>ID</th>" +
                    "<th>Фамилия доктора</th>" +
                    "<th>Имя доктора</th>" +
                    "<th>Отчество доктора</th>" +
                    "<th>Специальность доктора</th>" +
                    "<th>% отчислений</th>" +
            "</tr>";

    //Строка таблицы
    public  String toTableRow (){
        return String.format(/*"│ %1$3d │ %2$14s  │ %3$18s │ %4$15s │ %5$17s │ %6$14s │ %7$15s │ %8$17s │ %9$17s │ %10$17s │ %11$16s │ %12$15.2f │"*/
                "<tr>" +
                        "<td> %1$d </td>" +
                        "<td> %2$s </td>" +
                        "<td> %3$s </td>" +
                        "<td> %4$s </td>" +
                        "<td> %5$s </td>" +
                        "<td> %6$.2f </td>" +
                "</tr>",
                id,
                surname, name, patronymic,speciality, percent);
    };

}
