package models.entities;

public record Exam(
        int id,

        String passDate,
        String subjectName,
        String examinerSurname,
        String examinerName,
        String examinerPatronymic,
        String studentSurname,
        String studentName,
        String studentPatronymic,
        String studentAddress,
        String brithDate,

        String passport,
        int examinerPayment,
        int grade

){
    public String toTableRow() {
        return String.format("<tr>" +
                        "<td> %1$d </td>" +
                        "<td> %2$s </td>" +
                        "<td> %3$s </td>" +
                        "<td> %4$s </td>" +
                        "<td> %5$s </td>" +
                        "<td> %6$s </td>" +
                        "<td> %7$s </td>" +
                        "<td> %8$s </td>" +
                        "<td> %9$s </td>" +
                        "<td> %10$s </td>" +
                        "<td> %11$s </td>" +
                        "<td> %12$s </td>" +
                        "<td> %13$d </td>" +
                        "<td> %14$d </td>" +
                        "</tr>",
                id, subjectName,
                examinerSurname, examinerName, examinerPatronymic, studentAddress, passDate,
                studentSurname, studentName, studentPatronymic, brithDate, passport, examinerPayment, grade);
    } // toTableRow

    public static final String HEADER ="<tr>" +
            "<th>ID</th>" +
            "<th>Предмет</th>" +
            "<th>Фамилия экзаменатора</th>" +
            "<th>Имя экзаменатора</th>" +
            "<th>Отчество экзаменатора</th>" +
            "<th>Адрес студента</th>" +
            "<th>Дата проведения</th>" +
            "<th>Фамилия доктора</th>" +
            "<th>Имя студента</th>" +
            "<th>Отчество студента</th>" +
            "<th>Дата рождения студента</th>" +
            "<th>Паспорт студента</th>" +
            "<th>Плата экзаменатору</th>" +
            "<th>Оценка</th>" +
            "</tr>";
}