package models.entities.task1;

public record Speciality(int id, String speciality) {

    //Заголовок таблицы
    public static String HEADER = "<th>ID</th>" +
            "<th>Специальность</th>" +
            "</tr>";

    //Строка таблицы
    public  String row (){
        return String.format("<tr>" +
                        "<td> %1$d </td>" +
                        "<td> %2$s </td>" +
                        "</tr>",
                id,speciality);
    };

}
