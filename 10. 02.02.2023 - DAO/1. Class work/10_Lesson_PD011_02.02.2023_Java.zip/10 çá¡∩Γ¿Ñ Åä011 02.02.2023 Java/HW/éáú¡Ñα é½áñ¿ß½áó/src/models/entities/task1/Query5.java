package models.entities.task1;


public record Query5(
        int id,
        String date,
        String doctorSurname,
        String doctorName,
        String doctorPatronymic,
        String speciality,
        int price,
        double percent,
        double salary) {

    //Заголовок таблицы
    public static String HEADER ="<tr>" +
                    "<th>Id</th>" +
                    "<th>Дата приема</th>" +
                    "<th>Фамилия доктора</th>" +
                    "<th>Имя доктора</th>" +
                    "<th>Отчество доктора</th>" +
                    "<th>Специалист</th>" +
                    "<th>Стоимость приема</th>" +
                    "<th>% отчислений</th>" +
                    "<th>Зарплата</th>" +
            "</tr>";

    //Строка таблицы
    public  String toTableRow (){
        return String.format(
                "<tr>" +
                        "<td> %1$d </td>" +
                        "<td> %2$s </td>" +
                        "<td> %3$s </td>" +
                        "<td> %4$s </td>" +
                        "<td> %5$s </td>" +
                        "<td> %6$s </td>" +
                        "<td> %7$d </td>" +
                        "<td> %8$.2f </td>" +
                        "<td> %9$.2f </td>" +
                        "</tr>"
                ,id, date,
                doctorSurname, doctorName, doctorPatronymic, speciality, price, percent, salary);
    };

}
