package models;

import models.entities.task1.*;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.*;
import java.util.ArrayList;
import java.util.*;

//Класс для запросов к БД
public class DBHandlerTask1 {
    //Соединение с БД
    private final Connection connection;

    //Объект этого же класса для работы с БД
    private static DBHandlerTask1 instance = null;

    //Создание объекта только 1 раз
    public static synchronized DBHandlerTask1 getInstance() throws Exception {
        if (instance == null)
            instance = new DBHandlerTask1();

        return instance;
    }

    private DBHandlerTask1() throws Exception {
        //Регистрация драйвера SQLLite
       /* DriverManager.registerDriver(new JDBC());*/

        //Регистрация драйвера MySQL
        Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();

        //Создаём подключение к БД
        this.connection = loadConnection();
    }

    //Загрузка конфигурации для подключения к БД MySQL
    private static Connection loadConnection() throws Exception {
        Properties properties = new Properties();

        try(InputStream is = Files.newInputStream(Paths.get("app_data/PolyclinicDB.properties"))){
            properties.load(is);
        }

        //Чтение параметров из файла
        String url = properties.getProperty("url");
        String username = properties.getProperty("username");
        String password = properties.getProperty("password");

        //Получаем подключение
        return DriverManager.getConnection(url,username,password);
    }

    //Получить приемы пациентов
    public List<Appointment> getAppointments() throws SQLException{

        String query = """
               select
                   *
               from view_appointments
                """;

        //Создать оператор запроса
        try(Statement state = connection.createStatement()) {

            //Выполнение запроса
            ResultSet set = state.executeQuery(query);

            return appointmentsToList(set);

        }
    }

    //Получить всех докторов
    public List<Doctor> getDoctors() throws SQLException{

        String query = """
               select
                   *
               from view_doctors
                """;

        //Создать оператор запроса
        try(Statement state = connection.createStatement()) {

            //Выполнение запроса
            ResultSet set = state.executeQuery(query);

            return doctorsToList(set);

        }
    }

    //Получить всех пациентов
    public List<Patient> getPatients() throws SQLException{

        String query = """
               select
                   *
               from view_patients
                """;

        //Создать оператор запроса
        try(Statement state = connection.createStatement()) {

            //Выполнение запроса
            ResultSet set = state.executeQuery(query);

            return patientsToList(set);

        }
    }

    //region Перевод набора данных таблицы в коллекцию
    //Перевести набор данных из таблицы в коллекцию приемов
    public List<Appointment> appointmentsToList(ResultSet resultSet) throws SQLException {
        List<Appointment> collection = new ArrayList<>();

        while (resultSet.next()){
            collection.add(new Appointment(
                    resultSet.getInt("id"),
                    resultSet.getString("appointment_date"),

                    resultSet.getString("patient_surname"),
                    resultSet.getString("patient_name"),
                    resultSet.getString("patient_patronymic"),

                    resultSet.getString("born_date"),
                    resultSet.getString("address"),

                    resultSet.getString("doctor_surname"),
                    resultSet.getString("doctor_name"),
                    resultSet.getString("doctor_patronymic"),

                    resultSet.getString("speciality"),

                    resultSet.getString("passport"),

                    resultSet.getDouble("percent"),
                    resultSet.getInt("price"))
            );
        }
        return collection;
    }

    //Перевести набор данных из таблицы в коллекцию докторов
    public List<Doctor> doctorsToList(ResultSet resultSet) throws SQLException {
        List<Doctor> collection = new ArrayList<>();

        while (resultSet.next()){
            collection.add(new Doctor(
                    resultSet.getInt("id"),
                    resultSet.getString("doctor_surname"),
                    resultSet.getString("doctor_name"),
                    resultSet.getString("doctor_patronymic"),

                    resultSet.getString("speciality"),
                    resultSet.getDouble("percent")
            )); //add
        }
        return collection;
    }

    //Перевести набор данных из таблицы в коллекцию пациентов
    public List<Patient> patientsToList(ResultSet resultSet) throws SQLException {
        List<Patient> collection = new ArrayList<>();

        //Сформировать коллекцию из набора данных полученного при запросе
        while (resultSet.next()){
            collection.add(new Patient(
                    resultSet.getInt(1),
                    resultSet.getString("patient_surname"),
                    resultSet.getString("patient_name"),
                    resultSet.getString("patient_patronymic"),

                    resultSet.getString("born_date"),
                    resultSet.getString("address"),
                    resultSet.getString("passport")
            ));
        }
        return collection;
    }
    //endregion

    //region Запросы
    //Запрос 1 -
    public List<Patient> query1(String patient_surname) throws SQLException{

        String query = """
               select
                   *
               from
                   view_patients
               where
                   /*view_patients.patient_surname like ? || '%';*/
                   view_patients.patient_surname like ?
                """;

        //Создать оператор запроса
        try(PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setString(1,patient_surname+"%");

            //Выполнение запроса
            ResultSet set = ps.executeQuery();

            return patientsToList(set);

        }
    }

    //Запрос 2 - Выбирает информацию о врачах, для которых значение в поле.
    // Процент отчисления на зарплату, больше заданного
    public List<Doctor> query2(Double percent) throws SQLException{

        String query = """
               select
                   *
               from
                   view_doctors
               where
                   view_doctors.percent > ?;
                """;

        //Создать оператор запроса
        try(PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setDouble(1,percent);

            //Выполнение запроса
            ResultSet set = ps.executeQuery();

            return doctorsToList(set);

        }
    }

    //Запрос 3 - Выбирает информацию о приемах за некоторый период
    public List<Appointment> query3(String from,String to) throws SQLException{

        String query = """
                select
                    *
                from
                    view_appointments
                where
                    view_appointments.appointment_date between ? and ?
                """;

        //Создать оператор запроса
        try(PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setString(1,from);
            ps.setString(2,to);

            //Выполнение запроса
            ResultSet set = ps.executeQuery();

            return appointmentsToList(set);

        }
    }

    //Запрос 4 - Выбирает из таблицы информацию о врачах с заданной специальностью
    public List<Doctor> query4(String speciality) throws SQLException{

        String query = """
               select
                   *
               from 
                view_doctors
               where view_doctors.speciality like ?
                """;

        //Создать оператор запроса
        try(PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setString(1,speciality);

            //Выполнение запроса
            ResultSet set = ps.executeQuery();

            return doctorsToList(set);

        }
    }


    //Запрос 5
    public List<Query5> query5() throws Exception{
        List<Query5> collection = new ArrayList<>();

        //Запрос
        String query = """
                select
                        id
                     , view_appointments.appointment_date
                     , view_appointments.doctor_surname
                     , view_appointments.doctor_name
                     , view_appointments.doctor_patronymic
                     , view_appointments.speciality
                     , view_appointments.price
                     , view_appointments.percent
                     , view_appointments.price * percent / 100 as salary
                from
                    view_appointments
                order by
                    view_appointments.speciality
                """;

        //Запуск оператора запроса
        try(Statement statement = connection.createStatement()){

            ResultSet result = statement.executeQuery(query);

            //Сформировать коллекцию
            while (result.next()){
                collection.add(new Query5(
                        result.getInt("id"),

                        result.getString("appointment_date"),

                        result.getString("doctor_surname"),
                        result.getString("doctor_name"),
                        result.getString("doctor_patronymic"),

                        result.getString("speciality"),

                        result.getInt("price"),
                        result.getDouble("percent"),
                        result.getDouble("salary")

                ));
            }

        }

        return collection;
    }

    //Запрос 6
    public List<Query6> query6() throws Exception{
        List<Query6> collection = new ArrayList<>();

        //Запрос
        String query = """
                select
                    view_appointments.appointment_date as date,
                    count(*) as amount,
                    max(view_appointments.price) as maxPrice
                from
                    view_appointments
                group by
                    view_appointments.appointment_date
                """;

        //Запуск оператора запроса
        try(Statement statement = connection.createStatement()){

            ResultSet result = statement.executeQuery(query);

            //Сформировать коллекцию
            while (result.next()){
                collection.add(new Query6(
                        result.getString("date"),
                        result.getInt("amount"),
                        result.getInt("maxPrice")
                ));
            }

        }

        return collection;
    }

    //Запрос 7
    public List<Query7> query7() throws Exception{
        List<Query7> collection = new ArrayList<>();

        //Запрос
        String query = """
                select
                    view_appointments.speciality,
                    count(*) as amount,
                    avg(view_appointments.percent) as avgPercent
                from
                    view_appointments
                group by
                    view_appointments.speciality
                """;

        //Запуск оператора запроса
        try(Statement statement = connection.createStatement()){

            ResultSet result = statement.executeQuery(query);

            //Сформировать коллекцию
            while (result.next()){
                collection.add(new Query7(
                        result.getString("speciality"),
                        result.getInt("amount"),
                        result.getDouble("avgPercent")
                ));
            }

        }

        return collection;
    }
    //endregion

    //Добавление записи
    public List<Appointment> addAppointment() throws SQLException {

        String query = """
                insert into appointments
                (appointment_date, id_patient, id_doctor)
                values
                    (?,  ?,  ?); 
                """;

        //Создать оператор запроса
        try(PreparedStatement ps = this.connection.prepareStatement(query)) {

            ps.setString(1,"2022-05-07");
            ps.setInt(2,3);
            ps.setInt(3,2);

            //Выполнение запроса
            ps.executeUpdate();

        }

        return getAppointments();
    } //addAppointment

    // Редактирование записи
    public List<Appointment> editAppointment(String date, String doctorToChange) throws SQLException {

        //Поменять доктора для приема за определённую дату
        String query = """
                update appointments
                set
                    id_doctor = (select view_doctors.id from view_doctors where view_doctors.doctor_surname = ?)
                where
                    appointments.appointment_date like ?;
                """;

        //Создать оператор запроса
        try(PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setString(1,doctorToChange);
            ps.setString(2,date);

            //Выполнение запроса
            ps.executeUpdate();

        }

        return getAppointments();
    } //editAppointment

    // Удаление записи
    public List<Appointment> deleteAppointment(String passport) throws SQLException {

        //Поменять доктора для приема за определённую дату
        String query = """
                delete from appointments
                where (select patients.passport
                       from patients
                       where patients.id = appointments.id_patient) = ?;
                """;

        //Создать оператор запроса
        try(PreparedStatement ps = this.connection.prepareStatement(query)) {

            ps.setString(1,passport);

            //Выполнение запроса
            ps.executeUpdate();
        }

        return getAppointments();
    } //deleteAppointment


}
