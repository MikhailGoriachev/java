package models;

import models.entities.Exam;
import models.entities.task1.*;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

//Класс для запросов к БД
public class DBHandlerTask2 {

    //Соединение с БД
    private final Connection connection;

    //Объект этого же класса для работы с БД
    private static DBHandlerTask2 instance = null;

    //Создание объекта только 1 раз
    public static synchronized DBHandlerTask2 getInstance() throws Exception {
        if (instance == null)
            instance = new DBHandlerTask2();

        return instance;
    }

    private DBHandlerTask2() throws Exception {
        //Регистрация драйвера MySQL
        Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();

        //Создаём подключение к БД
        this.connection = loadConnection();
    }

    //Загрузка конфигурации для подключения к БД MySQL
    private static Connection loadConnection() throws Exception {
        Properties properties = new Properties();

        try(InputStream is = Files.newInputStream(Paths.get("app_data/ExamsDB.properties"))){
            properties.load(is);
        }

        //Чтение параметров из файла
        String url = properties.getProperty("url");
        String username = properties.getProperty("username");
        String password = properties.getProperty("password");

        //Получаем подключение
        return DriverManager.getConnection(url,username,password);
    }

    //Получить приемы пациентов


    //region Перевод набора данных таблицы в коллекцию

    //Перевести набор данных из таблицы в коллекцию экзаменов
    public List<Exam> appointmentsToList(ResultSet resultSet) throws SQLException {
        List<Exam> collection = new ArrayList<>();

        /*while (resultSet.next()){
            collection.add(new Exam(
                    resultSet.getInt("id"),
                    resultSet.getString("subject_name"),

                    resultSet.getString("pass_date"),

                    resultSet.getString("examiner_surname"),
                    resultSet.getString("examiner_name"),
                    resultSet.getString("examiner_patronymic"),

                    resultSet.getString("student_surname"),
                    resultSet.getString("student_surname"),
                    resultSet.getString("student_patronymic"),

                    resultSet.getString("student_address"),

                    resultSet.getString("student_passport"),
                    resultSet.getInt("examiner_payment"),
                    resultSet.getInt("grade"))
            );
        }*/
        return collection;
    }

    //endregion

    //region Запросы

    //Запрос 1 -

    //Запрос 2 -

    //Запрос 3 -

    //Запрос 4 -

    //Запрос 5

    //Запрос 6

    //Запрос 7

    //endregion

    //Добавление записи


    // Редактирование записи


    // Удаление записи

    //deleteAppointment


}
