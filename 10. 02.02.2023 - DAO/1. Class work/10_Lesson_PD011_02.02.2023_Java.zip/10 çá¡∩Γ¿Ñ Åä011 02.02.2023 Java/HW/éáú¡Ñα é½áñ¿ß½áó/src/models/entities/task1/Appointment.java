package models.entities.task1;

public record Appointment(
        int id,
        String date,
        String patientSurname,
        String patientName,
        String patientPatronymic,
        String dob,
        String address,
        String doctorSurname,
        String doctorName,
        String doctorPatronymic,
        String speciality,

        String passport,
        double percent,
        int price

){
    public String toTableRow() {
        return String.format("<tr>" +
                        "<td> %1$d </td>" +
                        "<td> %2$s </td>" +
                        "<td> %3$s </td>" +
                        "<td> %4$s </td>" +
                        "<td> %5$s </td>" +
                        "<td> %6$s </td>" +
                        "<td> %7$s </td>" +
                        "<td> %8$s </td>" +
                        "<td> %9$s </td>" +
                        "<td> %10$s </td>" +
                        "<td> %11$s </td>" +
                        "<td> %12$s </td>" +
                        "<td> %13$d </td>" +
                        "<td> %14$.2f </td>" +
                        "</tr>",
                id, date,
                patientSurname, patientName, patientPatronymic, address, dob,
                doctorSurname, doctorName, doctorPatronymic, speciality, passport, price, percent);
    } // toTableRow

    public static final String HEADER ="<tr>" +
            "<th>ID</th>" +
            "<th>Дата приема</th>" +
            "<th>Фамилия пациента</th>" +
            "<th>Имя пациента</th>" +
            "<th>Отчество пациента</th>" +
            "<th>Адрес пациента</th>" +
            "<th>Дата рождения</th>" +
            "<th>Фамилия доктора</th>" +
            "<th>Имя доктора</th>" +
            "<th>Отчество доктора</th>" +
            "<th>Специалист</th>" +
            "<th>Паспорт пациента</th>" +
            "<th>Стоимость приема</th>" +
            "<th>% отчислений</th>" +
    "</tr>";
}
