package models.entities.task1;

public record Query7(
        String speciality,
        int amount,
        double avgPercent) {

    //Заголовок таблицы
    public static String HEADER ="<tr>" +
            "<th>Специальность</th>" +
            "<th>Количество докторов</th>" +
            "<th>Средний %</th>" +
            "</tr>";

    //Строка таблицы
    public  String toTableRow (){
        return String.format(
                        "<tr>" +
                        "<td> %1$s </td>" +
                        "<td> %2$d </td>" +
                        "<td> %3$.2f </td>" +
                        "</tr>",speciality,amount, avgPercent);
    };

}