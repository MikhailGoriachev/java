

import controllers.*;
import utils.Utils;

import javax.swing.*;


public class Main {
    public static void main(String[] args) throws Exception {


        try {
            //Контроллеры
            Object[] controllers = new Object[]{
                    new Task1Controller(),
                    new Task2Controller()
            };

            //Вызов методов на контроллерах
            while (true) {
                switch (showMenu()) {
                    case 0 -> ((Task1Controller) controllers[0]).run();
                    case 1 -> ((Task2Controller) controllers[1]).run();
                    case 2 -> System.exit(0);

                    default -> {
                        return;
                    }
                }
            }
        } catch (Exception e) {
            Utils.showWindowButtons(e.getMessage() + "\n","Ошибка!",new Object[]{"Выход"},"", JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage() + "\n");
            e.printStackTrace();
        }

    }//main

    //Вывод меню
    public static int showMenu(){

        //Задание значений для окна
        String title = "Задание на 02.02.23";
        String message = "<html><h1>Меню</h1>";
        Object[] buttons = new Object[]{
                "Задача 1",
                "Задача 2",
                "Выход"
        };


        return Utils.showWindowButtons(message,title,buttons,"Выход",JOptionPane.DEFAULT_OPTION);
    }

}