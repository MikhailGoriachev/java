package controllers;

import models.DBHandlerTask1;
import models.entities.task1.Doctor;
import utils.Utils;

import javax.swing.*;
import java.util.*;


public class Task1Controller {

    //Создается объект для работы с БД
    DBHandlerTask1 handler = DBHandlerTask1.getInstance();

    public Task1Controller() throws Exception {
    }

    //Запуск меню контроллера
    public void run() throws Exception {

        //Задание значений для окна
        String title = "База данных: поликлиника";
        String message = "<html><h1>Задача 1</h1>";
        Object[] buttons = new Object[]{
                "Запросы",
                "Таблицы",
                "CRUD-операци",
                "Выход"
        };

        //Вызов методов на контроллерах
        while (true) {
            switch (Utils.showWindowButtons(message,title,buttons,"Выход",JOptionPane.DEFAULT_OPTION)) {
                case 0 -> queries();
                case 1 -> tables();
                case 2 -> crud();
                default -> {
                    return;
                }
            }
        }
    }

    //Запросы. Меню
    public void queries() throws Exception{
        //Кнопки меню
        var buttons = new Object[]{"Запрос 1","Запрос 2","Запрос 3","Запрос 4","Запрос 5","Запрос 6","Запрос 7","Выход"};

        //Меню
        while (true) {

            //Выбранный пункт
            var point = Utils.showWindowButtons("Выберете запрос","",buttons,"Выход", JOptionPane.DEFAULT_OPTION);

            //Вывод зазпросов
            switch (point) {
                //Зпапрос 1
                case 0 -> {

                    var patients = handler.getPatients();

                    //Получить первую букву фамилии случайного пациента
                    String firstLettre = patients.get(Utils.getRandom(0,patients.size()))
                            .surname().substring(0,2);   // charAt(0)

                    System.out.printf("\n\tПараметр запроса 1: \u001b[38;5;34m%s\u001b[0m \n",firstLettre);

                    //Вывод таблицы докторов
                    if (Utils.showPatients(handler.query1(firstLettre)) == 0) {
                        break;
                    }
                }

                case 1 -> {
                    var doctors = handler.getDoctors();

                    //Получить случайню специальность
                    double percent = doctors.stream().mapToDouble(Doctor::percent).average().getAsDouble();

                    System.out.printf(Locale.UK,"\n\tОтчисление врачу за прием для запроса 2: \u001b[38;5;34m%.2f\u001b[0m \n",percent);

                    //Вывод таблицы докторов
                    if (Utils.showDoctors(handler.query2(percent)) == 0) {
                        break;
                    }
                }

                //Запрос 3
                case 2 -> {

                    /*Date from = new Date(2021,3,1);
                    Date to = new Date(2021,11,1);*/

                    //Строковые значения дат
                    String from = "2021-03-21";
                    String to = "2021-11-01";


                    System.out.printf(Locale.UK,"\n\tДиапазон дат для запроса 3: от %3$s%1$s \u001b[0m до %3$s%2$s \u001b[0m\n",from,to,"\u001b[38;5;34m");

                    //Для выхода обратно в меню
                    if (Utils.showAppointments(handler.query3(from, to)) == 0) {
                        break;
                    }
                }

                //Запрос 4
                case 3 -> {

                    var doctors = handler.getDoctors();

                    //Получить случайню специальность
                    String speciality = doctors.get(Utils.getRandom(0,doctors.size()))
                                        .speciality();

                    System.out.printf("\n\tСпециальность для запроса 4: \u001b[38;5;34m%s\u001b[0m \n",speciality);

                    //Вывод таблицы докторов
                    if (Utils.showDoctors(handler.query4(speciality)) == 0) {
                        break;
                    }
                }

                //Запрос 5
                case 4 -> {

                    //Для выхода обратно в меню
                    if (Utils.showQuery5(handler.query5()) == 0) {
                        break;
                    }
                }

                //Запрос 6
                case 5 -> {
                    //Для выхода обратно в меню
                    if (Utils.showQuery6(handler.query6()) == 0) {
                        break;
                    }
                }

                //Запрос 7
                case 6 -> {
                    //Для выхода обратно в меню
                    if (Utils.showQuery7(handler.query7()) == 0) {
                        break;
                    }
                }
                default -> {
                    return;
                }
            }
        }//while

    }//run

    //Вывод таблиц
    public void tables() throws Exception{

        var buttons = new Object[]{"Приемы","Врачи","Пациенты","Выход"};

        //Меню
        while (true) {

            //Выбранный пункт
            var point = Utils.showWindowButtons("Выберете таблицу","",buttons,"Выход", JOptionPane.DEFAULT_OPTION);


            switch (point) {

                case 0 -> {
                    //Для выхода обратно в меню
                    if (Utils.showAppointments(handler.getAppointments()) == 0) {
                        break;
                    }
                }

                case 1 -> {
                    //Для выхода обратно в меню
                    if (Utils.showDoctors(handler.getDoctors()) == 0) {
                        break;
                    }
                }

                case 2 -> {
                    //Для выхода обратно в меню
                    if (Utils.showPatients(handler.getPatients()) == 0) {
                        break;
                    }
                }
                default -> {
                    return;
                }
            }
        }//while
    }

    //Вывод CRUD-операций
    public void crud() throws Exception{

        var buttons = new Object[]{"Добавление","Редактирование","Удаление","Выход"};

        //Меню
        while (true) {

            //Выбранный пункт
            var point = Utils.showWindowButtons("Выберете операцию","CRUD",buttons,"Выход", JOptionPane.DEFAULT_OPTION);


            switch (point) {

                case 0 -> {

                    var appointments = handler.addAppointment();
                    int addedId = appointments.get(appointments.size()-1).id();

                    System.out.printf("\n\tId добавленного приема: \u001b[38;5;34m%s\u001b[0m \n",addedId);

                    //Для выхода обратно в меню
                    if (Utils.showAppointments(appointments) == 0) {
                        break;
                    }
                }
                case 1 -> {
                    //По дате менять доктора на другого (по этой дате доктор работать не может)
                    var surnames = handler.getDoctors().stream().map(Doctor::surname).toList();

                    String surname = surnames.get(Utils.getRandom(0,surnames.size()));

                    String date = "2021-10-28";

                    var appointments = handler.editAppointment(date,surname);

                    System.out.printf("\n\tИзменили прием с датой: %3$s%1$s\u001b[0m \n\tФамилия нового доктора: %3$s%2$s\u001b[0m\n",date, surname,"\u001b[38;5;34m");

                    //Для выхода обратно в меню
                    if (Utils.showAppointments(appointments) == 0) {
                        break;
                    }
                }
                case 2 -> {
                    var appointments = handler.getAppointments();

                    String passport = appointments.get(Utils.getRandom(0,appointments.size())).passport();

                    int amount = appointments.stream().filter(a -> a.passport().equals(passport)).toList().size();

                    System.out.printf("\n\tУдалили приемы для пациентов с паспортами: %3$s%1$s\u001b[0m \n\tКоличество удаляемых записей: %3$s%2$s\u001b[0m\n",passport, amount,"\u001b[38;5;34m");

                    //Для выхода обратно в меню
                    if (Utils.showAppointments(handler.deleteAppointment(passport)) == 0) {
                        break;
                    }
                }

                default -> {
                    return;
                }
            }
        }//while
    }



}
