package controllers;

import models.DBHandlerTask1;
import utils.Utils;

import javax.swing.*;


public class Task2Controller {

    //Создается объект для работы с БД
    DBHandlerTask1 handler = DBHandlerTask1.getInstance();

    public Task2Controller() throws Exception {
    }

    //Запуск меню контроллера
    public void run() throws Exception {

        //Задание значений для окна
        String title = "База данных: вступительные экзамены";
        String message = "<html><h1>Задача 2</h1>";
        Object[] buttons = new Object[]{
                "Запросы",
                "Таблицы",
                "CRUD-операци",
                "Выход"
        };

        //Вызов методов на контроллерах
        while (true) {
            switch (Utils.showWindowButtons(message,title,buttons,"Выход",JOptionPane.DEFAULT_OPTION)) {
                case 0 -> queries();
                case 1 -> tables();
                case 2 -> crud();
                default -> {
                    return;
                }
            }
        }
    }

    //Запросы. Меню
    public void queries() throws Exception{
        //Кнопки меню
        var buttons = new Object[]{"Запрос 1","Запрос 2","Запрос 3","Запрос 4","Запрос 5","Запрос 6","Запрос 7","Выход"};

        //Меню
        while (true) {

            //Выбранный пункт
            var point = Utils.showWindowButtons("Выберете запрос","",buttons,"Выход", JOptionPane.DEFAULT_OPTION);

            //Вывод зазпросов
            switch (point) {
                //Зпапрос 1
                case 0 -> {
                    //Запрос
                    if (Utils.showWindowButtons("Запрос 1 в разработке!", "Запрос 1", new Object[]{"Назад"}, "", JOptionPane.DEFAULT_OPTION) == 0) {
                        break;
                    }
                }

                case 1 -> {

                    //Запрос 2
                    if (Utils.showWindowButtons("Запрос 2 в разработке!", "Запрос 2", new Object[]{"Назад"}, "", JOptionPane.DEFAULT_OPTION) == 0) {
                        break;
                    }
                }

                //Запрос 3
                case 2 -> {

                    //Запрос 3
                    if (Utils.showWindowButtons("Запрос 3 в разработке!", "Запрос 3", new Object[]{"Назад"}, "", JOptionPane.DEFAULT_OPTION) == 0) {
                        break;
                    }
                }

                //Запрос 4
                case 3 -> {

                    //Запрос
                    if (Utils.showWindowButtons("Запрос 4 в разработке!", "Запрос 4", new Object[]{"Назад"}, "", JOptionPane.DEFAULT_OPTION) == 0) {
                        break;
                    }
                }

                //Запрос 5
                case 4 -> {

                    //Запрос
                    if (Utils.showWindowButtons("Запрос 5 в разработке!", "Запрос 5", new Object[]{"Назад"}, "", JOptionPane.DEFAULT_OPTION) == 0) {
                        break;
                    }
                }

                //Запрос 6
                case 5 -> {
                    //Запрос
                    if (Utils.showWindowButtons("Запрос 6 в разработке!", "Запрос 6", new Object[]{"Назад"}, "", JOptionPane.DEFAULT_OPTION) == 0) {
                        break;
                    }
                }

                //Запрос 7
                case 6 -> {
                    //Запрос
                    if (Utils.showWindowButtons("Запрос 7 в разработке!", "Запрос 7", new Object[]{"Назад"}, "", JOptionPane.DEFAULT_OPTION) == 0) {
                        break;
                    }
                }
                default -> {
                    return;
                }
            }
        }//while

    }//run

    //Вывод таблиц
    public void tables() throws Exception{

        var buttons = new Object[]{"Абитуриенты","Экзамены","Экзаменаторы","Предметы","Выход"};

        //Меню
        while (true) {

            //Выбранный пункт
            var point = Utils.showWindowButtons("Выберете таблицу","",buttons,"Выход", JOptionPane.DEFAULT_OPTION);


            switch (point) {

                case 0 -> {
                    //Запрос к таблице
                    if (Utils.showWindowButtons("Вывод таблицы абитуриентов в разработке!", "Таблица абитуриентов", new Object[]{"Назад"}, "", JOptionPane.DEFAULT_OPTION) == 0) {
                        break;
                    }
                }

                case 1 -> {
                    //Запрос к таблице
                    if (Utils.showWindowButtons("Вывод таблицы экзаменов в разработке!", "Таблица экзаменов", new Object[]{"Назад"}, "", JOptionPane.DEFAULT_OPTION) == 0) {
                        break;
                    }
                }

                case 2 -> {
                    //Запрос к таблице
                    if (Utils.showWindowButtons("Вывод таблицы экзаменаторов в разработке!", "Таблица экзаменаторов", new Object[]{"Назад"}, "", JOptionPane.DEFAULT_OPTION) == 0) {
                        break;
                    }
                }

                case 3 -> {
                    //Запрос к таблице
                    if (Utils.showWindowButtons("Вывод таблицы предметов в разработке!", "Таблица предметов", new Object[]{"Назад"}, "", JOptionPane.DEFAULT_OPTION) == 0) {
                        break;
                    }
                }
                default -> {
                    return;
                }
            }
        }//while
    }

    //Вывод CRUD-операций
    public void crud() throws Exception{

        var buttons = new Object[]{"Добавление","Редактирование","Удаление","Выход"};

        //Меню
        while (true) {

            //Выбранный пункт
            var point = Utils.showWindowButtons("Выберете операцию","CRUD",buttons,"Выход", JOptionPane.DEFAULT_OPTION);


            switch (point) {

                case 0 -> {

                    //Добавление
                    if (Utils.showWindowButtons("Добавление в таблицу в разработке!", "Добавление экзамена", new Object[]{"Назад"}, "", JOptionPane.DEFAULT_OPTION) == 0) {
                        break;
                    }
                }
                case 1 -> {

                    //Редактирование
                    if (Utils.showWindowButtons("Редактирование в разработке!", "Редактирование экзамена", new Object[]{"Назад"}, "", JOptionPane.DEFAULT_OPTION) == 0) {
                        break;
                    }
                }
                case 2 -> {

                    //Удаление
                    if (Utils.showWindowButtons("Удаление записи в разработке!", "Удаление экзамена", new Object[]{"Назад"}, "", JOptionPane.DEFAULT_OPTION) == 0) {
                        break;
                    }
                }

                default -> {
                    return;
                }
            }
        }//while
    }



}
