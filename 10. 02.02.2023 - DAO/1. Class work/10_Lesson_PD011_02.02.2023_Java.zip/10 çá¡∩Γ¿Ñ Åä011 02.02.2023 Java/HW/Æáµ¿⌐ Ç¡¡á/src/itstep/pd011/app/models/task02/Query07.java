package itstep.pd011.app.models.task02;

import java.sql.Date;

public record Query07(
        Date date,
        double avg
) {
    public Query07(Date date, double avg) {
        this.date = date;
        this.avg = avg;
    }

    @Override
    public String toString() {
        return "<tr>" +
                "<td>"+String.format("%1$td.%1$tm.%1$tY",date)+"</td>"+
                "<td>"+String.format("%.2f",avg)+"</td>"+
                "</tr>";
    }
}
