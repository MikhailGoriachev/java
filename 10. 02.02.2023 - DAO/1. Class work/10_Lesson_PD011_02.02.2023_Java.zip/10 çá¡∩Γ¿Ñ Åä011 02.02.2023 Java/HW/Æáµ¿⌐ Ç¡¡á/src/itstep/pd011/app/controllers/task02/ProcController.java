package itstep.pd011.app.controllers.task02;

import itstep.pd011.app.Main;
import itstep.pd011.app.handlers.ResultsOfExamsHandler;
import itstep.pd011.app.utils.Utils;

import javax.swing.*;
import java.sql.Date;

public class ProcController {

    public static void run(){
        try {

            // Создаем экземпляр по работе с БД, в этом экземпляре реализуем все запросы к БД
            ResultsOfExamsHandler dbHandler = ResultsOfExamsHandler.getInstance();

            while (true) {

                switch (showMenu()) {
                    case 0 -> {
                        String param01 = "Гущина";
                        String param02 = "0483274910";
                        Utils.showApplicants(dbHandler.doProc01(param01,param02),"Выбирает информацию об абитуриентах с фамилией "+param01+", серией/номером паспорта "+param02);
                    }

                    case 1 -> {
                        String param = "Еремина";
                        Utils.showExams(dbHandler.doProc02Or03(param,"{call proc02(?)}"), "Выбирает информацию об экзаменах, которые были приняты экзаменатором с фамилией "+ param);

                    }
                    case 2 -> {

                        String param = "0483274910";
                        Utils.showExams(dbHandler.doProc02Or03(param,"{call proc03(?)}"),"Выбирает информацию об экзаменах, сданных абитуриентом с номером/серией паспорта " + param);
                    }

                    case 3 -> Utils.showQuery05ResultOfExams(dbHandler.doProc05(),"Вычисляет для каждого экзамена размер налога и зарплаты экзаменатора");
                    case 4 -> Utils.showQuery06ResultOfExams(dbHandler.doProc06(),"Для каждого года рождения определяет количество абитуриентов");
                    case 5 -> Utils.showQuery07ResultOfExams(dbHandler.doProc07(),"Выполняет группировку по полю Дата сдачи экзамена в таблице ЭКЗАМЕНЫ. Для каждой даты определяет среднее значения по полю Оценка ");
                  //  case 6 -> Utils.showQuery07(dbHandler.doQuery07(),"Для каждой специальности вычисляет средний Процент отчисления на зарплату от стоимости приема");

                    // выход
                    default -> {
                        return;
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        } // try-catch
    }

    // вывод окна меню
    public static int showMenu() {
        return JOptionPane.showOptionDialog(
                null,
                "<html><h1>Меню</h1>",
                "Выбор хранимой процедуры",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(Main.class.getResource("../../../images/leopard.png")),
                new Object[] {"Процедура 1", "Процедура 2","Процедура 3", "Процедура 5", "Процедура 6", "Процедура 7",
                        "Процедура 8", "Процедура 9", "Процедура 10", "Выход"},
                "Выход"
        );
    }
}
