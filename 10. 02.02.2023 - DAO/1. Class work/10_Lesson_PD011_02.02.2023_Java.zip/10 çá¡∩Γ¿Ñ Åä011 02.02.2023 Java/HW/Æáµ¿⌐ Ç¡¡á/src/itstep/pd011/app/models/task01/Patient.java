package itstep.pd011.app.models.task01;

import java.sql.Date;

public record Patient(
        int id,
        String surname,
        String name,
        String patronymic,
        Date date_of_birth,
        String address
) {

    public Patient(int id, String surname, String name, String patronymic, Date date_of_birth, String address) {
        this.id = id;
        this.surname = surname;
        this.name = name;
        this.patronymic = patronymic;
        this.date_of_birth = date_of_birth;
        this.address = address;
    }

    @Override
    public String toString() {
        return "<tr>" +
                "<td>"+id+"</td>"+
                "<td>"+surname+"</td>"+
                "<td>"+name+"</td>"+
                "<td>"+patronymic+"</td>"+
                "<td>"+String.format("%1$td.%1$tm.%1$tY",date_of_birth)+"</td>"+
                "<td>"+address+"</td>"+
                "</tr>";
    }
}
