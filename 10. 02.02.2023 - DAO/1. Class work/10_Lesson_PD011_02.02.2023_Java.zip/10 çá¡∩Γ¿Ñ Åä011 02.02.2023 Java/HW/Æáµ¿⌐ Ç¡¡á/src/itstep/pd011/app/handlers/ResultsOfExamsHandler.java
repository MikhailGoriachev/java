package itstep.pd011.app.handlers;

import itstep.pd011.app.models.task01.Doctor;
import itstep.pd011.app.models.task02.*;
import itstep.pd011.app.utils.Utils;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.*;
import java.util.*;
import java.util.Properties;

public class ResultsOfExamsHandler {

    // Используем шаблон одиночка, чтобы не плодить множество
    // экземпляров класса DbHandler
    private static ResultsOfExamsHandler instance = null;

    // потокобезопасное создание подключения
    public static synchronized ResultsOfExamsHandler getInstance() throws Exception {
        if (instance == null)
            instance = new ResultsOfExamsHandler();
        return instance;
    }

    // Объект, в котором будет храниться соединение с БД
    private Connection connection;

    // приватный конструктор - требование синглтона
    private ResultsOfExamsHandler() throws Exception {
        // Регистрируем драйвер, с которым будем работать
        // в нашем случае MySQL
        Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();

        // Выполняем подключение к базе данных
        // this.connection = DriverManager.getConnection(URL, USER_NAME, PASSWORD);
        this.connection = Utils.loadConnection("app_data/results_of_exams_db.properties");
    } // DbHandler


    //Выбирает информацию об абитуриентах с заданной фамилией, серией/номером паспорта
    public List<Applicant> doProc01(String surname, String passport){

        List<Applicant> applicants = new ArrayList<>();

        // вызов хранимой процедуры
        String sql = "{call proc01(?,?)}";
        try (CallableStatement callableStatement = connection.prepareCall(sql)) {

            // задать входного параметра
            callableStatement.setString(1, surname);
            callableStatement.setString(2, passport);

            // выполнить процедуру
            callableStatement.execute();

            // прочитали значение выходного параметра
            ResultSet resultSet = callableStatement.getResultSet();

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                applicants.add(new Applicant(
                        resultSet.getInt("Id"), resultSet.getString("surname"),
                        resultSet.getString("name"), resultSet.getString("patronymic"),
                        resultSet.getString("address"), resultSet.getInt("year"),
                        resultSet.getString("passport")
                ));
            } // while
        } catch (Exception ex) {
            ex.printStackTrace();
        } // try-catch

        return applicants;
    }

    //Выбирает информацию об экзаменах, которые были приняты экзаменатором с заданной фамилией
    //Выбирает информацию об экзаменах, сданных абитуриентом с заданным номером/серией паспорта
    public List<Exam> doProc02Or03(String param, String proc){

        List<Exam> exams = new ArrayList<>();

        // вызов хранимой процедуры
        String sql = proc; // "{call proc02(?)}";
        try (CallableStatement callableStatement = connection.prepareCall(sql)) {

            // задать входного параметра
            callableStatement.setString(1, param);

            // выполнить процедуру
            callableStatement.execute();

            // прочитали значение выходного параметра
            ResultSet resultSet = callableStatement.getResultSet();

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                exams.add(new Exam(
                        resultSet.getInt("Id"), resultSet.getDate("date"),
                        resultSet.getString("title"), resultSet.getString("applicants_surname"),
                        resultSet.getString("applicants_name"), resultSet.getString("applicants_patronymic"),
                        resultSet.getString("examiners_surname"), resultSet.getString("examiners_name"),
                        resultSet.getString("examiners_patronymic"), resultSet.getInt("price"),
                        resultSet.getInt("result")
                ));
            } // while
        } catch (Exception ex) {
            ex.printStackTrace();
        } // try-catch

        return exams;
    }

    //Выполняет группировку по полю Год рождения в таблице АБИТУРИЕНТЫ. Для каждой группы определяет количество абитуриентов (итоги по полю Код абитуриента)
    public List<Query05> doProc05(){

        List<Query05> query05List = new ArrayList<>();

        // вызов хранимой процедуры
        String sql = "{call proc05()}";
        try (Statement statement = connection.createStatement()) {

            // выполнить процедуру
            statement.execute(sql);

            ResultSet resultSet = statement.getResultSet();

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                query05List.add(new Query05(
                        resultSet.getInt("Id"), resultSet.getInt("tax"),
                        resultSet.getInt("salary")
                ));
            } // while
        } catch (Exception ex) {
            ex.printStackTrace();
        } // try-catch

        return  query05List;
    }

    //Выполняет группировку по полю Год рождения в таблице АБИТУРИЕНТЫ. Для каждой группы определяет количество абитуриентов (итоги по полю Код абитуриента)
    public List<Query06> doProc06(){

        List<Query06> query06List = new ArrayList<>();

        // вызов хранимой процедуры
        String sql = "{call proc06()}";
        try (Statement statement = connection.createStatement()) {

            // выполнить процедуру
            statement.execute(sql);

            ResultSet resultSet = statement.getResultSet();

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                query06List.add(new Query06(
                        resultSet.getInt("year"), resultSet.getInt("count")
                ));
            } // while
        } catch (Exception ex) {
            ex.printStackTrace();
        } // try-catch

        return  query06List;
    }

    //Выполняет группировку по полю Дата сдачи экзамена в таблице ЭКЗАМЕНЫ. Для каждой даты определяет среднее значения по полю Оценка
    public List<Query07> doProc07(){

        List<Query07> query07List = new ArrayList<>();

        // вызов хранимой процедуры
        String sql = "{call proc07()}";
        try (Statement statement = connection.createStatement()) {

            // выполнить процедуру
            statement.execute(sql);

            ResultSet resultSet = statement.getResultSet();

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                query07List.add(new Query07(
                        resultSet.getDate("date"), resultSet.getDouble("avg_result")
                ));
            } // while
        } catch (Exception ex) {
            ex.printStackTrace();
        } // try-catch

        return  query07List;
    }
}
