package itstep.pd011.app.models.task02;

public record Applicant(
        int id,
        String surname,
        String name,
        String patronymic,
        String address,
        int year,
        String passport
) {
    public Applicant(int id, String surname, String name, String patronymic, String address, int year, String passport) {
        this.id = id;
        this.surname = surname;
        this.name = name;
        this.patronymic = patronymic;
        this.address = address;
        this.year = year;
        this.passport = passport;
    }

    @Override
    public String toString() {
        return "<tr>" +
                "<td>"+id+"</td>"+
                "<td>"+surname+"</td>"+
                "<td>"+name+"</td>"+
                "<td>"+patronymic+"</td>"+
                "<td>"+address+"</td>"+
                "<td>"+year+"</td>"+
                "<td>"+passport+"</td>"+
                "</tr>";
    }
}
