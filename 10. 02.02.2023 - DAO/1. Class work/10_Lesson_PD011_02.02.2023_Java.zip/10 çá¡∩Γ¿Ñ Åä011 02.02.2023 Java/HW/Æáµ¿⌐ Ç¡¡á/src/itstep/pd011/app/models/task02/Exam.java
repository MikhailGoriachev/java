package itstep.pd011.app.models.task02;

import java.sql.Date;

public record Exam(
        int id,
        Date date,
        String title,
        String applicants_surname,
        String applicants_name,
        String applicants_patronymic,
        String examiners_surname,
        String examiners_name,
        String examiners_patronymic,
        int price,
        int result

) {
    public Exam(int id, Date date, String title, String applicants_surname, String applicants_name, String applicants_patronymic, String examiners_surname, String examiners_name, String examiners_patronymic, int price, int result) {
        this.id = id;
        this.date = date;
        this.title = title;
        this.applicants_surname = applicants_surname;
        this.applicants_name = applicants_name;
        this.applicants_patronymic = applicants_patronymic;
        this.examiners_surname = examiners_surname;
        this.examiners_name = examiners_name;
        this.examiners_patronymic = examiners_patronymic;
        this.price = price;
        this.result = result;
    }

    @Override
    public String toString() {
        return "<tr>" +
                "<td>"+id+"</td>"+
                "<td>"+String.format("%1$td.%1$tm.%1$tY",date)+"</td>"+
                "<td>"+title+"</td>"+
                "<td>"+applicants_surname+"</td>"+
                "<td>"+applicants_name+"</td>"+
                "<td>"+applicants_patronymic+"</td>"+
                "<td>"+examiners_surname+"</td>"+
                "<td>"+examiners_name+"</td>"+
                "<td>"+examiners_patronymic+"</td>"+
                "<td>"+price+"</td>"+
                "<td>"+result+"</td>"+
                "</tr>";
    }
}
