package itstep.pd011.app.models.task01;

import java.sql.Date;

public record Query06(
        Date date,
        int max
) {

    public Query06(Date date, int max) {
        this.date = date;
        this.max = max;
    }

    @Override
    public String toString() {
        return "<tr>" +
                "<td>"+String.format("%1$td.%1$tm.%1$tY",date)+"</td>"+
                "<td>"+max+"</td>"+
                "</tr>";
    }
}
