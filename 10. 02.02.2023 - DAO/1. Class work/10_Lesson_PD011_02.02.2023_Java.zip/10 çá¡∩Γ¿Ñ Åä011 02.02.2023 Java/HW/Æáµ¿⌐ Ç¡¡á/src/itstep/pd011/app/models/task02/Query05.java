package itstep.pd011.app.models.task02;

public record Query05(
        int id,
        int tax,
        int salary
) {

    public Query05(int id, int tax, int salary) {
        this.id = id;
        this.tax = tax;
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "<tr>" +
                "<td>"+id+"</td>"+
                "<td>"+tax+"</td>"+
                "<td>"+salary+"</td>"+
                "</tr>";
    }
}
