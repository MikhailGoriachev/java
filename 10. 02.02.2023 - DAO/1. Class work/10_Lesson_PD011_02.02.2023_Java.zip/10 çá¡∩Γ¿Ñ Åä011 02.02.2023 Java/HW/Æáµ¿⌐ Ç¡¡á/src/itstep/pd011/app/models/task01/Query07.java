package itstep.pd011.app.models.task01;

public record Query07(
        String name,
        double avg
) {

    public Query07(String name, double avg) {
        this.name = name;
        this.avg = avg;
    }

    @Override
    public String toString() {
        return "<tr>" +
                "<td>"+name+"</td>"+
                "<td>"+String.format("%.2f",avg)+"</td>"+
                "</tr>";
    }
}
