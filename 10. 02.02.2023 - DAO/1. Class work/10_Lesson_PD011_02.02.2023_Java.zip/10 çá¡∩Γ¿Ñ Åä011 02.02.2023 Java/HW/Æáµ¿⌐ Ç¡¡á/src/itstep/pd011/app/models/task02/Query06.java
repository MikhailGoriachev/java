package itstep.pd011.app.models.task02;

public record Query06(
        int year,
        int count
) {

    public Query06(int year, int count) {
        this.year = year;
        this.count = count;
    }

    @Override
    public String toString() {
        return "<tr>" +
                "<td>"+year+"</td>"+
                "<td>"+count+"</td>"+
                "</tr>";
    }
}
