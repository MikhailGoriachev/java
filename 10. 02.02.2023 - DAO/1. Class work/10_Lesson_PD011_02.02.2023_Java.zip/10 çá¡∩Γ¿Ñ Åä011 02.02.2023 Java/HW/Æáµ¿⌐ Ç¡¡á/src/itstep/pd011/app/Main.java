package itstep.pd011.app;

import javax.swing.*;

import itstep.pd011.app.controllers.task01.CRUDController;
import itstep.pd011.app.controllers.task01.QueryController;
import itstep.pd011.app.controllers.task01.TableController;
import itstep.pd011.app.controllers.task02.ProcController;

public class Main {
    public static void main(String[] args) {

        while (true) {

            switch (showMenu()) {

                case 0 -> TableController.run();
                case 1 -> QueryController.run();
                case 2 -> CRUDController.run();
                case 3 -> ProcController.run();

                // выход
                default -> {
                    return;
                }
            }
        }

    }

    // вывод окна меню
    public static int showMenu() {
        return JOptionPane.showOptionDialog(
                null,
                "<html><h1>Меню</h1>",
                "Домашнее задание на 30.01.2023",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(Main.class.getResource("../../../images/fish.png")),
                new Object[] {"Таблицы", "Запросы","(C)RUD операции", "Хранимые процедуры", "Выход"},
                "Выход"
        );
    }

}