package itstep.pd011.app.controllers.task01;

import itstep.pd011.app.handlers.AppointmentHandler;
import itstep.pd011.app.utils.Utils;

import java.sql.Date;

public class CRUDController {

    public static void run(){
        try {

            // Создаем экземпляр по работе с БД, в этом экземпляре реализуем все запросы к БД
            AppointmentHandler dbHandler =AppointmentHandler.getInstance();

            dbHandler.addReceipt(); //добавление
            Utils.showReceipts(dbHandler.getAllReceipts(),"Добавили заипись о приеме");

            Date param = new Date(2023 - 1900, 1, 2);
            String str = String.format("%1$td.%1$tm.%1$tY",param);

            int count = dbHandler.updateReceipt(param);
            Utils.showReceipts(dbHandler.getAllReceipts(),"Изменили стоимость приема на 5000 у всех записей, где указана дата " +str+". Количество измененных записей: "+count);

            count = dbHandler.deleteReceipt(param);
            Utils.showReceipts(dbHandler.getAllReceipts(),"Удалили всех записей, где указана дата " +str+". Количество удаленных записей: "+count);

        } catch (Exception e) {
            e.printStackTrace();
        } // try-catch
    }
}
