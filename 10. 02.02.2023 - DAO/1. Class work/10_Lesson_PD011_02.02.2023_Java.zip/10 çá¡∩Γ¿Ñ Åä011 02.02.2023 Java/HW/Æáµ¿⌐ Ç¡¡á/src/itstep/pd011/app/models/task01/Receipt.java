package itstep.pd011.app.models.task01;

import java.sql.Date;

public record Receipt(
        int id,
        Date date,
        int price,
        String doctor,
        String specialtie,
        String patient
) {

    public Receipt(int id, Date date, int price, String doctor, String specialtie, String patient) {
        this.id = id;
        this.date = date;
        this.price = price;
        this.doctor = doctor;
        this.specialtie = specialtie;
        this.patient = patient;
    }

    @Override
    public String toString() {
        return "<tr>" +
                "<td>"+id+"</td>"+
                "<td>"+String.format("%1$td.%1$tm.%1$tY",date)+"</td>"+
                "<td>"+price+"</td>"+
                "<td>"+doctor+"</td>"+
                "<td>"+specialtie+"</td>"+
                "<td>"+patient+"</td>"+
                "</tr>";
    }
}
