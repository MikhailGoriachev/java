package itstep.pd011.app.handlers;

import java.sql.*;
import java.sql.Date;
import java.util.*;

import itstep.pd011.app.models.task01.*;
import itstep.pd011.app.utils.Utils;

public class AppointmentHandler {

    // Используем шаблон одиночка, чтобы не плодить множество
    // экземпляров класса DbHandler
    private static AppointmentHandler instance = null;

    // потокобезопасное создание подключения
    public static synchronized AppointmentHandler getInstance() throws Exception {
        if (instance == null)
            instance = new AppointmentHandler();
        return instance;
    }

    // Объект, в котором будет храниться соединение с БД
    private Connection connection;

    // приватный конструктор - требование синглтона
    private AppointmentHandler() throws Exception {
        // Регистрируем драйвер, с которым будем работать
        // в нашем случае MySQL
        Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();

        // Выполняем подключение к базе данных
        // this.connection = DriverManager.getConnection(URL, USER_NAME, PASSWORD);
        this.connection = Utils.loadConnection("app_data/db_appointment.properties");
    } // DbHandler

    // пример операции выборки данных из таблицы - получить и вывести всех врачей
    public List<Doctor> getAllDoctors() throws Exception {
        List<Doctor> doctors = new ArrayList<>();

        // Выполняем подключение к базе данных, создаем оператор для выборки данных
        try (Statement statement = connection.createStatement()) {

            // выполнить выборку данных
            ResultSet resultSet = statement.executeQuery("select * from view_doctors");

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                doctors.add(new Doctor(
                        resultSet.getInt("Id"), resultSet.getString("surname"),
                        resultSet.getString("name"), resultSet.getString("patronymic"),
                        resultSet.getString("Specialtie"), resultSet.getInt("tax")
                ));
            } // while
        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return doctors;
    }

    // пример операции выборки данных из таблицы - получить и вывести всех пациентов
    public List<Patient> getAllPatients() {
        List<Patient> patients = new ArrayList<>();

        // Выполняем подключение к базе данных, создаем оператор для выборки данных
        try (Statement statement = connection.createStatement()) {

            // выполнить выборку данных
            ResultSet resultSet = statement.executeQuery("select * from patients");

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                patients.add(new Patient(
                        resultSet.getInt("Id"), resultSet.getString("surname"),
                        resultSet.getString("name"), resultSet.getString("patronymic"),
                        resultSet.getDate("Date_of_Birth"), resultSet.getString("address")
                ));
            } // while
        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return patients;
    }

    // пример операции выборки данных из таблицы - получить и вывести всех приемы
    public List<Receipt> getAllReceipts() {
        List<Receipt> receipts = new ArrayList<>();

        // Выполняем подключение к базе данных, создаем оператор для выборки данных
        try (Statement statement = connection.createStatement()) {

            // выполнить выборку данных
            ResultSet resultSet = statement.executeQuery("select * from view_receipts");

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                receipts.add(new Receipt(
                        resultSet.getInt("Id"), resultSet.getDate("date"),
                        resultSet.getInt("price"), resultSet.getString("Doctor"),
                        resultSet.getString("Specialtie"), resultSet.getString("Patient")
                ));
            } // while
        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return receipts;
    }

    //Выбирает информацию о пациентах с фамилиями, начинающимися на заданную последовательность символов
    public List<Patient> doQuery01(String param) {

        List<Patient> patients = new ArrayList<>();

        String sql = "select * from patients where patients.surname like ?";

        // выполнение запроса - получение данных из таблицы
        try (PreparedStatement ps = this.connection.prepareStatement(sql)) {
            ps.setString(1, param + "%");
            ResultSet resultSet = ps.executeQuery();

            while (resultSet.next()) {
                patients.add(new Patient(
                        resultSet.getInt("id"), resultSet.getString("surname"),
                        resultSet.getString("name"), resultSet.getString("patronymic"),
                        resultSet.getDate("date_of_birth"), resultSet.getString("address")
                ));
            } // while

        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return patients;
    }

    //Выбирает информацию о врачах, для которых значение в поле Процент отчисления на зарплату, больше заданного
    public List<Doctor> doQuery02(int param) {

        List<Doctor> doctors= new ArrayList<>();

        String sql = "select * from view_doctors where view_doctors.tax > ? ";

        // выполнение запроса - получение данных из таблицы
        try (PreparedStatement ps = this.connection.prepareStatement(sql)) {
            ps.setInt(1, param);
            ResultSet resultSet = ps.executeQuery();

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                doctors.add(new Doctor(
                        resultSet.getInt("id"), resultSet.getString("surname"),
                        resultSet.getString("name"), resultSet.getString("patronymic"),
                        resultSet.getString("specialtie"), resultSet.getInt("tax")
                ));
            } // while

        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return doctors;
    }

    //Выбирает информацию о приемах за некоторый период
    public List<Receipt> doQuery03(Date param01, Date param02) {

        List<Receipt> receipts= new ArrayList<>();

        String sql = "select * from view_receipts where date between ? and ?";

        // выполнение запроса - получение данных из таблицы
        try (PreparedStatement ps = this.connection.prepareStatement(sql)) {
            ps.setDate(1, param01);
            ps.setDate(2, param02);
            ResultSet resultSet = ps.executeQuery();

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                receipts.add(new Receipt(
                        resultSet.getInt("id"), resultSet.getDate("date"),
                        resultSet.getInt("price"), resultSet.getString("doctor"),
                        resultSet.getString("specialtie"), resultSet.getString("patient")
                ));
            } // while

        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return receipts;
    }

    //Выбирает из таблицы информацию о врачах с заданной специальностью
    public List<Doctor> doQuery04(String param) {

        List<Doctor> doctors= new ArrayList<>();

        String sql = "select * from view_doctors where view_doctors.specialtie like ? ";

        // выполнение запроса - получение данных из таблицы
        try (PreparedStatement ps = this.connection.prepareStatement(sql)) {
            ps.setString(1, param);
            ResultSet resultSet = ps.executeQuery();

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                doctors.add(new Doctor(
                        resultSet.getInt("id"), resultSet.getString("surname"),
                        resultSet.getString("name"), resultSet.getString("patronymic"),
                        resultSet.getString("specialtie"), resultSet.getInt("tax")
                ));
            } // while

        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return doctors;
    }

    //Вычисляет размер заработной платы врача за каждый прием. Включает поля
    // Фамилия врача, Имя врача, Отчество врача, Специальность врача, Стоимость приема, Зарплата. Сортировка по полю
    // Специальность врача
    public List<Query05> doQuery05() {

        List<Query05> query05List= new ArrayList<>();

        String sql = "select view_receipts.doctor, " +
                            "view_receipts.specialtie, " +
                            "view_receipts.price,"+
                            "view_receipts.price *(view_receipts.tax/100) - (view_receipts.tax/100)*view_receipts.price *13/100 as Salary " +
                    "from view_receipts " +
                    "order by view_receipts.specialtie";

        // выполнение запроса - получение данных из таблицы
        try (Statement statement = this.connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery(sql);

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                query05List.add(new Query05(
                        resultSet.getString("doctor"), resultSet.getString("specialtie"),
                        resultSet.getInt("price"), resultSet.getDouble("Salary")
                ));
            } // while

        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return query05List;
    }

    //Выполняет группировку по полю Дата приема. Для каждой даты вычисляет максимальную стоимость приема
    public List<Query06> doQuery06() {

        List<Query06> query06List= new ArrayList<>();

        String sql = "select receipts.date,MAX(price) as max from receipts group by receipts.date order by receipts.date";

        // выполнение запроса - получение данных из таблицы
        try (Statement statement = this.connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery(sql);

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                query06List.add(new Query06(
                        resultSet.getDate("date"), resultSet.getInt("max")
                ));
            } // while

        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return query06List;
    }

    //Выполняет группировку по полю Специальность.
    // Для каждой специальности вычисляет средний Процент отчисления на зарплату от стоимости приема
    public List<Query07> doQuery07() {

        List<Query07> query07List= new ArrayList<>();

        String sql = "select specialties.name, AVG(tax) as avg from specialties join doctors on specialties.Id = doctors.id_specialtie group by specialties.name";

        // выполнение запроса - получение данных из таблицы
        try (Statement statement  = this.connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery(sql);

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                query07List.add(new Query07(
                        resultSet.getString("name"), resultSet.getDouble("avg")
                ));
            } // while

        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return query07List;
    }

    // добавить прием - Create (C)RUD
    public void addReceipt() {
        String sql = """
            INSERT INTO receipts (
                                     date,
                                     price,
                                     id_patient,
                                     id_doctor
                                 )
                                 VALUES (
                                     ?,
                                     ?,
                                     ?,
                                     ?
                                 );;
            """;

        try (PreparedStatement ps = this.connection.prepareStatement(sql)) {
            // нумерация параметров - с 1
            ps.setDate(1, new Date(2023 - 1900, 1, 2));
            ps.setInt(2, 2000);
            ps.setInt(3, 1);
            ps.setInt(4, 1);

            ps.executeUpdate();
            // ps.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch
    }

    // изменить запись о клиенте - Update CR(U)D
    public int updateReceipt(Date param) {

        // количество измененных элементов
        int counterUpdated = 0;

        // запрос на изменение записи в таблице
        String sql = """
                UPDATE receipts
                   SET 
                       price = ?
                 WHERE 
                       date like ?;
            """;

        // выполнение запроса на изменение
        try (PreparedStatement ps = this.connection.prepareStatement(sql)) {
            // установить параметры запроса
            ps.setInt(1, 5000);
            ps.setDate(2, param);

            // собственно выполнить запрос
            counterUpdated = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return counterUpdated;
    }

    // удалить запись о клиенте - Delete CRU(D)
    public int deleteReceipt(Date param) {
        // количество удаленных записей
        int counterDeleted = 0;

        // запрос на удаление
        String sql = """
            delete from
                receipts
            where
                date = ?;
        """;

        // выполнение запроса
        try (PreparedStatement ps = this.connection.prepareStatement(sql)) {
            ps.setDate(1, param);
            counterDeleted = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return counterDeleted;
    }

}
