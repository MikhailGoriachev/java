package itstep.pd011.app.models.task01;

// объектное представление таблицы клиентов БД insurance
// таблица Doctors

public record Doctor(
        int id,
        String surname,
        String name,
        String patronymic,
        String specialtie,
        int tax
) {

    public Doctor(int id, String surname, String name, String patronymic, String specialtie, int tax) {
        this.id = id;
        this.surname = surname;
        this.name = name;
        this.patronymic = patronymic;
        this.specialtie = specialtie;
        this.tax = tax;
    }

    @Override
    public String toString() {
        return "<tr>" +
                "<td>"+id+"</td>"+
                "<td>"+surname+"</td>"+
                "<td>"+name+"</td>"+
                "<td>"+patronymic+"</td>"+
                "<td>"+specialtie+"</td>"+
                "<td>"+tax+"</td>"+
                "</tr>";
    }
}
