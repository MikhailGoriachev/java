package itstep.pd011.app.controllers.task01;

import itstep.pd011.app.handlers.AppointmentHandler;
import itstep.pd011.app.utils.Utils;
import itstep.pd011.app.Main;
import javax.swing.*;
import java.sql.Date;

public class QueryController {

    public static void run(){
        try {

            // Создаем экземпляр по работе с БД, в этом экземпляре реализуем все запросы к БД
            AppointmentHandler dbHandler = AppointmentHandler.getInstance();

            while (true) {

                switch (showMenu()) {
                    case 0 -> {
                                String param = "Ник";
                                Utils.showPatients(dbHandler.doQuery01(param),"Выбирает информацию о пациентах с фамилиями, начинающимися на последовательность символов "+param);
                    }
                    case 1 -> {
                        int param = 90;
                        Utils.showDoctors(dbHandler.doQuery02(param), "Выбирает информацию о врачах, для которых значение в поле Процент отчисления, больше "+ param);

                    }
                     case 2 -> {
                        Date param01 = new Date(2022 - 1900, 10, 25);
                        Date param02 = new Date(2022 - 1900, 11, 1);

                         String str01 = String.format("%1$td.%1$tm.%1$tY",param01);
                         String str02 = String.format("%1$td.%1$tm.%1$tY",param02);

                        Utils.showReceipts(dbHandler.doQuery03(param01,param02),"Выбирает информацию о приемах за период "+str01+" : "+ str02);
                    }

                    case 3 -> {
                        String param = "Дерматолог";
                        Utils.showDoctors(dbHandler.doQuery04(param),"Выбирает из таблицы информацию о врачах с заданной специальностью ("+param+")");
                    }

                    case 4 -> Utils.showQuery05(dbHandler.doQuery05(),"Вычисляет размер заработной платы врача за каждый прием.");
                    case 5 -> Utils.showQuery06(dbHandler.doQuery06(),"Выполняет группировку по полю Дата приема. Для каждой даты вычисляет максимальную стоимость приема");
                    case 6 -> Utils.showQuery07(dbHandler.doQuery07(),"Для каждой специальности вычисляет средний Процент отчисления на зарплату от стоимости приема");

                    // выход
                    default -> {
                        return;
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        } // try-catch
    }

    // вывод окна меню
    public static int showMenu() {
        return JOptionPane.showOptionDialog(
                null,
                "<html><h1>Меню</h1>",
                "Выбор запроса",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(Main.class.getResource("../../../images/horse.png")),
                new Object[] {"Запрос 1", "Запрос 2","Запрос 3", "Запрос 4", "Запрос 5", "Запрос 6", "Запрос 7" ,"Выход"},
                "Выход"
        );
    }
}
