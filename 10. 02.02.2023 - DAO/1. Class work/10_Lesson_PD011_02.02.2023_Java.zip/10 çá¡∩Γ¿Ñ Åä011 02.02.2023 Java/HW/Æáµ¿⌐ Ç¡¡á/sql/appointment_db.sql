CREATE DATABASE  IF NOT EXISTS `db_appointment_tatsiy_anna` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `db_appointment_tatsiy_anna`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: db_appointment_tatsiy_anna
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `doctors`
--

DROP TABLE IF EXISTS `doctors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `doctors` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `surname` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `patronymic` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `id_specialtie` int NOT NULL,
  `tax` double NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Doctors_Specialties` (`id_specialtie`),
  CONSTRAINT `FK_Doctors_Specialties` FOREIGN KEY (`id_specialtie`) REFERENCES `specialties` (`Id`),
  CONSTRAINT `Doctors_tax_check` CHECK ((`tax` between 0 and 100))
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctors`
--

LOCK TABLES `doctors` WRITE;
/*!40000 ALTER TABLE `doctors` DISABLE KEYS */;
INSERT INTO `doctors` VALUES (1,'Николаев','Мирон','Никитич',2,95),(2,'Иванова','Екатерина','Ростиславовна',8,85),(3,'Комарова','Майя','Игоревна',3,95),(4,'Алексеев','Владислав','Лукич',7,90),(5,'Михеев','Даниил','Романович',1,80),(6,'Долгова','Мария','Арсентьевна',4,90),(7,'Колпакова','Вера','Алексеевна',7,80),(8,'Субботин','Кирилл','Тимурович',3,80),(9,'Шестакова','Екатерина','Тимофеевна',9,85),(10,'Лазарева','Виктория','Никитична',7,90),(11,'Белякова','Виктория','Максимовна',9,85),(12,'Калашников','Илья','Робертович',9,90),(13,'Литвинова','Елизавета','Ивановна',5,85),(14,'Лаврентьев','Роберт','Максимович',6,80),(15,'Поляков','Георгий','Павлович',8,95),(16,'Гущина','Мария','Робертовна',9,95);
/*!40000 ALTER TABLE `doctors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patients` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `surname` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `patronymic` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `date_of_Birth` date NOT NULL,
  `address` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients`
--

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES (1,'Николаев','Мирон','Никитич','2010-03-23','Балканская, 07'),(2,'Иванова','Екатерина','Ростиславовна','1980-05-12','1905 года, 39'),(3,'Комарова','Майя','Игоревна','2013-10-03','Балканская, 94'),(4,'Алексеев','Владислав','Лукич','1975-05-07','1905 года, 08'),(5,'Михеев','Даниил','Романович','2001-09-21','Ломоносова, 31'),(6,'Трофимова','Мария','Арсентьевна','1980-09-04','Косиора, 18'),(7,'Колпакова','Вера','Алексеевна','2010-09-07','Ленина, 25'),(8,'Кузнецов','Кирилл','Тимурович','1999-06-23','Космонавтов, 20'),(9,'Шестакова','Екатерина','Тимофеевна','1900-09-09','Сталина, 08'),(10,'Лазарева','Виктория','Никитична','1987-12-17','Бухарестская, 34'),(11,'Белова','Виктория','Максимовна','2003-11-19','Будапештсткая, 79'),(12,'Калашников','Илья','Робертович','1989-03-23','Чехова, 18'),(13,'Литвинова','Елизавета','Ивановна','1973-05-28','Балканская, 44'),(14,'Ермолаев','Роберт','Максимович','2009-06-21','Будапештсткая, 36'),(15,'Гордеев','Георгий','Павлович','1983-07-26','Балканская, 04'),(16,'Ильина','Мария','Робертовна','1996-05-02','Гагарина, 13');
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receipts`
--

DROP TABLE IF EXISTS `receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `receipts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `price` int NOT NULL,
  `id_patient` int NOT NULL,
  `id_doctor` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Receipts_Patients` (`id_patient`),
  KEY `FK_Receipts_Doctors` (`id_doctor`),
  CONSTRAINT `FK_Receipts_Doctors` FOREIGN KEY (`id_doctor`) REFERENCES `doctors` (`Id`),
  CONSTRAINT `FK_Receipts_Patients` FOREIGN KEY (`id_patient`) REFERENCES `patients` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipts`
--

LOCK TABLES `receipts` WRITE;
/*!40000 ALTER TABLE `receipts` DISABLE KEYS */;
INSERT INTO `receipts` VALUES (2,'2022-12-01',5002,1,4),(3,'2022-11-27',2001,1,4),(4,'2022-11-02',2501,4,8),(5,'2022-11-05',4000,5,5),(6,'2022-11-10',4000,7,7),(7,'2022-11-11',2500,1,3),(8,'2022-11-30',2000,5,9),(9,'2022-11-30',2000,6,9),(10,'2022-11-10',2500,7,6),(11,'2022-11-14',4000,2,8),(12,'2022-11-20',2500,6,3),(13,'2022-11-21',2000,3,2),(14,'2022-11-22',2500,1,4),(15,'2022-11-28',2000,6,1),(16,'2022-11-08',3000,3,2),(17,'2022-11-11',3000,3,1),(18,'2022-11-20',3000,1,5),(20,'2022-11-25',3000,3,5),(21,'2022-11-27',4000,1,1),(22,'2022-11-27',5000,9,6),(23,'2022-11-27',5000,1,2),(24,'2022-12-01',5001,3,6),(25,'2022-12-01',5001,3,1);
/*!40000 ALTER TABLE `receipts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `specialties`
--

DROP TABLE IF EXISTS `specialties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `specialties` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `specialties`
--

LOCK TABLES `specialties` WRITE;
/*!40000 ALTER TABLE `specialties` DISABLE KEYS */;
INSERT INTO `specialties` VALUES (1,'Аллерголог'),(2,'Гастроэнтеролог'),(3,'Дерматолог'),(4,'Диетолог'),(5,'Иммунолог'),(6,'Кардиолог'),(7,'Невропатолог'),(8,'Нарколог'),(9,'Нефролог'),(10,'Нейрохирург');
/*!40000 ALTER TABLE `specialties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `view_doctors`
--

DROP TABLE IF EXISTS `view_doctors`;
/*!50001 DROP VIEW IF EXISTS `view_doctors`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_doctors` AS SELECT 
 1 AS `Id`,
 1 AS `surname`,
 1 AS `name`,
 1 AS `patronymic`,
 1 AS `Specialtie`,
 1 AS `SpecialtieId`,
 1 AS `tax`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_receipts`
--

DROP TABLE IF EXISTS `view_receipts`;
/*!50001 DROP VIEW IF EXISTS `view_receipts`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_receipts` AS SELECT 
 1 AS `Id`,
 1 AS `date`,
 1 AS `price`,
 1 AS `Doctor`,
 1 AS `Specialtie`,
 1 AS `tax`,
 1 AS `Patient`,
 1 AS `Date_of_Birth`,
 1 AS `address`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `view_doctors`
--

/*!50001 DROP VIEW IF EXISTS `view_doctors`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_doctors` AS select `doctors`.`Id` AS `Id`,`doctors`.`surname` AS `surname`,`doctors`.`name` AS `name`,`doctors`.`patronymic` AS `patronymic`,`specialties`.`name` AS `Specialtie`,`specialties`.`Id` AS `SpecialtieId`,`doctors`.`tax` AS `tax` from (`doctors` join `specialties` on((`doctors`.`id_specialtie` = `specialties`.`Id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_receipts`
--

/*!50001 DROP VIEW IF EXISTS `view_receipts`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_receipts` AS select `receipts`.`id` AS `Id`,`receipts`.`date` AS `date`,`receipts`.`price` AS `price`,concat(`doctors`.`surname`,' ',`doctors`.`name`,' ',`doctors`.`patronymic`) AS `Doctor`,`specialties`.`name` AS `Specialtie`,`doctors`.`tax` AS `tax`,concat(`patients`.`surname`,' ',`patients`.`name`,' ',`patients`.`patronymic`) AS `Patient`,`patients`.`date_of_Birth` AS `Date_of_Birth`,`patients`.`address` AS `address` from ((`receipts` join (`doctors` join `specialties` on((`doctors`.`id_specialtie` = `specialties`.`Id`))) on((`receipts`.`id_doctor` = `doctors`.`Id`))) join `patients` on((`receipts`.`id_patient` = `patients`.`Id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-01 15:24:33
