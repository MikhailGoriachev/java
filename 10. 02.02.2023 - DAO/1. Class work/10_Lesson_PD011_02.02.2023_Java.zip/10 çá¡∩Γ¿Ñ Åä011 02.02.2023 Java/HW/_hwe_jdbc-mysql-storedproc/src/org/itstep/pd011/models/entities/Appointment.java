package org.itstep.pd011.models.entities;

import java.sql.Date;

// сведения о факте врачебного приема
public record Appointment(
        int id,
        Date date,
        String patientSurname,
        String patientName,
        String patientPatronymic,
        Date dob,
        String address,
        String doctorSurname,
        String doctorName,
        String doctorPatronymic,
        String categoryName,
        double price,
        double interest

){
    public String toTableRow() {
        // получить фамилию и инициалы для пациента, доктора
        String patient = patientSurname + " " + patientName.charAt(0) + "." + patientPatronymic.charAt(0) + ".";
        String doctor = doctorSurname + " " + doctorName.charAt(0) + "." + doctorPatronymic.charAt(0) + ".";
        // форматирование даты http://proglang.su/java/date-and-time#formatirovanie-daty-s-pomoschyu-printf
        return String.format("│ %1$3d │  %2$td.%2$tm.%2$tY │ %3$-20s │    %4$td.%4$tm.%4$tY │ %5$-20s │ %6$-22s │ %7$15.2f │ %8$12.2f │",
                id, date,
                patient, dob,
                doctor, categoryName, price, interest);
    } // toTableRow

    public static final String HEADER =
        "\t┌─────┬─────────────┬──────────────────────┬───────────────┬──────────────────────┬────────────────────────┬─────────────────┬──────────────┐\n"+
        "\t│  Ид │ Дата приема │ Пациент              │ Дата рождения │ Доктор на приеме     │ Специальность          │ Стоимость, руб. │ % отчислений │\n"+
        "\t├─────┼─────────────┼──────────────────────┼───────────────┼──────────────────────┼────────────────────────┼─────────────────┼──────────────┤\n";

    public static final String FOOTER =
        "\t└─────┴─────────────┴──────────────────────┴───────────────┴──────────────────────┴────────────────────────┴─────────────────┴──────────────┘\n";
} // record Appointment
