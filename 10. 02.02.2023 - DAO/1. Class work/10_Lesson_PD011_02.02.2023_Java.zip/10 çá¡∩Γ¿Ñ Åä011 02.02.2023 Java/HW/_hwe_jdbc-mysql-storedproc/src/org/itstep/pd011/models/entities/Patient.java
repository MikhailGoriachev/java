package org.itstep.pd011.models.entities;

import java.sql.Date;

// пациенты
public record Patient (
        int id,
        String surname,
        String name,
        String patronymic,
        Date dob,
        String address
) {
    // представление объекта класса в виде стоки таблицы
    public String toTableRow() {
        // форматирование даты http://proglang.su/java/date-and-time#formatirovanie-daty-s-pomoschyu-printf
        // %td - день   %tm - месяц   %tY - год
        return String.format(
            "│ %1$3d │ %2$-20s │ %3$-16s │ %4$-22s │    %5$td.%5$tm.%5$tY │ %6$-34s │",
            // "│ %3d │ %-20s │ %-15s │ %-20s │ %-20s │ %6$-36s │",
            id, surname, name, patronymic, dob, address
        );
    } // toTableRow

    public static final String HEADER =
        "\t┌─────┬──────────────────────┬──────────────────┬────────────────────────┬───────────────┬────────────────────────────────────┐\n"+
        "\t│  Ид │ Фамилия              │ Имя              │ Отчество               │ Дата рождения │ Адрес проживания                   │\n"+
        "\t├─────┼──────────────────────┼──────────────────┼────────────────────────┼───────────────┼────────────────────────────────────┤\n";

    public static final String FOOTER =
        "\t└─────┴──────────────────────┴──────────────────┴────────────────────────┴───────────────┴────────────────────────────────────┘\n";
} // record Patient
