package org.itstep.pd011;

// выполнение запросов к БД MySQL, вызов хранимых процедур

import org.itstep.pd011.controllers.Task1Controller;

import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {

        try {
            Task1Controller task1Controller = new Task1Controller();

            task1Controller.showCategories();
            task1Controller.showPersons();
            task1Controller.showPatients();
            task1Controller.showDoctors();
            task1Controller.showAppointments();

            task1Controller.showQuery01();
            task1Controller.showQuery02();
            task1Controller.showQuery03();
            task1Controller.showQuery04();
            task1Controller.showQuery05();
            task1Controller.showQuery06();
            task1Controller.showQuery07();

        } // try

        catch (SQLException ex) {
            System.out.println("\033[31;1m" + ex.getMessage() + "\033[0m");
            ex.printStackTrace();
        } // catch

        catch (Exception ex) {
            ex.printStackTrace();
        } // catch
    } // main
} // class Main