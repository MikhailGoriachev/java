package org.itstep.pd011.models.entities;

// тип для отображения итогового запроса - средний процент
// отчислений на зарплату по специальностям
public record Query07 (
   String categoryName,    // врачебная специальность
   int quantity,           // количество врачей этой специальности в базе данных
   double avgInterest      // средний процент отчислений на ЗП
) {

    // представление объекта класса в виде строки таблицы
    public String toTableRow() {
        return String.format(
            "│ %-28s │ %20d │ %9.2f │",
            categoryName, quantity, avgInterest
        );
    } // toTableRow

    public static final String HEADER =
        "\t┌──────────────────────────────┬──────────────────────┬───────────┐\n"+
        "\t│ Врачебная специальность      │ Кол-во докторов в БД │ Средний % │\n"+
        "\t├──────────────────────────────┼──────────────────────┼───────────┤\n";

    public static final String FOOTER =
        "\t└──────────────────────────────┴──────────────────────┴───────────┘\n";
} // record Query07
