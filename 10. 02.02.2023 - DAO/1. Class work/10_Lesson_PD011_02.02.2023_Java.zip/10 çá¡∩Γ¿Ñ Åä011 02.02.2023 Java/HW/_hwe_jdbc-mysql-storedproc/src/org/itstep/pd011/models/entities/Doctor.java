package org.itstep.pd011.models.entities;


// сведения о докторе
public record Doctor(
        int id,
        String surname,
        String name,
        String patronymic,
        String categoryName,
        double interest
) {} // record Doctor
