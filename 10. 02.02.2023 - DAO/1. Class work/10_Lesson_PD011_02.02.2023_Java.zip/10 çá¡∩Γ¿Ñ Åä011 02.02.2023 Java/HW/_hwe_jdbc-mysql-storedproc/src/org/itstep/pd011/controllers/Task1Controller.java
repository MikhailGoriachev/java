package org.itstep.pd011.controllers;

import org.itstep.pd011.models.DbHandlerPaidClinic;
import org.itstep.pd011.models.entities.Appointment;
import org.itstep.pd011.models.entities.Category;
import org.itstep.pd011.models.entities.Patient;
import org.itstep.pd011.models.entities.Query07;

import java.sql.Date;
import java.sql.SQLException;

// выполнение запросов по задаче 1, вывод результатов запросов
public class Task1Controller {


    private DbHandlerPaidClinic dbHandlerPaidClinic;

    public Task1Controller() throws Exception {
        this(DbHandlerPaidClinic.getInstance());
    }

    public Task1Controller(DbHandlerPaidClinic dbHandlerPaidClinic) {
        this.dbHandlerPaidClinic = dbHandlerPaidClinic;
    }

    public DbHandlerPaidClinic getDbHandler() { return dbHandlerPaidClinic; }

    public void showCategories() {
        StringBuilder body = new StringBuilder();
        dbHandlerPaidClinic.getAllCategories().forEach(t -> body.append(String.format("\t%s\n", t.toTableRow())));

        System.out.printf("\tВрачебные специальности\n%s%s%s\n", Category.HEADER, body, Category.FOOTER);
    } // showCategories

    public void showPersons() {

    } // showPersons

    public void showPatients() throws SQLException {
        var data = dbHandlerPaidClinic.getAllPatients();

        StringBuilder body = new StringBuilder();
        data.forEach(t -> body.append(String.format("\t%s\n", t.toTableRow())));
        System.out.printf("\n\tСведения о пациентах\n%s%s%s\n", Patient.HEADER, body, Patient.FOOTER);
    } // showPatients

    public void showDoctors() {

    } // showDoctors


    public void showAppointments() throws SQLException {
        var data = dbHandlerPaidClinic.getAllAppointments();

        var body = new StringBuilder();
        data.forEach(t -> body.append(String.format("\t%s\n", t.toTableRow())));

        System.out.printf("\n\tВсе факты врачебных приемов\n%s%s%s", Appointment.HEADER, body, Appointment.FOOTER);
    } // showAppointments

    // -------------------------------------------------------------------------

    public void showQuery01() {

    } // showQuery01

    public void showQuery02() {

    } // showQuery02

    // Запрос 3. Запрос с параметрами
    // Выбирает информацию о приемах за некоторый период
    public void showQuery03() throws SQLException {
        int year = 2023, month = 1;
        Date fromDate =  new Date(year-1900, month-1, 1);
        Date toDate = new Date(year-1900, month-1, 12);
        var data = dbHandlerPaidClinic.query03(fromDate, toDate);

        var body = new StringBuilder();
        data.forEach(t -> body.append(String.format("\t%s\n", t.toTableRow())));

        System.out.printf("\n\tЗапрос 3. Приемы за период [%1$td.%1$tm.%1$tY, %2$td.%2$tm.%2$tY]\n%3$s%4$s%5$s",
                fromDate, toDate, Appointment.HEADER, body, Appointment.FOOTER);
    } // showQuery03

    public void showQuery04() {

    } // showQuery04

    public void showQuery05() {

    } // showQuery05

    public void showQuery06() {

    } // showQuery06

    // Запрос 7. Итоговый запрос
    // Выполняет группировку по полю Специальность. Для каждой специальности
    // вычисляет средний Процент отчисления на зарплату от стоимости приема
    public void showQuery07() throws SQLException {
        var data = dbHandlerPaidClinic.query07();

        StringBuilder body = new StringBuilder();
        data.forEach(t -> body.append(String.format("\t%s\n", t.toTableRow())));

        System.out.printf("\n\tЗапрос 7. Средний процент отчислений на зарплату по специальностям\n%s%s%s",
                Query07.HEADER, body, Query07.FOOTER);
    } // showQuery07
} // class Task1Controller
