package org.itstep.pd011.models.entities;

// персональные данные - модель для таблицы persons
public record Person(
    int id,
    String surname,
    String name,
    String patronymic
) { } // record Person
