package org.itstep.pd011.models.entities;

import java.sql.Date;

// тип для отображения итогового запроса - максимальные стоимости приема по датам
public record Query06(
        Date date,        // дата приема
        int  quantity,    // количество фактов приема пациентов
        double maxPrice    // максимальная стоимость приема за дату
) {
} // record Query06
