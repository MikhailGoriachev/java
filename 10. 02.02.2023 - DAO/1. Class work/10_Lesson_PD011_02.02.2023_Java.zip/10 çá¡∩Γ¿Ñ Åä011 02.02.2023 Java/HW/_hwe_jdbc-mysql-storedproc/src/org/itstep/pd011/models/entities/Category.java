package org.itstep.pd011.models.entities;

// сведения о врачебных специальностях
public record Category(
    int id,
    String categoryName
) {

    public String toTableRow() {
        return String.format("│ %3d │ %-28s │", id, categoryName);
    } // toTableRow

    public static final String HEADER =
        "\t┌─────┬──────────────────────────────┐\n"+
        "\t│  Ид │ Врачебная специальность      │\n"+
        "\t├─────┼──────────────────────────────┤\n";

    public static final String FOOTER =
        "\t└─────┴──────────────────────────────┘\n";
} // class Category
