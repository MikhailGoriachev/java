package org.itstep.pd011.models;

import org.itstep.pd011.models.entities.*;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

// подключение к базе данных, выполнение запросов
public class DbHandlerPaidClinic {
    // Константа, в которой хранится адрес подключения
    private static final String CON_STR = "jdbc:sqlite:app_data/paid_clinic.db";

    // Используем шаблон одиночка, чтобы не плодить множество
    // экземпляров класса DbHandler
    private static DbHandlerPaidClinic instance = null;

    public static synchronized DbHandlerPaidClinic getInstance() throws Exception {
        if (instance == null) {
            instance = new DbHandlerPaidClinic();
        } // if
        return instance;
    } // DbHandler

    // Объект, в котором будет храниться соединение с БД
    private Connection connection;

    private DbHandlerPaidClinic() throws Exception {
        // Регистрируем драйвер, с которым будем работать
        // в нашем случае MySQL
        Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();

        // Выполняем подключение к базе данных
        this.connection = loadConnection();
    } // DbHandler

    // чтение параметров подключения из конфигурационного файла
    private static Connection loadConnection() throws Exception {
        // Properties - представление, хранение свойств в формате "ключ" - "значение"
        // свойства могут читаться из файла
        Properties props = new Properties();
        try(InputStream in = Files.newInputStream(Paths.get("assets/database.properties"))){
            props.load(in);
        }

        // сохранение свойств
        String url = props.getProperty("urlPaidClinic");
        String username = props.getProperty("username");
        String password = props.getProperty("password");

        return DriverManager.getConnection(url, username, password);
    } // loadConnection



    // выборка данных из таблицы - получить коллекцию сведений о докторах
    public List<Doctor> getAllDoctors() throws SQLException {
        // Выполняем подключение к базе данных, создаем оператор для выборки данных
        //  PreparedStatement применим для однообразия обработки, в данном случае,
        // т.К. параметров у запроса нет, можно использовать и Statement
        try (PreparedStatement ps = connection.prepareStatement("select * from view_doctors")) {
            // выполнить запрос и вернуть коллекцию
            return getDoctors(ps);
        } // try
    } // getAllDoctors


    // выборка данных из таблицы - получит коллекцию сведений
    // о пациентах
    public List<Patient> getAllPatients() throws SQLException {
        // Выполняем подключение к базе данных, создаем оператор для выборки данных
        try (PreparedStatement ps = connection.prepareStatement("select * from view_patients")) {
            // выполнить запрос и вернуть коллекцию
            return getPatients(ps);
        } // try
    } // getAllPatients


    // получить коллекцию сведений о фактах приемах
    public List<Appointment> getAllAppointments() throws SQLException {
        List<Appointment> appointments = new ArrayList<>();

        // Выполняем подключение к базе данных, создаем оператор для выборки данных
        try (PreparedStatement ps = connection.prepareStatement("select * from view_appointments;")) {
            // выполнить запрос и вернуть коллекцию
            return getAppointments(ps);
         }  // try
    } // getAllAppointments


    // получить коллекцию всех записей врачебных специальностей
    public List<Category> getAllCategories() {
        List<Category> categories = new ArrayList<>();

        // Выполняем подключение к базе данных, создаем оператор для выборки данных
        try (Statement statement = connection.createStatement()) {

            // выполнить выборку данных
            ResultSet resultSet = statement.executeQuery("select * from categories");

            // Проходим по выборке, формируя коллекцию записей типа Category
            while (resultSet.next()) {
                categories.add(new Category(
                    resultSet.getInt("id"),
                    resultSet.getString("category_name")
                ));
            } // while
        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return categories;
    } // getAllCategories


    // получить коллекцию всех записей персональных данных
    public List<Person> getAllPersons() {
        List<Person> persons = new ArrayList<>();

        // Выполняем подключение к базе данных, создаем оператор для выборки данных
        try (Statement statement = connection.createStatement()) {

            // выполнить выборку данных
            ResultSet resultSet = statement.executeQuery("select * from persons");

            // Проходим по выборке, формируя коллекцию записей типа Person
            while (resultSet.next()) {
                persons.add(new Person(
                    resultSet.getInt("id"),
                    resultSet.getString("surname"),
                    resultSet.getString("name"),
                    resultSet.getString("patronymic")
                ));
            } // while
        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return persons;
    } // getAllPersons

    //region запросы по заданию

    // Запрос 1. Запрос с параметрами
    // Выбирает информацию о пациентах с фамилиями, начинающимися на заданную
    // параметром последовательность символов
    List<Patient> query01(String surnameStartsWith) throws SQLException {
        // собственно запрос, параметры задаем знаком ?
        String sql = """
            select
                *
            from
                view_patients
            where
                patient_surname like ? || '%';
            """;

        // Выполняем подключение к базе данных, создаем оператор для выборки данных
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            // установить параметр запроса
            ps.setString(1, surnameStartsWith);

            // выполнить запрос и вернуть коллекцию
            return getPatients(ps);
        } // try
    } // query01

    // Запрос 2. Запрос с параметрами
    // Выбирает информацию о врачах, для которых значение в поле Процент отчисления
    // на зарплату, больше заданного
    public List<Doctor> query02(double boundInterest) throws SQLException {

        String sql= """
            select
                *
            from
                view_doctors
            where
                interest > ?;
            """;

        // Выполняем подключение к базе данных, создаем оператор для выборки данных
        try (PreparedStatement ps = connection.prepareStatement(sql)) {

            // установить параметр запроса
            ps.setDouble(1, boundInterest);

            // выполнить запрос и вернуть коллекцию
            return getDoctors(ps);
        } // try
    } // query02

    // Запрос 3. Запрос с параметрами
    // Выбирает информацию о приемах за некоторый период
    public List<Appointment> query03(Date from, Date to) throws SQLException {
        List<Appointment> appointments = new ArrayList<>();

        // текст запроса с параметрами
        String sql = """
             select
                 *
             from
                 view_appointments
             where
                 date between ? and ?;
             """;

        // Выполняем подключение к базе данных, создаем оператор для выборки данных
        try (PreparedStatement ps = connection.prepareStatement(sql)) {

            // задать параметры запроса
            ps.setDate(1, from);
            ps.setDate(2, to);

            // выполнить запрос и вернуть коллекцию
            return getAppointments(ps);
        } // try
    } // query03

    // Запрос 4. Запрос с параметрами
    // Выбирает из таблицы информацию о врачах с заданной специальностью
    public List<Doctor> query04(String categoryName) throws SQLException {
        String sql= """
            select
                *
            from
                view_doctors
            where
                category_name = ?;
            """;

        // Выполняем подключение к базе данных, создаем оператор для выборки данных
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            // установить параметр запроса
            ps.setString(1, categoryName);

            // выполнить запрос и вернуть коллекцию
            return getDoctors(ps);
        } // try
    } // query04

    // Запрос 5. Запрос с вычисляемыми полями
    // Вычисляет размер заработной платы врача за каждый прием. Включает поля
    // Фамилия врача, Имя врача, Отчество врача, Специальность врача, Стоимость
    // приема, Зарплата. Сортировка по полю Специальность врача
    public List<Query05> query05() throws SQLException {

        String sql = """
            select
                id
                , `date`
                , doctor_surname 
                , doctor_name    
                , doctor_patronymic 
                , category_name
                , price
                , interest
                , price * interest / 100 as salary
            from
                view_appointments
            order by
                category_name;
            """;

        // Выполняем подключение к базе данных, создаем оператор для выборки данных
        try (Statement statement = connection.createStatement()) {
            List<Query05> results = new ArrayList<>();

            // выполнить выборку данных
            ResultSet resultSet = statement.executeQuery(sql);

            // Проходим по выборке, формируя коллекцию записей типа Query05
            while (resultSet.next()) {
                results.add(new Query05(
                    resultSet.getInt("id"),
                    resultSet.getDate("date"),
                    resultSet.getString("doctor_surname"),
                    resultSet.getString("doctor_name"),
                    resultSet.getString("doctor_patronymic"),
                    resultSet.getString("category_name"),
                    resultSet.getInt("price"),
                    resultSet.getDouble("interest"),
                    resultSet.getDouble("salary")
                ));
            } // while
            return results;
        } // try
    } // query05

    // Запрос 6. Итоговый запрос
    // Выполняет группировку по полю Дата приема. Для каждой даты вычисляет
    // максимальную стоимость приема
    public List<Query06> query06() throws SQLException {

        String sql = """
            select
                date
                , count(price) as quantity
                , max(price) as maxPrice
            from
                view_appointments
            group by
                date;
            """;

        // Выполняем подключение к базе данных, создаем оператор для выборки данных
        try (Statement statement = connection.createStatement()) {
            List<Query06> results = new ArrayList<>();

            // выполнить выборку данных
            ResultSet resultSet = statement.executeQuery(sql);

            // Проходим по выборке, формируя коллекцию записей типа Query06
            while (resultSet.next()) {
                results.add(new Query06(
                    resultSet.getDate("date"),
                    resultSet.getInt("quantity"),
                    resultSet.getDouble("maxPrice")
                ));
            } // while
            return results;
        } // try
    } // query06

    // Запрос 7. Итоговый запрос
    // Выполняет группировку по полю Специальность. Для каждой специальности
    // вычисляет средний Процент отчисления на зарплату от стоимости приема
    public List<Query07> query07() throws SQLException {
        String sql = """
            select
                category_name
                , count(category_name) as quantity
                , avg(interest) as avgInterest
            from
                view_appointments
            group by
                category_name;
            """;

        // Выполняем подключение к базе данных, создаем оператор для выборки данных
        try (Statement statement = connection.createStatement()) {
            List<Query07> results = new ArrayList<>();

            // выполнить выборку данных
            ResultSet resultSet = statement.executeQuery(sql);

            // Проходим по выборке, формируя коллекцию записей типа Query07
            while (resultSet.next()) {
                results.add(new Query07(
                    resultSet.getString("category_name"),
                    resultSet.getInt("quantity"),
                    resultSet.getDouble("avgInterest")
                 ));
            } // while
            return results;
        } // try
    } // query07

    //endregion


    //region Выборки сущностей, повторяющиеся более, чем в одном запросе

    // выполнение запроса к таблице/представлению doctors/view_doctors,
    // возврат коллекции данных о докторах
    private List<Doctor> getDoctors(PreparedStatement ps) throws SQLException {
        List<Doctor> doctors = new ArrayList<>();
        ResultSet resultSet = ps.executeQuery();

        // Проходим по выборке, формируя коллекцию записей типа Doctor
        while (resultSet.next()) {
            doctors.add(new Doctor(
                resultSet.getInt("id"),
                resultSet.getString("surname"),
                resultSet.getString("name"),
                resultSet.getString("patronymic"),
                resultSet.getString("category_name"),
                resultSet.getDouble("interest")
            ));
        } // while
        return doctors;
    } // getDoctors


    // выполнение запроса к таблице/представлению patients/view_patients
    private List<Patient> getPatients(PreparedStatement ps) throws SQLException {
        List<Patient> patients = new ArrayList<>();

        // выполнить выборку данных
        ResultSet resultSet = ps.executeQuery();

        // Проходим по выборке, формируя коллекцию записей типа Patient
        while (resultSet.next()) {
            patients.add(new Patient(
                resultSet.getInt("id"),
                resultSet.getString("patient_surname"),
                resultSet.getString("patient_name"),
                resultSet.getString("patient_patronymic"),
                resultSet.getDate("dob"),
                resultSet.getString("address")
            ));
        } // while

        return patients;
    } // getPatients


    private List<Appointment> getAppointments(PreparedStatement ps) throws SQLException {
        List<Appointment> appointments = new ArrayList<>();
        ResultSet resultSet = ps.executeQuery();

        // Проходим по выборке, формируя коллекцию записей типа Appointment
        while (resultSet.next()) {
            appointments.add(new Appointment(
                resultSet.getInt("id"),
                resultSet.getDate("date"),
                resultSet.getString("patient_surname"),
                resultSet.getString("patient_name"),
                resultSet.getString("patient_patronymic"),
                resultSet.getDate("dob"),
                resultSet.getString("address"),
                resultSet.getString("doctor_surname"),
                resultSet.getString("doctor_name"),
                resultSet.getString("doctor_patronymic"),
                resultSet.getString("category_name"),
                resultSet.getDouble("price"),
                resultSet.getDouble("interest")
            ));
        } // while
        return appointments;
    } // getAppointments

    //endregion
} // class DbHandler
