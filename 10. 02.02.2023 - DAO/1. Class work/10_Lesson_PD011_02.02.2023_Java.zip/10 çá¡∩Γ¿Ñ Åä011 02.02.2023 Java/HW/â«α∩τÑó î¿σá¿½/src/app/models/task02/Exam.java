package app.models.task02;


import java.util.Date;

// Класс Экзамен
public record Exam(
        int id,
        String academicSubjectName,
        String examTypeName,
        String examinerLastName,
        String examinerFirstName,
        String examinerPatronymic,
        int examinerExamFee,
        String studentLastName,
        String studentFirstName,
        String studentPatronymic,
        String studentsAddress,
        int studentYearOfBirth,
        String studentPassport,
        Date date,
        int score
) {
    // вывод в строку таблицы
    public String toTableRow() {
        return String.format(
                "<tr>" +
                        "<th>%1$d</th>" +
                        "<td>%2$s</td>" +
                        "<td>%3$s</td>" +
                        "<td>%4$s</td>" +
                        "<td>%5$s</td>" +
                        "<td>%6$s</td>" +
                        "<td>%7$s</td>" +
                        "<td align='right'>%8$d</td>" +
                        "<td>%9$s</td>" +
                        "<td>%10$s</td>" +
                        "<td>%11$s</td>" +
                        "<td>%12$s</td>" +
                        "<td>%13$d</td>" +
                        "<td>%14$td.%14$tm.%14$tY</td>" +
                        "<td align='right'>%15$d</td>" +
                        "</tr>",
                id,
                academicSubjectName,
                examTypeName,
                examinerLastName,
                examinerFirstName,
                examinerPatronymic,
                examinerExamFee,
                studentLastName,
                studentFirstName,
                studentPatronymic,
                studentsAddress,
                studentYearOfBirth,
                studentPassport,
                date,
                score
        );
    }
}
