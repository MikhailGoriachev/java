package org.itstep.pd011.controllers;

import org.itstep.pd011.models.task2.Library;

// разработка не завершена
public class Task2Controller {

    private Library library;

    public Task2Controller() {
        this(new Library());
    }

    public Task2Controller(Library library) {
        this.library = library;
    }

    public void run() {
        library.show("\nСведения о библиотеке и книгах:\n");

        library.orderByAuthor();

        library.orderByYearDesc();

        library.orderByAmount();

        library.orderByTitle();
    }
} // class Task2Controller
