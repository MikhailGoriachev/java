package org.itstep.pd011.models.task2;

// Класс, представляющий сведения о книгах: числовой идентификатор книги,
// фамилию и инициалы автора, название, год издания, количество экземпляров
// данной книги в библиотеке.
public class Book {
    // числовой идентификатор книги
    private int id;

    // фамилию и инициалы автора
    private String author;

    // название книги
    private String title;

    // год издания книги
    private int year;

    // количество экземпляров книги с библиотеке
    private int amount;

    public Book() {
    }

    public Book(int id, String author, String title, int year, int amount) {
        this.id = id;
        this.author = author;
        this.title = title;
        this.year = year;
        this.amount = amount;
    }

    // геттеры и сеттеры для полей книги

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    @Override
    public String toString() {
        return String.format("│ Ид: %d │ Автор: '%s' │ Название: %s │ Год: %d │ Количество: %d │",
                id, author, title, year, amount);
    } // toString

    // Форирование строки таблицы
    public String toTableRow(int i) {
        return String.format("│ %5d │ %3d │ %-18s │ %-56s  │ %10d │ %10d │", i, id, author, title, year, amount);
    } // toTableRow

    // вывод заголовка таблицы вывода
    public static final String HEADER =
            "\t┌───────┬─────┬────────────────────┬────────────────────────────┬──────┬────────────┐\n" +
            "\t│ Номер │ Ид. │ Автор              │ Название                   │  Год │ Количество │\n" +
            "\t├───────┼─────┼────────────────────┼────────────────────────────┼──────┼────────────┤\n";

    // нижнаяя строка рамки таблицы вывода
    public static final String BOTTOM =
            "\t└───────┴─────┴─────────────────────┴───────────────────────────┴──────┴────────────┘";

} // class Book
