package org.itstep.pd011.controllers;

import java.util.List;
import java.util.function.Consumer;

import org.itstep.pd011.models.task1.Goods;
import org.itstep.pd011.models.task1.Store;

/*
*
* Требуется выполнение следующих функций:
*     • формирование коллекции (начальное заполнение коллекции, не менее
*       12 записей);
*     • вывод коллекции в консоль;
*     • упорядочивание коллекции по наименованию товара;
*     • упорядочивание коллекции по убыванию цены единицы товара;
*     • формирование коллекции товаров с минимальной ценой;
*     • формирование коллекции товаров с максимальной ценой.
* */
public class Task1Controller {
    private Store store;

    public Task1Controller() {
        store = new Store();
    } // Task1Controller

    public void run() {
        store.show("\nТовары в магазине");

        // TODO: в метод !!!
        store.orderByName();
        store.show("\nТовары в магазине упорядочены по наименованию");

        // TODO: в метод !!!
        System.out.println("\nТовары с минимальной ценой");
        List<Goods> minPrices = store.filterMinPrice();
        minPrices.forEach(new Consumer<Goods>() {
            @Override
            public void accept(Goods goods) {
                System.out.println(goods);
            }
        });

        // TODO: в метод !!!
        System.out.println("\nТовары с макcимальной ценой");
        List<Goods> maxPrices = store.filterMaxPrice();
        maxPrices.forEach(new Consumer<Goods>() {
            @Override
            public void accept(Goods goods) {
                System.out.println(goods);
            }
        });
    }
} // class Task1Controller
