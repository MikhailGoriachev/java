package org.itstep.pd011.models.task1;

/*
* класс Goods, описывающий товар (наименование товара, количество
* товара, цена единицы товара)
* */
public class Goods {
    // наименование товара
    private String name;

    // количество товара
    private int amount;

    // цена единицы товара
    private int price;

    public Goods() {
        this("авторучка шариковая", 12, 10);
    } // Goods

    public Goods(String name, int amount, int price) {
        this.name = name;
        this.amount = amount;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Goods{" +
                "name='" + name + '\'' +
                ", amount=" + amount +
                ", price=" + price +
                '}';
    }
} // clas Goods

