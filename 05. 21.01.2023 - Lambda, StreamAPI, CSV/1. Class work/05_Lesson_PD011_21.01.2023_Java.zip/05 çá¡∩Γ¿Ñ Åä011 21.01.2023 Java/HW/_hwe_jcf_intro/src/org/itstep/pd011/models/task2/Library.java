package org.itstep.pd011.models.task2;

import java.security.InvalidParameterException;
import java.util.*;
import java.util.function.Consumer;

// Описание библиотекаи: название, адрес, максимальное количество
// хранимых книг, коллекцию сведений о книгах.
public class Library {
    // максимальное количество хранимых книг
    final int BOOK_CAPACITY = 1200;

    // название
    private String name;

    // адрес
    private String address;

    // коллекцию сведений о книгах
    private HashMap<Integer, Book> books;

    public Library() {
        this("Библиотека \"Квант\"", "ул. Овнатаняна, 3а", new HashMap<>());
        initialize();
    }

    // канонический конструктор
    public Library(String name, String address, HashMap<Integer, Book> books) {
        this.name = name;
        this.address = address;
        this.books = books;
    }

    // Название библиотеки
    public String getName() {
        return name;
    }
    public void setName(String name) {
        if (name.isEmpty() || name.isBlank())
            throw new InvalidParameterException("Название библиотеки должно быть задано");

        this.name = name;
    } // setName

    // адрес библиотеки
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        if (address.isEmpty() || address.isBlank())
            throw new InvalidParameterException("Адрес библиотеки должен быть задан");

        this.address = address;
    } // setAddress

    // геттер и сеттер для коллекции книг
    public HashMap<Integer, Book> getItems() {
        return books;
    }
    public void setItems(HashMap<Integer, Book> books) {
        if (books == null)
            throw new InvalidParameterException("Коллекция книг не задана");

        this.books = new HashMap<>(books);
    } // setItems

    public void initialize() {
        books = new HashMap<>();
        books.put(100, new Book(100,   "Дронов В.А.",      "Laravel. Быстрая разработка веб-сайтов",           2017, 7));
        books.put(101, new Book(101,   "Зандстра М.",      "PHP: объекты, шаблоны и методики програмиирования",2015,  6));
        books.put(102, new Book(102,    "Никсон Р.",       "Создаем динамически веб-сайты с помощью PHP",      2016, 1));
        books.put(103, new Book(103,    "Стаффер М.",      "laravel. Полное руководство",                      2020, 3));
        books.put(104, new Book(104,    "Дейтел П.",       "Исусственный интеллект, большие данные",           2020, 2));
        books.put(105, new Book(105,    "Прохоренок Н.А.", "Python 3 и pyQt 5. разработка приложений",         2016, 3));
        books.put(106, new Book(106,    "Уилкс М.",        "Профессиональная разработка на Python",            2021, 7));
        books.put(107, new Book(107,    "Дронов В.А.",     "Стандартная библиотека Python 3",                  2019, 2));
        books.put(108, new Book(108,    "Прохоренок Н.А.", "Unity и C#. Геймдев: от идеи до реализации",       2019, 4));
        books.put(109, new Book(109,    "Хокинг Дж.",      "Unity. Мультиплатформенная обработка на C#",       2016, 8));
        books.put(110, new Book(110,    "Никсон Р.",       "Сюрреализм на JavaScript",                         2014, 2));
        books.put(111, new Book(111,    "Дейтел П.",       "Веб-разработка с применением Node и Express",      2017, 3));
    } // initialize

    public void show(String title) {
        System.out.println(title);

        // используйте iter :)
        int row = 1;
        for (var entry : books.entrySet()) {
            System.out.println(entry.getValue().toTableRow(row++));
        }
    } // show

    // выдача сведений о всех книгах, упорядоченных по фамилиям авторов
    public void orderByAuthor() {
        List<Book> temp = new ArrayList<>(books.values());

        Collections.sort(temp, new Comparator<Book>() {
            @Override
            public int compare(Book o1, Book o2) {
                return o1.getAuthor().compareTo(o2.getAuthor());
            }
        });

        show("\nCведения о книгах, упорядоченных по фамилиям авторов", temp);
    } // orderByAuthor

    // выдача сведений о всех книгах, упорядоченных по убыванию года издания
    public void orderByYearDesc() {
        List<Book> temp = new ArrayList<>(books.values());

        Collections.sort(temp, new Comparator<Book>() {
            @Override
            public int compare(Book o1, Book o2) {
                return o2.getYear() - o1.getYear();
            }
        });

        show("\nCведения о книгах, упорядоченных по убыванию года издания", temp);
    } // orderByYearDesc

    // выдача сведений о всех книгах, упорядоченных по возрастанию количества;
    public void orderByAmount() {
        List<Book> temp = new ArrayList<>(books.values());

        Collections.sort(temp, new Comparator<Book>() {
            @Override
            public int compare(Book o1, Book o2) {
                return o1.getAmount() - o2.getAmount();
            }
        });

        show("\nCведения о книгах, упорядоченных по возрастанию количества", temp);
    } // orderByAmount


    // выдача сведений о всех книгах, упорядоченных по названию
    public void orderByTitle() {
        List<Book> temp = new ArrayList<>(books.values());

        Collections.sort(temp, new Comparator<Book>() {
            @Override
            public int compare(Book o1, Book o2) {
                return o1.getTitle().compareTo(o2.getTitle());
            }
        });

        show("\nCведения о книгах, упорядоченных по названию", temp);
    } // orderByAmount


    // вывод списка книг - для вывода результатов работы сортировок
    public  void show(String title, List<Book> listBook) {
        System.out.println(title);

        int row = 1;
        listBook.forEach(new Consumer<Book>() {
            @Override
            public void accept(Book book) {
                System.out.println(book.toTableRow(row));
            } // accept
        });
    } // show
} // class Library
