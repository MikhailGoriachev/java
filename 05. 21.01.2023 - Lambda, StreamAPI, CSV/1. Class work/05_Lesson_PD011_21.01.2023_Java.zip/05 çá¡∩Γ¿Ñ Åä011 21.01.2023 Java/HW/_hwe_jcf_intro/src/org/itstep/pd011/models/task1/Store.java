package org.itstep.pd011.models.task1;

import java.util.*;
import java.util.function.Consumer;

/*
* Класс Store для хранения коллекции товаров
* Требуется выполнение следующих функций:
*     • формирование коллекции (начальное заполнение коллекции, не менее
*       12 записей);
*     • вывод коллекции в консоль;
*     • упорядочивание коллекции по наименованию товара;
*     • упорядочивание коллекции по убыванию цены единицы товара;
*     • формирование коллекции товаров с минимальной ценой;
*     • формирование коллекции товаров с максимальной ценой.
* */
public class Store {
    private List<Goods> listGoods;
    private String nameStore;

    public Store() {
        this(new ArrayList<>(), "Магазин № 22");
        initialize();
    } // Store

    public Store(List<Goods> listGoods, String name) {
        this.listGoods = listGoods;
        this.nameStore = name;
    } // Store

    // формирование коллекции (начальное заполнение коллекции, не менее
    // 12 записей)
    public void initialize() {
        listGoods = Arrays.asList(
            new Goods(),
            new Goods("пиджак замшевый", 2, 12000),
            new Goods("фотокамера отечественная", 3, 1000),
            new Goods("фотокамера импортная", 2, 13000),
            new Goods("сапоги резиновые", 4, 500)
        );
    } // initialize

    public List<Goods> getListGoods() {
        return listGoods;
    }

    public void setListGoods(List<Goods> listGoods) {
        this.listGoods = listGoods;
    }

    public String getNameStore() {
        return nameStore;
    }

    public void setNameStore(String nameStore) {
        this.nameStore = nameStore;
    }

    // упорядочивание коллекции по наименованию товара
    public void orderByName() {
        // так даже лучше, но еще не прошли :)
        // listGoods.sort(Comparator.comparing(Goods::getName));

        listGoods.sort(new Comparator<Goods>() {
            @Override
            public int compare(Goods o1, Goods o2) {
                return o1.getName().compareTo(o2.getName());
            } // compare
        });
    } // orderByName

    // формирование коллекции товаров с минимальной ценой
    public List<Goods> filterMinPrice() {
        List<Goods> filtered = new ArrayList<>();
        int minPrice = Collections.min(listGoods, new Comparator<Goods>() {
            @Override
            public int compare(Goods o1, Goods o2) {
                return o1.getPrice() - o2.getPrice();
            } // compare
        }).getPrice();

        // выборка
        for(var goods:listGoods) {
            if (goods.getPrice() == minPrice) {
                filtered.add(goods);
            } // if
        } // for goods
        return filtered;
    } // filterMinPrice

    // формирование коллекции товаров с максимальной ценой
    public List<Goods> filterMaxPrice() {
        List<Goods> filtered = new ArrayList<>();
        int maxPrice = Collections.max(listGoods, new Comparator<Goods>() {
            @Override
            public int compare(Goods o1, Goods o2) {
                return o1.getPrice() - o2.getPrice();
            } // compare
        }).getPrice();

        for(var goods:listGoods) {
            if (goods.getPrice() == maxPrice) {
                filtered.add(goods);
            } // if
        } // for goods
        return filtered;
    } // filterMinPrice
    public void show(String title) {
        System.out.println(title);

        // скорей бы лямбды :)
        // listGoods.forEach(System.out::println);

        listGoods.forEach(new Consumer<Goods>() {
            @Override
            public void accept(Goods goods) {
                System.out.println(goods);
            }
        });
    }
} // class Store
