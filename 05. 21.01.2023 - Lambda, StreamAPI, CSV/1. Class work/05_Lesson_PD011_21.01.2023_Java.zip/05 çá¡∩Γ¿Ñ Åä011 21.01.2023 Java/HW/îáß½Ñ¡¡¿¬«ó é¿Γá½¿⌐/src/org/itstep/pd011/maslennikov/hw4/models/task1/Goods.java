package org.itstep.pd011.maslennikov.hw4.models.task1;

import org.itstep.pd011.maslennikov.hw4.models.IHtmlTableRenderable;

import static org.itstep.pd011.maslennikov.hw4.services.HtmlTableFormatter.*;

import java.security.InvalidParameterException;

public class Goods implements IHtmlTableRenderable {

    // наименование товара
    private String name;

    // количество товара
    private int quantity;

    // цена единицы товара
    private int price;

    public Goods(String name, int quantity, int price) {
        this.name = name;
        this.quantity = quantity;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name.isBlank())
            throw new InvalidParameterException("Не задано наименование товара");

        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        if (quantity < 0)
            throw new InvalidParameterException("Недопустимое количество товара");

        this.quantity = quantity;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        if (price < 0)
            throw new InvalidParameterException("Недопустимая цена единицы товара");

        this.price = price;
    }

    @Override
    public String toHtmlTableRow(int n) {
        return row(
                cell(n, "center"),
                cell(name, "left"),
                cell(quantity, "right"),
                cell(price, "right")
        );
    }
}
