package org.itstep.pd011.maslennikov.hw4.utils;

import javax.swing.*;
import java.text.ParseException;
import java.util.concurrent.CancellationException;

public class Utils {
    private static final java.util.Random rand = new java.util.Random();

    // метод, возвращающий случайное вещественное число,
    // передаются нижнее и верхнее значения
    public static double rand(double lo, double hi){
        return lo + rand.nextDouble() * (hi - lo);
    }

    // перегруженный метод, возвращающий случайное целое число,
    // передаются нижнее и верхнее значения
    public static int rand(int lo, int hi) {
        return lo + rand.nextInt(hi - lo + 1);
    }

    public static int showMenu(String content, String title, String[] menu, String initialValue) {
        return JOptionPane.showOptionDialog(
                null,
                content,
                title,
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                menu,
                initialValue
        );
    }

    public static String inputString(String message, String initial) {
        String result = JOptionPane.showInputDialog(null, message, initial);

        if (result == null)
            throw new CancellationException();

        return result;
    }

    public static void errorMessage(String message) {
        JOptionPane.showMessageDialog(null, message, "Ошибка", JOptionPane.ERROR_MESSAGE);
    }

    public static int parseInt(String source, String exceptionMessage) throws Exception {
        int parsed;
        try {
            parsed = Integer.parseInt(source);
        } catch (NumberFormatException e) {
            throw new Exception(exceptionMessage);
        }

        return parsed;
    }
}
