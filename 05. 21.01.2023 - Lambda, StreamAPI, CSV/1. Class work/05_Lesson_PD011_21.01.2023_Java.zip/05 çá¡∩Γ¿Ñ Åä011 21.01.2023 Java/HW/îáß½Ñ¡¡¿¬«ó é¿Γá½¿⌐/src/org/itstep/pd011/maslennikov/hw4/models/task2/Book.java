package org.itstep.pd011.maslennikov.hw4.models.task2;

import org.itstep.pd011.maslennikov.hw4.models.IHtmlTableRenderable;

import static org.itstep.pd011.maslennikov.hw4.services.HtmlTableFormatter.*;

import java.security.InvalidParameterException;

public class Book implements IHtmlTableRenderable {
    // числовой идентификатор книги,
    private int id;

    // фамилию и инициалы автора,
    private String author;

    // название
    private String title;

    // год издания
    private int pubYear;

    // количество экземпляров данной книги в библиотеке
    private int quantity;

    public Book(int id, String author, String title, int pubYear, int quantity) {
        setId(id);
        setAuthor(author);
        setTitle(title);
        setPubYear(pubYear);
        setQuantity(quantity);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        if (author.isBlank())
            throw new InvalidParameterException("Не задано имя автора");

        this.author = author;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        if (title.isBlank())
            throw new InvalidParameterException("Не задано название книги");

        this.title = title;
    }

    public int getPubYear() {
        return pubYear;
    }

    public void setPubYear(int pubYear) {
        if (pubYear < 0)
            throw new InvalidParameterException("Недопустимый год издания");

        this.pubYear = pubYear;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        if (quantity < 0)
            throw new InvalidParameterException("Недопустимое количество книг");

        this.quantity = quantity;
    }

    @Override
    public String toHtmlTableRow(int n) {
        return row(
                cell(id, "center"),
                cell(title, "left"),
                cell(author, "left"),
                cell(pubYear, "right"),
                cell(quantity, "right")
        );
    }
}
