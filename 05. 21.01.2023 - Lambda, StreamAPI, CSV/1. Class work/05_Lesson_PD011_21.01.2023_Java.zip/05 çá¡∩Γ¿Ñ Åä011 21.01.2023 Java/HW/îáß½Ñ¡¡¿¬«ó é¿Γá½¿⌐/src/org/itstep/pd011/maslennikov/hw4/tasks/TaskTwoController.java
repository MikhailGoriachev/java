package org.itstep.pd011.maslennikov.hw4.tasks;

import org.itstep.pd011.maslennikov.hw4.models.task1.Store;
import org.itstep.pd011.maslennikov.hw4.models.task2.Library;
import org.itstep.pd011.maslennikov.hw4.utils.Utils;

import javax.swing.*;
import java.util.concurrent.CancellationException;

public class TaskTwoController {

    private static Library library;

    public static void run() {
        library = new Library();

        String message = library.toHtmlTable("Список книг:");

        while (message != null) {
            message = switch (showMenu(message)) {
                case 0 -> sourceData();
                case 1 -> {
                    try {
                        yield addBook();
                    } catch (CancellationException e) {
                        yield sourceData();
                    } catch (Exception e) {
                        yield e.getMessage();
                    }
                }
                case 2 -> {
                    try {
                        yield removeBook();
                    } catch (CancellationException e) {
                        yield sourceData();
                    } catch (Exception e) {
                        yield e.getMessage();
                    }
                }
                case 3 -> orderByAuthor();
                case 4 -> orderByPubYearDesc();
                case 5 -> orderByQuantity();
                case 6 -> orderByTitle();
                default -> null;
            };
        }
    }

    private static String sourceData() {
        return library.toHtmlTable("Список книг");
    }

    private static String addBook() throws Exception {

        String title = Utils.inputString("Введите название книги", "О дивный новый мир");

        String author = Utils.inputString("Введите фамилию и инициалы автора:", "Олдос Хаксли");

        String pubYearString = Utils.inputString("Введите год издания:", "1932");
        int year = Utils.parseInt(pubYearString, "Год издания должно быть целое число");

        String quantityString = Utils.inputString("Введите количество:", "12");
        int quantity = Utils.parseInt(quantityString, "Год издания должно быть целое число");

        library.add(title, author, year, quantity);

        return library.toHtmlTable("Добавлена информация о книге");
    }

    private static String removeBook() throws Exception {
        String idString = Utils.inputString("Введите id книги для удаления:", "1");
        int id = Utils.parseInt(idString, "Id должно быть целое число");

        library.remove(id);

        return library.toHtmlTable("Удалена информация о книге");
    }

    public static String orderByAuthor() {
        return Library.toHtmlTable(library.orderedByAuthor(), "Упорядочено по автору");
    }

    public static String orderByPubYearDesc() {
        return Library.toHtmlTable(library.orderedByPubYearDesc(), "Упорядочено по убыванию года издания");
    }

    public static String orderByQuantity() {
        return Library.toHtmlTable(library.orderedByQuantity(), "Упорядочено по количеству");
    }

    public static String orderByTitle() {
        return Library.toHtmlTable(library.orderedByTitle(), "Упорядочено по названию");
    }

    private static int showMenu(String content) {
        return Utils.showMenu(
                content,
                "Задача 1",
                new String[]{
                        "Исходные",
                        "Добавить",
                        "Удалить",
                        "Упорядочить по автору",
                        "Упорядочить по убыв. года издания",
                        "Упорядочить по количеству",
                        "Упорядочить по названию",
                        "Назад"},
                "Выход");

    }
}
