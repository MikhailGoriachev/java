package org.itstep.pd011.maslennikov.hw4.models.task2;

import org.itstep.pd011.maslennikov.hw4.services.HtmlTableFormatter;

import static org.itstep.pd011.maslennikov.hw4.services.HtmlTableFormatter.*;

import java.security.InvalidKeyException;
import java.util.*;

public class Library {
    HashMap<Integer, Book> books;

    public Library() {
        books = new HashMap<>();

        books.put(1, new Book(1, "Джон Р. Р. Толкин", "Властелин колец", 1954, 12));
        books.put(2, new Book(2, "Джейн Остин", "Гордость и предубеждение", 1813, 10));
        books.put(3, new Book(3, "Филип Пулман", "Тёмные начала", 1995, 6));
        books.put(4, new Book(4, "Дуглас Адамс", "Автостопом по галактике", 1979, 7));
        books.put(5, new Book(5, "Джоан Роулинг", "Гарри Поттер и Кубок огня", 2000, 5));
        books.put(6, new Book(6, "Харпер Ли", "Убить пересмешника", 1960, 16));
        books.put(7, new Book(7, "Алан Александр Милн", "Винни Пух", 1926, 13));
        books.put(8, new Book(8, "Джордж Оруэлл", "1984", 1948, 9));
        books.put(9, new Book(9, "Клайв Стэйплз Льюис", "Лев, колдунья и платяной шкаф", 1950, 4));
        books.put(10, new Book(10, "Шарлотта Бронте", "Джейн Эйр", 1847, 8));
        books.put(11, new Book(11, "Джозеф Хеллер", "Уловка-22", 1961, 2));
        books.put(12, new Book(12, "Эмили Бронте", "Грозовой перевал", 1874, 18));
        books.put(13, new Book(13, "Себастьян Фолкс", "Пение птиц", 1993, 13));
        books.put(14, new Book(14, "Дафна Дюморье", "Ребекка", 1938, 11));
        books.put(15, new Book(15, "Джером Сэлинджер", "Над пропастью во ржи", 1951, 4));
    }


    public void add(String title, String author, int pubYear, int quantity) {
        var newId = Collections.max(new ArrayList<>(books.values()), Comparator.comparingInt(Book::getId)).getId() + 1;

        var newBook = new Book(newId, author, title, pubYear, quantity);

        books.put(newId, newBook);
    }

    public void remove(int id) throws InvalidKeyException {
        if (!books.containsKey(id)) {
            throw new InvalidKeyException("Отсутствует заданный ключ");
        }

        books.remove(id);
    }

    public List<Book> orderedByAuthor() {
        List<Book> list = new ArrayList<>(books.values());

        list.sort(Comparator.comparing(Book::getAuthor));

        return list;
    }

    public List<Book> orderedByPubYearDesc() {
        List<Book> list = new ArrayList<>(books.values());

        list.sort((b1, b2) -> b2.getPubYear() - b1.getPubYear());

        return list;
    }

    public List<Book> orderedByQuantity() {
        List<Book> list = new ArrayList<>(books.values());

        list.sort(Comparator.comparingInt(Book::getQuantity));

        return list;
    }

    public List<Book> orderedByTitle() {
        List<Book> list = new ArrayList<>(books.values());

        list.sort(Comparator.comparing(Book::getTitle));

        return list;
    }

    public String toHtmlTable(String title) {
        return Library.toHtmlTable(new ArrayList<>(books.values()), title);
    }

    public static String toHtmlTable(List<Book> books, String title) {
        HtmlTableFormatter formatter = new HtmlTableFormatter(
                headerCell("Id"),
                headerCell("Наименование"),
                headerCell("Автор"),
                headerCell("Год издания"),
                headerCell("Количество")
        );

        return formatter.table(books, title);
    }
}
