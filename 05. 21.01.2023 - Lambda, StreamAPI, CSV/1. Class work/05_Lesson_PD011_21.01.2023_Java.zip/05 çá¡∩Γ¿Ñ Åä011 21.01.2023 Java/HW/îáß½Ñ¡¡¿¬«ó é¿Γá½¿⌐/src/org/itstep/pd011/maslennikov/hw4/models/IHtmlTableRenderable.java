package org.itstep.pd011.maslennikov.hw4.models;

public interface IHtmlTableRenderable {
    String toHtmlTableRow(int n);
}
