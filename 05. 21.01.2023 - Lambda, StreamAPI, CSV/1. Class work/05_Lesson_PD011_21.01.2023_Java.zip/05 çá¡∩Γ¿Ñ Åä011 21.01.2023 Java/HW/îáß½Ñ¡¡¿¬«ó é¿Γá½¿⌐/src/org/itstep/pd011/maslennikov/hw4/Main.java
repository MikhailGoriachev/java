package org.itstep.pd011.maslennikov.hw4;

import org.itstep.pd011.maslennikov.hw4.tasks.TaskOneController;
import org.itstep.pd011.maslennikov.hw4.tasks.TaskTwoController;
import org.itstep.pd011.maslennikov.hw4.utils.Utils;

import java.io.PrintWriter;
import java.io.StringWriter;

public class Main {
    public static void main(String[] args) {

        String message = "Домашняя работа";

        try {
            while (true) {
                switch (showMenu(message)) {
                    case 0 -> TaskOneController.run();
                    case 1 -> TaskTwoController.run();
                    default -> {
                        return;
                    }
                }
            }
        } catch (Exception ex) {
            StringWriter sw = new StringWriter();
            ex.printStackTrace(new PrintWriter(sw));

            Utils.errorMessage(sw.toString());
        }
    }

    public static int showMenu(String message) {
        return Utils.showMenu(
                "<html><h1>Меню</h1>",
                message,
                new String[]{"Задача 1", "Задача 2", "Выход"},
                "Выход"
        );
    }
}


