package org.itstep.pd011.maslennikov.hw4.tasks;

import org.itstep.pd011.maslennikov.hw4.models.task1.Store;
import org.itstep.pd011.maslennikov.hw4.utils.Utils;

public class TaskOneController {

    private static Store store;

    public static void run() {
        store = new Store();

        String message = store.toHtmlTable("Список товаров:");

        while (message != null) {
            message = switch (showMenu(message)) {
                case 0 -> sourceData();
                case 1 -> orderedByName();
                case 2 -> orderedByPriceDes();
                case 3 -> cheapestGoods();
                case 4 -> mostExpensiveGoods();
                default -> null;
            };
        }
    }

    private static String sourceData() {
        return store.toHtmlTable("Транспортные средства");
    }

    private static String orderedByName() {
        return store.orderedByName().toHtmlTable("Упорядочено по наименованию:");
    }

    private static String orderedByPriceDes() {
        return store.orderedByPriceDesc().toHtmlTable("Упорядочено по убыванию цены:");
    }

    private static String cheapestGoods() {
        return store.cheapestGoods().toHtmlTable("Товары с минимальной ценой:");
    }

    private static String mostExpensiveGoods() {
        return store.mostExpensiveGoods().toHtmlTable("Товары с максимальной ценой:");
    }

    private static int showMenu(String content) {
        return Utils.showMenu(
                content,
                "Задача 1",
                new String[]{"Исходные",
                        "<html>Упорядочить<br>по наименованию",
                        "Упорядочить по цене",
                        "С минимальной ценой",
                        "С максимальной ценой",
                        "Назад"},
                "Выход");

    }
}
