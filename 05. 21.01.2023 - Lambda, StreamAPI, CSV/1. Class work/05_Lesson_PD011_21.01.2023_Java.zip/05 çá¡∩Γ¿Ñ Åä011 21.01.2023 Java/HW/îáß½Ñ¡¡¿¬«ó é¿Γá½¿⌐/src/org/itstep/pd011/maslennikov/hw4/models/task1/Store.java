package org.itstep.pd011.maslennikov.hw4.models.task1;

import org.itstep.pd011.maslennikov.hw4.services.HtmlTableFormatter;

import static org.itstep.pd011.maslennikov.hw4.services.HtmlTableFormatter.*;

import java.util.*;

public class Store {

    private ArrayList<Goods> items;

    public Store(ArrayList<Goods> items) {
        this.items = new ArrayList<>(items);
    }

    private final HtmlTableFormatter tableFormatter = new HtmlTableFormatter(
            headerCell("№"),
            headerCell("Наименование"),
            headerCell("Количество"),
            headerCell("Цена/ед., руб.")
    );

    public Store() {
        items = new ArrayList<>(Arrays.asList(
                new Goods("Робот-пылесос Roborock S6 MaxV", 1, 44_990),
                new Goods("Монопод для селфи Xiaomi Mi Bluetooth Selfie Stick", 5, 1_290),
                new Goods("Материнская плата intel H110 Asus", 4, 5590),
                new Goods("Портативная акустика Bluetooth GravaStar Mars Bounce", 7, 18990),
                new Goods("Чайник Rondell Infinity", 7, 2_990),
                new Goods("Смартфон Tecno Spark 8C 4/64Gb Turq Cyan", 6, 9_990),
                new Goods("Планшет 10.36\" Chuwi HiPad Max 8/128Гб Gray", 3, 18_990),
                new Goods("Ноутбук 15.6\" Asus X515EA-BQ2322W", 7, 48_990),
                new Goods("Видеокарта nVidia RTX 3060 Gigabyte", 4, 37_990),
                new Goods("Кресло для геймеров MSI MAG CH130X", 1, 29_990),
                new Goods("Колонки 2.1 Sven MS-2100 ", 8, 9_790),
                new Goods("Точка доступа TP-Link Deco M5", 11, 6_590)
        ));
    }

    public Store orderedByName() {
        ArrayList<Goods> ordered = new ArrayList<>(items);

        ordered.sort(Comparator.comparing(Goods::getName));

        return new Store(ordered);
    }

    public Store orderedByPriceDesc() {
        ArrayList<Goods> ordered = new ArrayList<>(items);

        ordered.sort((g1, g2) -> g2.getPrice() - g1.getPrice());

        return new Store(ordered);
    }

    public Store cheapestGoods() {
        ArrayList<Goods> cheapest = new ArrayList<>();

        var minPrice = Collections.min(items, Comparator.comparingInt(Goods::getPrice)).getPrice();

        items.forEach((item) -> {
            if (item.getPrice() == minPrice) cheapest.add(item);
        });

        return new Store(cheapest);
    }

    public Store mostExpensiveGoods() {
        ArrayList<Goods> expensive = new ArrayList<>();

        var maxPrice = Collections.max(items, Comparator.comparingInt(Goods::getPrice)).getPrice();

        items.forEach((item) -> {
            if (item.getPrice() == maxPrice) expensive.add(item);
        });

        return new Store(expensive);
    }

    public String toHtmlTable(String title) {
        return tableFormatter.table(items, title);
    }
}
