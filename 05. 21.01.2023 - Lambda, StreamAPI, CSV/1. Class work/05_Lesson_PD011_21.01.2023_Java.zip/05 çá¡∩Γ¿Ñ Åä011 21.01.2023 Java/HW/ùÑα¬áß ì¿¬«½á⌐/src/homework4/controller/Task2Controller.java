package homework4.controller;

import homework4.Menu;

public class Task2Controller {
    public void task2() {
        try {
            boolean flag = true;
            while (flag) {
                switch (Menu.showMenu2()) {
                    case 0 -> System.out.println("в разработке");
                    case 1 -> System.out.println("в разработке");
                    case 2 -> System.out.println("в разработке");
                    case 3 -> System.out.println("в разработке");
                    case 4 -> System.out.println("в разработке");
                    case 5 -> System.out.println("в разработке"); 
                    case 6 -> flag = false;
                }
            }
        } catch (Exception exc) {
            exc.printStackTrace();
        }
    }
}
