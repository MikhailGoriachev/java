package homework4;

import javax.swing.*;

public class Menu {
    public static int showMenu(){
        return  JOptionPane.showOptionDialog(
                null, "Меню", "Меню",
                JOptionPane.YES_NO_CANCEL_OPTION, 1, null,
                new Object[] {"задача 1", "задача 2", "выход"},
                "задача 1");
    }
    public static int showMenu1(){
        return  JOptionPane.showOptionDialog(
                null, "Меню задача 1", "Меню задача 1",
                JOptionPane.YES_NO_CANCEL_OPTION, 1, null,
                new Object[] {"Коллекция", "по наименованию", "по убыванию цены", "с минимальной ценой", "с максимальной ценой", "демонстрация ошибки", "Основное меню"},
                "Коллекция");
    }
    public static int showMenu2(){
        return  JOptionPane.showOptionDialog(
                null, "Меню задача 2", "Меню задача 2",
                JOptionPane.YES_NO_CANCEL_OPTION, 1, null,
                new Object[] {"Коллекция", "Добавить", "по фамилиям", "по убыванию года", "по количеству", "по названию", "Основное меню"},
                "Коллекция");
    }
}
