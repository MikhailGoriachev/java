package homework4.controller;

import homework4.models.task1.Goods;
import homework4.models.task1.Store;
import static homework4.Menu.showMenu1;

public class Task1Controller {
    public void task1() throws Exception {
        Store store = new Store();
        try {
        boolean flag = true;
        while (flag) {
            switch (showMenu1()) {
                case 0 -> {
                    System.out.println("\033[34mКоллекция товаров\033[0m");
                    Store.show(store.getGoods());   // вывод коллекции
                }
                case 1 -> {
                    System.out.println("\033[34mпо наименованию товара\033[0m");
                    store.sortTitle();
                    Store.show(store.getGoods());
                }
                case 2 -> {
                    System.out.println("\033[34mпо убыванию цены\033[0m");
                    store.sortPrice();
                    Store.show(store.getGoods());
                }
                case 3 -> {
                    System.out.println("\033[34mтовары с минимальной ценой\033[0m");
                    Store.show(store.selectMinPrice());
                }
                case 4 -> {
                    System.out.println("\033[34mтовары с максимальной ценой\033[0m");
                    Store.show(store.selectMaxPrice());
                }
                case 5 -> {
                    System.out.println("\033[34mОбработка ошибки\033[0m");
                    Goods goods = new Goods("", 10, 10);
                }
                case 6 -> flag = false;
            }
        }
        } catch (Exception exc) {
            exc.printStackTrace();
        }
    }
}
