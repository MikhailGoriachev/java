package homework4.models.task1;

import java.util.*;

public class Store {
   List<Goods> goods;

    public List<Goods> getGoods() {
        return goods;
    }

    public void setGoods(List<Goods> goods) {
        this.goods = goods;
    }

    public Store() throws Exception {
        this.goods = new ArrayList<>(Arrays.asList(
                new Goods("порошок Ушастый нянь", 5, 247),
                new Goods("гель Gallus", 3, 744),
                new Goods("паста для стирки Пальмира", 10, 58),
                new Goods("салфетки Paclan Color", 50, 179),
                new Goods("порошок Sarma Active", 20, 130),
                new Goods("белизна Чистолюб", 15, 141),
                new Goods("кондиционер Power Wash", 5, 471),
                new Goods("порошок Ariel Color", 35, 744),
                new Goods("порошок Лотос-Волга", 20, 74),
                new Goods("средство Passion Gold", 18, 303),
                new Goods("средство для посуды Sarma", 30, 152),
                new Goods("паста для стирки Пальмира", 33, 58)
                ));
    }
    // •	вывод коллекции в консоль
    public static void show(List<Goods> list){
        top();
        list.forEach(System.out::println);
        System.out.println("------------------------------------------------------------");
    }
    public static void top(){
        System.out.print("""
                +--------------------------------+-------------+------------+
                |           Название             |  Количество |     Цена   |
                +--------------------------------+-------------+------------+
                """);
    }
    // сортировка по названию
    public void sortTitle(){
        goods.sort(Comparator.comparing(a -> a.title));
    }
    // сортировка по убыванию цены
    public void sortPrice(){
        goods.sort((a, b) -> b.price - a.price);
    }
    // формирование коллекции товаров с минимальной ценой
    public List<Goods> selectMinPrice(){
        int min = goods.stream().min(Comparator.comparing(i -> i.price)).get().price;
        List<Goods> list = new ArrayList<>();
        for (var item:goods){
            if (item.price == min){
                list.add(item);
            }
        }
        return list;
    }
    // формирование коллекции товаров с максимальной ценой
    public List<Goods> selectMaxPrice(){
        int max = goods.stream().max(Comparator.comparing(i -> i.price)).get().price;
        List<Goods> list = new ArrayList<>();
        for (var item:goods){
            if (item.price == max){
                list.add(item);
            }
        }
        return list;
    }
}
