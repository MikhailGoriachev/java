package homework4.models.task1;

public class Goods {
    String title;     // наименование товара
    int count;        // количество товара
    int price;        // цена единицы товара

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) throws Exception {
        if (title.equals("")){
            throw new Exception("\033[32mНет названия\033[0m");
        }
        else{
            this.title = title;
        }
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) throws Exception {
        if (count < 0){
            throw new Exception("\033[32mНе может быть меньше 0\033[0m");
        }
        else { this.count = count;}
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) throws Exception {
        if (price < 0){
            throw new Exception("\033[32mНе может быть меньше 0\033[0m");
        }
        else { this.price = price; }
    }

    public Goods(String title, int count, int price) throws Exception {
        this.setTitle(title);
        this.setCount(count);
        this.setPrice(price);
    }

    @Override
    public String toString() {
        return  String.format("| %-30s | %11s | %10s |", title, count, price);
    }
}
