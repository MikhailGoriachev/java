package homework4;

import homework4.controller.Task1Controller;
import homework4.controller.Task2Controller;

public class Main {
    public static void main(String[] args)
    {
        Task1Controller task1 = new Task1Controller();
        Task2Controller task2 = new Task2Controller();
        try {
            boolean flag = true;
            while (flag) {
                switch (Menu.showMenu()){
                    case 0 -> task1.task1();
                    case 1 -> task2.task2();
                    case 2 -> flag = false;
                }
            }
        } catch (Exception exc) {
            exc.printStackTrace();
        }
    }
}