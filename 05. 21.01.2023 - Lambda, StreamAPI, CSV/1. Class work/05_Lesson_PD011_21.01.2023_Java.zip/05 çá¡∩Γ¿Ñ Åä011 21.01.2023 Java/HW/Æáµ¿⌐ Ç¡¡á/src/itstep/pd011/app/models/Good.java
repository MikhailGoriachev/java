package itstep.pd011.app.models;

import itstep.pd011.app.utils.Utils;

/*Разработайте класс Goods, описывающий товар (наименование товара, количество товара, цена единицы товара)*/
public class Good {

    private final String title;
    private final int amount;
    private final int price;

    public String getTitle() {
        return title;
    }

    public int getAmount() {
        return amount;
    }

    public int getPrice() {
        return price;
    }

    public Good() {
        this.title = Utils.titles[Utils.getInt(0,Utils.titles.length-1)];
        this.amount = Utils.getInt(1,100);
        this.price = Utils.getInt(1000,50000);

    }

    public static int compare (Good g1, Good g2){
        if(g1.getPrice() > g2.getPrice())
            return 1;
        return -1;
    }

    @Override
    public String toString() {
        return "<tr>" +
                "<td>"+title+"</td>" +
                "<td>"+amount+"</td>" +
                "<td>"+price+"</td>" +
                "</tr>";
    }
}
