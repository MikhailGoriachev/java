package itstep.pd011.app.models;

import itstep.pd011.app.utils.Utils;

import java.security.InvalidParameterException;
import java.util.*;

public class Library {

    private final String title;//название
    private final String address;
    private final int maxAmount;
    private final HashMap<Integer,Book> bookHashMap;

    public String getTitle() {
        return title;
    }

    public String getAddress() {
        return address;
    }

    public int getMaxAmount() {
        return maxAmount;
    }

    //Количество книг в библиотеке
    public int getAmount() {

        int count = 0;

        for (var b:bookHashMap.values()) {
            count += b.getAmount();
        } // foreach

        return count;
    }

    public Library() {

        this.title = "Мир книг";
        this.address= "бул. Пушкина, 23, Донецк";
        this.maxAmount = 180;

        bookHashMap = new HashMap<>();

        for (int i = 0; i<12; i++ ){
            bookHashMap.put(i,new Book());
        }
    }

    public String show(List<Book> books){

        StringBuilder sb = new StringBuilder(Utils.headerBooks);

        books.forEach(sb::append);
        sb.append("</tbody></table>");

        return sb.toString();
    }

    //добавление данных о книгах, вновь поступающих в библиотеку;
    public void addBook() throws InvalidParameterException {

        Book newBook = new Book();

        if(getAmount() + newBook.getAmount() > maxAmount) throw new InvalidParameterException("Не хватает места для новых сведений о книгах! Добавление было отменено");

        bookHashMap.put(bookHashMap.size(),newBook);
    }

    //удаление данных о списываемых книгах;
    public void deleteBook() throws ArrayStoreException {

        if(bookHashMap.size() == 1) throw new ArrayStoreException("В библиотеке осталась последняя запись! Удаление было отменено");
        bookHashMap.remove(Utils.getInt(0,bookHashMap.size()-1));

        //перезаписываем HashMap так как значения удаляются, но индекс остается
        refresh();
    }

    private void refresh(){

        List<Book> list = new ArrayList<>(bookHashMap.values());

        bookHashMap.clear();

        for (int i = 0; i<list.size(); i++ ){
            bookHashMap.put(i,list.get(i));
        }
    }

    //выдача сведений о всех книгах, упорядоченных по фамилиям авторов;
    public List<Book> OrderByAuthor(){

        List<Book> list = new ArrayList<>(bookHashMap.values());

        Collections.sort(list,(o1,o2) -> o1.getAuthor().compareTo(o2.getAuthor()));

        return list;
    }

    //выдача сведений о всех книгах, упорядоченных по убыванию года издания;
    public List<Book> OrderByYear(){

        List<Book> list = new ArrayList<>(bookHashMap.values());

        Collections.sort(list, (b1,b2) -> b2.getYear() - b1.getYear());

        return list;
    }

    //выдача сведений о всех книгах, упорядоченных по возрастанию количества;
    public List<Book> OrderByAmount(){

        List<Book> list = new ArrayList<>(bookHashMap.values());

        Collections.sort(list, (b1,b2) -> b1.getAmount() - b2.getAmount());

        return list;
    }

    //выдача сведений о всех книгах, упорядоченных по названию.
    public List<Book> OrderByTitle(){

        List<Book> list = new ArrayList<>(bookHashMap.values());

        Collections.sort(list,(o1,o2) -> o1.getTitle().compareTo(o2.getTitle()));

        return list;
    }
}
