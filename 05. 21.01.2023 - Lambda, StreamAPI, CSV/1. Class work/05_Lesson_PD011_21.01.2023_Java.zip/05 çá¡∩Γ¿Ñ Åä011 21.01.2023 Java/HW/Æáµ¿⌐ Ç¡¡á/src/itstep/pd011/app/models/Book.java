package itstep.pd011.app.models;

import  itstep.pd011.app.utils.Utils;

//Сведения о книгах содержат: числовой идентификатор книги, фамилию и инициалы автора, название, год издания,
// количество экземпляров данной книги в библиотеке.
public class Book {

    private final int index;
    private final String author;
    private final String title;
    private final int year;
    private final int amount;

    public int getIndex() {
        return index;
    }
    public String getAuthor() {
        return author;
    }
    public String getTitle() {
        return title;
    }
    public int getYear() {
        return year;
    }
    public int getAmount() {
        return amount;
    }

    public Book() {
        this.index = Utils.getInt(10000,90000);
        this.author = Utils.authors[Utils.getInt(0,Utils.authors.length-1)];
        this.title = Utils.titlesBooks[Utils.getInt(0,Utils.titlesBooks.length-1)];
        this.year = Utils.getInt(1980,2023);
        this.amount = Utils.getInt(10,15);
    }

    @Override
    public String toString() {
        return "<tr>" +
                "<td>"+index+"</td>" +
                "<td>"+author+"</td>" +
                "<td>"+title+"</td>" +
                "<td>"+year+"</td>" +
                "<td>"+amount+"</td>" +
                "</tr>";
    }
}
