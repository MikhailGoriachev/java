package itstep.pd011.app.models;

import itstep.pd011.app.utils.Utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

// класс Store для хранения коллекции товаров
public class Store {

    private final List<Good> goodList;

    public List<Good> getGoodList() {
        return goodList;
    }

    public Store() {
        goodList = new ArrayList<>();

        for (int i = 0; i<12; i++ ){
            goodList.add(new Good());
        }
    }

    public String show(List<Good> list){

        StringBuilder sb = new StringBuilder(Utils.headerGoods);

        list.forEach(sb::append);
        sb.append("</tbody></table>");

        return sb.toString();
    }

    //упорядочивание коллекции по наименованию товара;
    public void OrderByTitle(){

        goodList.sort((g1, g2) -> g1.getTitle().compareTo(g2.getTitle()));
        //goodList.sort(Comparator.comparing(Good::getTitle));
    }

    //упорядочивание коллекции по убыванию цены единицы товара;
    public void OrderByPrice(){

        goodList.sort((g1, g2) -> g2.getPrice()- g1.getPrice());
    }

    //формирование коллекции товаров с минимальной ценой;
    public int findMinPrice(){

       return goodList.stream().min(Good::compare).get().getPrice();
    }

    //формирование коллекции товаров с максимальной ценой.
    public int findMaxPrice(){
        // return Collections.max(goodList, new Comparator<Good>());
        return goodList.stream().max(Good::compare).get().getPrice();
    }

    //Выборка товаров с минимальной ценой/максимальной ценой
    public List<Good> select(int price){

        List<Good> list = new ArrayList<>();

        goodList.forEach(g ->  {
            if(g.getPrice() == price) list.add(g);
        });

        return list;
    }
}
