package itstep.pd011.app.controllers;

import itstep.pd011.app.models.Store;
import itstep.pd011.app.utils.Utils;

import javax.swing.*;

public class Task01Controller {

    private final Store store;

    public Task01Controller() {
        this.store = new Store();
    }

    // работа по заданию
    public void run() {

        Utils.showMessage(store.show(store.getGoodList()),"Вывод коллекции товаров");

        store.OrderByTitle();
        Utils.showMessage(store.show(store.getGoodList()),"Упорядочивание по наименованию");

        store.OrderByPrice();
        Utils.showMessage(store.show(store.getGoodList()),"Упорядочивание по убыванию цены ");

        int min = store.findMinPrice();
        int max = store.findMaxPrice();

        Utils.showMessage(store.show(store.select(min)),"Товары с минимальной ценой ");
        Utils.showMessage(store.show(store.select(max)),"Товары с максимальной ценой ");
    }

}
