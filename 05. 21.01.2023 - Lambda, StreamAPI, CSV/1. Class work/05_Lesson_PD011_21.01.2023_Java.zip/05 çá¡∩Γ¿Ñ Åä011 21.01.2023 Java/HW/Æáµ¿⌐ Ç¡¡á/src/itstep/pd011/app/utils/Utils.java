package itstep.pd011.app.utils;

import javax.swing.*;
import java.util.Random;

public class Utils
{
    // случайное целочисленное число
    public static int getInt(int min, int max) {
        return new Random().nextInt(min, max);
    }

    // случайное вещественное число
    public static double getDouble(double min, double max) {
        return min + (max - min) * new Random().nextDouble();
    }

    // вывод сообщения об ошибке
    public static void showErrorMessage(String message, String title) {
        JOptionPane.showMessageDialog(null, message, title, JOptionPane.ERROR_MESSAGE);
    }

    // вывод данных в окно
    public static void showMessage(String message, String title) {
        JOptionPane.showOptionDialog(
                null,
                message,
                title,
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(),
                new Object[] {"Далее"},
                "Далее"
        );
    }

    public static String [] titles ={ "Клавиатура", "Ноутбук", "Телевизор", "Фен", "Триммер",
            "Весы", "Пульсоксиметр", "Батарейка",
            "Шагомер", "Принтер", "3D-ручка", "Wi-Fi роутер", "Маршрутизатор", "Электроочаг", "Видеокарта",
            "Блок питания", "Жесткий диск",
            "Сетевая карта", "IP-камера", "Муляж камеры"};

    public static String[] authors = {"Пономарев Р. М.","Орлов К. Н.","Майорова Я. Е.","Михайлова О. Д.","Дроздов М. Е.",
            "Павлов Е. К.","Пугачев И. И.","Богданов Е. И.","Зуев Д. Д.","Попова В. А.",
            "Латышев А. Г.","Гончаров А. Д.","Захарова А. Ф.","Колесникова А. И.","Козин Е. А.",
            "Иванова Д. Д.","Овчинников Р. К.","Фомина С. К.","Толкачева В. Д.","Лебедева С. Е."};

    public static String[] titlesBooks = {
            "Игра богов","Последний шаг","Воскресший закат","Путь к славе","Откровения",
            "Путь к звездам","Химическая реакция","Вечный дождь","Пульсация","Вторая жизнь",
            "После заката","Судьба мира","Серый кот","Сквозь ладони","Новый горизонт",
            "Звездная карта","Невеста барда","Одна на двоих","Странные сны","Морской бой"
    };

    public static String headerGoods =
            "<html><table border='1' >" +
                    "<thead><tr>" +
                    "<th>Наименование</th>" +
                    "<th>Количество</th>" +
                    "<th>Цена</th>" +
                    "</tr></thead><tbody>";

    public static String headerBooks =
            "<html><table border='1' >" +
                    "<thead><tr>" +
                    "<th>Id</th>" +
                    "<th>Автор</th>" +
                    "<th>Название</th>" +
                    "<th>Год издания</th>" +
                    "<th>Количество</th>" +
                    "</tr></thead><tbody>";
}
