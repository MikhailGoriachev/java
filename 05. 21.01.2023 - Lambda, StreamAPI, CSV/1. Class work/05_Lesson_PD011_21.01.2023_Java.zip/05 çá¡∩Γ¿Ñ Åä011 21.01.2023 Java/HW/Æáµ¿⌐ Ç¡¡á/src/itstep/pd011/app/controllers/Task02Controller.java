package itstep.pd011.app.controllers;

import itstep.pd011.app.Main;
import itstep.pd011.app.models.Library;
import itstep.pd011.app.utils.Utils;

import javax.swing.*;
import java.security.InvalidParameterException;

public class Task02Controller {

    private final Library library;

    public Task02Controller() {
        library = new Library();
    }

    // работа по заданию
    public void run() {

        while (true) {
            try {
            switch (showMenu()) {

                case 0:
                    Utils.showMessage(library.show(library.OrderByAuthor()), "Книги упорядоченных по фамилиям авторов");
                    break;

                case 1:
                    Utils.showMessage(library.show(library.OrderByYear()), "Книги упорядоченных по убыванию года");
                    break;


                case 2:
                    Utils.showMessage(library.show(library.OrderByAmount()), "Книги упорядоченных по количеству");
                    break;


                case 3:
                    Utils.showMessage(library.show(library.OrderByTitle()), "Книги упорядоченных по названию");
                    break;

                case 4:
                    library.addBook();
                    Utils.showMessage("<html><h2 style = 'color: green'>Книги были успешно добавлены</h2>", "Добавление книг");
                    break;

                case 5:
                    library.deleteBook();
                    Utils.showMessage("<html><h2 style = 'color: green'>Книги были успешно удалены</h2>", "Удаление книг");
                    break;


                // выход
                default:
                    return;

                } // switch
            } // try
            catch (InvalidParameterException ex) {
                Utils.showMessage("<html><h2 style = 'color: red'>" + ex.getMessage() + "</h2>", "Ошибка добавления");
            }
            catch (ArrayStoreException ex) {
                Utils.showMessage("<html><h2 style = 'color: red'>" + ex.getMessage() + "</h2>", "Ошибка удаления");
            }
        } // while
    } //

    // вывод окна меню
    public int showMenu() {
        return JOptionPane.showOptionDialog(
                null,
                "<html><h1>"+library.getTitle()+"</h1>" +
                "<p>"+library.getAddress()+"<br> Макс кол-во книг: "+library.getMaxAmount()+
                        "<br>Текущее кол-во книг: "+library.getAmount() +"</p>",
                "Меню второго задания",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(Main.class.getResource("../../../images/library.png")),
                new Object[] {"По фамилиям", "По убыванию года", "По количеству" ,"По названию", "Добавление", "Удаление", "Выход"},
                "Выход"
        );
    }
}
