package app.interfaces;

// Интерфейс для контроллера
public interface IController {
    
    // запуск обработки
    void run() throws Exception;
}
