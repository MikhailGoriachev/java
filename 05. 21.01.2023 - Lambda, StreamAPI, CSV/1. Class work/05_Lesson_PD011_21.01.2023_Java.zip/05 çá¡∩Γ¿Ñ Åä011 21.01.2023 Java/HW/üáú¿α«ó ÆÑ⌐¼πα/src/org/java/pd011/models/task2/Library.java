package org.java.pd011.models.task2;


// класс Library, описывающий библиотеку, имеет следующие поля:
// - название
// - адрес
// - максимальное количество хранимых книг
// - коллекция сведения о книгах

import org.java.pd011.infrastructure.Utils;
import org.java.pd011.models.task1.Good;

import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.List;

public class Library {

    // название
    private String name;

    // адрес
    private String address;

    // максимальное количество хранимых книг
    private int maxNumberKept;

    // коллекция книг
    private List<Book> books = new ArrayList<>();


    // конструктор по умолчанию
    public Library(){this(12);}

    // конструкторы с парамметрами
    public Library(int n) {
        // if (n <= 0) throw new InvalidParameterException("Заданно некорректное количество элементов");
        // if(books.isEmpty()) books.clear();
        // for (int i = 0; i < n; i++) books.add(/*Utils.getBook()*/);
    } // Library

    public Library(List<Book> books) {
        this.books = books;
    } // Library


    // переопределение метода toString()
    @Override
    public String toString() {
        return "Library{" +
                "name='" + name + '\'' +
                ", address='" + address + '\'' +
                ", maxNumberKept=" + maxNumberKept +
                ", books=" + books +
                '}';
    } // toString

} // class Library
