package org.java.pd011.models.task1;

import org.java.pd011.infrastructure.Utils;

import java.lang.reflect.Array;
import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

// Класс Store для хранения коллекции товаров. Реализуте следующий функционал:
//        •	формирование коллекции (начальное заполнение коллекции, не менее 12 записей);
//        •	вывод коллекции в консоль;
//        •	упорядочивание коллекции по наименованию товара;
//        •	упорядочивание коллекции по убыванию цены единицы товара;
//        •	формирование коллекции товаров с минимальной ценой;
//        •	формирование коллекции товаров с максимальной ценой.
public class Store {

    private List<Good> goods = new ArrayList<>();


    public Store(){ this(12); }

    public Store(int n){ Initialize(n); }
    // конструктор c параметрами

    public Store(List<Good> goods) {
        this.goods = goods;
    } // Store

    public List<Good> getGoods() { return goods; }


    // случайное формирование коллекции товаров
    public void Initialize(int n) {
        if (n <= 0) throw new InvalidParameterException("Заданно некорректное количество элементов");
        if(goods.isEmpty()) goods.clear();
        for (int i = 0; i < n; i++) goods.add(Utils.getGood());

        var comparer = new Comparator<Good>() {
            @Override
            public int compare(Good o1, Good o2) {
                return Double.compare(o1.getPrice(), o2.getPrice());
            }
        };

        // сами добавляем еще один элемент с минимальной ценной,
        // чтобы при выборке выовдилось хотя бы два элемента
        // Collections
        Good good = Collections.min(goods, comparer);
        goods.add(good);

        // сами добавляем еще один элемент с максимальной ценной,
        // чтобы при выборке выовдилось хотя бы два элемента
        good = Collections.max(goods, comparer);
        goods.add(good);
    } // Initialize

    public static String toHeader() {
        return """
                \t┌──────────────────┬────────────┬────────────────────────┐
                \t│   Наименование   │ Количество │ Цена за единицу товара │
                \t├──────────────────┼────────────┼────────────────────────┤
                """;}

    public static String toFooter(){return "\t└──────────────────┴────────────┴────────────────────────┘\n";}

} // class Store
