package org.java.pd011;

import org.java.pd011.controllers.Task1Controller;
import org.java.pd011.controllers.Task2Controller;

import javax.swing.*;
import java.security.InvalidParameterException;
import java.util.Locale;


public class Main {
        public static void main(String[] args) {
            try {

                while (true) {
                    switch (showMenu()) {
                        case 0 -> Task1Controller.run();
                        case 1 -> Task2Controller.run();
                        default -> {
                            System.out.println("\n\t\t\033[35mвыход из приложения, до встречи!\033[0m");
                            return;
                        }
                    } // switch
                } // while
            } catch(Exception e){
                System.out.printf(Locale.UK, """

                        \t\033[1;35mERROR:\033[31m %s\033[1;35m
                        \tСтек возникшего исключения:
                        \t""", e.getMessage());
                e.printStackTrace();
                System.out.print("\033[0m");
            }
        }


        public static int showMenu() {
            return JOptionPane.showOptionDialog(
                    null,
                    "<html><h3>Выберите <u>пункт</u> меню:</h3>",
                    "Решения задач",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    new ImageIcon(Main.class.getResource("images/choice.png")),
                    new Object[]{"Класс Store", "Класс Library", "Выход"},
                    "Выход"
            );
        } // showMenu

}