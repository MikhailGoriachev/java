package org.java.pd011.controllers;

import org.java.pd011.models.task2.Library;

import javax.swing.*;

public class Task2Controller {

    Library library = new Library();

    public Task2Controller(){}

    public static void run(){
        JOptionPane.showMessageDialog(null, "Все еще в разработке :( ");
    } // run
}
