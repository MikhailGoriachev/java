package org.java.pd011.models.task2;


// Класс Book, описывающий книгу, содержит следующие поля:
// - числовой идентификатор книги
// - фамилию и инициалы автора
// - название
// - год издания
// - количество экземпляров данной книги в библиотеке.
public class Book {
    // числовой идентификатор
    private int id;

    // Ф.И.О автора
    private String fioAuthor;

    // название
    private String name;

    // год издания
    private int yearIssue;

    // количество экземпляров
    private int amount;

    // конструктор
    public Book(int id, String fioAuthor, String name, int yearIssue, int amount) {
        this.id = id;
        this.fioAuthor = fioAuthor;
        this.name = name;
        this.yearIssue = yearIssue;
        this.amount = amount;
    } // Book

    // переопределение метода toString()
    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", fioAuthor='" + fioAuthor + '\'' +
                ", name='" + name + '\'' +
                ", yearIssue=" + yearIssue +
                ", amount=" + amount +
                '}';
    } // toString
} // class Book

