package org.java.pd011.infrastructure;

import java.util.List;
import java.util.Random;
import org.java.pd011.models.task1.Good;

public class Utils {
    private static final Random random = new Random();

    // формирование случайных чисел типа int
    public static int getRandom(int lo, int hi) {
        return lo + random.nextInt(hi - lo);
    }  // getRandom

    // формирование случайных чисел типа double
    public static double getRandom(double lo, double hi) {
        return lo + (hi - lo)*random.nextDouble();
    }  // getRandom

    // ------------------- вспомогательные методы для для решения конкретных задач -------------------

    // генерация объекта Good
    public static Good getGood(){
        String[] name = {"чай", "кофе", "кола", "сухарики", "кефир", "молоко", "тан", "айран", "бекон", "вода"};
        return new Good(name[getRandom(0, name.length)], getRandom(1, 51), getRandom(100f, 10001f));
        // return new Good(name[getRandom(0, name.length)], getRandom(1, 51), getRandom(-11f, 1));
    } // getGood

    // минимальная цена в коллекции товаров
    public static double minPrice(List<Good> lg){
        double min = Double.MAX_VALUE;

        for (Good good : lg) if (good.getPrice() < min) min = good.getPrice();

        return min;
    }// minPrice

    public static double maxPrice(List<Good> lg) {
        double max = Double.MIN_VALUE;

        for (Good good : lg) if (good.getPrice() > max) max = good.getPrice();

        return max;
    } // maxPrice
}
