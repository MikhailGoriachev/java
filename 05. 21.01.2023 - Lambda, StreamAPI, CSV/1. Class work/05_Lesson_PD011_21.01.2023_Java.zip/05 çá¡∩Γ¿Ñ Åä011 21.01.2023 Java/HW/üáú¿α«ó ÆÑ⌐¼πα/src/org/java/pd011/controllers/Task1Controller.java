package org.java.pd011.controllers;

import org.java.pd011.infrastructure.Utils;
import org.java.pd011.models.task1.Good;
import org.java.pd011.models.task1.Store;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;

public class Task1Controller {

    private Store store = new Store();

    public Task1Controller() { }

    public Task1Controller(Store store) { this.store = store; }

    // случайное формирование коллекции Store
    public void fillStore(int n){ store.Initialize(n); }


    // вывод коллекции Store
    public String show(String title) {
        StringBuffer sbf = new StringBuffer(title+"\n");
        sbf.append(Store.toHeader());

        // анонимный класс
        store.getGoods().forEach(new Consumer<Good>() {
            @Override
            public void accept(Good item){ sbf.append("\t").append(item.toTableRow()).append("\n"); }
        });

        // лямбда-выражение
        // store.getGoods().forEach((item) -> sbf.append("\t").append(item.toTableRow()).append("\n"));

        sbf.append(Store.toFooter());
        return sbf.toString();
    } // show

    // вывод коллекции Store
    public String show(List<Good> lg, String title) {
        StringBuffer sbf = new StringBuffer(title+"\n");
        sbf.append(Store.toHeader());

        // анонимный класс
        lg.forEach(new Consumer<Good>() {
            @Override
            public void accept(Good item){ sbf.append("\t").append(item.toTableRow()).append("\n"); }
        });

        // лямбда-выражение
        // store.getGoods().forEach((item) -> sbf.append("\t").append(item.toTableRow()).append("\n"));

        sbf.append(Store.toFooter());
        return sbf.toString();
    } // show

    // сортировка коллекции по наименованию товара
    public void orderByName(){
        // анонимный класс
        store.getGoods().sort(new Comparator<Good>() {
            @Override
            public int compare(Good o1, Good o2) { return o1.getName().compareTo(o2.getName()) ; }
        });

        // лямбда-выражение
        // store.getGoods().sort(((item1, item2) -> item1.getName().compareTo(item2.getName())));
    } // orderByName

    // сортировка коллекции по убыванию цены за единицу товаара
    public void orderByPrice(){
        // анонимный класс
        store.getGoods().sort(new Comparator<Good>() {
            @Override
            public int compare(Good o1, Good o2) { return Double.compare(o2.getPrice(),o1.getPrice()); }
        });

        // лямбда-выражение
        // store.getGoods().sort(((item1, item2) -> Double.compare(item2.getPrice(), item1.getPrice())));
    } // orderByPrice

    // выборка в новую коллекцию товаров с минимальной ценной за единиуц товара
    public List<Good> selectGoodsMinPrice(){
        double minPrice = Utils.minPrice(store.getGoods());
        List<Good> minPriceGoods = new ArrayList<>();

        store.getGoods().forEach(item ->{
            // Math.abs(minPrice - item.getPrice()) < 1e-3
            if(Double.compare(minPrice, item.getPrice()) == 0) minPriceGoods.add(item);
        });

        return minPriceGoods;
    } // selectGoodsMinPrice

    // выборка в новую коллекцию товаров с максимальной ценной за единиуц товара
    public List<Good> selectGoodsMaxPrice(){
        double maxPrice = Utils.maxPrice(store.getGoods());
        List<Good> maxPriceGoods = new ArrayList<>();

        store.getGoods().forEach(item ->{
            if(Double.compare(maxPrice, item.getPrice()) == 0) maxPriceGoods.add(item);
        });

        return maxPriceGoods;
    } // selectGoodsMinPrice

    // возможно стоило создать класс Application и там демонстрировать выполнение задания
    public static void run() {
        Task1Controller taskController = new Task1Controller();

        System.out.println("\n\n\033[33m" + taskController.show("\t\t\t\t\t\033[1;35mИсходная коллекция товаров\033[0;033m") + "\033[m");

        taskController.orderByName();
        System.out.println("\033[33m" + taskController.show("\t\t\t\033[1;35mКоллекция упорядоченна по наименованию товаров\033[0;033m") + "\033[m");

        taskController.orderByPrice();
        System.out.println("\033[33m" + taskController.show("\t\t\033[1;35mКоллекция упорядоченна по убыванию цены за единицу товара\033[0;033m") + "\033[m");

        List<Good> minPriceGoods = new ArrayList<>(taskController.selectGoodsMinPrice());
        System.out.println(
                "\033[33m" +
                taskController.show(
                        minPriceGoods,
                        "\t\t\033[1;35mКоллекция с товарами с минимальной ценной (\" + String.format(\"%.2f\",maxPriceGoods.get(0).getPrice()) +\" ₽)\033[0;033m")
                + "\033[m");

        List<Good> maxPriceGoods = new ArrayList<>(taskController.selectGoodsMaxPrice());
        System.out.println(
                "\033[33m" +
                taskController.show(
                        maxPriceGoods,
                        "\t\t\033[1;35mКоллекция с товарами с максимальной ценной (" + String.format("%.2f",maxPriceGoods.get(0).getPrice()) +" ₽)\033[0;033m")
                + "\033[m");
    } // run

} // Task1Controller
