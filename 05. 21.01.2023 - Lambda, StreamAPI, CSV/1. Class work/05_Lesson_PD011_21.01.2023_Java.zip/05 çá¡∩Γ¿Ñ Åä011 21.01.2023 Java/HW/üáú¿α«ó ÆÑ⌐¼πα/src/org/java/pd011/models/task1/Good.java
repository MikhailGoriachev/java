package org.java.pd011.models.task1;

import java.security.InvalidParameterException;

// Класс Goods, описывающий товар (наименование товара, количество товара, цена единицы товара)
public class Good {

    // наименование товара
    private String name;

    // количество товара
    private int amount;

    // цена единицы товара
    private double price;


    // конструктор по умолчанию
    public Good(){ this("Каркаде", 22, 222);}

    // конструктор с параметрами
    public Good(String name, int amount, double price) {
        setName(name);
        setAmount(amount);
        setPrice(price);
    } // Goods

    // ----------------- аксессоры -----------------

    // наименование товара
    public String getName() {return name;}
    public void setName(String name) {
        if (name.isEmpty() || name.isBlank()) throw new InvalidParameterException ("Некорректное именование товара");
        this.name = name;
    } // setName


    // количество товара
    public int getAmount() { return amount; }
    public void setAmount(int amount) {
        if (amount < 0) throw new InvalidParameterException ("Некорректное количество товара");

        this.amount = amount;
    } // setAmount


    // цена единицы товара
    public double getPrice() { return price; }
    public void setPrice(double price) {
        if (price <= 0) throw new InvalidParameterException ("Некорректная цена товара");

        this.price = price;
    } // setPrice

    // вывод товара в формате строки таблицы
    public String toTableRow() {
        return String.format("│ %-16s │ %10d │ %20.2f ₽ │", name, amount, price);
    } // toTableRow

    // переопределение метода toString()
    @Override
    public String toString() {
        return "Goods{" +
                "name='" + name + '\'' +
                ", amount=" + amount +
                ", price=" + price +
                '}';
    } // toString
} // class Goods
