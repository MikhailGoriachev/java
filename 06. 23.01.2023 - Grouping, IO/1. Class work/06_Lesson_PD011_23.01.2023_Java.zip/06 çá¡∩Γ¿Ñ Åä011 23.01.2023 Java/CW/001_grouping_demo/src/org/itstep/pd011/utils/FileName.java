package org.itstep.pd011.utils;

import java.security.InvalidParameterException;

// вспомогательный класс для проверки того, что строка - правильное имя файла
public class FileName {


} // class FileName
