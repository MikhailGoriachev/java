
package itstep.pd011.app;

import itstep.pd011.app.controllers.Task02Controller;
import itstep.pd011.app.controllers.Task01Controller;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {

        Task01Controller t1 = new Task01Controller();
        Task02Controller t2 = new Task02Controller();

        while (true) {

            switch (showMenu()) {

                case 0 -> t1.run();
                case 1 -> t2.run();

                // выход
                default -> {
                    return;
                }
            }
        }

    }

    // вывод окна меню
    public static int showMenu() {
        return JOptionPane.showOptionDialog(
                null,
                "<html><h1>Меню</h1>",
                "Домашнее задание на 23.01.2023",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(Main.class.getResource("../../../images/fish.png")),
                new Object[] {"Задание 1", "Задание 2", "Выход"},
                "Выход"
        );
    }

}