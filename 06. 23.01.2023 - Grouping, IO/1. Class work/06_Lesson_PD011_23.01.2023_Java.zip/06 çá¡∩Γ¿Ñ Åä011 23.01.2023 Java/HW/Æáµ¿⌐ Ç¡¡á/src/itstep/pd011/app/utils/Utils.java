package itstep.pd011.app.utils;

import javax.swing.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class Utils {

    // случайное целочисленное число
    public static int getInt(int min, int max) {
        return new Random().nextInt(min, max);
    }

    // случайное вещественное число
    public static double getDouble(double min, double max) {
        return min + (max - min) * new Random().nextDouble();
    }

    // вывод сообщения об ошибке
    public static void showErrorMessage(String message, String title) {
        JOptionPane.showMessageDialog(null, message, title, JOptionPane.ERROR_MESSAGE);
    }

    // вывод данных в окно
    public static void showMessage(String message, String title) {
        JOptionPane.showOptionDialog(
                null,
                message,
                title,
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(),
                new Object[]{"Далее"},
                "Далее"
        );
    }

    public static String showSelect(String message, String title, Object[] strings) {
      return (String) JOptionPane.showInputDialog(
                null,
                message,
                title,
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(),
                strings,
                "Отмена"
        );
    }

    public static String getDouble(double start_value){
        double value = start_value;
        return JOptionPane.showInputDialog(null, "Введите вещественное число (целое.дробное)", value);
    }

    public static String getInt(int start_value){
        int value = start_value;
        return  JOptionPane.showInputDialog(null, "Введите целое число", value);
    }

    public static String[] firstNamesFemale = {
            "Екатерина","Елизавета","Медина","Василиса","Виктория",
            "Арина","Ника","Элина","Варвара","Полина"};
    public static String[] firstNamesMale = {
            "Константин","Илья","Андрей","Георгий","Артём",
            "Богдан","Кирилл","Ян","Марк","Алексей"};

    public static String[] secondNamesFemale = {
            "Котова","Дьяконова","Степанова","Кузнецова","Антонова",
            "Щербакова","Васильева","Ильинская","Никитина","Ершова"};

    public static String[] secondNamesMale = {
            "Николаев","Лавров","Морозов","Колесников","Абрамов",
            "Кузнецов","Худяков","Громов","Григорьев","Тихонов"};

    public static String[] cityNames = {
            "Амвросиевка","Белицкое","Горловка","Дебальцево","Докучаевск",
            "Донецк","Дружковка","Енакиево","Ждановка","Зугрэс",
            "Иловайск","Константиновка","Краматорск","Курахово","Макеевка",
            "Мариуполь","Новоазовск","Снежное","Торез","Харцызск"};

    public static String headerPeople =
            "<html><table border='1' >" +
                    "<thead><tr>" +
                    "<th>Фамилия</th>" +
                    "<th>Имя</th>" +
                    "<th>Возраст</th>" +
                    "<th>Город</th>" +
                    "<th>Рост</th>" +
                    "</tr></thead><tbody>";

    public static String headerCities =
            "<html><table border='1' >" +
                    "<thead><tr>" +
                    "<th>Город</th>" +
                    "</tr></thead><tbody>";
}
