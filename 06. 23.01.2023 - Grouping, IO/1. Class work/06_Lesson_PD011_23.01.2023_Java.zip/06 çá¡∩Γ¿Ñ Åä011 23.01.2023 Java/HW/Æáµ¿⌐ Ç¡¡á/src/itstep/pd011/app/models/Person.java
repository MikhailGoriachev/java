package itstep.pd011.app.models;

import itstep.pd011.app.utils.Utils;
public class Person {

    String secondName; //фамилия
    String firstName; //имя
    int age;//возраст
    String city;//название города
    double height;//рост

    public String getSecondName() {
        return secondName;
    }

    public String getFirstName() {
        return firstName;
    }

    public int getAge() {
        return age;
    }

    public String getCity() {
        return city;
    }

    public double getHeight() {
        return height;
    }

    public Person(String secondName, String firstName, int age, String city, double height) {
        this.secondName = secondName;
        this.firstName = firstName;
        this.age = age;
        this.city = city;
        this.height = height;
    }

    public Person() {

        int g = Utils.getInt(0,2);

        if(g == 0){
            this.firstName = Utils.firstNamesMale[Utils.getInt(0,Utils.firstNamesMale.length-1)];
            this.secondName = Utils.secondNamesMale[Utils.getInt(0,Utils.secondNamesMale.length-1)];

        }else {
            this.firstName = Utils.firstNamesFemale[Utils.getInt(0,Utils.firstNamesFemale.length-1)];
            this.secondName = Utils.secondNamesFemale[Utils.getInt(0,Utils.secondNamesFemale.length-1)];
        }

        this.age = Utils.getInt(18,65);
        this.city = Utils.cityNames[Utils.getInt(0,Utils.cityNames.length-1)];
        this.height = Utils.getDouble(1.6,2.1);

    }

    // фабричный метод - формируем объект Person из строки файла данных
    public static Person parsePerson(String str) {
        String[] tokens = str.split(";");
        return new Person(tokens[0], tokens[1], Integer.parseInt(tokens[2]), tokens[3], Double.parseDouble(tokens[4]));
    } // parsePerson

    @Override
    public String toString() {
        return "<tr>" +
                "<td>"+secondName+"</td>"+
                "<td>"+firstName+"</td>"+
                "<td>"+age+"</td>"+
                "<td>"+city+"</td>"+
                "<td>"+String.format("%.1f",height)+"</td>"+
                "</tr>";
    }
}
