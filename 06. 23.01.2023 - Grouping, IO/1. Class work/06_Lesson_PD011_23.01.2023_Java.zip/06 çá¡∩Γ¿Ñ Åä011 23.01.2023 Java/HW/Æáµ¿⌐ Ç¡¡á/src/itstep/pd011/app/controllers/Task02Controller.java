package itstep.pd011.app.controllers;

import itstep.pd011.app.Main;
import itstep.pd011.app.models.Person;
import itstep.pd011.app.utils.Utils;

import javax.swing.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.stream.Collectors;

public class Task02Controller {

    private List<Person> people;
    private static final String FILENAME = "people.csv";
    private static final int N = 15;

    public Task02Controller() {

        people = new ArrayList<>();

        try {
            if (Files.notExists(Paths.get(FILENAME))) {
                fill();
                write();
            } else {
                load();
            }

        } catch (Exception ex) {
        ex.printStackTrace();
        } // try-catch

    }

    private void fill(){

        for (int i = 0; i<N; i++){
            people.add(new Person());
        }

    }

    public String show(List<Person> list){

        StringBuilder sb = new StringBuilder(Utils.headerPeople);

        list.forEach(sb::append);
        sb.append("</tbody></table>");

        return sb.toString();
    }

    // загрузка данных из файла в формате CSV
    private void load() throws IOException{
        List<String> text = new ArrayList<>();
        people.clear();  // формируем новую коллекцию

        // читаем текстовый файл одной операцией
        text = Files.readAllLines(Paths.get(FILENAME), StandardCharsets.UTF_8);

        text.forEach(str -> people.add(Person.parsePerson(str)));
    }

    // вывод коллекции в файл формата CSV
    public void write() throws IOException {
        List<String> lines = new ArrayList<>();
        people.forEach(p->lines.add(
                String.format(Locale.UK, "%s;%s;%d;%s;%f",p.getSecondName(),p.getFirstName(),p.getAge(),p.getCity(),p.getHeight())
        ));

        Files.write(Paths.get(FILENAME), lines, StandardCharsets.UTF_8);
    }

    // работа по заданию
    public void run() {

        try {
            while (true) {

                switch (showMenu()) {

                    case "Города, по алфавиту":

                        //Вывести список городов, упорядоченный по алфавиту
                        StringBuilder sb = new StringBuilder(Utils.headerCities);

                        people.stream().map(Person::getCity).distinct()
                                .sorted().toList().forEach(p -> sb.append("<tr><td>" + p + "</tr></td>"));

                        sb.append("</tbody></table>");
                        Utils.showMessage(sb.toString(), "Города, по алфавиту");
                        break;

                    case "Жители, по алфавиту":
                        //Вывести список жителей, упорядоченный по алфавиту
                        Utils.showMessage(show(people
                                .stream()
                                .sorted((p1, p2) -> p1.getSecondName().compareTo(p2.getSecondName()))
                                .toList()), "Жители, упорядоченные по алфавиту");
                        break;

                    case "Жители, по убыванию возраста":
                        //Вывести список жителей, упорядоченный по убыванию возраста
                        Utils.showMessage(show(people
                                .stream()
                                .sorted((p1, p2) -> p2.getAge() - p1.getAge())
                                .toList()), "Жители, упорядоченные по убыванию возраста");
                        break;

                    case "Жители, по росту":
                        //Вывести список жителей по росту
                        Utils.showMessage(show(people
                                .stream()
                                .sorted((p1, p2) -> Double.compare(p1.getHeight(), p2.getHeight()))
                                .toList()), "Вывести список жителей по росту ");
                        break;

                    case "Добавить":
                        // добавление записи в коллекцию (с перезаписью файла данных)
                        //Добавляемую запись формируйте фабричным методом
                        Person newPerson = new Person();

                        people.add(newPerson);
                        write(); // (с перезаписью файла данных)

                        Utils.showMessage(Utils.headerPeople + newPerson + "</tbody></table>", "Добавление новой записи");
                        break;

                    case "Удалить":
                        //удаление записи из коллекции (с перезаписью файла данных).
                        Utils.showMessage(Utils.headerPeople + people.remove(Utils.getInt(0,people.size()-1)) + "</tbody></table>", "Удаление записи");
                        write(); // (с перезаписью файла данных)
                        break;

                    case "Жители с заданной фамилией":
                        //Выбрать жителей с заданной фамилией

                        String second  = Utils.showSelect("<html><br><h2>Выберите фамилию</h2>","Выбрать жителей с заданной фамилией ",
                                people.stream().map(Person::getSecondName).distinct()
                                        .sorted().toArray());

                        if(second == null) break;

                        Utils.showMessage(show(people
                                .stream()
                                .filter(p-> Objects.equals(p.getSecondName(), second))
                                .toList()), "Жители с заданной фамилией");
                        break;

                    case "Города, в которых есть жители с заданной фамилией":
                        //Выбрать города, в которых есть жители с заданной фамилией

                        String secondName  = Utils.showSelect("<html><br><h2>Выберите фамилию</h2>","Выбрать города, в которых есть жители с заданной фамилией",
                                people.stream().map(Person::getSecondName).distinct()
                                        .sorted().toArray());

                        if(secondName == null) break;

                        StringBuilder s = new StringBuilder(Utils.headerCities);

                        people.stream()
                                .filter(p-> Objects.equals(p.getSecondName(), secondName))
                                .map(Person::getCity).distinct()
                                .toList().forEach(p -> s.append("<tr><td>" + p + "</tr></td>"));

                        s.append("</tbody></table>");
                        Utils.showMessage(s.toString(), "Города, в которых есть жители с заданной фамилией");
                        break;

                    case "Города, в которых есть жители с заданным диапазоном роста":
                        //Выбрать города, в которых есть жители с заданным диапазоном роста
                        String height = Utils.getDouble(1.8);
                        if(height == null) break;

                        double height_lo = Double.parseDouble(height);

                        height = Utils.getDouble(2.);
                        if(height == null) break;

                        double height_hi = Double.parseDouble(height);

                        StringBuilder sm = new StringBuilder(Utils.headerCities);

                        people.stream()
                                .filter(p-> p.getHeight() >= height_lo && p.getHeight() <= height_hi)
                                .map(Person::getCity).distinct()
                                .toList().forEach(p -> sm.append("<tr><td>" + p + "</tr></td>"));

                        sm.append("</tbody></table>");
                        Utils.showMessage(sm.toString(), "Города, в которых есть жители с заданным диапазоном роста");
                        break;

                    case "Жители заданного города с заданным диапазоном возраста":
                        //Выбрать жителей заданного города с заданным диапазоном возраста
                        String city  = Utils.showSelect("<html><br><h2>Выберите город</h2>","Выбрать жителей заданного города с заданным диапазоном возраста ",
                                people.stream().map(Person::getCity).distinct()
                                        .sorted().toArray());

                        if(city == null) break;

                        String age = Utils.getInt(18);
                        if(age == null) break;

                        int age_lo = Integer.parseInt(age);

                        age = Utils.getInt(56);
                        if(age == null) break;

                        int age_hi = Integer.parseInt(age);

                        Utils.showMessage(show(people.stream()
                                .filter(p-> p.getAge() >= age_lo && p.getAge() <= age_hi && p.getCity().equals(city))
                                .toList()), "Жители заданного города с заданным диапазоном возраста");
                        break;

                    // выход
                    default:
                        return;
                }
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        } // try-catch
    }

    // вывод окна меню
    public String showMenu() {
        String s = (String)JOptionPane.showInputDialog(
                null,
                "<html><br><h2>Выберите вариант</h2>",
                "Меню второго задания",
                JOptionPane.QUESTION_MESSAGE,
                new ImageIcon(Main.class.getResource("../../../images/leopard.png")),
                new Object[] {"Города, по алфавиту", "Жители, по алфавиту", "Жители, по убыванию возраста",
                        "Жители, по росту", "Добавить", "Удалить", "Жители с заданной фамилией",
                        "Города, в которых есть жители с заданной фамилией",
                        "Города, в которых есть жители с заданным диапазоном роста",
                        "Жители заданного города с заданным диапазоном возраста"
                        ,"Назад"},
                "Назад");

        if(s == null) return "Назад";

        return s;
    }
}
