package itstep.pd011.app.controllers;

import itstep.pd011.app.Main;
import itstep.pd011.app.utils.Utils;

import javax.swing.*;
import java.lang.reflect.Array;
import java.util.*;

public class Task01Controller {

    private int [] ints;
    private double [] doubles;

    private StringBuilder sb;

    private static final int N = 12;

    public Task01Controller() {

        ints = new int[N];
        doubles = new double[N];

        fill(ints);
        fill(doubles);
    }

    //Заполняем массивы
    public void fill(int [] arr)
    {
        for (int i = 0; i<N; i++){
            arr[i] = Utils.getInt(-1,3);
        }
    }

    public void fill(double [] arr)
    {
        for (int i = 0; i<N; i++){
            arr[i] = Utils.getDouble(-10.,10.);
        }
    }

    // работа по заданию
    public void run() {

        while (true) {
            switch (showMenu()) {
                case 0 -> {
                    sb = new StringBuilder("<html><br><p>Исходный массив:</p><html><table><tbody><tr>");

                    //Вычислить сумму элементов массива, расположенных после
                    // минимального элемента.
                    double min = Arrays.stream(doubles).min().getAsDouble();
                    int imin = -1;
                    for (int i = 0; i < N; i++) {
                        if (doubles[i] == min) {
                            imin = i;
                            break;
                        } // if
                    } // for i
                    double sum = Arrays.stream(doubles).skip(imin + 1).sum();

                    //Вывод исходного массива
                    Arrays.stream(doubles).forEach(e -> sb.append(String.format((e == min) ? "<td style = 'color:red'>%.2f</td style = 'color:black'>" : "<td>%.2f</td>", e)));
                    sb.append("</table></tbody></tr>");
                    sb.append(String.format("<br><p>Сумма после минимального элемента: %.3f</p>", sum));

                    //Вычислить количество элементов массива, равных нулю;
                    long countZero = Arrays.stream(ints).filter(x -> x == 0).count();
                    sb.append(String.format("<p>Количество элементов, равных нулю: %d</p>", countZero));
                    sb.append("<br><p>После сортировки:</p><table><tbody><tr>");

                    //Упорядочить элементы массива по возрастанию модулей.
                    Arrays.stream(doubles)
                            .map(Math::abs)
                            .sorted()
                            .forEach(e -> sb.append(String.format("<td>%.2f</td>", e)));
                    sb.append("<html><table><tbody><tr>");
                    Utils.showMessage(sb.toString(), "Решение варианта 14");
                }
                case 1 -> {
                    sb = new StringBuilder("<html><br><p>Исходный массив:</p><html><table><tbody><tr>");

                    //Вывод исходного массива
                    Arrays.stream(ints).forEach(e -> sb.append(String.format("<td>%d</td>", e)));
                    sb.append("</table></tbody></tr>");

                    //Вычислить количество положительных элементов массива;
                    long countPositive = Arrays.stream(ints).filter(x -> x >= 0).count();
                    sb.append(String.format("<br><p>Количество положительных элементов: %d</p>", countPositive));

                    //Вычислить сумму элементов массива, расположенных после
                    //последнего элемента, равного нулю.
                    int i_zero = -1;
                    for (int i = ints.length-1; i >= 0; --i) {
                        if (ints[i] == 0) {
                            i_zero = i;
                            break;
                        } // if
                    } // for i
                    int sumZero = Arrays.stream(ints).skip(i_zero + 1).sum();
                    sb.append(String.format("<p>Сумма после последнего нулевого элемента: %d</p>", sumZero));

                    //Преобразовать массив таким образом, чтобы сначала располагались элементы <= 1,
                    // а потом — все остальные.
                    sb.append("<br><p>После сортировки:</p><table><tbody><tr>");
                    int[] helper01 = Arrays.stream(ints)
                            .filter(x -> x <= 1).toArray();
                    int[] helper02 = Arrays.stream(ints)
                            .filter(x -> x > 1).toArray();
                    Arrays.stream(helper01).forEach(e -> sb.append(String.format("<td>%d</td>", e)));
                    Arrays.stream(helper02).forEach(e -> sb.append(String.format("<td>%d</td>", e)));
                    sb.append("<html><table><tbody><tr>");
                    Utils.showMessage(sb.toString(), "Решение варианта 17");
                }

                // выход
                default -> {
                    return;
                }
            }
        }
    }

    // вывод окна меню
    public int showMenu() {
        return JOptionPane.showOptionDialog(
                null,
                "<html><br><h2>Выберите вариант</h2>",

                "Меню первого задания",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(Main.class.getResource("../../../images/horse.png")),
                new Object[] {"Вариант 14", "Вариант 17", "Назад"},
                "Назад"
        );
    }
}
