package org.itstep.pd011.controllers;

import org.itstep.pd011.Main;
import org.itstep.pd011.infrastructure.Utils;

import java.util.*;
import java.util.function.Predicate;

/*
* Задача 1.
* При помощи StreamAPI выполните следующие обработки массивов, состоящих
* из случайных чисел:
*
* Вариант 14. В одномерном массиве, состоящем из п вещественных
* элементов:
*     1. Вычислить количество элементов массива, равных нулю;
*     2. Вычислить сумму элементов массива, расположенных после
*        минимального элемента.
*     3. Упорядочить элементы массива по возрастанию модулей.
*
* Вариант 17. В одномерном массиве, состоящем из п целочисленных
* элементов:
*     1. Вычислить количество положительных элементов массива;
*     2. Вычислить сумму элементов массива, расположенных после
*        последнего элемента, равного нулю.
*     3. Преобразовать массив таким образом, чтобы сначала
*        располагались элементы <= 1, а потом — все остальные.
* */
public class Task1Controller {
    public final double DBL_LO = -10, DBL_HI = 10;
    public final int INT_LO = -10, INT_HI = 10;


    // выполнение варианта 14
    public void doVariant14() {
        // создать масси и вывести его в консоль
        double[] data = Utils.create(Utils.getRandom(12, 18), DBL_LO, DBL_HI);

        // вывод массива с выделением цветом нулевых элементов
        // (положительные выделяются в коде метода, бе внешнего предиката)
        Predicate<Double> p = t -> Utils.equals(t, 0);
        var s = Utils.arrayToStringBuilder(data, "\n\tИсходный массив:\n", p);
        System.out.println(s);

        // количество элементов массива, равных нулю
        long zeroes =  Arrays.stream(data).filter(datum -> Utils.equals(datum, 0.)).count();
        System.out.printf("\tНулей в массиве: %d\n", zeroes);

        // сумма элементов массива, расположенных после минимального элемента

        // получить индекс минимального элемента (indexOf() есть на ArrayList<>
        // boxed() формирует поток класса-оболочки Double
        // идея - Горячев Михаил
        List<Double> dataList = Arrays.stream(data).boxed().toList();

        // это не баг, это фича - такое решение не работает в Java
        // List<Double> dataList = Arrays.asList(Utils.toDoubleArray(data));
        int imin = dataList.indexOf(dataList.stream().min(Double::compare).get());
        double sum = Arrays.stream(data).skip(imin + 1).sum();

        // такое суммирование тоже возможно
        // double sum = dataList.stream().skip(imin + 1).reduce((acc, item) -> acc + item).get();

        StringBuilder sb = Utils.arrayToStringBuilder(data,
            "\n\tМассив с выделением минимального и последующих элементов:\n", imin);
        sb.append(String.format(Locale.UK,
            "\tМиниммальный элемент массива: \033[1;34m%.2f\033[0m, его индекс: \033[1;34m%d\033[0m\n",
            data[imin], imin));
        sb.append(String.format(Locale.UK,
            "\tCумма элементов, расположенных после минимального: \033[1;31m%.2f\033[0m\n",
            sum));
        System.out.println(sb);

        // Упорядочить элементы массива по возрастанию модулей
        // идея - Таций Анна
        data = Arrays.stream(data).map(Math::abs).sorted().toArray();

        s = Utils.arrayToStringBuilder(data, "\tМассив упорядочен по возрастанию модулей:\n", p);
        System.out.println(s);
    } // doVariant14


    // выполнение варианта 17
    public void doVariant17() {
        int[] data = Utils.create(Utils.getRandom(12, 18), INT_LO, INT_HI);

        // вывод массива с выделением цветом нулевых элементов (это задаем предикатом)
        // метод arrayToStringBuilder() выделяет цветом элементы больше нуля
        var s = Utils.arrayToStringBuilder(data, "\n\tИсходный массив:\n", t -> t == 0);
        System.out.println(s);

        // Количество положительных элементов массива
        long positives =  Arrays.stream(data).filter(datum -> datum >= 0).count();
        System.out.printf("\tПоложительных в массиве: %d\n", positives);

        // Вычислить сумму элементов массива, расположенных после
        // последнего элемента, равного нулю.
        int indexLastZero = Arrays.stream(data).boxed().toList().lastIndexOf(0);
        StringBuilder sb = Utils.arrayToStringBuilder(data,
            "\n\tМассив с выделением последнего нуля и элементов за ним:\n", indexLastZero);

        if (indexLastZero >= 0 && indexLastZero < data.length-1) {
            int sum = Arrays.stream(data).skip(indexLastZero + 1).sum();

            sb.append(String.format(Locale.UK,
                "\tПоследний нулевой элемент размещен по индексу       : \033[1;34m%5d\033[0m\n", indexLastZero))
              .append(String.format(Locale.UK,
                "\tCумма элементов, расположенных после последнего нуля: \033[1;31m%5d\033[0m\n", sum));
        } else {
            sb.append("\t\033[31;1mНет нулей или ноль в последней позиции - расчет суммы невозможен.\033[0m");
        } // if
        System.out.println(sb);

        // Преобразовать массив таким образом, чтобы сначала
        // располагались элементы <= 1, а потом — все остальные.
        data = Arrays.stream(data)
            .boxed()
            // идея - Горячев Михаил
            // .sorted(Comparator.comparing(a -> a > 1))
            .sorted((d1, d2) -> (d1 <= 1 && d2 > 1)? -1: (d1 > 1 && d2 <= 1)?1:0)
            .mapToInt(Integer::intValue)
            .toArray();

        s = Utils.arrayToStringBuilder(data,
            "\tМассив упорядочен по правилу \033[4m\"Элементы меньше или равные 1 в начало массива\"\033[0m:\n",
            t -> t <= 1);
        System.out.println(s);
    } // doVariant17

    // демонстрация решения задачи
    public void run() {
        // выполнение варианта 14
        doVariant14();

        System.out.println("\n\t----------------------------------------------------------------------------------");

        // выполнение варианта 17
        doVariant17();
    } // run

} // class Task1Controller
