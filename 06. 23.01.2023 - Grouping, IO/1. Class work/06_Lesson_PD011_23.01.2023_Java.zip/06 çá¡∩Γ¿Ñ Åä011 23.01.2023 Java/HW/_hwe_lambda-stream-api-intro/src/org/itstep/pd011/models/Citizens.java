package org.itstep.pd011.models;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/*
* коллекция жителей городов, выполнение запросов по заданию
* чтение из CSV-файла, запись в CSV-файл
*
* Запросы к коллекции:
* a. Выбрать жителей заданного города с заданным диапазоном возраста
* b. Выбрать жителей с заданной фамилией
* c. Выбрать города, в которых есть жители с заданной фамилией
* d. Выбрать города, в которых есть жители с заданным диапазоном роста
* e. Вернуть коллекцию городов, упорядоченную по алфавиту
* f. Вернуть коллекцию жителей, упорядоченную по алфавиту
* g. Вернуть коллекцию жителей, упорядоченную по убыванию возраста
* h. Вернуть коллекцию жителей, упорядоченную по росту
* */
public class Citizens {

    List<Citizen> citizens;
    private String fileName;

    public Citizens() throws IOException {
        this("data/citizens.csv");
    } // Citizens

    public Citizens(String fileName) throws IOException {
        this.citizens = new ArrayList<>();
        this.fileName = fileName;

        if (!Files.exists(Paths.get(fileName))) {
            initialize();
            write(fileName);
        } else {
            load(fileName);
        } // if
    } // Citizens

    // геттер/сеттер для имени файла
    public String getFileName() { return fileName; }
    public void setFileName(String fileName) {
        if (fileName.isEmpty() || fileName.isBlank())
            throw new InvalidParameterException("Недопустимое имя файла");
        this.fileName = fileName;
    } // setFileName

    // заполнение коллекции начальными данными
    void initialize() {
        citizens = new ArrayList<>(Arrays.asList(
           new Citizen("Яровая", "Любовь", 34, 178.2, "Горловка"),
           new Citizen("Киселева", "Тамара", 26, 190.0, "Донецк"),
           new Citizen("Сивцова", "Наталья", 46, 177.7, "Макеевка"),
           new Citizen("Цапенко", "Илья", 21, 141.1, "Енакиево"),
           new Citizen("Вареца", "Григорий", 56, 191.5, "Донецк"),
           new Citizen("Иотова", "Екатерниа", 35, 163.1, "Горловка"),
           new Citizen("Маринов", "Николай", 456, 187.1, "Макеевка"),
           new Citizen("Росщупкин", "Евгений", 33, 187.5, "Енакиево"),
           new Citizen("Караникола", "Лариса", 43, 186.1, "Горловка"),
           new Citizen("Житников", "Кирилл", 39, 197.7, "Макеевка"),
           new Citizen("Важдаев", "Олег", 36, 191.9, "Енакиево"),
           new Citizen("Юсупова", "Галина", 33, 159.1, "Моспино")
        ));
    } // initialize

    // загрузка данных из файла в формате CSV
    private void load(String fileName) {
        List<String> text = null;
        citizens.clear();  // формируем новую коллекцию

        try {
            // читаем текстовый файл одной операцией
            text = Files.readAllLines(Paths.get(fileName), StandardCharsets.UTF_8);

            // для каждой строки - разбить строку на токены, сформировать объект класса Citizen
            text.forEach(str -> citizens.add(new Citizen(str)));
        } catch (Exception ex) {
            ex.printStackTrace();
        } // try-catch
    } // load

    // для удобства
    public void write() throws IOException { write(this.fileName); }

    // вывод коллекции в файл формата CSV
    public void write(String path) throws IOException {

        List<String> lines = new ArrayList<>();
        citizens.forEach(c -> lines.add(c.toCsv()));

        Files.write(Paths.get(path), lines, StandardCharsets.UTF_8);
    } // write


    // возвращает строку, содержащую таблицу результатов
    public String toTable() {
        var sbf = new StringBuilder();

        // установка нумерации строк таблицы
        Citizen.row = 1;

        // шапка таблицы и перевод строки после шапки таблицы
        sbf.append(Citizen.HEADER).append("\n");

        // вывод тела таблицы
        citizens.forEach(p -> sbf.append("\t").append(p.toTableRow()).append("\n"));

        // подвал таблицы и перевод строки после подвала
        sbf.append(Citizen.FOOTER).append("\n");

        return sbf.toString();
    } // toTable

    public void add(Citizen citizen) { citizens.add(citizen);  }
    public int size() { return citizens.size();   }
    public void removeAt(int index) {  citizens.remove(index);   }

    // Выбрать жителей заданного города с заданным диапазоном возраста
    // Выбрать жителей с заданной фамилией
    // Выбрать города, в которых есть жители с заданной фамилией
    // Выбрать города, в которых есть жители с заданным диапазоном роста
    // Вернуть коллекцию городов, упорядоченную по алфавиту
    // Вернуть коллекцию жителей, упорядоченную по алфавиту
    // Вернуть коллекцию жителей, упорядоченную по убыванию возраста
    // Вернуть коллекцию жителей, упорядоченную по росту
} // class Citizens
