package org.itstep.pd011;

/**
 * Общий ресурс для синхронизации потоков при помощи семафора
 */
public class CommonRes {
    int number = 0;
}
