package org.itstep.pd011.app.controllers;

import org.itstep.pd011.app.utils.Utils;
import java.net.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.stream.Stream;

/*Загрузка главной страницы сайта NewtonSoft, определение количества символов < и > на загруженной странице */

public class Task04Controller implements Runnable{

    @Override // реализация интерфейса Runnable - этот метод и есть код потока
    public void run(){

        var testString = readHtmlDoc("https://www.newtonsoft.com/json");

        //загрузка главной страницы сайта NewtonSoft,
        System.out.println(testString);

        //определение количества символов <td> на загруженной странице
        long count = testString.chars().filter(c -> c == '<' || c == '>').count();

        Utils.showMessage("<html><h3>Задание 4: Количество тегов td: "+count+"</h3>","Определение количества символов <td> на загруженной странице");
    }

    // чтение документа из Интернета
    public StringBuilder readHtmlDoc(String urlName) {

        StringBuilder sb = new StringBuilder();

        try {
            // создать объект для работы с URL
            URL url = new URL(urlName);

            // открыть поток чтения по URL --> new URL(urlName).openStream()
            try(BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()))) {

                // построчное чтение данных, используем Stream API, lines() - поток данных Stream<String>
                reader.lines().forEach(x-> sb.append(x).append("\n"));
            } // try

        } catch (MalformedURLException e) {
            System.out.println("\n\tНекорректный протокол, домен или имя файла\n");;
        } catch (IOException e) {
            e.printStackTrace();
        } // try-catch

        return sb;
    } // readHtmlDoc
}
