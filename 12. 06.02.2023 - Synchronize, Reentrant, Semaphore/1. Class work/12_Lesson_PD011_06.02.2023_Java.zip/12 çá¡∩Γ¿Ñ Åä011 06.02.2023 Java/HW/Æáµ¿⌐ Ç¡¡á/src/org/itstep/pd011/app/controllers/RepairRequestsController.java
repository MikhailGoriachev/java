package org.itstep.pd011.app.controllers;

import org.itstep.pd011.app.models.RepairRequest;
import org.itstep.pd011.app.services.Serializer;
import org.itstep.pd011.app.utils.Utils;

import java.io.File;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.nio.file.Files;

public class RepairRequestsController implements Runnable {

    private final String FILE_NAME = "app_data/repairRequests.dat";

    private List<RepairRequest> repairRequests;

    public RepairRequestsController() {

        Serializer<RepairRequest> sz = new Serializer<>(FILE_NAME);

        if(Files.notExists(Paths.get(FILE_NAME))){

            //сериализация этой коллекции при первом запуске;
            File theDir = new File("app_data");
            if (!theDir.exists()){
                theDir.mkdirs();
            }

            init();
            // выполнить сериализацию
            sz.serialize(repairRequests);
        }else{//десериализация, перемешивание и сериализация при последующих запусках.
            repairRequests = sz.deserialize();
            Collections.shuffle(repairRequests);
            sz.serialize(repairRequests);
        }
    }

    private void init(){
        repairRequests = new ArrayList<>();

        for (int i = 0; i<12; i++){
            repairRequests.add(RepairRequest.create());
        }
    }

    @Override // реализация интерфейса Runnable - этот метод и есть код потока
    public void run(){

        Utils.showRepairRequests(repairRequests,"Коллекция заявок на ремонт ноутбуков");
    }
}
