package org.itstep.pd011.app.utils;

import javax.swing.*;
import java.util.List;
import java.util.Random;

import org.itstep.pd011.app.models.RepairRequest;

public class Utils {

    // случайное целочисленное число
    public static int getInt(int min, int max) {
        return new Random().nextInt(min, max);
    }

    // случайное вещественное число
    public static double getDouble(double min, double max) {
        return min + (max - min) * new Random().nextDouble();
    }

    // вывод данных в окно
    public static void showMessage(String message, String title) {
        JOptionPane.showOptionDialog(
                null,
                message,
                title,
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(),
                new Object[]{"Далее"},
                "Далее"
        );
    }


    public static String[] titles = {

            "NB",
            "AD",
            "HR",
            "EVE",
            "N",
            "G8",
            "EX-CF-F",
            "DMA-DM",
            "E-CJG",
            "EX-C6FV"
    };

    public static String[] models = {
            "Acer",
            "Lenovo",
            "ASUS",
            "HP",
            "Echips Envy",
            "Huawei",
            "MSI",
            "HIPER",
            "Honor",
            "CHUWI",
    };

    public static String[] processorTypes = {
            "Intel Сore",
            "Intel Core M",
            "Intel Pentium",
            "Intel Celeron",
            "A",
            "Athlon / Athlon Silver",
            "Hyper Threading",
            "Ryzen ",
            "Ryzen H",
            "Ryzen Pro"
    };

    public static String[] faultDescriptions = {
            "механические неисправности корпуса ноутбука",
            "неисправности клавиатуры",
            "неисправности зарядки",
            "неисправности материнской платы ",
            "поломки матрицы, петель, шлейфа в ноутбуке",
            "проблемы видеокарты ноутбука",
            "проблемы жесткого диска ноутбука",
            "неисправность батареи ноутбука",
            "проблемы с охлаждением мобильного компьютера",
            "программные проблемы ноутбуков",
    };

    public static String[] owners = {
            "Моисеева А. В.",
            "Алексеева А. Ф.",
            "Кулешов Д. Н.",
            "Сидоров М. А.",
            "Кудрявцева С. И.",
            "Матвеев В. С.",
            "Шевелева А. В.",
            "Семенов М. Л.",
            "Афанасьева А. Т.",
            "Ковалева А. М."
    };

    public static int[] amountOfRams = {2,4,8,16,32,64};

    public static int[] storagesCapacity = {128,256,512,1024,2048};

    public static String headerRepairRequests =
            "<table border='1' >" +
                    "<thead><tr>" +
                    "<th>Наименование устройства</th>" +
                    "<th>Модель</th>" +
                    "<th>Тип процессора</th>" +
                    "<th>Объем оп памяти</th>" +
                    "<th>Емкость накопителя</th>" +
                    "<th>Диагональ экрана</th>" +
                    "<th>Описание неисправности</th>" +
                    "<th>Владелец</th>" +
                    "</tr></thead><tbody>";

    public static void showRepairRequests(List<RepairRequest> repairRequests, String caption) {

        StringBuilder sb = new StringBuilder("<html><h3>"+caption+"</h3>");
        sb.append(headerRepairRequests);
        repairRequests.forEach(sb::append);
        showMessage(sb.append("</tbody></table>").toString(),caption);
    }

}
