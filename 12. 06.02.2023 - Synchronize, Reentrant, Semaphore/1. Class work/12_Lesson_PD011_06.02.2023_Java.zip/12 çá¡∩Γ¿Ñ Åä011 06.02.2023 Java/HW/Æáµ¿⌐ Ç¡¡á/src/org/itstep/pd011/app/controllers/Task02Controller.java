package org.itstep.pd011.app.controllers;

/*Обработка текстового файла – подсчет (без учета регистра) частоты слов.
Текстовый файл подготовить заранее, формировать его в коде не надо.
Текст из файла и сформированный словарь вывести в консоль при помощи
StringBuilder */

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

public class Task02Controller implements Runnable {

    @Override // реализация интерфейса Runnable - этот метод и есть код потока
    public void run(){
        String fileName = "app_data/text.txt";

        try {

            // читаем текстовый файл одной операцией
            String text = Files.readString(Paths.get(fileName), StandardCharsets.UTF_8);
            text = text.replace("\t", " ");
            text = text.replace("\n", " ");
            text = text.replace("\r", " ");

            // разбить строку на токены (слова), удалить пустые токены
            var tokens = Arrays.stream(text.split("[ ,.:!?]"))
                    .filter(t -> !t.isEmpty() && !t.isBlank())
                    .map(String::toLowerCase)
                    .sorted(Comparator.comparingInt(String::length))
                    .toList();

            Map<String, Integer> map = new HashMap<>();

            //Текст из файла и сформированный словарь
            for(String token: tokens){
                map.put(token, (int)tokens.stream().filter(s -> s.equals(token)).count());
            }

            //Текст из файла и сформированный словарь вывести в консоль при помощи StringBuilder
            StringBuilder sb = new StringBuilder();

            int i = 1;
            for(String key: map.keySet()){
                sb.append(String.format("%-11s -> %-2d\t\t",key,map.get(key)));
                if (i++ % 6 == 0)sb.append("\n");
            }

            System.out.println(sb);

        } catch (Exception ex) {
        ex.printStackTrace();
        } // try-catch
    }
}
