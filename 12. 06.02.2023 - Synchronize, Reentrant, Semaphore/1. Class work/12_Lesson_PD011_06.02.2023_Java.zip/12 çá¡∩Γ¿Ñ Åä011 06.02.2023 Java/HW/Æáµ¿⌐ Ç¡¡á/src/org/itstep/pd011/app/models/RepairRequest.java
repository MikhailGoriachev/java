package org.itstep.pd011.app.models;

import org.itstep.pd011.app.utils.Utils;

import java.io.Serializable;

public class RepairRequest implements Serializable {

    private String title; //наименование устройства
    private String model; //модель
    private String processorType; //тип процессора
    private int amountOfRam; //объем оперативной памяти
    private int storageCapacity; //емкость накопителя
    private double diagonal; //диагональ экрана
    private String faultDescription; //описание неисправности
    private String owner; //фамилия и инициалы владельца

    public RepairRequest(String title, String model, String processorType, int amountOfRam, int storageCapacity, double diagonal, String faultDescription, String owner) {
        this.title = title;
        this.model = model;
        this.processorType = processorType;
        this.amountOfRam = amountOfRam;
        this.storageCapacity = storageCapacity;
        this.diagonal = diagonal;
        this.faultDescription = faultDescription;
        this.owner = owner;
    }

    @Override
    public String toString() {
        return "<tr>" +
                "<td>"+title+"</td>"+
                "<td>"+model+"</td>"+
                "<td>"+processorType+"</td>"+
                "<td>"+amountOfRam+"</td>"+
                "<td>"+storageCapacity+"</td>"+
                "<td>"+String.format("%.2f",diagonal)+"</td>"+
                "<td>"+faultDescription+"</td>"+
                "<td>"+owner+"</td>"+
                "</tr>";
    }

    public static RepairRequest create(){

        return new RepairRequest(
                Utils.titles[Utils.getInt(0,Utils.titles.length)] + "-"+ Utils.getInt(453,1485),
                Utils.models[Utils.getInt(0,Utils.models.length)],
                Utils.processorTypes[Utils.getInt(0,Utils.processorTypes.length)],
                Utils.amountOfRams[Utils.getInt(0,Utils.amountOfRams.length)],
                Utils.storagesCapacity[Utils.getInt(0,Utils.storagesCapacity.length)],
                Utils.getDouble(10,20),
                Utils.faultDescriptions[Utils.getInt(0,Utils.faultDescriptions.length)],
                Utils.owners[Utils.getInt(0,Utils.owners.length)]
        );
    }
}
