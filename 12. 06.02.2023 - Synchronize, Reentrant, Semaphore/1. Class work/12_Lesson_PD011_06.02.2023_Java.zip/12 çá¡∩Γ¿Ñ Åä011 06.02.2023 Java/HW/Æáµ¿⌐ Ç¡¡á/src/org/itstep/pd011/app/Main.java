package org.itstep.pd011.app;

import org.itstep.pd011.app.controllers.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        try {
            // коллекция анонимных объектов
            List<Thread> threadList = new ArrayList<>(Arrays.asList(
                    new Thread(new Task01Controller()),
                    new Thread(new Task02Controller()),
                    new Thread(new RepairRequestsController()),
                    new Thread(new Task04Controller())
            ));

            // запускаем потоки
            for(Thread thread:threadList) thread.start();
            // ждем их завершения
            for(Thread thread:threadList) thread.join();

        } catch (Exception ex) {
            ex.printStackTrace();
        } // try-catch
    }
}