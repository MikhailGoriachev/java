package org.itstep.pd011.app.controllers;

import org.itstep.pd011.app.services.Serializer;
import org.itstep.pd011.app.utils.Utils;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Task01Controller implements Runnable{

    private List<Double> elems;

    public Task01Controller() {

        String fileName = "app_data/doubles.dat";
        Serializer<Double> sz = new Serializer<>(fileName);

        if(Files.notExists(Paths.get(fileName))){

            //сериализация этой коллекции при первом запуске;
            File theDir = new File("app_data");
            if (!theDir.exists()){
                theDir.mkdirs();
            }

            init();
            // выполнить сериализацию
            sz.serialize(elems);

        }else{//десериализация, перемешивание и сериализация при последующих запусках.
            elems = sz.deserialize();
            Collections.shuffle(elems);
            sz.serialize(elems);
        }
    }

    private void init(){
        elems = new ArrayList<>();

        for (int i = 0; i<20; i++){
            elems.add(Utils.getDouble(-10,10));
        }
    }

    //Вывод результатов в консоль при помощи StringBuilder.
    private void show(String caption){

        StringBuilder sb = new StringBuilder(String.format("\n\t%s\n", caption));

        elems.forEach(e -> sb.append(String.format("%8.2f", e)));

        System.out.println(sb);
    }

    @Override // реализация интерфейса Runnable - этот метод и есть код потока
    public void run(){

        // Сортировка коллекции, прочитанной из файла по заданию
        //вывод в консоль

        show("Задание 1: Исходная коллекция:");

        //Сортировки данных в коллекции: по возрастанию
        elems.sort(Double::compare);
        show("Задание 1: Сортировки данных в коллекции: по возрастанию");

        //Сортировки данных в коллекции: по убыванию модулей
        elems.sort((d1,d2) -> Double.compare(Math.abs(d2),Math.abs(d1)));
        show("Задание 1: Сортировки данных в коллекции: по убыванию модулей");

        //Сортировки данных в коллекции: [-5, -1] в конец файла.
        final double a = -5, b = -1;
        List<Double> temp01 =  elems.stream().filter(x-> x >= a && x <= b).toList();
        temp01.forEach(x->elems.remove(x));
        Collections.shuffle(elems);
        elems.addAll(temp01);
        show(String.format("Задание 1: Сортировки данных в коллекции: [%.1f, %.1f] в конец файла", a, b));

    }
}
