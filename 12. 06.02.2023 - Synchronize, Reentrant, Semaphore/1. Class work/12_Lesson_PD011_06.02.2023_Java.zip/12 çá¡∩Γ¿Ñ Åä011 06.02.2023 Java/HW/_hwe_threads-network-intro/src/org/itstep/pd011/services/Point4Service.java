package org.itstep.pd011.services;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

// Загрузка главной страницы сайта NewtonSoft, определение количества
// символов < и > на загруженной странице
public class Point4Service implements Runnable {
    @Override
    public void run() {
        var sbr = new StringBuilder(
        String.format("""
            
            Поток %d. Пункт 4.
            Загрузка главной страницы сайта NewtonSoft, определение количества.
            символов '<' и '>' на загруженной странице
            """, Thread.currentThread().threadId()));

        long numbers = readAndProcHtmlDoc("https://www.newtonsoft.com/json");

        // вывести ответ
        sbr.append(String.format(
                "\nПоток %d. Пункт 4.\n" +
                "Общее количество символов '<' и '>': \033[1;4m  %d  \033[0m\n\n",
                Thread.currentThread().threadId(), numbers));

        System.out.println(sbr);
    }

    // чтение документа из Интернета, построчная обработка
    public long readAndProcHtmlDoc(String urlName) {
        long numbers = -1;

        try {
            // создать объект для работы с URL
            URL url = new URL(urlName);

            // для загруженного контента
            var sbr = new StringBuilder();

            // открыть поток чтения по URL --> new URL(urlName).openStream()
            try(BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()))) {

                // построчное чтение данных, используем Stream API, lines() - поток данных Stream<String>
                reader.lines().forEach(sbr::append); // reading content

                // подсчет количества символов < и > при помощи StreamAPI
               numbers = sbr.chars().filter(c -> c == '<' | c == '>').count();

                // вывести контент в консоль одной операцией
                // System.out.println(sbr);
            } // try
        } catch (MalformedURLException e) {
            System.out.println("\n\tНекорректный протокол, домен или имя файла\n");
        } catch (IOException e) {
            e.printStackTrace();
        } // try-catch

        return numbers;
    } // readAndProcHtmlDoc
}
