package org.itstep.pd011.services;

public class Point1Service implements Runnable {
    @Override
    public void run() {
        System.out.printf("Поток %d. Пункт 1. В разработке.\n", Thread.currentThread().threadId());
    } // run
}
