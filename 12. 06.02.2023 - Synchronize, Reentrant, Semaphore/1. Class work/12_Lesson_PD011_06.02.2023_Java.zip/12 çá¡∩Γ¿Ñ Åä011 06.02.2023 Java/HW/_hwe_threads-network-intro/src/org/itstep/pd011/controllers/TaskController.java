package org.itstep.pd011.controllers;

import org.itstep.pd011.services.Point1Service;
import org.itstep.pd011.services.Point2Service;
import org.itstep.pd011.services.Point3Service;
import org.itstep.pd011.services.Point4Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TaskController {
    private Point1Service point1Service;
    private Point2Service point2Service;
    private Point3Service point3Service;
    private Point4Service point4Service;

    public TaskController() {
        this(new Point1Service(), new Point2Service(), new Point3Service(), new Point4Service());
    } // TaskController

    public TaskController(Point1Service point1Service, Point2Service point2Service, Point3Service point3Service, Point4Service point4Service) {
        this.point1Service = point1Service;
        this.point2Service = point2Service;
        this.point3Service = point3Service;
        this.point4Service = point4Service;
    } // TaskController

    // запуск всех потоков решения задач параллельно
    public void run() throws InterruptedException {
        // коллекция анонимных объектов
        List<Thread> threadList = new ArrayList<>(Arrays.asList(
            new Thread(point1Service),
            new Thread(point2Service),
            new Thread(point3Service),
            new Thread(point4Service)
        ));

        // запускаем потоки
        for(Thread thread:threadList) thread.start();

        // ждем их завершения
        for(Thread thread:threadList) thread.join();
    } // run
}

