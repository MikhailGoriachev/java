package org.itstep.pd011.services;

public class Point2Service implements Runnable {
    @Override
    public void run() {
        System.out.printf("Поток %d. Пункт 2. В разработке.\n", Thread.currentThread().threadId());
    }
}
