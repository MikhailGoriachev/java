package org.itstep.pd011.models;

// Заявка на ремонт ноутбука
// наименование устройства, модель, тип процессора, объем оперативной памяти,
// емкость накопителя, диагональ экрана, описание неисправности, фамилия
// и инициалы владельца
public class RepairRequest {
    // идентификатор заявки
    private int id;

    // наименование устройства
    private String device;

    // модель
    private String model;

    // тип процессора
    private String cpu;

    // объем оперативной памяти, ГБайт
    private int ram;

    // емкость накопителя, ГБайт
    private int storage;

    // диагональ экрана
    private double diagonal;

    // описание неисправности
    private String defectDescription;

    // фамилия и инициалы владельца
    private String owner;


    public RepairRequest() {}

    public RepairRequest(int id, String device, String model, String cpu, int ram, int storage, double diagonal, String defectDescription, String owner) {
        this.id = id;
        this.device = device;
        this.model = model;
        this.cpu = cpu;
        this.ram = ram;
        this.storage = storage;
        this.diagonal = diagonal;
        this.defectDescription = defectDescription;
        this.owner = owner;
    }

    public int getId() {
        return id;
    }

    public String getDevice() {
        return device;
    }

    public void setDevice(String device) {
        this.device = device;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getCpu() {
        return cpu;
    }

    public void setCpu(String cpu) {
        this.cpu = cpu;
    }

    public int getRam() {
        return ram;
    }

    public void setRam(int ram) {
        this.ram = ram;
    }

    public int getStorage() {
        return storage;
    }

    public void setStorage(int storage) {
        this.storage = storage;
    }

    public double getDiagonal() {
        return diagonal;
    }

    public void setDiagonal(double diagonal) {
        this.diagonal = diagonal;
    }

    public String getDefectDescription() {
        return defectDescription;
    }

    public void setDefectDescription(String defectDescription) {
        this.defectDescription = defectDescription;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    @Override
    public String toString() {
        return "RepairRequest{" +
                "id=" + id +
                ", device='" + device + '\'' +
                ", model='" + model + '\'' +
                ", cpu='" + cpu + '\'' +
                ", ram=" + ram +
                ", storage=" + storage +
                ", diagonal=" + diagonal +
                ", defectDescription='" + defectDescription + '\'' +
                ", owner='" + owner + '\'' +
                '}';
    }
} // class RepairRequest
