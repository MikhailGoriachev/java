package org.itstep.pd011.services;

public class Point3Service implements Runnable {
    @Override
    public void run() {
        System.out.printf("Поток %d. Пункт 3. В разработке.\n", Thread.currentThread().threadId());
    }
}
