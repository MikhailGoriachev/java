package home_task.models;

import home_task.utils.Utils;

import javax.swing.*;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class WordFrequency implements Runnable {

    //Имя файла
    public final String FILE_NAME = "app_data/words.txt";

    //Словарь частотнотси
    public HashMap<String, Integer> frequencyDict;

    public WordFrequency() {
        frequencyDict = new HashMap<>();
    }

    //Код потока
    @Override
    public void run()  {
        try {

            //Прочитать файла
            String str = readFile();

            var words = str.split("[ ,.!)(\n:;]");

            //Очистка масива от пустых строк ипробелов
            words = Arrays.stream(words).filter(w -> !w.isEmpty() && !w.isBlank() && w.length()> 1 ).toArray(String[]::new);

            //Подсчёт частоты
            countFrequency(words);

            //Сортировка частотного словаря по убыванию ключей
            Map<String, Integer> sorted = frequencyDict.entrySet().stream()
                    .sorted(Comparator.comparing(es -> -es.getKey().length()))
                    .collect(Collectors.toMap(
                            Map.Entry::getKey,
                            Map.Entry::getValue,
                            (a, b) -> { throw new AssertionError(); },
                            LinkedHashMap::new ));

            //Вывод окна с таблицей
            Utils.showWindowButtons(wordsToTable(/*frequencyDict*/sorted),"Частотный словарь",
                    new Object[]{"Назад"},"", JOptionPane.DEFAULT_OPTION);

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    private String readFile() throws IOException {

        StringBuilder sb = new StringBuilder();

        //
        try(Scanner sc = new Scanner(new File(FILE_NAME))){

            while (sc.hasNext())
                sb.append(sc.nextLine().trim()).append("\n");

        }
        return sb.toString();
    }

    //Вывод
    private String wordsToTable(Map<String, Integer> dictionary){
        //Формирование таблицы
        StringBuilder sb = new StringBuilder(Utils.tableHtmlHeader)
                .append(String.format("<tr><th colspan='2'>%s</th></tr>","Массив слов"))
                .append("<tr><th>Слово</th><th>Частота</th></tr>");

        for (var wf:dictionary.entrySet()) {
            sb.append(String.format("<tr><td>%1$s</td><td>%2$d</td></tr>",wf.getKey(),wf.getValue()));
        }

        return sb.append(Utils.tableHtmlFooter).toString();
    }

    //Подсчёт частоты слов
    private void countFrequency(String[] words){

        int frequency;


        for (int i = 0; i < words.length; i++) {
            frequency = 0;
            String word = words[i].toLowerCase();

            //Если частота уже подсчитывалась
            if (frequencyDict.containsKey(word))
                continue;

            //Проход дальше по массиву от текущего элемента
            for (int j = i; j <  words.length; j++) {
                if (words[j].toLowerCase().equals(word))
                    frequency++;
            }

            //Частота слова
            frequencyDict.put(word,frequency);

        }

    }
}
