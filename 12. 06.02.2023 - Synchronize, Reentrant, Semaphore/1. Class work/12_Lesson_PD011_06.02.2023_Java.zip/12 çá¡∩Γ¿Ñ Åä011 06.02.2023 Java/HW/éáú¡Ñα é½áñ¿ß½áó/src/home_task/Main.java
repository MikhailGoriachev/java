package home_task;

import home_task.controllers.*;
import home_task.utils.Utils;

import javax.swing.*;


public class Main {
    public static void main(String[] args){


        try {
            //Контроллеры
            Runnable[] controllers = new Runnable[]{
                 new Task1Controller()
            };

            //Вызов методов на контроллерах
            while (true) {
                switch (showMenu()) {
                    case 0 -> controllers[0].run();
                    case 1 -> System.exit(0);

                    default -> {
                        return;
                    }
                }
            }
        } catch (Exception e) {
            Utils.showWindowButtons(e.getMessage() + "\n","Ошибка!",new Object[]{"Выход"},"", JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage() + "\n");
            e.printStackTrace();
        }



    }//main

    //Вывод меню
    public static int showMenu(){

        //Задание значений для окна
        String title = "Задание на 06.02.23";
        String message = "<html><h1>Меню</h1>";
        Object[] buttons = new Object[]{
                "Задача 1",
                "Выход"
        };


        return Utils.showWindowButtons(message,title,buttons,"Выход",JOptionPane.DEFAULT_OPTION);
    }

}