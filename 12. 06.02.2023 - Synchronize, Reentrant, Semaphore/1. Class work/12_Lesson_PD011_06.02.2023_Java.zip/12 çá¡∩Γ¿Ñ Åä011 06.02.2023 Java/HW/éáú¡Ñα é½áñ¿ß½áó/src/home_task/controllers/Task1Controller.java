package home_task.controllers;

import home_task.models.FloatFile;
import home_task.models.NetWorkHandle;
import home_task.models.WordFrequency;
import home_task.models.laptopsRepair.Repairs;
import home_task.utils.Utils;

import javax.swing.*;


public class Task1Controller implements Runnable{


    public Task1Controller() throws Exception {
    }

    //Запуск меню конроллера
    @Override
    public void run() {
        // поток для работы с файлом вещественных чисел
        try {
            Thread thread1 = new Thread(new FloatFile());
            Thread thread2 = new Thread(new Repairs());
            Thread thread3 = new Thread(new WordFrequency());
            Thread thread4 = new Thread(new NetWorkHandle());

            thread1.start();
            thread2.start();
            thread3.start();
            thread4.start();

            thread1.join();
            thread2.join();
            thread3.join();
            thread4.join();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }//run

    //Обработки коллекции вещественных чисел из файла
    private void fileHandling(){
        //Задание значений для окна
        String title = "Обработки коллекции вещественных чисел";
        String message = "<html><h1>Задача 1</h1>";
        Object[] buttons = new Object[]{
                "Сортировка по возрастанию",
                "Сортировка по убыванию модулей",
                "Переместить числа из диапазона в конец файла",
                "Выход"
        };

        //Вызов методов на контроллерах
        while (true) {
            switch (Utils.showWindowButtons(message,title,buttons,"Выход",JOptionPane.DEFAULT_OPTION)) {
                case 0 -> {

                    if (Utils.showWindowButtons("Сортировка по возрастанию в разработке", "Сортировка",
                            new Object[]{"Назад"}, "",
                            JOptionPane.WARNING_MESSAGE) == 0)
                        break;
                }
                case 1 -> {
                    if (Utils.showWindowButtons("Сортировка по убыванию модулей в разработке!", "Сортировка",
                            new Object[]{"Назад"}, "",JOptionPane.WARNING_MESSAGE) == 0)
                        break;
                }
                case 2 -> {
                    if (Utils.showWindowButtons("Перемещение чисел в конец файла в разработке!", "Пермещение чисел",
                            new Object[]{"Назад"}, "",JOptionPane.WARNING_MESSAGE) == 0)
                        break;
                }
                default -> {
                    return;
                }
            }
        }
    }




}
