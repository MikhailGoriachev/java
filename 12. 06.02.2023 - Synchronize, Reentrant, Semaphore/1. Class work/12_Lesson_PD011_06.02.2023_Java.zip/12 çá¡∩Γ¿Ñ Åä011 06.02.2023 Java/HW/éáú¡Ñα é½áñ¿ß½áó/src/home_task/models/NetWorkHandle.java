package home_task.models;

import home_task.utils.Utils;

import javax.swing.*;
import java.io.*;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;

public class NetWorkHandle implements Runnable {

    //Адрес ресурса
    public final String URL_ADDRESS = "https://www.newtonsoft.com/json";

    public NetWorkHandle() {
    }

    // код потока
    @Override
    public void run() {
        try {
            //Получить разметку в виде строки
            StringBuilder context = readPage();

            //Подсчёт количества заданныйх символов - char
            long symbol1 = context.chars().filter(t -> t == '<').count();
            long symbol2 = context.chars().filter(t -> t == '>').count();

            //Запись результатов
            HashMap<Character,Long> result = new HashMap<>();
            result.put('<',symbol1);
            result.put('>',symbol2);

            //Вывод окна с таблицей
            Utils.showWindowButtons(resultToTable(result),"Подсчёт количества < и > в разметке",
                    new Object[]{"Назад"},"", JOptionPane.DEFAULT_OPTION);


        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    //Прочитать разметку
    private StringBuilder readPage() throws IOException {
        StringBuilder sb = new StringBuilder();

        URL url = new URL(URL_ADDRESS);

        try(BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()))){
            //Чтение полученных строк
            reader.lines().forEach(sb::append);
        }

        return sb;
    }


    //Вывод
    private String resultToTable(HashMap<Character, Long> results){
        //Формирование таблицы
        StringBuilder sb = new StringBuilder(Utils.tableHtmlHeader)
            .append("<tr><th colspan='2'>Подсчёт количества символов</th></tr>")
            .append("<tr><th>Символ</th><th>Количество</th></tr>");

        results.forEach((character, count) -> sb.append(String.format("<tr><td>%c</td><td>%d</td></tr>", character, count)));


        return sb.append(Utils.tableHtmlFooter).toString();
    }
}
