package home_task.models.laptopsRepair;

import home_task.utils.Utils;

import javax.swing.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class Repairs implements Runnable, Serializable {

    // имя файла
    public final String FILE_NAME = "app_data/repairs.bin";

    //Коллекция ноутбуков
    public List<Laptop> laptops;

    public Repairs() {
        if (!Files.exists(Path.of(FILE_NAME)))
        this.laptops = laptopsFactory();
    }

    public Repairs(List<Laptop> data) {
        laptops = data;
    }

    //Фабричный метод
    public List<Laptop> laptopsFactory(){
        return new ArrayList<>(List.of(new Laptop(),
                new Laptop(),
                new Laptop(),
                new Laptop(),
                new Laptop(),
                new Laptop(),
                new Laptop(),
                new Laptop(),
                new Laptop(),
                new Laptop())
        );
    }

    @Override
    public void run()  {
        try {

            if (!Files.exists(Path.of(FILE_NAME)))
                //Записать сгенерированную коллекцию в файл
                serialize();
            else
                //Перемешать коллекцию в файле
                shuffleData();

            //Вывод окна с таблицей
            Utils.showWindowButtons(toTable(),"Коллекция заявок на ремонт",
                    new Object[]{"Назад"},"", JOptionPane.DEFAULT_OPTION);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    //Перемешать коллекцию в файле
    public void shuffleData() throws Exception {
        deserialize();

        Laptop current = null;

        int secondInd = 0;
        Laptop secondVal = null;

        //Перемешивание элементов списка
        for (int i = 0; i < this.laptops.size(); i++) {
            current = laptops.get(i);
            secondInd = Utils.getRandom(0,laptops.size());
            secondVal = laptops.get(secondInd);

            //В текущий элемент добавляем значение из второго
            laptops.set(i,secondVal);
            laptops.set(secondInd,current);
        }

        //Перезаписать файл
        serialize();
    }

    private void  serialize() throws IOException {
        try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(FILE_NAME))){
            os.writeObject(this);
            /*for (Laptop l: laptops){
                os.writeObject(l);
            }*/

        }
    }

    private void deserialize() throws Exception {
        if (!Files.exists(Path.of(FILE_NAME)))
            return;

        try(ObjectInputStream is = new ObjectInputStream(new FileInputStream(FILE_NAME))){
            Repairs obj = (Repairs) is.readObject();
            laptops = obj.laptops;
            /*laptops = (List<Laptop>) is.readObject();*/
        }

    }

    //Вывод в таблицу
    public String toTable(){
        //Формирование таблицы
        StringBuilder sb = new StringBuilder(Utils.tableHtmlHeader)
                .append(String.format("<tr><th colspan='%1$d'>%2$s</th></tr>",laptops.size(),"Заявки на ремонт"))
                .append("<tr><th>Наименование</th><th>Модель</th><th>Процессор</th>")
                .append("<th>Объем RAM</th><th>Объем накопителя</th><th>Диагональ</th><th>Дефект</th><th>ФИО владельца</th></tr>");

        laptops.forEach(l -> sb.append(l.toTableRow()));
        return sb.toString();
    }

}
