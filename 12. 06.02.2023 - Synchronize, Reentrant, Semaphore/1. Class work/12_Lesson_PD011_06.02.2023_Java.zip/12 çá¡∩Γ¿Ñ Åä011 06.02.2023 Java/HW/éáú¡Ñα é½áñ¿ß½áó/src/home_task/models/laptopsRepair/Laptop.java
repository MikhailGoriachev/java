package home_task.models.laptopsRepair;

import home_task.utils.Utils;

import java.io.Serializable;

public class Laptop implements Serializable {

    //Наименование
    private String brand;

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    //Модель
    private String model;

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    //Тип процессора
    private String cpu;

    public String getCpu() {
        return cpu;
    }

    public void setCpu(String cpu) {
        this.cpu = cpu;
    }

    //Объем ram
    private int ram;


    public int getRam() {
        return ram;
    }

    public void setRam(int ram) {
        this.ram = ram;
    }

    //Объем накопителя
    private int hardDrive;

    public int getHardDrive() {
        return hardDrive;
    }

    public void setHardDrive(int hardDrive) {
        this.hardDrive = hardDrive;
    }

    //диагональ экрана
    private int diagonal;

    public int getDiagonal() {
        return diagonal;
    }

    public void setDiagonal(int diagonal) {
        this.diagonal = diagonal;
    }

    //описание неисправности
    private String defect;
    public String getDefect() {
        return defect;
    }

    public void setDefect(String defect) {
        this.defect = defect;
    }

    //фамилия и инициалы владельца
    private String ownerSnp;
    public String getOwnerSnp() {
        return ownerSnp;
    }

    public void setOwnerSnp(String ownerSnp) {
        this.ownerSnp = ownerSnp;
    }

    public Laptop(){
        this(Utils.getBrand(),
                Utils.getModel(),
                Utils.getCpu(),
                Utils.getRam(),
                Utils.getHardDrive(),
                Utils.getRandom(14,17),
                Utils.getDefect(),
                Utils.getOwner());
    }

    public Laptop(String brand, String model, String cpu, int ram, int hardDrive, int diagonal, String defect, String ownerSnp) {
        this.brand = brand;
        this.model = model;
        this.cpu = cpu;
        this.ram = ram;
        this.hardDrive = hardDrive;
        this.diagonal = diagonal;
        this.defect = defect;
        this.ownerSnp = ownerSnp;
    }

    //В строку таблицы
    public String toTableRow(){
        StringBuilder sb = new StringBuilder(String.format("<tr><td>%s</td>",this.brand))
                .append(String.format("<td>%s</td>",this.model))
                .append(String.format("<td>%s</td>",this.cpu))
                .append(String.format("<td>%d gb</td>",this.ram))
                .append(String.format("<td>%d gb</td>",this.hardDrive))
                .append(String.format("<td>%d</td>",this.diagonal))
                .append(String.format("<td>%s</td>",this.defect))
                .append(String.format("<td>%s</td>",this.ownerSnp));

        return sb.toString();
    }
}
