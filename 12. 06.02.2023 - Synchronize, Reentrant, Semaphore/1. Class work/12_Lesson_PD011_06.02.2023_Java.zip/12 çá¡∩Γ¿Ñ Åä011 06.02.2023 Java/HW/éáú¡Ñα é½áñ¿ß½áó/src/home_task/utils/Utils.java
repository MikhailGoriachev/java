package home_task.utils;

import javax.swing.*;
import java.util.Random;
import java.util.*;
public class Utils {

    //Генерация значений
    private static Random rand = new Random();

    public Utils() {
    }

    //Получение слуйчаных значений
    public static double getRandom(double lo, double hi) {
        return lo + rand.nextDouble() * (hi - lo);
    }

    public static int getRandom(int lo, int hi) {
        return lo + rand.nextInt(hi - lo);
    }


    // вывод окна с кнопками
    public static int showWindowButtons (String message, String title, Object[] buttons, String initialValue, int windowType) {
        return JOptionPane.showOptionDialog(
                null,
                message,
                title,
                JOptionPane.DEFAULT_OPTION,
                windowType,
                null,
                buttons,
                initialValue
        );
    }


    public static String tableHtmlHeader = "<html><table align='center' border='1' cellspacing='0' cellpadding='4'>";
    public static String tableHtmlFooter = "</table>";

    public static void listSbOutput(StringBuilder sbr,List<Double> list, String tableHeader){
        //Заголовок таблицы
        sbr.append(String.format("<tr><th colspan='%1$d'>%2$s</th></tr>",list.size(),tableHeader));

        //Исходный массив
        sbr.append("<tr>");
        list.forEach(n -> sbr.append( String.format("<td>%4.2f</td>",n)) );
        sbr.append("</tr>");
    }

    public static String[] brands = new String[]{
            "Asus","Lenovo","HP","Microsoft","Dell"
    };

    public static String[] models = new String[]{
            "A5","A2","Ideapad","A72","Surface Book","Pavilion"
    };

    public static String[] people = new String[]{
            "Дубровин А.Д.",
            "Кузин П.С.",
            "Антонов О.Д.",
            "Кондратов В.К.",
            "Костина О.В.",
            "Родионов П.Н.",
            "Крючкова О.Ю.",
            "Баженов В.П.",
            "Потапова М.А.",
            "Иванова А.Ю.",
    };

    public static String[] processors = new String[]{
            "Intel Сore","Intel Сore M","Intel Celeron", "Intel Pentium","AMD Ryzen 7","AMD Ryzen 8","AMD Ryzen 5"
    };

    public static String[] defects = new String[]{
            "Отказ видеоадаптера",
            "Отказ батареи",
            "Повреждения шлейфа монитора",
            "Дефект корпуса",
            "Отказ клавиатуры",
            "Отказ сетевого адаптера",
            "Отказ touchpad",
            "Поломка порта зарядки"
    };

    //Объемы ram
    public static int[] ramGb = new int[]{
            4,8,16,32
    };

    //Объемы накопителя
    public static int[] hardDriveGb = new int[]{
            256,512,1024,2048
    };


    //Бренд ноутбука
    public static String getBrand(){
        return brands[getRandom(0,brands.length)];
    }

    //модель ноутбука
    public static String getModel(){
        return models[getRandom(0,models.length)];
    }

    //тип процессора
    public static String getCpu(){
        return processors[getRandom(0,processors.length)];
    }

    //Дефект ноутбука
    public static String getDefect(){
        return defects[getRandom(0,defects.length)];
    }

    //ФИО владельца
    public static String getOwner(){
        return people[getRandom(0,people.length)];
    }

    //Объём ram
    public static int getRam(){
        return ramGb[getRandom(0,ramGb.length)];
    }

    //Объём накопителя
    public static int getHardDrive(){
        return hardDriveGb[getRandom(0,hardDriveGb.length)];
    }



}
