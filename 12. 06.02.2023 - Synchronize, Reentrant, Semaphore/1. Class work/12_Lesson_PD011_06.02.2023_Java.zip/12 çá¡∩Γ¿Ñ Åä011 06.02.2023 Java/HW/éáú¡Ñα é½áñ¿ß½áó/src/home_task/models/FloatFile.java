package home_task.models;

import home_task.utils.Utils;

import javax.swing.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class FloatFile implements Runnable {

    //Длина записи
    public static final int FIELD_LENGTH = Double.BYTES;

    //Имя файла
    private final String fileName;

    public FloatFile() throws Exception {
        this("numbers.bin","app_data");
    }

    public FloatFile(String name, String dir) throws Exception {

        fileName = String.format("%1$s/%2$s",dir,name);

        //Если файла не существует
        if (!Files.exists(Path.of(fileName))){
            createFile();
        }
    }

    //Запуск потока
    @Override
    public void run() {
        try {
            //Перемешать массив в файле
            shuffleFile();

            List<Double> numbers = readFile();

            StringBuilder sb = new StringBuilder(Utils.tableHtmlHeader);

            //Часть таблицы с исходной коллекцией
            Utils.listSbOutput(sb,numbers,"Прочитанный массив из файла");

            //Сортировка по возрастанию
            numbers.sort(Comparator.naturalOrder());

            //Отсортированная коллекция
            Utils.listSbOutput(sb,numbers,"Сортировка по возрастанию");

            //Сортировка по убыванию модулей
            numbers.sort((n1,n2) -> Double.compare(Math.abs(n2), Math.abs(n1)));

            //Отсортированная коллекция
            Utils.listSbOutput(sb,numbers,"Сортировка по убыванию модулей");

            writeToFile(numbers);

            //Переместить значения из диапазона в конец файла

            numbersToEnd();

            //Перечитать изменённый файл
            numbers = readFile();

            Utils.listSbOutput(sb,numbers,"Переместить значения из диапазона [-5, -1] в конец файла");

            //Вывод окна с таблицей
            Utils.showWindowButtons(sb.append(Utils.tableHtmlFooter).toString(),"Файл вещественных чисел",
                    new Object[]{"Назад"},"", JOptionPane.DEFAULT_OPTION);

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    //Создать и заполнить файл
    private void createFile() throws IOException {
        int amount = Utils.getRandom(15,21);

        try(DataOutputStream os = new DataOutputStream(new FileOutputStream(fileName))){
            for (int i = 0; i < amount; i++)
                os.writeDouble(Utils.getRandom(-10,10));
        }

    }

    //Чтение из файла
    private List<Double> readFile() throws IOException {

        List<Double> result = new ArrayList<>();

        try(DataInputStream is = new DataInputStream(new FileInputStream(fileName))){
            int i = 0;
            while (is.available() > 0)
                result.add(is.readDouble());
        }

        return result;
    }

    //Записать список в файл
    private void writeToFile(List<Double> numbers) throws IOException {
        try(DataOutputStream os = new DataOutputStream(new FileOutputStream(fileName))){
            //Запись элементов в файл
            for(Double n:numbers){
                os.writeDouble(n);
            }
        }
    }

    //Перемешать файл
    private void shuffleFile() throws IOException {

        //Кол-во записей в файле
        int amount = (int)Files.size(Path.of(fileName))/FIELD_LENGTH;

        try(RandomAccessFile raf = new RandomAccessFile(fileName,"rw")){
            int posCurr = 0;
            double first = 0;
            int posSecond = 0;
            double second = 0;

            for (int i = 0; i < amount; i++) {
                //Текущая позиция
                posCurr = i*FIELD_LENGTH;

                //Установка текущей позиции и чтение значения
                raf.seek(posCurr);
                first = raf.readDouble();

                //Переход на случайную позицию
                posSecond = Utils.getRandom(0, amount) * FIELD_LENGTH;
                raf.seek(posSecond);

                //Чтение второго значения
                second = raf.readDouble();

                //Переход на текущую (первую) позицию в файле и записать значение со случайной позиции
                raf.seek(posCurr);
                raf.writeDouble(second);

                //Переход на вторую позицию в файле и записать значение с текущей позиции
                raf.seek(posSecond);
                raf.writeDouble(first);

            }
        }
    }//shuffleFile

    //Числа из диапазона [-5, -1] в конец файла
    private void numbersToEnd() throws IOException {

        int amount = (int)Files.size(Path.of(fileName))/FIELD_LENGTH;

        //Скорректировать размер
        amount = amount >= 20 ? amount-1 : amount;

        //Костыльное временное имя файла
        String tempFile = fileName + "2";

        //Индексы элементов, подходящих под условие
        List<Integer> indices = new ArrayList<>();

        try(RandomAccessFile raf = new RandomAccessFile(fileName,"rw");
            RandomAccessFile raf2 = new RandomAccessFile(tempFile,"rw");){
            int addedAmount = 0;
            double num = 0;


            //Сначала числа в диапазон не попадающие
            for (int i = 0; i < amount; i++) {
                num = raf.readDouble();

                if (num > -1 || num < -5) {
                    raf2.writeDouble(num);
                    addedAmount++;
                }
                else indices.add(i);
            }

            //Переход на опозицию после последней записи
            raf2.seek(addedAmount *FIELD_LENGTH);
            raf.seek(0);

            /*for (int i = 0; i < amount; i++) {
                num = raf.readDouble();
                if (num >= -5 && num <= -1)
                    raf2.writeDouble(num);
            }//for*/

            for (int matchInd:indices) {
                raf.seek(matchInd*FIELD_LENGTH);
                num = raf.readDouble();
                raf2.writeDouble(num);
            }

            //Закрыть потоки
            raf.close();
            raf2.close();

            //Получить имя прочитанного файла
            Path path = Paths.get(fileName);

            Files.delete(path);

            new File(tempFile).renameTo(path.toFile());
        }

    }


    //Удалить файл
    public boolean deleteFile() throws IOException {
        return Files.deleteIfExists(Path.of(fileName));
    }
}
