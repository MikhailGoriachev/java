package app.models;

/*
    2.	Создание коллекции заявок на ремонт ноутбуков (наименование устройства, модель, тип процессора, объем 
    оперативной памяти, емкость накопителя, диагональ экрана, описание неисправности, фамилия и инициалы владельца), 
    сериализация этой коллекции при первом запуске; десериализация, перемешивание и сериализация при последующих 
    запусках. Вывод результатов в консоль при помощи StringBuilder
*/

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

// Класс Процесс 2
public class Proc02 implements Runnable {

    public final String FILE_NAME;


    // конструктор по умолчанию
    public Proc02() {
        FILE_NAME = "app_data/laptops.xml";
    }


    @Override
    public void run() {

        try {
            // начальная инициализация
            if (!Files.exists(Path.of(FILE_NAME)))
                serialization(List.of(
                        new Laptop("Asus", "VivoBook 15", "Intel Core i5", 16, 512, 15.2, "Матрица"),
                        new Laptop("Asus", "VivoBook 16", "Intel Core i7", 16, 512, 15.2, "Клавиатура"),
                        new Laptop("Apple", "MacBook Air", "Intel Core i5", 32, 512, 13d, "Матрица"),
                        new Laptop("Samsung", "GalaxyBook", "Intel Core i7", 8, 256, 15.2, "Материнская плата"),
                        new Laptop("Apple", "MacBook Pro", "Intel Core i7", 32, 1024, 15.2, "Матрица"),
                        new Laptop("Asus", "VivoBook 14", "Intel Core i3", 16, 512, 15.2, "Динамик"),
                        new Laptop("Samsung", "GalaxyBook", "Intel Core i5", 8, 256, 15.2, "Батарея"),
                        new Laptop("Samsung", "GalaxyBook 15", "Intel Core i5", 8, 256, 15.2, "Батарея"),
                        new Laptop("Apple", "MacBook Pro", "Intel Core i7", 32, 1024, 15.2, "Матрица"),
                        new Laptop("Apple", "MacBook Pro", "Intel Core i7", 32, 1024, 15.2, "Матрица")
                ));

            // загрузка данных
            var list = deserialization();

            // вывод данных
            showToConsole(list);

            // перемешивание
            Collections.shuffle(list);

            // запись данных
            serialization(list);

            // вывод данных
            showToConsole(list);

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    // сериализация
    public void serialization(List<Laptop> data) throws IOException {
        try (var stream = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
//            stream.writeObject(data);
            for (var d : data) {
                stream.writeObject(d);
            }
        }
    }

    // десериализация
    public List<Laptop> deserialization() throws Exception {
        if (!Files.exists(Path.of(FILE_NAME)))
            return new ArrayList<>();

        var list = new ArrayList<Laptop>();
        
        try (var stream = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            while (stream.available() > 0)
                list.add((Laptop) stream.readObject());
            return list;
        }
    }

    // вывод данных в виде таблицы в консоль
    public void showToConsole(List<Laptop> data) {
        var sb = new StringBuffer();


        sb.append("\n\u001B[35m")
                .append("\t+——————————————————————+——————————————————————+——————————————————————+———————+—————————+———————————+——————————————————————+\n")
                .append("\t| Название             | Модель               | Процессор            | RAM   | Storage | Диагональ | Дефект               |\n")
                .append("\t+——————————————————————+——————————————————————+——————————————————————+———————+—————————+———————————+——————————————————————+\n");

        data.forEach(d -> sb.append(d.toTableRow()));

        sb.append("\t+——————————————————————+——————————————————————+——————————————————————+———————+—————————+———————————+——————————————————————+\u001B[0m\n\n");

        System.out.println(sb);
    }
}
