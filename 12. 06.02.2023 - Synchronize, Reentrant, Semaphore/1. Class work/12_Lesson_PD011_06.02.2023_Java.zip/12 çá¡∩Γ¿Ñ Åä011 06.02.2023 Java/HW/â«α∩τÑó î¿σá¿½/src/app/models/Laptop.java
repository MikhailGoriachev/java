package app.models;

// Класс Ноутбук
// (наименование устройства, модель, тип процессора, объем оперативной памяти, емкость накопителя, диагональ экрана, 
// описание неисправности, фамилия и инициалы владельца) 
public record Laptop(
        String name,
        String model,
        String processor,
        int ram,
        int storageCapacity,
        double diagonal,
        String defectDescription) {

    // вывод персоны в строку таблицы
    public String toTableRow() {
        return String.format(
                "\t| %-20s |" +
                " %-20s |" +
                " %-20s |" +
                " %-5d |" +
                " %-7d |" +
                " %-9.1f |" +
                " %-20s |\n",
                name,
                model,
                processor,
                ram,
                storageCapacity,
                diagonal,
                defectDescription
        );
    }
}
