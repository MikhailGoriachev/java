package org.itstep.pd011;

// интерфейс с константами - альтернатива для перечисления с
// конструктором и полями
public interface INumbers {
    int ONE = -1;
    int TWO = -2;
    int THREE = -3;
    int FOUR = -4;
    int FIVE = -5;
} // interface INumbers
