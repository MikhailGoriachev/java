package org.itstep.pd011;

public class ClassINumbers implements INumbers {
    // этот класс содержит все константы, объявленные в интерфейсе INumbers
    // больше ничего в этом классе нет (унаследованное от Object не в счет)
} // class ClassINumbers
