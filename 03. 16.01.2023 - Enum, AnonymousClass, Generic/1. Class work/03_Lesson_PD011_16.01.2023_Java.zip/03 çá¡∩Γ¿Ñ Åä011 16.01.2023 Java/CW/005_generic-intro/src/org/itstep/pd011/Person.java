package org.itstep.pd011;

// неизменный тип
public record Person(String name, int age, double salary) {
}
