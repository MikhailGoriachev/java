
package org.itstep.pd011.hw002;
import javax.swing.*;
import java.security.InvalidParameterException;

public class Main {
    public static void main(String[] args) {
        while (true) {
            String result = (String) JOptionPane.showInputDialog(null,
                    "<html><h3>Выберите <u>пункт</u> меню:</h3>",
                    "Вариант для решения",
                    JOptionPane.QUESTION_MESSAGE,
                    new ImageIcon(Main.class.getResource("comparing.png")),
                    new Object[]{"Класс String", "Классы String, StringBuilder, StringTokenizer", "Классы Mobiles", "Наследование, полиморфизм"},
                    "Методы класса Math");
            System.out.printf("\nВы выбрали пункт меню \033[1;4m  %s  \033[0m\n", result == null ? "Выход" : result);
            if (result == null) break;
            switch (result) {
                case "Класс String" -> Solve.task1();
                case "Классы String, StringBuilder, StringTokenizer" -> Solve.task2();
                case "Классы Mobiles" -> Solve.task3();
                case "Наследование, полиморфизм" -> Solve.task4();
            } // switch
        } // while
    }
}