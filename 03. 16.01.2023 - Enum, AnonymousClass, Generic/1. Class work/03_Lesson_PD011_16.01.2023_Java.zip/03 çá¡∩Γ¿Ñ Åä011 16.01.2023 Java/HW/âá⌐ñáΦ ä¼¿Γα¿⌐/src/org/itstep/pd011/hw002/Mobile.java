package org.itstep.pd011.hw002;

public class Mobile {

    // Фирма-разработчик
    private String manufacturer;

    // Название
    private String name;

    // Год выпуска
    private int    year;

    // Цена
    private double price;

    public Mobile() {
    }

    public Mobile(String manufacturer, String name, int year, double price) {
        this.manufacturer = manufacturer;
        this.name = name;
        this.year = year;
        this.price = price;
    }

    @Override
    public String toString() {
        return String.format("Фирма-разработчик: %-15s; Название: %-15s; год выпуска: %d; цена: %.2f;", manufacturer, name, year, price);
    } // toString

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
} // Mobile
