package org.itstep.pd011.hw002;

import java.util.Collections;
import java.util.Comparator;
import java.util.StringTokenizer;
import java.util.Arrays;

public class Solve {
    // решение Задачи1
    public static void task1() {
        // Дан символ C и строки S, S0. После каждого вхождения символа C в строку S вставить строку S0
        System.out.println("\n\tДан символ C и строки S, S0. После каждого вхождения символа C в строку S вставить строку S0");
        String S = " кот ломом колол слона кот", C = "о", S0 = "у";
        System.out.println("\nСтрока S> "+S+"\nСимвол C> "+C+"\nСтрока S0> "+S0);
        S = S.replace(C, C + S0);
        System.out.println("\nСтрока S после replace> "+S);

        // Даны строки S и S0. Проверить, содержится ли строка S0 в строке S. Если содержится, то вывести TRUE, если не содержится, то вывести FALSE
        System.out.println("\n\tДаны строки S и S0. Проверить, содержится ли строка S0 в строке S. Если содержится, то вывести TRUE, если не содержится, то вывести FALSE");
        S0 = "коут";
        System.out.println("\n Есть ли в строке \""+S+"\" строка \""+S0+"\" "+S.contains(S0));

        // Даны строки S и S0. Удалить из строки S первую подстроку, совпадающую с S0. Если совпадающих подстрок нет, то вывести строку S без изменений.
        System.out.println("\n\tДаны строки S и S0. Удалить из строки S первую подстроку, совпадающую с S0. Если совпадающих подстрок нет, то вывести строку S без изменений.");
        System.out.println("Строка S до имзенения> "+S+"\n строка S0> "+S0);
        S0 = "коут";
        S = S.replaceFirst(S0, "");
        System.out.println("Строка S после изменения> "+S);
    } // task1

    // решение Задачи2
    public static void task2() {
        String str = "Быть или не --- быть       ,  \t\t вот в чем вопрос. Достойно ль\n" +
                "Смиряться ,под ударами .. судьбы,\n" +
                "Иль надо оказать   сопротивленье\n" +
                "И в смертной схватке с \t целым морем бед \n" +
                "Покончить с ними? Умереть. ????????? Забыться.";
        StringBuilder out = new StringBuilder();

        StringTokenizer stz = new StringTokenizer(str, " .,\t\n:;-!?");


        // вывод текста для обработки
        System.out.printf("\033[37m%s\033[0m\n-----------------------------------------------------------\n", str);

        // определить количество токенов (слов) в строке
        int n = stz.countTokens();
        String[] words = new String[n];

        // разбиение на токены
        for (int i = 0; i < n; i++)
            words[i] = stz.nextToken();

        System.out.printf("Всего слов: %d\n", n);
        Arrays.sort(words, (a, b) -> b.compareTo(a));
        for (String word : words)
            out.append(word + " ");

        System.out.println("Строка со словами в обратном от алфавита порядке: " + out);
        System.out.println("Самые короткие слова: " + getShortestWord(words));
        System.out.println("Самые длинные слова: " + getLongestWord(words));
    } // task2

    private static String getShortestWord(String[] words){
        int shortWord = Integer.MAX_VALUE;
        String shortest = "";
        for(int i = 0;i<words.length;i++)
            if (words[i].length()<shortWord) {
                shortWord = words[i].length();
                shortest = words[i];
            }
        return shortest;
    } // getShortestWord
    private static String getLongestWord(String[] words){
        int longWord = Integer.MIN_VALUE;
        String longest = "";
        for(int i = 0;i<words.length;i++)
            if (words[i].length() > longWord) {
                longWord = words[i].length();
                longest = words[i];
            }
        return longest;
    } // getLongestWord

    // Классы. Создать класс Mobile, описывающий мобильный телефон (фирма-разработчик, название модели, стоимость, год выпуска). Создайте и проинициируйте массив из 12 элементов класса Mobile (коллекцию мобильных телефонов).
    public static void task3() {
        int n = 12;
        Mobile[] mobiles = {
                new Mobile("Samsung", "Galaxy A51", 2020, 25000),
                new Mobile("Xiaomi", "10T", 2019, 30000),
                new Mobile("Xiaomi", "10T Pro", 2019, 35000),
                new Mobile("Realme", "C21", 2022, 7900),
                new Mobile("Realme", "9С", 2022, 15000),
                new Mobile("Samsung", "Galaxy A12", 2020, 14600),
                new Mobile("Xiaomi", "Redmi Note 9T", 2021, 16500),
                new Mobile("Xiaomi", "POCO M3 Pro 5G", 2021, 11500),
                new Mobile("HONOR", "10X Lite", 2018, 12500),
                new Mobile("Xiaomi", "Redmi Note 10S", 2022, 12300),
                new Mobile("Samsung", "Galaxy A32", 2021, 17000),
                new Mobile("Xiaomi", "POCO X3 Pro", 2021, 30000),
        };
        System.out.println("\tМассив телефонов:\n");
        showMobiles(mobiles);
        System.out.println("\nСуммарная стоимость телефонов в массиве: "+sumMobiles(mobiles));
        System.out.println("\nМодель с миниальной стоимостью>\n"+getMinPriceMobile(mobiles));
        System.out.println("\nМодель с максимальной стоимостью>\n"+getMaxPriceMobile(mobiles));

        // упорядочить массив телефонов по убыванию года выпуска
        Arrays.sort(mobiles, new Comparator<Mobile>() {
            @Override
            public int compare(Mobile m1, Mobile m2) {
                return m2.getYear() < m1.getYear()?-1:m2.getYear() > m1.getYear()?1:0;
            }
        });
        System.out.println("\tУпорядоченный по убыванию года выпуска массив телефонов:\n");
        showMobiles(mobiles);

        // упорядочить массив телефонов по возрастанию стоимости
        Arrays.sort(mobiles, new Comparator<Mobile>() {
            @Override
            public int compare(Mobile m1, Mobile m2) {
                return m2.getPrice() > m1.getPrice()?-1:m2.getPrice() < m1.getPrice()?1:0;
            }
        });
        System.out.println("\tУпорядоченный по возрастанию стоимости массив телефонов:\n");
        showMobiles(mobiles);
    } // task 3

    private static void showMobiles(Mobile[] mobiles) {
        for (Mobile m : mobiles) {
            String color = "";
            System.out.printf("%s%s\033[0m\n", color, m);
        } // for m
    } // showMobiles

    private static double sumMobiles(Mobile[] mobiles){
        double res = 0;
        for(int i = 0;i<mobiles.length;i++)
            res+=mobiles[i].getPrice();
        return res;
    } // sumMobiles

    private static Mobile getMinPriceMobile(Mobile[] mobiles){
        Mobile minPriceMobile = mobiles[0];
        for(int i = 1;i<mobiles.length;i++)
            if(mobiles[i].getPrice()<minPriceMobile.getPrice())
                minPriceMobile = mobiles[i];
        return minPriceMobile;
    } // getMinPriceMobile
    private static Mobile getMaxPriceMobile(Mobile[] mobiles){
        Mobile maxPriceMobile = mobiles[0];
        for(int i = 1;i<mobiles.length;i++)
            if(mobiles[i].getPrice()>maxPriceMobile.getPrice())
                maxPriceMobile = mobiles[i];
        return maxPriceMobile;
    } // getMaxPriceMobile

    // Наследование, полиморфизм. Разработайте производные от абстрактного
    // класса Body классы для работы с усеченным конусом, цилиндром, шаром и
    // правильной треугольной пирамидой. Предусмотрите хранение
    // наименования тела (строки «усеченный конус», «цилиндр» и т.д.), размеры
    // тел. Используйте интерфейс IBody для задания методов вычислений
    // площади поверхности, объема и вывода в строку таблицы (консольной или
    // HTML – по Вашему выбору). Создайте полиморфный массив из объемных тел
    // этих классов при помощи фабричного метода
    public static void task4() {
        System.out.println("\n\tВ разработке...");
    } // task 4
}
