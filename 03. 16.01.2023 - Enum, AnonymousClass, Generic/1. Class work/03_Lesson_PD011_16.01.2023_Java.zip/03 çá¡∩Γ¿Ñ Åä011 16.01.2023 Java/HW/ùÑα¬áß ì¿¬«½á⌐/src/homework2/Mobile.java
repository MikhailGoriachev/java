package homework2;

public class Mobile {
    private String maker;
    private String title;
    private int price;
    private int age;
    public static String topTable = """
 -----------------------------------------------------------------
| производитель   |        название      |   цена   | год выпуска |
 -----------------------------------------------------------------
            """;
    public static String bottomTable = """
   -----------------------------------------------------------------
            """;

    public String getMaker() {
        return maker;
    }

    public void setMaker(String maker) {
        this.maker = maker;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Mobile() {
    }

    public Mobile(String maker, String title, int price, int age) {
        this.maker = maker;
        this.title = title;
        this.price = price;
        this.age = age;
    }

    public static void show(Mobile[] arr){
        System.out.println(topTable);
        for (var item:arr){
            System.out.printf("| %15s | %20s | %8d | %11d |\n", item.maker, item.title, item.price, item.getAge());
        }
        System.out.println(bottomTable);
    }
}
