package homework2;

public class Utils {
    public static Mobile[] getArrayMobile(){
        return new Mobile[]{
                new Mobile("Samsung", "Galaxy A03", 13999, 2022),
                new Mobile("Samsung", "Galaxy M52", 39999, 2021),
                new Mobile("Xiaomi", "Redmi 9A", 7999,2021),
                new Mobile("Xiaomi", "POCO C40", 9999,2022),
                new Mobile("TCL", "305 Atlantic Blue", 9399,2022),
                new Mobile("Tecno", "Spark Go 2022", 6999,2022),
                new Mobile("Xiaomi", "Redmi Note 11", 14999,2020),
                new Mobile("Samsung", "Galaxy A73 5G", 39999, 2022),
                new Mobile("Realme", "C11 2021", 8999, 2021),
                new Mobile("ITEL", "A48 Green", 7699, 2020),
                new Mobile("ITEL", "A49 Starry Green", 8699,2021),
                new Mobile("Samsung", "Galaxy M53", 36999,2021),
        };
    }
}
