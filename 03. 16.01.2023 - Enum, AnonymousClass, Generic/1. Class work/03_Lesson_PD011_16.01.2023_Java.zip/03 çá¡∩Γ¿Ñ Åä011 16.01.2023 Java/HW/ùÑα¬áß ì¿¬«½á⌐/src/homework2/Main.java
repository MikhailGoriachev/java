package homework2;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        System.out.println("\033[34mДан символ C и строки S, S0. После каждого вхождения символа C в строку S вставить строку S0\033[0m");
        System.out.println("Введите строку");
        String S = getInputString();
        System.out.println("Введите строку");
        String S0 = getInputString();
        System.out.println("Введите символ");
        String C = getInputString();

        System.out.printf("\nS = %s\nS0 = %s\nC = %s\n", S, S0, C);
        S = S.replace(C, C.concat(S0));
        System.out.printf("\033[32m%s\n\n", S);

        System.out.println("\033[34mДаны строки S и S0. Проверить, содержится ли строка S0 в строке S.\nЕсли содержится, то вывести TRUE, если не содержится, то вывести FALSE\033[0m");
        System.out.printf("S = %s\nS0 = %s\n", S, S0);
        System.out.println(S.contains(S0) ? "TRUE" : "FALSE");

        System.out.println("\033[34m\nДаны строки S и S0. Удалить из строки S первую подстроку, совпадающую с S0.\nЕсли совпадающих подстрок нет, то вывести строку S без изменений.\033[0m");
        int index = S.indexOf(S0);
        System.out.printf("S = %s\nS0 = %s\n", S, S0);
        if (index != -1)
            S = S.substring(0, index).concat(S.substring(index + S0.length()));
        System.out.printf("\033[32m%s\n", S);

        String str = "кот ломом, колол? мамонта";
        StringTokenizer stz = new StringTokenizer(str, " ,?");
        System.out.println("\033[34mСтрока, состоящая из слов, разделенных пробелами и знаками препинания \033[0m");
        System.out.println(str);
        int n = stz.countTokens();
        StringBuilder sbd = new StringBuilder();
        for (int i = 0; i < n; i++) {
            sbd.append(stz.nextToken());
            sbd.append(" ");
        }
        System.out.println(sbd);

        Mobile[] mobiles = Utils.getArrayMobile();
        System.out.println("\nкласс Mobile");
        Mobile.show(mobiles);
        System.out.printf("\033[32mСтоимость всех телефонов: %d\033[0m\n", sumaPrice(mobiles));
        System.out.println("\033[34mмодели с минимальной ценой\033[0m");
        showMinPrice(mobiles);
        System.out.println("\033[34mмодели с максимальной ценой\033[0m");
        showMaxPrice(mobiles);
        System.out.println("\033[34mпо убыванию года выпуска \033[0m");
        Arrays.sort(mobiles, (a, b) -> Double.compare(b.getAge(), a.getAge()));
        Mobile.show(mobiles);
        System.out.println("\033[34mпо возрастанию стоимости\033[0m");
        Arrays.sort(mobiles, (a, b) -> Double.compare(a.getPrice(), b.getPrice()));
        Mobile.show(mobiles);
    }

    // ввод строки
    static String getInputString() {
        Scanner in = new Scanner(System.in);
        String str = "";
        do {
            str = in.nextLine();//"кот ломом колол слона";
        } while (str.equals(""));
        return str;
    }

    // суммарную стоимость телефонов в массиве
    static int sumaPrice(Mobile[] arr) {
        int suma = 0;
        for (var item:arr){
            suma += item.getPrice();
        }
        return suma;
    }
    // минимальная цена
    static int minPrice(Mobile[] arr){
        int min = arr[0].getPrice();
        for (var item:arr){
            if (item.getPrice() < min){
                min = item.getPrice();
            }
        }
        return min;
    }
    // максимальная цена
    static int maxPrice(Mobile[] arr){
        int max = arr[0].getPrice();
        for (var item:arr){
            if (item.getPrice() > max){
                max = item.getPrice();
            }
        }
        return max;
    }
    static void showMinPrice(Mobile[] arr){
        int min = minPrice(arr);
        System.out.print(Mobile.topTable);
        for (var item:arr){
            if (item.getPrice() == min){
                System.out.printf("| %15s | %20s | %8d | %11d |\n", item.getMaker(), item.getTitle(), item.getPrice(), item.getAge());
            }
        }
        System.out.println(Mobile.bottomTable);
    }
    static void showMaxPrice(Mobile[] arr){
        int max = maxPrice(arr);
        System.out.print(Mobile.topTable);
        for (var item:arr){
            if (item.getPrice() == max){
                System.out.printf("| %15s | %20s | %8d | %11d |\n", item.getMaker(), item.getTitle(), item.getPrice(), item.getAge());
            }
        }
        System.out.println(Mobile.bottomTable);
    }

}