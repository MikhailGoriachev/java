package org.itstep.pd011.models;

import java.util.Arrays;

public class Mobiles {

    Mobile[] mobiles = new Mobile[]{};

    public void initialize(){
        mobiles = new Mobile[]{
                new Mobile("Samsung", "Galaxy A72", 28000, 2021),
                new Mobile("Samsung", "Galaxy A53", 23000, 2022),
                new Mobile("Xiaomi", "Xiaomi 12X", 57000, 2022),
                new Mobile("Realme", "Realme GT2", 36000, 2021),
                new Mobile("Apple", "iPhone 12", 45500, 2020),
                new Mobile("Vivo", "iQOO Neo 6", 42000, 2022),
                new Mobile("Samsung", "Galaxy Z Flip4", 57000, 2022),
                new Mobile("Vivo", "Vivo X50Pro", 46000, 2022),
                new Mobile("Xiaomi", "Xiaomi Poco F4", 47700, 2022),
                new Mobile("Realme", "Realme 9", 23000, 2021),
                new Mobile("Apple", "iPhone 13", 57000, 2021),
                new Mobile("Vivo", "Vivo S9", 35000, 2022),
        };
    }


    // найти суммарную стоимость телефонов в массиве
    public double sumPrice(){
        double sum = 0;
        for (Mobile value : mobiles) {
            sum += value.getPrice();
        }

        return sum;
    }


    // модели с минимальной ценой
    public double MinPrice() {
        double minPrice = Double.MAX_VALUE;

        for (Mobile value : mobiles) {
            if (value.getPrice() < minPrice)
                minPrice= value.getPrice();
        }

        return minPrice;
    }

    // модели с максимальной ценой
    public double MaxPrice() {
        double maxPrice = Double.MIN_VALUE;

        for (Mobile value : mobiles) {
            if (value.getPrice() > maxPrice)
                maxPrice= value.getPrice();
        }

        return maxPrice;
    }

    // упорядочить коллекцию телефонов по убыванию года выпуска
    // (используйте лямбда-выражение для сравнения элементов)
    public void orderByYear(){
        Arrays.sort(mobiles, (o1, o2) -> Integer.compare(o2.getYear(), o1.getYear()));
    }

    // упорядочить коллекцию телефонов по возрастанию стоимости
    // (используйте лямбда-выражение для сравнения элементов)
    public void orderByPrice(){
        Arrays.sort(mobiles, (o1, o2) -> Double.compare(o1.getPrice(), o2.getPrice()));
    }


    // вывести модели с минимальной и максимальной ценой
    public void SelectWherePriceEq(double price) {
        for (Mobile m : mobiles) {
            String color = "";
            if (m.getPrice() == price) color = "\033[34;1m";
            System.out.printf("%s%10s\033[0m\n",color, m);
        } // for
    }

    // вывод массива объектов
    public void showMobile(String title) {
        System.out.println(title);

        for (Mobile m : mobiles) {
            m.show();
        } // for
    }


} // class Mobiles
