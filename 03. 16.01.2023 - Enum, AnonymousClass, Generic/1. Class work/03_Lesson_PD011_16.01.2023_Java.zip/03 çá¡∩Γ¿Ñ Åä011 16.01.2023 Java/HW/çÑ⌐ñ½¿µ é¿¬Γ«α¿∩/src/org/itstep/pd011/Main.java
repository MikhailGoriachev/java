package org.itstep.pd011;

import org.itstep.pd011.models.Mobiles;

import java.util.Arrays;
import java.util.Comparator;
import java.util.StringTokenizer;

public class Main {
    public static void main(String[] args) {

        ProcessTask1();
        ProcessTask2();
        ProcessTask3();

    }


    private static void ProcessTask1(){
        System.out.printf("\033[34m%s\033[0m\n-----------------------------------------------------------\n", "\tКласс String. Обработка для строк и символов");

        String c = "к";
        String s = "кот ломом колол слона";
        String s0 = "енот";

        System.out.printf("Строка : \"%s\"\n", s);


        // Дан символ C и строки S, S0.
        // После каждого вхождения символа C в строку S вставить строку S0.
        System.out.printf("После каждого вхождения символа \"%s\" в строку \"%s\" вставить строку \"%s\"\n", c,s,s0);
        s = s.replaceAll(c, c + s0);
        System.out.printf("\n\033[32;1m\"%s\"\033[0m\n\n\"", s);


        // Даны строки S и S0. Проверить, содержится ли строка S0 в строке S.
        // Если содержится, то вывести TRUE, если не содержится, то вывести FALSE
        s0 = "на";
        System.out.printf("Проверить, содержится ли строка \"%s\" в строке \"%s\"\n", s0, s);

        if (s.contains(s0))
            System.out.printf("\033[32;1m\"%s\"\033[0m\n\n\"", "TRUE");
        else
            System.out.printf("\033[32;1m\"%s\"\033[0m\n\n\"", "FALSE");


        // Даны строки S и S0. Удалить из строки S первую подстроку,
        // совпадающую с S0. Если совпадающих подстрок нет,
        // то вывести строку S без изменений
        s0 = "ло";
        System.out.printf("Удалить из строки \"%s\" первую подстроку совпадающую с \"%s\"\n", s, s0);

        s = s.replaceFirst(s0, "");
        System.out.printf("\n\033[32;1m\"%s\"\033[0m\n\n\"", s);

    } // ProcessTask1


    // Вывести строку, содержащую эти же слова,
    // разделенные одним пробелом и расположенные в порядке,
    // обратном алфавитному, определить и вывести самое
    // короткое и самое длинное слово в строке.
    private static void ProcessTask2(){
        System.out.printf("\033[34m%s\033[0m\n--------------------------------------------------------------------------\n", "\tКлассы String, StringBuilder, StringTokenizer. Обработка для слов");

        String str = "Значимость проверки систем.. этих проблем настолько очевидна," +
                " что новая модель организационной деятельности, что представляет" +
                " собой интересный эксперимент! Проверки систем массового участия.";

        System.out.printf("Строка до обработки : \n\"%s\"\n\n", str);

        StringTokenizer stz = new StringTokenizer(str, " .,\t\n:;-!?");

        int n = stz.countTokens();

        String[] words = new String[n];
        for (int i = 0; i < n; i++) {
            words[i] = stz.nextToken();
        } // for i


        // строка содержащая слова расположенные в порядке, обратном алфавитному
        Arrays.sort(words, Comparator.reverseOrder());

        str = String.join(" ", words);
        System.out.printf("Cтрока содержащая слова расположенные в порядке, обратном алфавитному: \n\033[32;1m\"%s\"\033[0m\n\n", str);

        String wMin = minWord(words);
        String wMax = maxWord(words);

        System.out.printf("Cамое короткое слово: \033[32;1m\"%s\"\033[0m\n", wMin);
        System.out.printf("Cамое длинное слово: \033[32;1m\"%s\"\033[0m\n", wMax);

    } // ProcessTask2


    private static void ProcessTask3(){
        System.out.printf("\n\033[34m%s\033[0m\n-------------------------------------------------------------------\n", "\tКлассы. Создать класс Mobile, описывающий мобильный телефон. ");

        Mobiles mobiles = new Mobiles();
        mobiles.initialize();

        mobiles.showMobile("\nМассив объектов:\n");

        double sum = mobiles.sumPrice();
        System.out.printf("\nСуммарная стоимость телефонов: \033[32;1m%.1f\033[0m рубл.\n", sum);

        double minPrice = mobiles.MinPrice();
        System.out.printf("\nТелефоны с минимальной ценой: \033[34;1m%.1f\033[0m рубл.\n", minPrice);
        mobiles.SelectWherePriceEq(minPrice);

        double maxPrice = mobiles.MaxPrice();
        System.out.printf("\nТелефоны с максимальной ценой: \033[34;1m%.1f\033[0m рубл.\n", maxPrice);
        mobiles.SelectWherePriceEq(maxPrice);


        mobiles.orderByYear();
        mobiles.showMobile("\nМассив объектов упорядочен по убыванию года выпуска:\n");

        mobiles.orderByPrice();
        mobiles.showMobile("\nМассив объектов упорядочен по возрастанию стоимости:\n");

    } // ProcessTask3

    //------------------------------------------------------------------------------------------
    // поиск короткого слова
    private static String minWord(String[] words){
        int minLen = Integer.MAX_VALUE;
        String wMin = "";

        for (String word:words) {
            if (word.length() < minLen) {
                wMin = word;
                minLen = word.length();
            } // if
        } // for

        return wMin;
    }

    // поиск длинного слова
    private static String maxWord(String[] words){
        int maxLen = 0;
        String wMax = "";

        for (String word:words) {
            if (word.length() > maxLen) {
                wMax = word;
                maxLen = word.length();
            } // if
        } // for

        return wMax;
    }

} // class Main