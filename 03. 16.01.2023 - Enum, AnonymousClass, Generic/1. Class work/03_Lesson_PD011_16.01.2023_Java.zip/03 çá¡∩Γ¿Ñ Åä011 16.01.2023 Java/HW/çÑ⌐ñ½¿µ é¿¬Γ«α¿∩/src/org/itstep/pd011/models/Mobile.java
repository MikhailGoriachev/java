package org.itstep.pd011.models;

// Класс Mobile, описывающий мобильный телефон:
// фирма-разработчик,
// название модели,
// стоимость,
// год выпуска
public class Mobile {

    // фирма-разработчик
    private String companyName;

    // название модели
    private String name;

    // стоимость
    private double price;

    // год выпуска
    private int    year;

    // конструктор
    public Mobile() {
    }


    public Mobile(String companyName, String name, double price, int year) {
        this.companyName = companyName;
        this.name = name;
        this.price = price;
        this.year = year;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public String getName() {
        return name;
    }

    public int getYear() {
        return year;
    }

    public double getPrice() {
        return price;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Фирма: '" + companyName + '\'' +
                " модель: '" + name + '\'' +
                " цена: " + price +
                " год: " + year;
    }


    public void show(){
        System.out.printf("Фирма:%-8s  Модель: %-14s  Цена: %4.1f  Год: %4d\n", companyName, name, price, year);
    }


} // class Mobile
