package app.models.task04;

// Абстрактный класс для фигуры
public abstract class Body {
    
    // название фигуры
    public String name;
}
