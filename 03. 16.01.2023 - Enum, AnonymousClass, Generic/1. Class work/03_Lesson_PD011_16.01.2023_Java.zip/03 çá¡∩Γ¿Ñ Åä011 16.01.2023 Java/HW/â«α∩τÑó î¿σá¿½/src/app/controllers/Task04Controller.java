package app.controllers;

import app.interfaces.IController;
import app.models.task03.Mobile;

import javax.swing.*;

/*
    •	Наследование, полиморфизм. Разработайте производные от абстрактного класса Body классы для работы с усеченным 
        конусом, цилиндром, шаром и правильной треугольной пирамидой. Предусмотрите хранение наименования тела (строки
        усеченный конус», «цилиндр» и т.д.), размеры тел. Используйте интерфейс IBody для задания методов вычислений 
        лощади поверхности, объема и вывода в строку таблицы (консольной или HTML – по Вашему выбору). Создайте 
        олиморфный массив из объемных тел этих классов при помощи фабричного метода. Реализовать обработки (не 
        спользовать StreamAPI):
        o	сформировать и вывести массив объектов (не менее 12 элементов)
        o	найти средний объем тел в массиве, среднюю площадь поверхности тел в массиве
        o	вывести тела с минимальной и максимальной площадью поверхности
        o	упорядочить массив тел по убыванию объема (используйте лямбда-выражение для сравнения элементов)
        o	упорядочить массив тел по возрастанию площади поверхности
*/

// Контроллер Задание 2
public class Task04Controller implements IController {

    // телефоны
    public Mobile[] figures;


    // конструктор по умолчанию
    public Task04Controller() {
        initialization();
    }

    // конструктор
    public Task04Controller(Mobile[] mobiles) {
        this.figures = mobiles;
    }


    // работа по заданию
    public void run() {
        var message = "<html>" +
                "<h2 align='center'>В разработке</h2>";

        showMessage(message, "Задание 4. Фигуры");
    }

    // инициализация коллекции
    public void initialization() {

    }

    // вывод в таблицу
    public String mobilesToTable(Mobile[] data) {
        StringBuilder table = new StringBuilder(
                "<table border='2' cellspacing='0' cellpadding='8'>" +
                        "<thead><tr>" +
                        "<th>№</th>" +
                        "<th>Бренд</th>" +
                        "<th>Модель</th>" +
                        "<th>Цена</th>" +
                        "<th>Бренд</th>" +
                        "<th>Год</th>" +
                        "</tr></thead><tbody>");

        for (int i = 0; i < data.length; i++) {
            table.append(data[i].toTableRow(i + 1));
        }

        table.append("</tbody></table>");

        return table.toString();
    }

    // вывод данных в окно
    public static void showMessage(String message, String title) {
        JOptionPane.showOptionDialog(
                null,
                message,
                title,
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(),
                new Object[]{"Далее"},
                "Далее"
        );
    }
}
