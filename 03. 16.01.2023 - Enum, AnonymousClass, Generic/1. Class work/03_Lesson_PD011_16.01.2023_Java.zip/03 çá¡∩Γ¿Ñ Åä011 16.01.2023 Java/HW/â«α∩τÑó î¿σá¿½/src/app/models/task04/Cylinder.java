package app.models.task04;

import app.interfaces.task04.IBody;

public class Cylinder extends Body implements IBody {
    
    @Override
    public double area() {
        return 0;
    }

    @Override
    public double volume() {
        return 0;
    }

    @Override
    public String toTableRow() {
        return null;
    }
}
