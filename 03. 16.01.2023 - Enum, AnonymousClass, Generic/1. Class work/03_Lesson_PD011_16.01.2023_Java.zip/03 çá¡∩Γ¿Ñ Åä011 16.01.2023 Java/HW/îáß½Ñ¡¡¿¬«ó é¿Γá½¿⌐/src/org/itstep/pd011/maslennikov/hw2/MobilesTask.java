package org.itstep.pd011.maslennikov.hw2;

import org.itstep.pd011.maslennikov.hw2.models.MobilesArray;

import javax.swing.*;

public class MobilesTask {
    static MobilesArray mobilesArray;

    public static void run() {
        String message = generate();

        while(message != null) {
            message = switch (showMenu(message)) {
                case 0 -> generate();
                case 1 -> sourceData();
                case 2 -> minPriceMobiles();
                case 3 -> maxPriceMobiles();
                case 4 -> orderByYearDes();
                case 5 -> orderByPrice();
                default -> null;
            };
        }
    }

    private static String generate() {
        mobilesArray = new MobilesArray(12);

        return sourceData();
    }

    private static String sourceData() {

        int totalCosts = mobilesArray.totalCosts();

        return mobilesArray.mobilesToHtmlTable() +
                "<div style='font-size:12px;margin:4px 0 10px'>Суммарная стоимость:" +
                "<span style='color:green'>"  + totalCosts + "</span></div>";
    }

    private static String minPriceMobiles() {
        return mobilesArray.getCheapest().mobilesToHtmlTable();
    }

    private static String maxPriceMobiles() {
        return mobilesArray.getMostExpensive().mobilesToHtmlTable();
    }

    private static String orderByYearDes() {
        return mobilesArray.orderedByYearDesc().mobilesToHtmlTable();
    }

    private static String orderByPrice() {
        return mobilesArray.orderedByPrice().mobilesToHtmlTable();
    }

    private static int showMenu(String content) {
        return JOptionPane.showOptionDialog(
                null,
                content,
                "Мобильные телефоны",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                new Object[]{"Сформировать", "Исходные", "С мин. ценой", "С макс. ценой", "По убыванию года выпуска", "По возрастанию стоимости", "Назад"},
                "Выход"
        );
    }
}
