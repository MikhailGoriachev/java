package org.itstep.pd011.maslennikov.hw2;

import java.util.InputMismatchException;
import java.util.Random;

public class Utils {
    private static final Random rand = new Random();

    // метод, возвращающий случайное вещественное число,
    // передаются нижнее и верхнее значения
    public static double getRandom(double lo, double hi){
        return lo + rand.nextDouble() * (hi - lo);
    }

    // перегруженный метод, возвращающий случайное целое число,
    // передаются нижнее и верхнее значения
    public static int getRandom(int lo, int hi) {
        return lo + rand.nextInt(hi - lo + 1);
    }

    public static String padRight(String s, int n) {
        return String.format("%-" + n + "s", s);
    }

    public static String padLeft(String s, int n) {
        return String.format("%" + n + "s", s);
    }
}
