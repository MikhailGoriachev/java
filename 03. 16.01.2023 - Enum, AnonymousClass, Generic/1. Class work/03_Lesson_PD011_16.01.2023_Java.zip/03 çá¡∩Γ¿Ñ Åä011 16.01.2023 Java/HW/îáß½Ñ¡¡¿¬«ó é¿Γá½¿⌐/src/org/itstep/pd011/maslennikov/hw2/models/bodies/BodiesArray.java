package org.itstep.pd011.maslennikov.hw2.models.bodies;

import org.itstep.pd011.maslennikov.hw2.Utils;

import java.util.Arrays;
import java.util.Comparator;


public class BodiesArray {

    // Коллекция фигур
    IBody[] bodies = new IBody[] {};

    public BodiesArray() {
    }

    public BodiesArray(int amount) {
        bodies = bodiesFactory(amount);
    }

    public BodiesArray(IBody[] bodies) {
        this.bodies = bodies;
    }

    // Фабрика коллекции тел
    private static IBody[] bodiesFactory(int amount) {

        IGenerate[] generators = new IGenerate[]{
                Sphere::Generate,
                Conoid::Generate,
                Pyramid::Generate,
                Cylinder::Generate,
        };

        IBody[] bodies = new IBody[amount];

        for (int i = 0; i < bodies.length; i++) {
            bodies[i] = generators[Utils.getRandom(0, generators.length - 1)].generate();
        }

        return bodies;
    }

    // Добавление элемента в колекцию
    public void add(IBody body) {
        bodies = Arrays.copyOf(bodies, bodies.length + 1);
        bodies[bodies.length - 1] = body;
    }

    // Очистить коллекцию
    public BodiesArray removeAll() {
        bodies = new IBody[]{};
        return this;
    }

    // Среднее арифметическое объемов тел
    public double getVolumesMean() {
        double volumes = 0;

        for(IBody body: bodies) {
            volumes += body.volume();
        }

        return volumes / bodies.length;
    }

    // Среднее арифметическое площадей поверхности тел
    public double getAreasMean() {
        double areas = 0;

        for(IBody body: bodies) {
            areas += body.area();
        }

        return areas / bodies.length;
    }

    // Тела с минимальными площадями поверхности
    public BodiesArray minAreaBodies() {
        double minArea = bodies[0].area();
        BodiesArray minAreaBodies = new BodiesArray();

        for (IBody body: bodies) {
            double curArea = body.area();

            if (curArea < minArea) {
                minArea = curArea;
                minAreaBodies.removeAll().add(body);
            } else if (curArea == minArea) {
                minAreaBodies.add(body);
            }
        }

        return minAreaBodies;
    }

    // Тела с максимальными площадями поверхности
    public BodiesArray maxAreaBodies() {
        double maxArea = bodies[0].area();
        BodiesArray maxAreaBodies = new BodiesArray();

        for (IBody body: bodies) {
            double curArea = body.area();

            if (curArea > maxArea) {
                maxArea = curArea;
                maxAreaBodies.removeAll().add(body);
            } else if (curArea == maxArea) {
                maxAreaBodies.add(body);
            }
        }

        return maxAreaBodies;
    }

    // Упорядочить по убыванию объемов тел
    public BodiesArray orderedByVolumesDesc() {
        IBody[] copy = Arrays.copyOf(bodies, bodies.length);
        Arrays.sort(copy, (b1, b2) -> Double.compare(b2.volume(), b1.volume()));
        return new BodiesArray(copy);
    }

    // Упорядочить по возрастанию площадей поверхности тел
    public BodiesArray orderedByAreas() {
        IBody[] copy = Arrays.copyOf(bodies, bodies.length);
        Arrays.sort(copy, Comparator.comparingDouble(IBody::area));
        return new BodiesArray(copy);
    }

    // Вывод коллекцию в строку табличным представлением
    public String toTableString(String title) {
        StringBuilder sb = new StringBuilder(title).append("\n");
        sb.append(Body.header());

        for (int i = 0; i < bodies.length; i++) {
            sb.append(bodies[i].toTableRow(i + 1)).append("\n");
        }

        sb.append(Body.footer());

        return sb.toString();
    }

    public String mobilesToHtmlTable() {
        StringBuilder sb = new StringBuilder(Body.htmlTableHeader());

        for (int i = 0; i < bodies.length; i++) {
            sb.append(bodies[i].toHtmlTableRow(i + 1));
        }

        sb.append(Body.htmlTableFooter());

        return sb.toString();
    }
}
