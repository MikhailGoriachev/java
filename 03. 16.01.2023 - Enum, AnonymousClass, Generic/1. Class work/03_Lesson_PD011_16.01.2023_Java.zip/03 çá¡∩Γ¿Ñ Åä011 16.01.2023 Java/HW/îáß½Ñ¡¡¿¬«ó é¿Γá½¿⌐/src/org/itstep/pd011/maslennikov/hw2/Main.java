package org.itstep.pd011.maslennikov.hw2;

import javax.swing.*;


public class Main {

    public static void main(String[] args) {

        // Консольный вариант демонстрации
        //ConsoleDemo.run();

        while(true) {
            switch (showMenu()) {
                case 0 -> StringsTask.run();
                case 1 -> MobilesTask.run();
                case 2 -> BodiesTask.run();
                default -> {
                    return;
                }
            }
        }
    }

    public static int showMenu() {
        return JOptionPane.showOptionDialog(
                null,
                "<html><h1>Меню</h1>",
                "Домашняя работа",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
               null,
                new Object[] {"Строки", "Mobile", "Геометрические тела", "Выход"},
                "Выход"
        );
    }
}