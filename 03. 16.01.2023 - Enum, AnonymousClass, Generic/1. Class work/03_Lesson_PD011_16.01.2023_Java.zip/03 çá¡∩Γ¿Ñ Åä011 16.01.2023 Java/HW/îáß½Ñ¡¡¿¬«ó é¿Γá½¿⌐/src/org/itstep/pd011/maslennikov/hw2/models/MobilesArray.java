package org.itstep.pd011.maslennikov.hw2.models;

import org.itstep.pd011.maslennikov.hw2.Utils;

import java.util.Arrays;
import java.util.Comparator;

public class MobilesArray {

    // Коллекция объектов мобильных телефонов
    private Mobile[] mobiles = new Mobile[] {};


    public MobilesArray() {
    }

    public MobilesArray(int amount) {
        this.mobiles = generate(amount);
    }

    public MobilesArray(Mobile[] mobiles) {
        this.mobiles = mobiles;
    }

    public Mobile[] generate(int amount) {
        Mobile[] mobiles = new Mobile[amount];

        for (int i = 0; i < mobiles.length; i++) {
            mobiles[i] = new Mobile("Производитель" + i,
                    "Модель" + i,
                    Utils.getRandom(3, 40) * 1000,
                    Utils.getRandom(2015, 2022));
        }

        return mobiles;
    }

    // Добавление элемента в колекцию
    public void add(Mobile mobile) {
        mobiles = Arrays.copyOf(mobiles, mobiles.length + 1);
        mobiles[mobiles.length - 1] = mobile;
    }

    // Очистить коллекцию
    public MobilesArray removeAll() {
        mobiles = new Mobile[]{};
        return this;
    }

    public int totalCosts() {
        int sum = 0;
        for(Mobile mobile: mobiles) {
           sum += mobile.getPrice();
        }
        return sum;
    }

    public MobilesArray getCheapest() {
        int minPrice = mobiles[0].getPrice();
        MobilesArray cheapestMobiles = new MobilesArray();

        for (Mobile mobile: mobiles) {
            int curPrice = mobile.getPrice();

            if (curPrice < minPrice) {
                minPrice = curPrice;
                cheapestMobiles.removeAll().add(mobile);
            } else if (curPrice == minPrice) {
                cheapestMobiles.add(mobile);
            }
        }

        return cheapestMobiles;
    }

    public MobilesArray getMostExpensive() {
        int maxPrice = mobiles[0].getPrice();
        MobilesArray cheapestMobiles = new MobilesArray();

        for (Mobile mobile: mobiles) {
            int curPrice = mobile.getPrice();

            if (curPrice > maxPrice) {
                maxPrice = curPrice;
                cheapestMobiles.removeAll().add(mobile);
            } else if (curPrice == maxPrice) {
                cheapestMobiles.add(mobile);
            }
        }

        return cheapestMobiles;
    }

    public MobilesArray orderedByYearDesc() {
        Mobile[] copy = Arrays.copyOf(mobiles, mobiles.length);
        Arrays.sort(copy, (m1, m2) -> m2.getYear() - m1.getYear());
        return new MobilesArray(copy);
    }

    public MobilesArray orderedByPrice() {
        Mobile[] copy = Arrays.copyOf(mobiles, mobiles.length);
        Arrays.sort(copy, Comparator.comparingInt(Mobile::getPrice));
        return new MobilesArray(copy);
    }

    private static String htmlTableHeader() {
        return "<html><table align='center' border='2' cellspacing='0' cellpadding='8' style='font-size:12px'>" +
                "<thead><tr>" +
                "<th>Производитель</th>" +
                "<th>Модель</th>" +
                "<th>Цена</th>" +
                "<th>Год выпуска</th>" +
                "</tr><tbody>";
    }

    private static String htmlTableFooter() {
        return "</tbody></table>";
    }

    public String mobilesToHtmlTable() {
        StringBuilder sb = new StringBuilder(htmlTableHeader());

        for(Mobile mobile: mobiles) {
            sb.append(mobile.toHtmlTableRow());
        }

        sb.append(htmlTableFooter());

        return sb.toString();
    }

    public String mobilesToString(String title) {
        StringBuilder sb = new StringBuilder(title).append("\n");

        for(Mobile mobile: mobiles) {
            sb.append(mobile).append("\n");
        }

        return sb.toString();
    }
}
