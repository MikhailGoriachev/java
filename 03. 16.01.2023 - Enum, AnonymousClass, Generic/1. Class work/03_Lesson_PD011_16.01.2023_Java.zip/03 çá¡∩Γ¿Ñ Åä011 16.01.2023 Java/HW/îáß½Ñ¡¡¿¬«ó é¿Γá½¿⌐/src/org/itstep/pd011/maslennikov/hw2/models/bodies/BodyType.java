package org.itstep.pd011.maslennikov.hw2.models.bodies;

public enum BodyType {

    Conoid("Усеченный конус"),
    Cylinder("Цилиндр"),
    Sphere("Шар"),
    Pyramid("Правильная треугольная пирамида");


    private String name;

    BodyType(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
