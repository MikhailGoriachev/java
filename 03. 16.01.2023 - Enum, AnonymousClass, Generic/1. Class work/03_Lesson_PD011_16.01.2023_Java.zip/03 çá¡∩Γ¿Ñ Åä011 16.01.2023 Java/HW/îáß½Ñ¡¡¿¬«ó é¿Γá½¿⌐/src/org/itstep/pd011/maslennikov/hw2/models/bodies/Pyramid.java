package org.itstep.pd011.maslennikov.hw2.models.bodies;

import org.itstep.pd011.maslennikov.hw2.Utils;

public class Pyramid extends Body{

    // Высота
    private double height;

    // Сторона основания
    private double sideA;

    // Сторона грани
    private double sideB;


    // Инициализатор
    {
        type = BodyType.Pyramid;
    }

    public Pyramid() {
    }

    public Pyramid(double height, double sideA, double sideB) {
        this.height = height;
        this.sideA = sideA;
        this.sideB = sideB;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        if (height <= 0)
            throw new IllegalArgumentException("Pyramid. Отрицательная или нулевая высота");
        this.height = height;
    }

    public double getSideA() {
        return sideA;
    }

    public void setSideA(double sideA) {
        if (sideA <= 0)
            throw new IllegalArgumentException("Pyramid. Отрицательная или нулевая сторона основания");
        this.sideA = sideA;
    }

    public double getSideB() {
        return sideB;
    }

    public void setSideB(double sideB) {
        if (sideB <= 0 || sideB < (sideA / 2) || sideB >= (sideA * 2))
            throw new IllegalArgumentException("Pyramid. Не верная сторона грани");
        this.sideB = sideB;
    }

    @Override
    public double area() {
        return Math.sqrt(3) * sideA * sideA / 4 + 3 * sideA * Math.sqrt(sideB * sideB - (sideA * sideA) / 4) / 2;
    }

    @Override
    public double volume() {
        return height * sideA * sideA / (4 * Math.sqrt(3));
    }

    @Override
    public String toTableRow(int n) {
        return "│" + Utils.padLeft(String.valueOf(n), 6) +
                " │ " + Utils.padRight(type.getName(), 34) +
                "│" + Utils.padLeft(String.format("%.2f x %.2f x %.2f", height, sideA, sideB), 23) +
                " │" + Utils.padLeft(String.format("%.2f", area()), 11) +
                " │" + Utils.padLeft(String.format("%.2f", volume()), 11) +
                " │";
    }

    @Override
    public String toHtmlTableRow(int n) {
        return "<tr style='color:gray'>" +
                "<td>" + n + "</td>" +
                "<td>" + type.getName() + "</td>" +
                "<td>" + String.format("%.2f x %.2f x %.2f", height, sideA, sideB) + "</td>" +
                "<td>" + String.format("%.2f", area()) + "</td>" +
                "<td>" + String.format("%.2f", volume()) + "</td>";
    }

    public static IBody Generate() {
        var a = Utils.getRandom(1, 5);
        var b = Utils.getRandom(a / 2d, a * 2d);
        return new Pyramid(Utils.getRandom(1, 10), a, b);
    }
}
