package org.itstep.pd011.maslennikov.hw2;

import org.itstep.pd011.maslennikov.hw2.models.bodies.BodiesArray;

import javax.swing.*;

public class BodiesTask {

    static BodiesArray bodiesArray;

    public static void run() {
        String message = generate();

        while (message != null) {
            message = switch (showMenu(message)) {
                case 0 -> generate();
                case 1 -> sourceData();
                case 2 -> minAreasBodies();
                case 3 -> maxAreasBodies();
                case 4 -> orderByVolumeDesc();
                case 5 -> orderByArea();
                default -> null;
            };
        }

    }

    private static String generate() {
        bodiesArray = new BodiesArray(12);

        return sourceData();
    }

    private static String sourceData() {
        double volumesMean = bodiesArray.getVolumesMean();
        double areasMean = bodiesArray.getAreasMean();

        return bodiesArray.mobilesToHtmlTable() +
                "<div style='font-size:12px;margin:4px 0 4px'>Средний объем тел:" +
                "<span style='color:green'>" + String.format("%.2f", volumesMean) + "</span></div>" +
                "<div style='font-size:12px;margin-bottom:10px'>Средняя площадь тел:" +
                "<span style='color:green'>" + String.format("%.2f", areasMean) + "</span></div>";
    }


    private static String minAreasBodies() {
        return bodiesArray.minAreaBodies().mobilesToHtmlTable();
    }

    private static String maxAreasBodies() {
        return bodiesArray.maxAreaBodies().mobilesToHtmlTable();
    }

    private static String orderByVolumeDesc() {
        return bodiesArray.orderedByVolumesDesc().mobilesToHtmlTable();
    }

    private static String orderByArea() {
        return bodiesArray.orderedByAreas().mobilesToHtmlTable();
    }

    private static int showMenu(String content) {
        return JOptionPane.showOptionDialog(
                null,
                content,
                "Геометрические тела",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                new Object[]{"Сформировать", "Исходные", "С мин. площадью", "С макс. площадью", "По убыванию объема", "По возрастанию площади", "Назад"},
                "Выход"
        );
    }
}
