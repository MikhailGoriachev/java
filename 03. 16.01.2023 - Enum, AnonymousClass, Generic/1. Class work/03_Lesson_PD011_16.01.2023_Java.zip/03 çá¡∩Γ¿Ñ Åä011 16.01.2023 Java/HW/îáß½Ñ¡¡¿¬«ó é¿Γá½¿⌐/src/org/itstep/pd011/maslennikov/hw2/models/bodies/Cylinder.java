package org.itstep.pd011.maslennikov.hw2.models.bodies;

import org.itstep.pd011.maslennikov.hw2.Utils;

public class Cylinder extends Body{

    // Радиус основания
    private double radius;

    // Высота
    private double height;


    // Инициализатор
    {
        type = BodyType.Cylinder;
    }

    public Cylinder() {
    }

    public Cylinder(double radius, double height) {
        this.radius = radius;
        this.height = height;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        if (radius <= 0)
            throw new IllegalArgumentException("Cylinder. Отрицательный или нулевой радиус основания");
        this.radius = radius;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        if (height <= 0)
            throw new IllegalArgumentException("Cylinder. Отрицательная или нулевая высота");
        this.height = height;
    }

    // площадь поверхности цилиндра
    // https://www-formula.ru/2011-09-21-04-33-30
    @Override
    public double area() {
        return 2d * Math.PI * radius * (height + radius);
    }

    // объем цилиндра
    // https://www-formula.ru/2011-09-21-10-54-43
    @Override
    public double volume() {
        return Math.PI * radius * radius * height;
    }

    @Override
    public String toTableRow(int n) {
        return "│" + Utils.padLeft(String.valueOf(n), 6) +
                " │ " + Utils.padRight(type.getName(), 34) +
                "│" + Utils.padLeft(String.format("%.2f x %.2f", radius, height), 23) +
                " │" + Utils.padLeft(String.format("%.2f", area()), 11) +
                " │" + Utils.padLeft(String.format("%.2f", volume()), 11) +
                " │";
    }

    @Override
    public String toHtmlTableRow(int n) {
        return "<tr style='color:gray'>" +
                "<td>" + n + "</td>" +
                "<td>" + type.getName() + "</td>" +
                "<td>" + String.format("%.2f x %.2f", radius, height) + "</td>" +
                "<td>" + String.format("%.2f", area()) + "</td>" +
                "<td>" + String.format("%.2f", volume()) + "</td>";
    }
    public static IBody Generate() {
        return new Cylinder(Utils.getRandom(1, 10), Utils.getRandom(1, 10));
    }
}
