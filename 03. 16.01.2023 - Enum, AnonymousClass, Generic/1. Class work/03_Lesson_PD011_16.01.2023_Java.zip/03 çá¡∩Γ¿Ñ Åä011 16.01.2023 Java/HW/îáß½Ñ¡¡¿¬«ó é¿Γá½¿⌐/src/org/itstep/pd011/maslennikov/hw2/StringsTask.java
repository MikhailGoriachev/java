package org.itstep.pd011.maslennikov.hw2;

import javax.swing.*;
import java.util.Arrays;
import java.util.Comparator;
import java.util.StringTokenizer;
import java.util.concurrent.CancellationException;

public class StringsTask {

    public static void run() {

        String message = "<html><h3>Выберите обработку строк</h3>";

        while(message != null) {
            message = switch (showMenu(message)) {
                case 0 -> pointOne();
                case 1 -> pointTwo();
                case 2 -> pointThree();
                case 3 -> pointFour();
                default -> null;
            };
        }
    }

    public static String pointOne() {
        String s, s0, c;
        try {
            s = inputString("Введите строку S", "тест для символа т");
            s0 = inputString("Введите строку S0", "cтр");
            c = inputString("Введите символ С", "т");
        }catch (CancellationException ex) {
            return "Отменено";
        }

        c = String.valueOf(c.charAt(0));

        String result = s.replace(String.valueOf(c), c + s0);

        return "<html>" +
                "<div style='font-size:12px;margin:10px 0 4px" +
                "'>Строка S: " + "<span style='color:green;margin-bottom:4px'>" + s + "</span></div>" +
                "<div style='font-size:12px;margin-bottom:4px'>Строка S0: " + "<span style='color:green'>" + s0 + "</span></div>" +
                "<div style='font-size:12px;margin-bottom:4px'>Символ C: " + "<span style='color:green'>"  + c + "</span></div>" +
                "<div style='font-size:12px;margin-bottom:4px" +
                "'>После каждого вхождения символа C в строку S вставлена строка S0: </div>" +
                "<div style='font-size:12px;margin-bottom:10px'>" + "<span style='color:green'>"  + result + "</span></div>";
    }

    public static String pointTwo() {
        String s, s0;
        try {
            s = inputString("Введите строку S", "тест для проверки подстроки 'тест'");
            s0 = inputString("Введите строку S0", "тест");
        }catch (CancellationException ex) {
            return "Отменено";
        }

        return "<html>" +
                "<div style='font-size:12px;margin:10px 0 4px" +
                "'>Строка S: " + "<span style='color:green;margin-bottom:4px'>" + s + "</span></div>" +
                "<div style='font-size:12px;margin-bottom:4px'>Строка S0: " + "<span style='color:green'>" + s0 + "</span></div>" +
                "<div style='font-size:12px;margin-bottom:4px'>В строке S содержится строка S0: " +
                "<span style='color:green'>"  + s.contains(s0) + "</span></div>";
    }

    public static String pointThree() {
        String s, s0;
        try {
            s = inputString("Введите строку S", "тест для удаления подстроки 'тест'");
            s0 = inputString("Введите строку S0", "тест");
        }catch (CancellationException ex) {
            return "Отменено";
        }

        String result = s;

        var index = s.indexOf(s0);

        if (index > -1) {
            result = s.substring(0, index) + s.substring(index + s0.length());
        }

        return "<html>" +
                "<div style='font-size:12px;margin:10px 0 4px" +
                "'>Строка S: " + "<span style='color:green;margin-bottom:4px'>" + s + "</span></div>" +
                "<div style='font-size:12px;margin-bottom:4px'>Строка S0: " + "<span style='color:green'>" + s0 + "</span></div>" +
                "<div style='font-size:12px;margin-bottom:4px" +
                "'>Удалено первое вхождение S0 в строке S: </div>" +
                "<div style='font-size:12px;margin-bottom:10px'>" + "<span style='color:green'>"  + result + "</span></div>";
    }

    public static String pointFour() {
        String string;
        try {
            string = inputString("Введите строку",
                    "Вывести строку, содержащую эти же слова, разделенные одним пробелом и расположенные в порядке, обратном алфавитному");
        }catch (CancellationException ex) {
            return "Отменено";
        }

        StringTokenizer stz = new StringTokenizer(string, " .,\t\n:;-!?");

        int count = stz.countTokens();

        String[] words = new String[count];

        for (int i = 0; i < count; i++) {
            words[i] = stz.nextToken();
        }

        Arrays.sort(words, Comparator.reverseOrder());

        int minLength = Integer.MAX_VALUE, maxLength = 0;
        String[] minWords = new String[]{};
        String[] maxWords = new String[]{};

        for (String word : words) {
            int curLength = word.length();

            if (curLength < minLength) {
                minLength = curLength;
                minWords = new String[]{word};
            } else if (curLength == minLength) {
                minWords = Arrays.copyOf(minWords, minWords.length + 1);
                minWords[minWords.length - 1] = word;
            }

            if (curLength > maxLength) {
                maxLength = curLength;
                maxWords = new String[]{word};
            } else if (curLength == maxLength) {
                maxWords = Arrays.copyOf(maxWords, maxWords.length + 1);
                maxWords[maxWords.length - 1] = word;
            }
        }

        String result = String.join(" ", words);
        String minWordsString = String.join(" ", minWords);
        String maxWordsString = String.join(" ", maxWords);

        return "<html>" +
                "<div style='font-size:12px;margin:10px 0 4px" +
                "'>Строка : " + "<span style='color:green;margin-bottom:4px'>" + string + "</span></div>" +
                "<div style='font-size:12px;margin-bottom:4px" +
                "'>Слова расположены в порядке, обратном алфавитному: </div>" +
                "<div style='font-size:12px;margin-bottom:10px'>" + "<span style='color:green'>"  + result + "</span></div>" +
                "<div style='font-size:12px;margin-bottom:4px'>Минимальные слова: " + "<span style='color:green'>" + minWordsString + "</span></div>" +
                "<div style='font-size:12px;margin-bottom:4px'>Максимальные слова: " + "<span style='color:green'>" + maxWordsString + "</span></div>";
    }

    private static int showMenu(String content) {
        return JOptionPane.showOptionDialog(
                null,
                content,
                "Строки",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                new Object[]{"Вставка строк", "Проверка вхождения", "Удаление подстроки", "Разбиение строки", "Назад"},
                "Выход"
        );
    }


    public static String inputString(String message, String initial) {
        String result = JOptionPane.showInputDialog(null, message, initial);

        if(result == null)
            throw new CancellationException();

        return result;
    }

}
