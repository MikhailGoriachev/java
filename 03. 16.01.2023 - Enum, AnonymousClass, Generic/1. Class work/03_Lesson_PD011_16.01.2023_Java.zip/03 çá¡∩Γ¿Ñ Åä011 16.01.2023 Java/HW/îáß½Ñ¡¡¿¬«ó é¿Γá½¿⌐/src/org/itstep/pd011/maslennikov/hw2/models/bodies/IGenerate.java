package org.itstep.pd011.maslennikov.hw2.models.bodies;

public interface IGenerate {
    public IBody generate();
}
