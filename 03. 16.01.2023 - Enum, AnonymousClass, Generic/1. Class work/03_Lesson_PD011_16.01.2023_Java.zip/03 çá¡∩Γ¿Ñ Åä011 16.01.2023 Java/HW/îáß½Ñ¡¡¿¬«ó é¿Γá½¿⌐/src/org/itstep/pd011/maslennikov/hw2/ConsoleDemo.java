package org.itstep.pd011.maslennikov.hw2;

import org.itstep.pd011.maslennikov.hw2.models.MobilesArray;
import org.itstep.pd011.maslennikov.hw2.models.bodies.BodiesArray;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;
import java.util.StringTokenizer;

public class ConsoleDemo {
    public static void run() {
        StringBuilder sb;

        /*
            Класс String.
         */

        //Реализуйте обработки для строк и символов, вводимых с клавиатуры

        String s, s0, result;
        char c;
        Scanner scanner = new Scanner(System.in);

        //	Дан символ C и строки S, S0. После каждого вхождения символа C в строку S вставить строку S0.


        System.out.println("Введите строку S:");
        s = scanner.nextLine();

        System.out.println("Введите строку S0:");
        s0 = scanner.nextLine();

        System.out.println("Введите символ C:");
        c = scanner.nextLine().charAt(0);

        result = s.replace(String.valueOf(c), c + s0);

        System.out.println("После каждого вхождения символа добавлена строка S0 :\n" + result);

        //	Даны строки S и S0. Проверить, содержится ли строка S0 в строке S.
        //	Если содержится, то вывести TRUE, если не содержится, то вывести FALSE

        System.out.println("Введите строку S:");
        s = scanner.nextLine();

        System.out.println("Введите строку S0:");
        s0 = scanner.nextLine();

        System.out.println("Содержание строки S0 в S:" + s.contains(s0));

        //	Даны строки S и S0. Удалить из строки S первую подстроку, совпадающую с S0.
        //	Если совпадающих подстрок нет, то вывести строку S без изменений.

        System.out.println("Введите строку S:");
        s = scanner.nextLine();

        System.out.println("Введите строку S0:");
        s0 = scanner.nextLine();

        var index = s.indexOf(s0);

        if (index > -1) {
            s = s.substring(0, index) + s.substring(index + s0.length());
        }

        System.out.println("Из строки S удалено первое вхождение подстроки S0:\n" + s);


        /* Классы String, StringBuilder, StringTokenizer.*/


        // Дана строка, состоящая из слов, разделенных пробелами и/или знаками препинания (одним или несколькими).
        // Вывести строку, содержащую эти же слова, разделенные одним пробелом и расположенные в порядке,
        // обратном алфавитному, определить и вывести самое короткое и самое длинное слово в строке.
        // Учтите, таких слов может быть несколько.

        System.out.println("Введите строку:");

        s = scanner.nextLine();

        StringTokenizer stz = new StringTokenizer(s, " .,\t\n:;-!?");

        int count = stz.countTokens();

        String[] words = new String[count];

        for (int i = 0; i < count; i++) {
            words[i] = stz.nextToken();
        }

        Arrays.sort(words, Comparator.reverseOrder());


        int minLength = Integer.MAX_VALUE, maxLength = 0;
        String[] minWords = new String[]{};
        String[] maxWords = new String[]{};

        for (String word : words) {
            int curLength = word.length();

            if (curLength < minLength) {
                minLength = curLength;
                minWords = new String[]{word};
            } else if (curLength == minLength) {
                minWords = Arrays.copyOf(minWords, minWords.length + 1);
                minWords[minWords.length - 1] = word;
            }

            if (curLength > maxLength) {
                maxLength = curLength;
                maxWords = new String[]{word};
            } else if (curLength == maxLength) {
                maxWords = Arrays.copyOf(maxWords, maxWords.length + 1);
                maxWords[maxWords.length - 1] = word;
            }
        }

        s = String.join(" ", words);

        System.out.println("Результат:\n" + new StringBuilder(s));

        System.out.println("Слова с минимальной длиной:\n" + String.join(" ", minWords));

        System.out.println("Слова с максимальной длиной:\n" + String.join(" ", maxWords));


        /* Классы */


        MobilesArray mobilesList = new MobilesArray(12);

        sb = new StringBuilder();

        sb.append(mobilesList.mobilesToString("Список телефонов:"))
                .append("\n")
                .append("Cуммарная стоимость телефонов: ").append(mobilesList.totalCosts())
                .append("\n\n")
                .append(mobilesList.getCheapest().mobilesToString("Телефоны с минимальной ценой:"))
                .append("\n")
                .append(mobilesList.getMostExpensive().mobilesToString("Телефоны с максимальной ценой:"))
                .append("\n")
                .append(mobilesList.orderedByYearDesc().mobilesToString("Упорядочено по убыванию года:"))
                .append("\n")
                .append(mobilesList.orderedByPrice().mobilesToString("Упорядочено по возрастанию цены:"));

        System.out.println(sb);

        /*
         *  Наследование, полиморфизм
         */

        BodiesArray bodiesArray = new BodiesArray(12);

        sb = new StringBuilder();

        sb.append(bodiesArray.toTableString("Коллекция тел:"))
                .append("Средний объем тел: ").append(String.format("%.2f", bodiesArray.getVolumesMean()))
                .append("\n")
                .append("Средний объем площадей поверхности тел: ").append(String.format("%.2f", bodiesArray.getAreasMean()))
                .append("\n\n")
                .append(bodiesArray.minAreaBodies().toTableString("Тела с минимальной площадью поверхности:"))
                .append("\n")
                .append(bodiesArray.maxAreaBodies().toTableString("Тела с максимальной площадью поверхности:"))
                .append("\n")
                .append(bodiesArray.orderedByVolumesDesc().toTableString("Упорядочено по убыванию объема:"))
                .append("\n")
                .append(bodiesArray.orderedByAreas().toTableString("Упорядочено по возрастанию площади поверхности:"));

        System.out.println(sb);
    }
}
