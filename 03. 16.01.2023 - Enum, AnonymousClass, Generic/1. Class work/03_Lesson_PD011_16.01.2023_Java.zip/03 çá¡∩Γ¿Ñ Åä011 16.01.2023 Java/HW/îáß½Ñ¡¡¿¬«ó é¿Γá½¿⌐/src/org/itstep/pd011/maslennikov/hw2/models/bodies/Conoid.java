package org.itstep.pd011.maslennikov.hw2.models.bodies;

import org.itstep.pd011.maslennikov.hw2.Utils;

public class Conoid extends Body {

    // Радиус верхнего основания
    private double radiusTop;

    // Радиус нижнего основания
    private double radiusBottom;

    // Высота
    private double height;

    // Инициализатор
    {
        type = BodyType.Conoid;
    }

    public Conoid() {
    }

    public Conoid(double radiusTop, double radiusBottom, double height) {
        this.radiusTop = radiusTop;
        this.radiusBottom = radiusBottom;
        this.height = height;
    }

    public double getRadiusTop() {
        return radiusTop;
    }

    public void setRadiusTop(double radiusTop) {
        if (radiusTop <= 0)
            throw new IllegalArgumentException("Conoid. Отрицательное или нулевое верхнее основание");
        this.radiusTop = radiusTop;
    }

    public double getRadiusBottom() {
        return radiusBottom;
    }

    public void setRadiusBottom(double radiusBottom) {
        if (radiusBottom <= 0)
            throw new IllegalArgumentException("Conoid. Отрицательное или нулевое нижнее основание");
        this.radiusBottom = radiusBottom;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        if (height <= 0)
            throw new IllegalArgumentException("Conoid. Отрицательная или нулевая высота");
        this.height = height;
    }

    // площадь поверхности усеченного конуса
    // https://www-formula.ru/2011-09-21-04-35-14
    @Override
    public double area() {
        double delta = radiusBottom - radiusTop;
        double l = Math.sqrt(height * height + delta * delta);
        return Math.PI * (l * radiusTop + l * radiusBottom +
                radiusBottom * radiusBottom + radiusTop * radiusTop);
    }

    // объем усеченного конуса
    // https://www-formula.ru/2011-09-21-10-55-40
    @Override
    public double volume() {
        return Math.PI * height *
                (radiusBottom * radiusBottom + radiusBottom * radiusTop +
                        radiusTop * radiusTop) / 3d;
    }

    @Override
    public String toString() {
        return "Conoid{" +
                "radiusTop=" + radiusTop +
                ", radiusBottom=" + radiusBottom +
                ", height=" + height +
                '}';
    }

    @Override
    public String toTableRow(int n) {
        return "│" + Utils.padLeft(String.valueOf(n), 6) +
                " │ " + Utils.padRight(type.getName(), 34) +
                "│" + Utils.padLeft(String.format("%.2f x %.2f x %.2f", radiusTop, radiusBottom, height), 23) +
                " │" + Utils.padLeft(String.format("%.2f", area()), 11) +
                " │" + Utils.padLeft(String.format("%.2f", volume()), 11) +
                " │";
    }

    @Override
    public String toHtmlTableRow(int n) {
        return "<tr style='color:gray'>" +
                "<td>" + n + "</td>" +
                "<td>" + type.getName() + "</td>" +
                "<td>" + String.format("%.2f x %.2f x %.2f", radiusTop, radiusBottom, height) + "</td>" +
                "<td>" + String.format("%.2f", area()) + "</td>" +
                "<td>" + String.format("%.2f", volume()) + "</td>";
    }

    public static IBody Generate() {
        return new Conoid(Utils.getRandom(1, 10), Utils.getRandom(1, 10), Utils.getRandom(1, 10));
    }
}
