package org.itstep.pd011.maslennikov.hw2.models;

import org.itstep.pd011.maslennikov.hw2.Utils;

public class Mobile {

    private String manufacturer;

    private String model;

    private int price;

    private int year;

    public Mobile() {
    }

    public Mobile(String manufacturer, String model, int price, int year) {
        this.manufacturer = manufacturer;
        this.model = model;
        this.price = price;
        this.year = year;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    @Override
    public String toString() {
        return  "Производитель: " + Utils.padRight(manufacturer, 18) +
                " модель: " + Utils.padRight(model, 10) +
                " цена: " + Utils.padRight( String.valueOf(price), 8) +
                " год выпуска: " + year;
    }

    public String toHtmlTableRow() {
        return "<tr style='color:gray'>" +
                "<td>" + manufacturer + "</td>" +
                "<td>" + model + "</td>" +
                "<td>" + price + "</td>" +
                "<td>" + year + "</td>";
    }
}
