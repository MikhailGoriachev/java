package org.itstep.pd011.maslennikov.hw2.models.bodies;

public abstract class Body implements IBody {

    protected BodyType type;


    // Шапка таблицы, статическое свойство
    public static String header() {
        return  //  7                      35                          24                  12            12
                "┌───────┬───────────────────────────────────┬────────────────────────┬────────────┬────────────┐\n" +
                "│ N п/п │ Тип фигуры                        │ Параметры              │  Площадь   │    Объем   │\n" +
                "├───────┼───────────────────────────────────┼────────────────────────┼────────────┼────────────┤\n";
    }

    // Подвал таблицы, статическое свойство
    public static String footer() {
        return
                "└───────┴───────────────────────────────────┴────────────────────────┴────────────┴────────────┘\n";
    }

    public static String htmlTableHeader() {
        return "<html><table align='center' border='2' cellspacing='0' cellpadding='8' style='font-size:12px'>" +
                "<thead><tr>" +
                "<th>N п/п</th>" +
                "<th>Тип фигуры</th>" +
                "<th>Параметры</th>" +
                "<th>Площадь</th>" +
                "<th>Объем</th>" +
                "</tr><tbody>";
    }

    public static String htmlTableFooter() {
        return "</tbody></table>";
    }

}
