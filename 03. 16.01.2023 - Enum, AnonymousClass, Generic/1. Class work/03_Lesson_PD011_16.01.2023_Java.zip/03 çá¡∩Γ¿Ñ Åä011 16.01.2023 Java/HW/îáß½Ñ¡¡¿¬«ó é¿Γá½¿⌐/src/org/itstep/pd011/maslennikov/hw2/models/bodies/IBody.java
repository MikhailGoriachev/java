package org.itstep.pd011.maslennikov.hw2.models.bodies;

public interface IBody {

    public double area();

    public double volume();

    public String toTableRow(int n);

    public String toHtmlTableRow(int n);
}
