package org.itstep.pd011.maslennikov.hw2.models.bodies;

import org.itstep.pd011.maslennikov.hw2.Utils;

public class Sphere extends Body{

    // Радиус
    private double radius;

    // Инициализатор
    {
        type = BodyType.Sphere;
    }

    public Sphere() { }

    public Sphere(double radius) {
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        if (radius <= 0)
            throw new IllegalArgumentException("Sphere. Отрицательный или нулевой радиус");
        this.radius = radius;
    }

    // площадь поверхности сферы
    // https://www-formula.ru/2011-09-21-04-30-33
    @Override
    public double area() {
        return 4d * Math.PI * radius * radius;
    }

    // объем шара
    // https://www-formula.ru/2011-09-21-10-52-47
    @Override
    public double volume() {
        return 4d * Math.PI * radius * radius * radius / 3d;
    }

    @Override
    public String toTableRow(int n) {
        return "│" + Utils.padLeft(String.valueOf(n), 6) +
                " │ " + Utils.padRight(type.getName(), 34) +
                "│" + Utils.padLeft(String.format("%.2f", radius), 23) +
                " │" + Utils.padLeft(String.format("%.2f", area()), 11) +
                " │" + Utils.padLeft(String.format("%.2f", volume()), 11) +
                " │";
    }

    @Override
    public String toHtmlTableRow(int n) {
        return "<tr style='color:gray'>" +
                "<td>" + n + "</td>" +
                "<td>" + type.getName() + "</td>" +
                "<td>" + String.format("%.2f", radius) + "</td>" +
                "<td>" + String.format("%.2f", area()) + "</td>" +
                "<td>" + String.format("%.2f", volume()) + "</td>";
    }

    public static IBody Generate() {
        return new Sphere(Utils.getRandom(1, 10));
    }
}
