package app.models;

import app.interfaces.IBody;

//Разработайте производные от абстрактного класса Body
public abstract class Body implements IBody {

    protected double r; //радиус

    // блок инициализации, выполняется перед любым конструктором
    { r = 1;}

    public Body(double r) {
        this.r = r;
    }

    public double getR() {
        return r;
    }

    public void setR(double r) {
        if (r <= 0) throw new IllegalArgumentException("Радиус не может быть отрицательным или равным нулю");
        this.r = r;
    }
}
