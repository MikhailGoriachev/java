package app.controllers;

import app.models.*;
import app.utils.Utils;

import java.util.Arrays;

public class Task04Controller {

    private Body[] _bodies;

    public Task04Controller(Body[] _bodies) {
        this._bodies = _bodies;
    }

    public Task04Controller() {

        _bodies = new Body[12];

        for (int i = 0; i<12; i++) {
            _bodies[i] = createFigure();
        } // for i
    }

    private Body createFigure(){

        int type = Utils.getInt(1,4);

        double r = Utils.getDouble(1, 10);
        double h = Utils.getDouble(1, 10);

        return switch (type) {
            case 1 -> new Ball(r);
            case 2 -> new Cone(r, h);
            case 3 -> new Cylinder(r, h);
            default -> new Pyramid(r, h);
        };
    }

    public void show(String captions){
        StringBuilder sb = new StringBuilder("\n\t"+captions+ "\n" + Utils.headerFigure);

        for (Body body: _bodies) {
            sb.append(body.toTableRow());
        } // for

        sb.append(Utils.footerFigure);

        System.out.print(sb.toString());
    }

    public void run() {

        //сформировать и вывести массив объектов (не менее 12 элементов)
        show("Сформировать и вывести массив объектов:");

        //упорядочить массив тел по убыванию объема
        Arrays.sort(_bodies, (t1, t2) -> Double.compare(t2.getVolume(), t1.getVolume()));
        show("Упорядочить массив тел по убыванию объема:");

        //упорядочить массив тел по возрастанию площади поверхности
        Arrays.sort(_bodies, (t1, t2) -> Double.compare(t1.getArea(), t2.getArea()));
        show("Упорядочить массив тел по возрастанию площади поверхности:");
    }
}
