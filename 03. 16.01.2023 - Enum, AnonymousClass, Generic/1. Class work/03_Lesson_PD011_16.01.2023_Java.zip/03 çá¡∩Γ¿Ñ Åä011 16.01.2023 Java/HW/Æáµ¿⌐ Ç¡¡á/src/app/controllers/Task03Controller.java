package app.controllers;

import app.models.Mobile;
import app.utils.Utils;

import java.lang.reflect.Array;
import java.util.Arrays;

public class Task03Controller {

    private final Mobile [] _mobiles;

    public Task03Controller(Mobile[] _mobiles) {
        this._mobiles = _mobiles;
    }

    public Task03Controller() {
        this(new Mobile[] {
                new Mobile("Apple","iPhone 11",36990 ,2019),
                new Mobile("Samsung","Galaxy S22",54890 ,2022),
                new Mobile("Xiaomi","POCO M5", 11500,2022),
                new Mobile("Apple","iPhone 13",64990 ,2021),
                new Mobile("Nokia","6300 4G",3900 ,2007),
                new Mobile("Xiaomi","Redmi 10C",12190 ,2022),
                new Mobile("Google","Pixel 5",30856 ,2020),
                new Mobile("HUAWEI","Nova 9 SE", 16499, 2022),
                new Mobile("Samsung","SM-B310E",1690 ,2014),
                new Mobile("HONOR","X8 6",15989 ,2018),
                new Mobile("Nokia","105 DS",1129 ,2013),
                new Mobile("Xiaomi","Redmi A1+",4990 , 2022),
        });

    }

    public void show(String captions){
        StringBuilder sb = new StringBuilder("\n\t"+captions+ "\n" + Utils.headerMobile);

        for (Mobile mobile: _mobiles) {
            sb.append(mobile.toString());
        } // for

        sb.append(Utils.footerMobile);

        System.out.print(sb.toString());
    }

    public void show(String captions, int value){
        StringBuilder sb = new StringBuilder("\n\t"+captions+ "\n" + Utils.headerMobile);

        for (Mobile mobile: _mobiles) {

            if(value == mobile.getPrice())
            {
                sb.append(mobile.toString());
            }

        } // for

        sb.append(Utils.footerMobile);

        System.out.print(sb.toString());
    }


    //найти суммарную стоимость телефонов в массиве
    public void findSunPrice(){

        int sum = 0;

        for (Mobile mobile: _mobiles) {
            sum += mobile.getPrice();
        } // for

        System.out.printf("\tСуммарная стоимость телефонов: " + sum + "\n");
    }

    //Найдем максимальную стоимость телефона
    public int findMaxPrice(){

        int maxPrice = Integer.MIN_VALUE;

        for (Mobile mobile: _mobiles) {

            if(maxPrice < mobile.getPrice()){
                maxPrice = mobile.getPrice();
            }

        } // for

        return  maxPrice;
    }

    //Найдем минимальную стоимость телефона
    public int findMinPrice(){

        int minPrice = Integer.MAX_VALUE;

        for (Mobile mobile: _mobiles) {

            if(minPrice > mobile.getPrice()){
                minPrice = mobile.getPrice();
            }

        } // for

        return  minPrice;
    }

    public void run() {

        //сформировать и вывести массив объектов (не менее 12 элементов)
        show("Сформировать и вывести массив объектов:");

        //найти суммарную стоимость телефонов в массиве
        findSunPrice();

        //вывести модели с минимальной и максимальной ценой
        int minPrice = findMinPrice();
        int maxPrice = findMaxPrice();

        show("Mодели с минимальной ценой:", minPrice);
        show("Mодели с максимальной ценой:", maxPrice);

        //упорядочить коллекцию телефонов по убыванию года выпуска
        Arrays.sort(_mobiles, (t1, t2) -> Integer.compare(t2.getYear(), t1.getYear()));
        show("Упорядочить коллекцию телефонов по убыванию года выпуска:");

        //упорядочить коллекцию телефонов по возрастанию стоимости
        Arrays.sort(_mobiles, (t1, t2) -> Integer.compare(t1.getPrice(), t2.getPrice()));
        show("Упорядочить коллекцию телефонов по возрастанию стоимости:");
    }
}
