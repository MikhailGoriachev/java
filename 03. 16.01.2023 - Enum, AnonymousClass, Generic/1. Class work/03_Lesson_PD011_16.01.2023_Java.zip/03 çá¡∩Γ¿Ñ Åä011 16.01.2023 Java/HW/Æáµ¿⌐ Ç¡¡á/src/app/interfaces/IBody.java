package app.interfaces;

public interface IBody {

    double getArea(); //вычислений площади поверхности
    double getVolume(); //объема
    String toTableRow(); //и вывода в строку таблицы
}
