package app.models;

/*Создать класс Mobile, описывающий мобильный телефон (фирма-разработчик, название модели, стоимость, год выпуска).*/
public class Mobile {

    private String maker; //фирма-разработчик
    private String title;  //название модели
    private int price; //стоимость
    private int year; //год выпуска

    // блок инициализации, выполняется перед любым конструктором
    {
        maker = "Фирма-разработчик";
        title = "Название модели";
        price = 0;
        year = 2023;
    }

    public Mobile(String maker, String title, int price, int year) {
        this.maker = maker;
        this.title = title;
        this.price = price;
        this.year = year;
    }

    public Mobile() {
        // вызов конструктора
        this("Apple", "IPhone 14 Pro Max" ,100000, 2023);
    }

    public String getMaker() {
        return maker;
    }

    public void setMaker(String maker) {
        this.maker = maker;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        if (price < 0) throw new IllegalArgumentException("Стоимость не может быть отрицательным");
        this.price = price;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        if (year < 0) throw new IllegalArgumentException("Год не может быть отрицательным");
        this.year = year;
    }

    @Override
    public String toString() {
        return  String.format("\t│%-19s│%-17s│%11s│%13s│\n",maker,title,price,year);
    }
}
