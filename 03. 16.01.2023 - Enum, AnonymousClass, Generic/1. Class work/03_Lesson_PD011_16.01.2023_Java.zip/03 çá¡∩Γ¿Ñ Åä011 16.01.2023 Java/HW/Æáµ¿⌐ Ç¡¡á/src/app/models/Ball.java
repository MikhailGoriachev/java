package app.models;

import app.interfaces.IBody;

public class Ball extends Body  implements IBody {

    public static String type =  "шар";

    public Ball(double r) {
        super(r);
    }

    @Override
    public double getArea() {
        return 4*Math.PI*r*r;
    }

    @Override
    public double getVolume() {
        return (4*Math.PI*r*r*r)/3;
    }

    @Override
    public String toTableRow() {
        return String.format("\t│%-19s│%18.2f│%7s│%7.2f│%7.2f│\n",type,r,"--",getArea(),getVolume());
    }
}
