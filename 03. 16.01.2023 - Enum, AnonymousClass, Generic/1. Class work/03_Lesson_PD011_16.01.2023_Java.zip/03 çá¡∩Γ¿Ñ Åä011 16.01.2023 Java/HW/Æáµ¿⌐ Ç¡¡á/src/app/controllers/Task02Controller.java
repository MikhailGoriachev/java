package app.controllers;

import java.util.Arrays;
import java.util.Collections;
import java.util.StringTokenizer;

public class Task02Controller {

    // вычисление по заданию
    public static void run() {

        //Дана строка, состоящая из слов, разделенных пробелами и/или знаками препинания (одним или несколькими)
        String s = "Идейные!!!      соображения ...      высшего порядка, а \n" +
                "также           начало,     повседневной   ..     работы  по формированию " +
                "позиции в  \n         значительной     ,,,,\n        ";

        //Вывести строку, содержащую эти же слова, разделенные одним пробелом и расположенные в порядке,
        // обратном алфавитному

        // StringTokenizer stz = new StringTokenizer(str); // разделители: пробел, \t, \n
        StringTokenizer stz = new StringTokenizer(s, " .,\t\n:;-!?");

        int n = stz.countTokens();      // количество токенов в строке
        String[] words = new String[n]; // массив слов/токенов, выделенных из строки

        // разбиение на токены
         for (int i = 0; stz.hasMoreTokens(); i++) {
            words[i] = stz.nextToken();
        } // for i

        //определить и вывести самое короткое и самое длинное слово в строке.
        int minLen = Integer.MAX_VALUE;
        int maxLen = Integer.MIN_VALUE;

        //находим мин и макс длинну слов в строке
        for (String word:words) {

            if (word.length() < minLen) {
                minLen = word.length();
            } // if

            if (word.length() > maxLen) {
                maxLen = word.length();
            } // if

        } // for

        System.out.print("\nСлова с минимальной длинной: ");

        // вывод слов с мин длинной
        for (String word:words) {

            if (word.length() == minLen) {
                System.out.print(word + ", ");
            } // if

        } // for

        System.out.print("\nСлова с максимальной длинной: ");

        // вывод слов с макс длинной
        for (String word:words) {

            if (word.length() == maxLen) {
                System.out.print(word + ", ");
            } // if

        } // for

        Arrays.sort(words, Collections.reverseOrder());//обратном алфавитному
        //Arrays.sort(words); // отсортирован по алфавиту

        //склеиваем массив строк в одну строку через пробел
        s = String.join(" ", words);

        System.out.printf("\n\n" +s);

    }
}
