package app.controllers;

import javax.swing.*;

public class Task01Controller {

    // вычисление по заданию
    public static void run() {

        String s = inputString("Ведите строку S", "котС ломом С колол Слона");
        String s0 = inputString("Ведите строку S0", "ло");

        String c = inputString("Ведите символ(ы) С", "С");


        //Дан символ C и строки S, S0. После каждого вхождения символа C в строку S вставить строку S0.
        String result01 = s.replace(c, s0);

        //Даны строки S и S0. Проверить, содержится ли строка S0 в строке S. Если содержится, то вывести TRUE, если не содержится, то вывести FALSE
        boolean result02 = s.contains(s0);

        //Даны строки S и S0. Удалить из строки S первую подстроку, совпадающую с S0.
        int index = s.indexOf(s0); //первое вхождение S0
        String result03 = s.substring(0,index+s0.length()+1);
        result03 = result03.replace(s0,"") + s.substring(index+s0.length()+1);

        System.out.printf("\nПосле каждого вхождения символа C в строку S вставить строку S0: \"%s\"", result01);
        System.out.printf("\nСодержится ли строка S0 в строке S: \"%b\"", result02);
        System.out.printf("\nУдалить из строки S первую подстроку, совпадающую с S0: \"%s\"", result03);

        JOptionPane.showMessageDialog(null,
                "<html><h2>Вы ввели:</h2>"+
                        "<h3> S: " + s + "<br>"+
                        "S0: " + s0 + "<br>"+
                        "С: " + c + "</h3>" +
                        "<h3 style = 'color: green'>Результат решения смотреть в консоли</h3>", "Результат", JOptionPane.PLAIN_MESSAGE);

    }

    // форма ввода строк
    public static String inputString(String message,  String defaultValue) {
        return JOptionPane.showInputDialog(null, message, defaultValue);
    }
}
