package app.models;

import app.interfaces.IBody;

public class Cone extends Body  implements IBody {

    public static String type =  "усеченный конус";
    private double h;

    public Cone(double r, double h) {
        super(r);
        this.h = h;
    }

    public double getH() {
        return h;
    }

    public void setH(double h) {
        if (h <= 0) throw new IllegalArgumentException("Высота не может быть отрицательным или равной нулю");
        this.h = h;
    }

    @Override
    public double getArea() {
        return Math.PI*r*(r+Math.sqrt(r*r+h*h));
    }

    @Override
    public double getVolume() {
        return Math.PI*r*r*h/3;
    }

    @Override
    public String toTableRow() {

        return String.format("\t│%-19s│%18.2f│%7.2f│%7.2f│%7.2f│\n",type,r,h,getArea(),getVolume());
    }
}
