package app;

import javax.swing.*;

import app.controllers.Task01Controller;
import app.controllers.Task02Controller;
import app.controllers.Task03Controller;
import app.controllers.Task04Controller;

public class Main {
    public static void main(String[] args) {

        Task03Controller t3 = new Task03Controller();
        Task04Controller t4 = new Task04Controller();

        while (true) {

            switch (showMenu()) {

                case 0 -> Task01Controller.run();
                case 1 -> Task02Controller.run();
                case 2 -> t3.run();
                case 3 -> t4.run();

                // выход
                default -> {
                    return;
                }
            }
        }

    }

    // вывод окна меню
    public static int showMenu() {
        return JOptionPane.showOptionDialog(
                null,
                "<html><h1>Меню</h1>",
                "Домашнее задание на 16.01.2023",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(Main.class.getResource("../images/fish.png")),
                new Object[] {"Задание 1", "Задание 2", "Задание 3", "Задание 4", "Выход"},
                "Выход"
        );
    }
}