package app.utils;

import javax.swing.*;
import java.util.Random;

// Класс Утилиты
public class Utils {
    
    // случайное целочисленное число
    public static int getInt(int min, int max) {
        return new Random().nextInt(min, max);
    }
    
    // случайное вещественное число
    public static double getDouble(double min, double max) {
        return min + (max - min) * new Random().nextDouble();
    }

    // вывод сообщения об ошибке
    public static void showErrorMessage(String message, String title) {
        JOptionPane.showMessageDialog(null, message, title, JOptionPane.ERROR_MESSAGE);
    }

    public static String headerMobile = "\t┌───────────────────┬─────────────────┬───────────┬─────────────┐\n" +
                                        "\t│ Фирма-разработчик │ Название модели │ Стоимость │ Год выпуска │\n" +
                                        "\t├───────────────────┼─────────────────┼───────────┼─────────────┤\n";
    public static String footerMobile = "\t└───────────────────┴─────────────────┴───────────┴─────────────┘\n";


    public static String headerFigure = "\t┌───────────────────┬──────────────────┬───────┬───────┬───────┐\n" +
                                        "\t│     Тип фигуры    │ R(сторона треуг) │   H   │   S   │   V   │\n" +
                                        "\t├───────────────────┼──────────────────┼───────┼───────┼───────┤\n";
    public static String footerFigure = "\t└───────────────────┴──────────────────┴───────┴───────┴───────┘\n";
}
