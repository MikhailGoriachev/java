package app.models;

import app.interfaces.IBody;
public class Pyramid extends Body  implements IBody{

    public static String type =  "пирамида";
    private double h;

    public Pyramid(double r, double h) {
        super(r);
        this.h = h;
    }

    public double getH() {
        return h;
    }

    public void setH(double h) {
        if (h <= 0) throw new IllegalArgumentException("Высота не может быть отрицательным или равной нулю");
        this.h = h;
    }

    @Override
    public double getArea() {
        return r*(r*Math.sqrt(3)+6*h)/4;
    }

    @Override
    public double getVolume() {
        return r*r*h/4/Math.sqrt(3);
    }

    @Override
    public String toTableRow() {
        return String.format("\t│%-19s│%18.2f│%7.2f│%7.2f│%7.2f│\n",type,r,h,getArea(),getVolume());
    }
}
