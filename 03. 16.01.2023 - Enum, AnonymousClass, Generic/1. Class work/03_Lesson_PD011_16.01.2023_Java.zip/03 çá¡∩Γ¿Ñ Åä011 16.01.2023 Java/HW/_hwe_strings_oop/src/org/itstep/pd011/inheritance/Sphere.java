package org.itstep.pd011.inheritance;

import java.util.Locale;

// Сфера (сфера Дайсона :) )
public class Sphere extends Body implements IBody {
    // радиус сферы - поле side1 класса Body
    public Sphere() { this(1); }

    public Sphere(double r) {
        super("сфера", r);
    }

    // радиус сферы - поле класса Body
    public double getR() { return side1; }
    public void setR(double r) { setSide1(r); }


    // https://www-formula.ru/2011-09-21-04-30-33
    @Override
    public double area() {
        // side1 - это радиус
        return 4*Math.PI*side1*side1;
    } // area

    // https://www-formula.ru/2011-09-21-04-30-33
    @Override
    public double volume() {
        return 4*Math.PI*side1*side1*side1/3;
    } // volume

    // вывод параметров объемного тела в строку таблицы
    @Override
    public String toTableRow() {
        return String.format(Locale.UK, "| %-20s | %10.3f |            |            | %10.3f | %10.3f |",
                name, side1, area(), volume());
    } // toTableRow


    @Override
    public String toString() {
        return String.format(Locale.UK,"%s: r=%.3f", name, side1);
    } // toString
} // class Sphere
