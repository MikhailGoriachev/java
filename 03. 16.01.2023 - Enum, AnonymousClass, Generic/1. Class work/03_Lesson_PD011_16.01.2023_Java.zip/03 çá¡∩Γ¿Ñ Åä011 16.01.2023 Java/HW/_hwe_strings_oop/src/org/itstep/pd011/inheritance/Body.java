package org.itstep.pd011.inheritance;

import java.security.InvalidParameterException;

// абстрактный класс Body - основа иерархии классов
public abstract class Body {
    // один из параметров объемного тела
    protected double side1;

    // наименование объемного тела
    protected String name;

    public Body() {
        this("default", 1);
    } // Body

    public Body(String name, double side1) {
        setName(name);
        setSide1(side1);

        this.side1 = side1;
    } // Body

    public String getName() { return name; }
    public void setName(String name) {
        if (name.isEmpty() || name.isBlank()) {
            throw new InvalidParameterException("Недопустимое наименование объемного тела");
        } // if

        this.name = name;
    } // setName

    // сеттер для делегирования из производных классов
    protected void setSide1(double side1) {
        if (side1 <= 0) {
            throw new InvalidParameterException("Недопустимое значение параметра объемного тела");
        } // if

        this.side1 = side1;
    } // setSide1
} // class Body
