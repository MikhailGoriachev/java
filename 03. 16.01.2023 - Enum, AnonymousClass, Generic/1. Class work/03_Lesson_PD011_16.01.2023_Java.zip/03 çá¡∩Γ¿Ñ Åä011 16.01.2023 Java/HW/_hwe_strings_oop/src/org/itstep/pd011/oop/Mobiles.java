package org.itstep.vpu811.models.task2;

import java.util.Arrays;

/*
 * Создать и проинициировать массив из 12 элементов класса Mobile (коллекцию
 * мобильных телефонов). Реализовать обработки для объекта класса Mobiles:
 *     o	формирование массива телефонов
 *     o    вывод массива (коллекции) телефонов в консоль
 *     o	найти минимальную цену телефона
 *     o	найти максимальную цену телефона
 *     o	вычисление суммарной стоимости телефонов коллекции
 *     o	упорядочить коллекцию телефонов по убыванию года выпуска
 *
 * */
public class Mobiles {
    // массив объектов типа Mobile
    public Mobile[] mobiles;

    // конструктор по умолчанию
    public Mobiles() { this(initialize()); }

    // конструктор с внедрением зависимости
    public Mobiles(Mobile[] mobiles) {
        this.mobiles = mobiles;
    } // Mobiles

    // формирование массива телефонов
    public static Mobile[] initialize() {
        return new Mobile[] {
            new Mobile("Samsung", "J5 SM-J510",    2016, 18000),
            new Mobile("BQ",      "Aurora SE",     2020,  8200),
            new Mobile("Xiaomi",  "Redmi 4",       2017, 11800),
            new Mobile("Huawei",  "P40 Pro",       2020, 38000),
            new Mobile("ZTE",     "Blade A910",    2017, 18000),
            new Mobile("Wigor",   "V2 Black",      2018,  4800),
            new Mobile("ZTE",     "Blade Z7",      2016, 26000),
            new Mobile("BQ",      "Magic O",       2020,  7400),
            new Mobile("Xiaomi",  "Redmi Note 10", 2020, 38000),
            new Mobile("Xiaomi",  "Redmi 5s",      2017, 17600),
            new Mobile("Samsung", "Galaxy A51",    2019, 26000),
            new Mobile("BQ",      "Aquaris M5.5",  2018,  4800)
        }; // new Mobile
    } // initialize

    // мутатор для задания массива телефонов
    public void setMobiles(Mobile[] mobiles) {
        this.mobiles = mobiles;
    } // setMobiles

    // вывод массива (коллекции) телефонов в консоль
    public void showMobiles(String title) {
        System.out.printf("\n\t%s\n%s\n", title, Mobile.HEADER);

        // вывод массива телефонов, номер элемента i
        int i = 1;
        for (Mobile mobile : mobiles) {
            System.out.printf("\t%s\n", mobile.toTableRow(i++));
        } // for mobile

        System.out.printf("\t%s\n", Mobile.DIVIDER);
    }  // showMobiles

    // найти максимальную цену телефона
    public int maxCost() {
        int max = Integer.MIN_VALUE;
        for (Mobile mobile : mobiles) {
            int cost = mobile.getCost();
            if (cost > max) max = cost;
        } // for mobile

        return max;
    } // maxCost

    // найти минимальную цену телефона
    public int minCost() {
        int min = Integer.MAX_VALUE;
        for (Mobile mobile : mobiles) {
            if (mobile.getCost() < min) min = mobile.getCost();
        } // for mobile

        return min;
    } // minCost

    // вывод телефонов с минимальной и максимальной ценой из массива телефонов в консоль
    public void showMobiles(String title, int minCost, int maxCost) {
        System.out.printf("\n\t%s\n%s\n", title, Mobile.HEADER);

        // вывод массива телефонов, номер элемента i
        int i = 0;
        for (Mobile mobile : mobiles) {
            if (mobile.getCost() == minCost || mobile.getCost() == maxCost)
                System.out.printf("\t%s\n", mobile.toTableRow(++i));
        } // for mobile

        System.out.printf("\t%s\n\n", Mobile.DIVIDER);
    }  // showMobiles

    // возвращает суммарную стоимость телефонов коллекции
    public int totalCost() {
        int total = 0;
        for (Mobile mobile : mobiles) {
            total += mobile.getCost();
        } // for mobile

        return total;
    } // totalCost

    // упорядочивание коллекции телефонов по убыванию года выпуска
	// в классе Mobile реализован интерфейс Comparable - сравнение
	// двух объектов по году выпуска, реализация интерфейса делает
	// возможным использование метода Arrays.sort()
    public void orderByYear() {
        Arrays.sort(mobiles);
    } // orderByYear

} // class Mobiles
