package org.itstep.pd011.inheritance;

import java.security.InvalidParameterException;
import java.util.Locale;

// Цилиндр
public class Cylinder extends Body implements IBody {
    // радиус основания цилиндра - поле side1 класса Body
    private double h; // высота цилиндра

    public Cylinder() {
        this(1, 1);
    } // Cone

    public Cylinder(double r, double h) {
        super("цилиндр", r);
        this.h = h;
    } // Cylinder

    // region Аксессоры и мутаторы
    public double getR() {
        return side1;
    }

    public void setR(double r) {
        setSide1(r);
    }

    public double getH() {
        return h;
    }

    public void setH(double h) {
        if (h <= 0) {
            throw new InvalidParameterException("Недопустимое значение параметра объемного тела");
        } // if

        this.h = h;
    } // setH
    // endregion

    // https://www-formula.ru/2011-09-21-04-33-30
    @Override
    public double area() {
        // side1 это радиус
        return 2 * Math.PI * side1 * (h + side1);
    } // area

    // https://www-formula.ru/2011-09-21-10-54-43
    @Override
    public double volume() {
        // side1 это радиус
        return Math.PI * side1 * side1 * h;
    } // volume

    // вывод параметров объемного тела в строку таблицы
    @Override
    public String toTableRow() {
        return String.format(Locale.UK, "| %-20s | %10.3f |            | %10.3f | %10.3f | %10.3f |",
                name, side1, h, area(), volume());
    } // toTableRow


    @Override
    public String toString() {
        return String.format(Locale.UK,"%s: r=%.3f; h=%.3f", name, side1, h);
    }
} // class Cylinder