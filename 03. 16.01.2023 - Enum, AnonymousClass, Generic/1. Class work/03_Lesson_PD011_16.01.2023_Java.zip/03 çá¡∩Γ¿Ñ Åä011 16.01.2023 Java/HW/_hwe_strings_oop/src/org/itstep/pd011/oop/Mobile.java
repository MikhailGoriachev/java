package org.itstep.vpu811.models.task2;

// Класс Mobile, описывающий мобильный телефон (фирма-разработчик,
// название модели, стоимость, год выпуска)
// реализация интерфейса Comparable делает
// возможным использование метода Arrays.sort()
public class Mobile implements Comparable {
    // region поля класса
    private String brand; // фирма-разработчик
    private String model; // название модели
    private int cost;     // стоимость
    private int year;     // год выпуска
    // endregion

    // region конструкторы класса
    // конструктор с параметрами
    public Mobile(String brand, String model, int year, int cost) {
        this.brand = brand;
        this.model = model;
        this.year = year;
        this.cost = cost;
    } // Mobile

    // конструктор по умолчанию
    public Mobile() {
        this("BQ", "6022G Aura", 2020, 5510);
    } // Mobile
    // endregion

    // region аксессоры и мутаторы - геттеры и сеттеры

    public String getBrand() { return brand; }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() { return model;  }

    public void setModel(String model) {
        this.model = model;
    }

    public int getCost() { return cost; }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public int getYear() { return year; }

    public void setYear(int year) {
        this.year = year;
    }
    // endregion

    // region строковое представление объекта

    @Override
    public String toString() {
        return String.format("Mobile {brand='%s', model='%s', cost=%d, year=%d}", brand, model, cost, year);
    } // toString

    // вывод данных объекта в формате строки таблицы
    public String toTableRow(int i) {
        return String.format("| %5d | %-15s | %-15s | %10d | %4d |", i, brand, model, cost, year);
    } // toTableRow


    // разделитель части таблицы вывода
    public static final String DIVIDER =
        "+-------+-----------------+-----------------+------------+------+";

    // вывод заголовка таблицы вывода
    public static final String HEADER =
        "\t+-------+-----------------+-----------------+------------+------+\n" +
        "\t| Номер | Производитель   | Модель          | Цена, руб. |  Год |\n" +
        "\t+-------+-----------------+-----------------+------------+------+";
    // endregion

    // компартор для сортировки массива объектов по убыванию года выпуска
	// методом Arrays.sort()
    @Override
    public int compareTo(Object obj) {
        return ((Mobile)obj).year - year;
    } // compareTo
} // class Mobile
