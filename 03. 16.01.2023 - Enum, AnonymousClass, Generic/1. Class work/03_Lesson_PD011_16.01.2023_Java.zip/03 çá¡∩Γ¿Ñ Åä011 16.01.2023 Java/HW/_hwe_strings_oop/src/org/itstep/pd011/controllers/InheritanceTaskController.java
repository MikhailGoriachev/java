package org.itstep.pd011.controllers;

import org.itstep.pd011.infrastructure.Utils;
import org.itstep.pd011.inheritance.*;

import java.util.Arrays;

/*
* Наследование, полиморфизм.
* Разработайте производные от абстрактного класса Body классы для работы
* с усеченным конусом, цилиндром, шаром и правильной треугольной пирамидой.
* Предусмотрите хранение наименования тела (строки «усеченный конус»,
* «цилиндр» и т.д.), размеры тел. Используйте интерфейс IBody для задания
* методов вычислений площади поверхности, объема и вывода в строку таблицы
* (консольной или HTML – по Вашему выбору). Создайте полиморфный массив из
* объемных тел этих классов при помощи фабричного метода.
* Реализовать обработки (не использовать StreamAPI):
*     o сформировать и вывести массив объектов (не менее 12 элементов)
*     o найти средний объем тел в массиве, среднюю площадь поверхности
*       тел в массиве
*     o вывести тела с минимальной и максимальной площадью поверхности
*     o упорядочить массив тел по убыванию объема (используйте
*       лямбда-выражение для сравнения элементов)
*     o упорядочить массив тел по возрастанию площади поверхности
* */
public class InheritanceTaskController {
    private IBody[] bodies;

    public InheritanceTaskController() { initialize();  }

    public InheritanceTaskController(IBody[] bodies) {
        this.bodies = bodies;
    } // InheritanceTaskController

    // формирование массива объектов
    public void initialize() {
        final int n = Utils.getRandom(12, 18);
        bodies = new IBody[n];
        for(int i = 0; i <n; ++i) {
            bodies[i] = volumetricFactory();
        } // for i
    } // initialize

    // вывод массива объектов
    public void showBodies(String title) {
        System.out.println(title);

        // вывод шапки таблицы

        // вывод тела таблицы
        for (IBody body : bodies) {
            System.out.println(body.toTableRow());
        } // for body

        // вывод подвала таблицы
    } // showBodies

    // средний объем тел в массиве

    // средняя площадь тел в массиве

    // упорядочить массив тел по убыванию объема (используйте
    // лямбда-выражение для сравнения элементов)
    public void orderByVolumeDesc() {
        Arrays.sort(bodies, (b1, b2) -> {
            return Double.compare(b2.volume(), b1.volume());
        });
    } // orderByArea

    // упорядочить массив тел по возрастанию площади поверхности
    // (используйте лямбда-выражение для сравнения элементов)
    public void orderByArea() {
        Arrays.sort(bodies, (b1, b2) -> {
            // double area1 = b1.area();
            // double area2 = b2.area();

            // return area1 < area1? -1: area1 > area2? 1: 0;
            // return Double.compare(area1, area2);
            return Double.compare(b1.area(), b2.area());
        });
        // Arrays.sort(bodies, Comparator.comparingDouble(IBody::area));
    } // orderByArea

    // фабрика объектов из иерархии IBody
    public static IBody volumetricFactory() {
        IBody body;
        final double LO = 0.1, HI = 20.;

        int typeBody = Utils.getRandom(0, 3);
        double p = Utils.getRandom(LO, HI);
        body = switch (typeBody) {
            case 0 -> new Conoid(p, p/Utils.getRandom(1.1, 3.2), Utils.getRandom(LO, HI));
            case 1 -> new Cylinder(p, Utils.getRandom(LO, HI));
            case 2 -> new Sphere(p);
            default -> new Tetrahedron(p, Utils.getRandom(LO, HI));
        }; // switch

        return body;
    } // volumetricFactory
} // class InheritanceTaskController
