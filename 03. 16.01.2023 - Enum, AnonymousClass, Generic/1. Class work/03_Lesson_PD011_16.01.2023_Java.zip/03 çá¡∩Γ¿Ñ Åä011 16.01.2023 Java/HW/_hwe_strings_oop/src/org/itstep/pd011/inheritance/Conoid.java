package org.itstep.pd011.inheritance;

import java.security.InvalidParameterException;
import java.util.Locale;

// усеченный конус
public class Conoid extends Body implements IBody {
    // радиус нижнего основания усеченного конуса - поле класса Body side1

    // радиус верхнего основания усеченого конуса
    private double r2;

    // высота усеченого конуса
    private double h;

    public Conoid() { this(1, 0.8, 1); } // Cone

    public Conoid(double r1, double r2, double h) {
        super("усеченный конус", r1);

        setR2(r2);
        setH(h);
    } // Cone

    // region Аксессоры и мутаторы
    public double getR1() { return side1; }
    public void setR1(double r1) { setSide1(r1); }

    public double getR2() { return r2; }
    public void setR2(double r2) {
        if (r2 <= 0) {
            throw new InvalidParameterException("Недопустимое значение параметра объемного тела");
        } // if

        this.r2 = r2;
    } // setR2

    public double getH() { return h; }
    public void setH(double h) {
        if (h <= 0) {
            throw new InvalidParameterException("Недопустимое значение параметра объемного тела");
        } // if

        this.h = h;
    }
    // endregion

    // площадь поверхности усеченного конуса
    // https://www-formula.ru/2011-09-21-04-35-14
    @Override
    public double area() {
        // side1 это радиус нижнего основания конуса
        double delta = side1 - r2;
        double l = Math.sqrt(h * h + delta * delta);
        return Math.PI * (l * side1 + l * r2 + side1 * side1 + r2 * r2);
    } // area

    // объем усеченного конуса
    // https://www-formula.ru/2011-09-21-10-55-40
    @Override
    public double volume() {
        // side1 это радиус нижнего основания усеченного конуса
        return Math.PI * h * (side1 * side1 + side1 * r2 +  r2 * r2) / 3d;
    } // volume


    // вывод параметров объемного тела в строку таблицы
    @Override
    public String toTableRow() {
        return String.format(Locale.UK, "| %-20s | %10.3f | %10.3f | %10.3f | %10.3f | %10.3f |",
                name, side1, r2, h, area(), volume());
    } // toTableRow

    @Override
    public String toString() {
        return String.format(Locale.UK, "%s: r1=%.3f; r2 = %.3f; h=%.3f" , name, side1, r2, h);
    } // toString
} // class Cone
