package org.itstep.pd011.inheritance;

//  интерфейс IBody для задания методов вычисления площади поверхности, объема
// вывода параметров объемного тела в строку таблицы
public interface IBody {
    // вычисление площади поверхности фигуры
    double area();

    // вычисление объема фигуры
    double volume();

    // вывод в строку таблицы
    String toTableRow();
} // interface IBody
