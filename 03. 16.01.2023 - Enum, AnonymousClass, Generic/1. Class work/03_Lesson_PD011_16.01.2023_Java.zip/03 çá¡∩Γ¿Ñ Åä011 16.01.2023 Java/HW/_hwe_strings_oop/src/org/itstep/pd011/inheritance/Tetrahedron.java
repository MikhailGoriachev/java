package org.itstep.pd011.inheritance;

import java.security.InvalidParameterException;
import java.util.Locale;

// правильная треугольная пирамида
// Пирамида, у которой основание равносторонний треугольник и грани равные,
// равнобедренные треугольники, называется правильной треугольной пирамидой
// или тетраэдром.
// https://www-formula.ru/2011-09-21-10-58-40
public class Tetrahedron extends Body implements IBody {
    // длина стороны основания правильной треугольной пирмиды - поле side1 класса Body

    // высота пирамиды
    private double h;

    public Tetrahedron() {
        this(1, 1);
    } // Tetrahedron

    public Tetrahedron(double a, double h) {
        super("тетраэдр", a);
        this.h = h;
    } // Tetrahedron

    // region Аксессоры и мутаторы
    public double getA() {
        return side1;
    }

    public void setA(double a) {
        setSide1(a);
    }

    public double getH() {
        return h;
    }

    public void setH(double h) {
        if (h <= 0) {
            throw new InvalidParameterException("Недопустимое значение параметра объемного тела");
        } // if

        this.h = h;
    } // setH
    // endregion

    // https://profmeter.com.ua/communication/learning/course/course7/lesson342/
    // https://microexcel.ru/ploshad-pravilnoy-piramidy/
    @Override
    public double area() {
        // side1 это длина стороны основания
        double aa = side1*side1;
        double bb = aa + h*h;
        return (aa * Math.sqrt(3) + 6*side1*Math.sqrt(bb - aa/4))/4;
    } // area

    // объем правильной треугольной пирамиды
    // https://www-formula.ru/2011-09-21-10-58-40
    @Override
    public double volume() {
        return h * side1 * side1 / (4. * Math.sqrt(3.));
    } // volume

    // вывод параметров объемного тела в строку таблицы
    @Override
    public String toTableRow() {
        return String.format(Locale.UK, "| %-20s | %10.3f |            | %10.3f | %10.3f | %10.3f |",
                name, side1, h, area(), volume());
    } // toTableRow


    @Override
    public String toString() {
        return String.format(Locale.UK,"%s: r=%.3f; h=%.3f", name, side1, h);
    }
} // class Tetrahedron
