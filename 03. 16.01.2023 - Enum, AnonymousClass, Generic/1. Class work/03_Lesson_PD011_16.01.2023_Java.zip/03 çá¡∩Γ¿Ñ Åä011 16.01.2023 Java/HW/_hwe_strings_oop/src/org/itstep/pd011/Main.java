package org.itstep.pd011;

import org.itstep.pd011.controllers.InheritanceTaskController;

public class Main {
    public static void main(String[] args) {

        InheritanceTaskController obj = new InheritanceTaskController();
        obj.showBodies("\nМассив объемны тел");

        obj.orderByArea();
        obj.showBodies("\nМассив объемных тел упорядочен по возрастанию площади поверхности");

        obj.orderByVolumeDesc();
        obj.showBodies("\nМассив объемных тел упорядочен по убыванию объемов");
    } // main
} // class Main