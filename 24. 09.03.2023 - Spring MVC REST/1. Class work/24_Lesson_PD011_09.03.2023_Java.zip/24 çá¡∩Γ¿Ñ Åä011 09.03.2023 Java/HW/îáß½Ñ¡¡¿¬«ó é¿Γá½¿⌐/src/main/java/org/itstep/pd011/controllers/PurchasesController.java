package org.itstep.pd011.controllers;

import org.itstep.pd011.entities.Purchase;
import org.itstep.pd011.services.GoodsService;
import org.itstep.pd011.services.PurchasesService;
import org.itstep.pd011.services.SalesService;
import org.itstep.pd011.services.UnitsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import java.io.Console;
import java.text.SimpleDateFormat;
import java.util.Optional;

@Controller
@RequestMapping("/purchases")
public class PurchasesController {
    @Autowired private PurchasesService purchasesService;
    @Autowired private UnitsService unitsService;
    @Autowired private GoodsService goodsService;


    @GetMapping
    public String purchasesList(ModelMap model) {
        model.addAttribute("purchases", purchasesService.getAll());

        return "purchases";
    }

    @GetMapping("/statistics")
    public String getPurchasesStatistics(ModelMap model) {
        model.addAttribute("purchases", purchasesService.getPurchaseStatistics());

        return "query06";
    }

    @GetMapping("/store")
    public ModelAndView storeGet(ModelMap model) {
        model.addAttribute("isCreate", true);
        model.addAttribute("unitsList", unitsService.getAll());
        model.addAttribute("goodsList", goodsService.getAll());

        return new ModelAndView("purchaseForm", "purchase", new Purchase());
    }

    @PostMapping("/store")
    public String storePost(@ModelAttribute("SpringWeb") Purchase purchase,
                            BindingResult result, ModelMap model) {
        if (result.hasErrors()) {
            result.getAllErrors().forEach(System.out::println);
            return "error";
        }

        purchasesService.save(purchase);

        model.addAttribute("purchases", purchasesService.getAll());
        return "purchases";
    }


    @GetMapping("/update/{id}")
    public ModelAndView updateGet(@PathVariable String id, ModelMap model) {
        Optional<Purchase> purchase = purchasesService.getById(Integer.parseInt(id));

        if(purchase.isEmpty()) {
            return new ModelAndView(new RedirectView("/purchases"));
        }

        model.addAttribute("isCreate", false);
        model.addAttribute("unitsList", unitsService.getAll());
        model.addAttribute("goodsList", goodsService.getAll());

        return new ModelAndView("purchaseForm", "purchase", purchase);
    }


    @GetMapping("/remove")
    public String removeGet(@RequestParam(value = "id", defaultValue = "1") String id, ModelMap model) {
        purchasesService.deleteById(Integer.parseInt(id));

        model.addAttribute("purchases", purchasesService.getAll());
        return "purchases";
    }
}