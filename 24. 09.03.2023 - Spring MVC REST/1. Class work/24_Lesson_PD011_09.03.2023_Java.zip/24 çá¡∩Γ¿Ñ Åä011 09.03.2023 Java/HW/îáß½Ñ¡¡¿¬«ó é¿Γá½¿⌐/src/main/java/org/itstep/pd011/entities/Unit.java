package org.itstep.pd011.entities;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

// Класс Единица измерения
@Entity
@Table(name = "units")
@Getter
@Setter
@NoArgsConstructor
public class Unit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    // сокращенное название
    @Column(name = "short")
    private String shortName;
    
    // полное название
    @Column(name = "long")
    private String longName;

}
