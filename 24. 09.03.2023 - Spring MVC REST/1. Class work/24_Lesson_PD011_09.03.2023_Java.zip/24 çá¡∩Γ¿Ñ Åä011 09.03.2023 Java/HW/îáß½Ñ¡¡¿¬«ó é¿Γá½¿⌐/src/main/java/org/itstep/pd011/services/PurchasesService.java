package org.itstep.pd011.services;

import org.itstep.pd011.entities.Purchase;
import org.itstep.pd011.models.Query06;

import java.util.List;
import java.util.Optional;

public interface PurchasesService {
    List<Purchase> getAll();

    Optional<Purchase> getById(Integer id);

    void save(Purchase item);

    void delete(Purchase item);

    void deleteById(Integer id);

    List<Purchase> getByUnitShortNameAndPriceLessThan(String unit, Integer price);

    List<Query06> getPurchaseStatistics();
}
