package org.itstep.pd011.models;

import java.util.Date;

public record Query05(Date saleDate, String productName, int purchasePrice, int salePrice, int quantitySold, int profit){
}
