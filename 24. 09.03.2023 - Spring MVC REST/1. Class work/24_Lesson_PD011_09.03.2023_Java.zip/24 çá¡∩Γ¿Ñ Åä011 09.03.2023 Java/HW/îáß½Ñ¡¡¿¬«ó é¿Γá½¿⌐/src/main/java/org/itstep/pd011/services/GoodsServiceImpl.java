package org.itstep.pd011.services;

import org.itstep.pd011.entities.Goods;
import org.itstep.pd011.repositories.GoodsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GoodsServiceImpl implements GoodsService {

    @Autowired
    private GoodsRepository repo;

    @Override
    public List<Goods> getAll() {
        return repo.findAll();
    }

    @Override
    public Optional<Goods> getById(Long id) {
        return repo.findById(id);
    }

    @Override
    public void save(Goods goods) {
        if(goods == null)
            return;

        repo.saveAndFlush(goods);
    }

    @Override
    public void delete(Goods goods) {
        if(goods == null)
            return;

        repo.delete(goods);
    }

    @Override
    public void deleteById(Long id) {
        if(id == null)
            return;

        repo.deleteById(id);
    }
}