package org.itstep.pd011.models;

public record Query06 (String name, Double avgPrice, Long amount){


}