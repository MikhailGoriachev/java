package org.itstep.pd011.services;

import org.itstep.pd011.entities.Purchase;
import org.itstep.pd011.models.Query06;
import org.itstep.pd011.repositories.PurchasesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PurchasesServiceImpl implements PurchasesService{
    @Autowired private PurchasesRepository repo;

    @Override
    public List<Purchase> getAll() {
        return repo.findAll();
    }

    @Override
    public Optional<Purchase> getById(Integer id) {
        return repo.findById(id);
    }

    @Override
    public void save(Purchase item) {
        if(item == null)
            return;

        repo.saveAndFlush(item);
    }

    @Override
    public void delete(Purchase item) {
        if(item == null)
            return;

        repo.delete(item);
    }

    @Override
    public void deleteById(Integer id) {
        if(id == null)
            return;

        repo.deleteById(id);
    }

    @Override
    public List<Purchase> getByUnitShortNameAndPriceLessThan(String unit, Integer price) {
        return repo.findPurchasesByUnit_ShortNameAndPriceLessThan(unit, price);
    }

    @Override
    public List<Query06> getPurchaseStatistics() {
        return repo.getPurchaseStatistics();
    }
}
