package org.itstep.pd011.entities;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

// Класс Продажа
@Entity
@Table(name = "sales")
@Getter
@Setter
@NoArgsConstructor
public class Sale {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    // закупка
    @ManyToOne
    @JoinColumn(name = "id_purchase", referencedColumnName = "id")
    private Purchase purchase;
    
    // единица товара
    @ManyToOne
    @JoinColumn(name = "id_unit", referencedColumnName = "id")
    private Unit unit;
    
    // продавец
    @ManyToOne
    @JoinColumn(name = "id_seller", referencedColumnName = "id")
    private Seller seller;
    
    // единица измерения
    @Column(name = "sale_date")
    @Temporal(TemporalType.DATE)
    private Date saleDate;
    
    // цена
    @Column(name = "price")
    private int price;
    
    // количество
    @Column(name = "amount")
    private int amount;

}
