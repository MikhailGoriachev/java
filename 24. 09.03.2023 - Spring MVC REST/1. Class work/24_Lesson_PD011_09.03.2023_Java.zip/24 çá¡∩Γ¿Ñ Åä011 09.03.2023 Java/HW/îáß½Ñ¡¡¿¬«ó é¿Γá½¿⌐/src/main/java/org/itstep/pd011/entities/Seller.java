package org.itstep.pd011.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;


// Класс Продавец
@Entity
@Table(name = "sellers")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Seller {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    // персона
    @ManyToOne
    @JoinColumn(name = "id_person", referencedColumnName = "id")
    private Person person;
    
    // процент комиссии
    @Column(name = "interest")
    private int interest;

}
