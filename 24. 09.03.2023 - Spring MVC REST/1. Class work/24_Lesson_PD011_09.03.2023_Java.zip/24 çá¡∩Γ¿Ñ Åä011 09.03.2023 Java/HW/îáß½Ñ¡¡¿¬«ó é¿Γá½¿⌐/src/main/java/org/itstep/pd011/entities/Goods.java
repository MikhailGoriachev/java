package org.itstep.pd011.entities;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;


// Класс Товар
@Entity
@Table(name = "goods")
@Getter
@Setter
@NoArgsConstructor
public class Goods {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    // название
    @Column(name = "name")
    private String name;

}
