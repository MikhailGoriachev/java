package org.itstep.pd011.entities;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.util.Date;

// Класс Закупка
@Entity
@Table(name = "purchases")
@Getter
@Setter
@NoArgsConstructor
public class Purchase {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    // товар  goods_id
    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "id_goods", referencedColumnName = "id")
    private Goods goods;
    
    // единица измерения
    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "id_unit", referencedColumnName = "id")
    private Unit unit;
    
    // дата
    @Column(name = "purchase_date")
    @Temporal(TemporalType.DATE)
    private Date purchaseDate;
    
    // цена
    @Column(name = "price")
    private int price;
    
    // количество
    @Column(name = "amount")
    private int amount;
}
