package org.itstep.pd011.repositories;

import org.itstep.pd011.entities.Purchase;
import org.itstep.pd011.models.Query06;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface PurchasesRepository extends JpaRepository<Purchase, Integer> {
    // Запрос 1.
    // Выбирает информацию о товарах, единицей измерения которых является «шт» (штуки)
    // и цена закупки составляет меньше 500 руб. Значения задавать параметрами
    List<Purchase> findPurchasesByUnit_ShortNameAndPriceLessThan(String unit, Integer price);


    // Запрос 2.
    // Выбирает информацию о товарах, цена закупки которых меньше 500 руб.
    // за единицу товара. Значения задавать параметрами
    List<Purchase> findPurchasesByPriceLessThan(int value);

    // Запрос 6.
    // Выполняет группировку по наименованию закупленного товара.
    // Для каждого наименования вычисляет среднюю цену закупки
    // товара, количество закупок
    @Query("""
      select 
          new org.itstep.pd011.models.Query06(g.name, avg(p.price), count(p.price))
      from 
          Purchase p join p.goods g 
      group by 
          g.name""")
    List<Query06> getPurchaseStatistics();
}
