package org.itstep.pd011.services;

import org.itstep.pd011.entities.Sale;
import org.itstep.pd011.models.Query05;
import org.itstep.pd011.repositories.SalesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

// реализация операций с использованием репозитория
@Service
public class SalesServiceImpl implements SalesService {
	@Autowired private SalesRepository repo;

	@Override
	public List<Sale> getAll() {
		return repo.findAll();
	}

	@Override
	public Optional<Sale> getById(Long id) {
		return repo.findById(id);
	}

	@Override
	public List<Sale> getByPriceRange(Integer from, Integer to) {
		return repo.findSalesByPriceBetween(from, to);
	}

	@Override
	public List<Query05> getSalesProfits() {
		return repo.getSalesProfits();
	}

	@Override
	public void save(Sale item) {
		if(item == null)
			return;

		repo.saveAndFlush(item);
	}

	@Override
	public void delete(Sale item) {
		if(item == null)
			return;

		repo.delete(item);
	}

	@Override
	public void deleteById(Long id) {
		if(id == null)
			return;

		repo.deleteById(id);
	}
}
