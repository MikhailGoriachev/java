package org.itstep.pd011.controllers;

import org.itstep.pd011.services.SellersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/sellers")
public class SellersController {
    @Autowired
    private SellersService sellersService;

    @GetMapping
    public String sellersList(ModelMap model) {
        model.addAttribute("sellers", sellersService.getAll());
        return "sellers";
    }

    @PostMapping("/by-interest")
    public String sellersByInterest(@RequestParam("interest") Integer interest,
                                    ModelMap model) {
        model.addAttribute("sellers", sellersService.getByInterest(interest));
        return "sellers";
    }

    @GetMapping("/summary")
    public String sellersSummary(ModelMap model) {
        model.addAttribute("sellers", sellersService.getSellersSummary());
        return "query07";
    }
}
