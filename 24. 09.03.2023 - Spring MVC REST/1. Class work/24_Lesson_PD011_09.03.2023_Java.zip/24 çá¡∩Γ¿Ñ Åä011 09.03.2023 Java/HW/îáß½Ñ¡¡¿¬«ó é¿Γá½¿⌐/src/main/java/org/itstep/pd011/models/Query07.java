package org.itstep.pd011.models;

public record Query07(String surname,
        String name,
        String patronymic,
        String passport,
        Integer totalSale,
        Long salesFact,
        Integer minSale,
        Integer maxSale) {
        }

