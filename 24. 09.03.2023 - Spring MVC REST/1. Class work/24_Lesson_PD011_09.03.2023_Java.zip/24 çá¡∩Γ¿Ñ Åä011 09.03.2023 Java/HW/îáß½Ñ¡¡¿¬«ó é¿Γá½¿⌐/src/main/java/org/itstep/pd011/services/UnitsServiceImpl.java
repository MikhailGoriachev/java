package org.itstep.pd011.services;

import org.itstep.pd011.entities.Unit;
import org.itstep.pd011.repositories.UnitsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UnitsServiceImpl implements UnitsService{

    @Autowired
    private UnitsRepository repo;

    @Override
    public List<Unit> getAll() {
        return repo.findAll();
    }

    @Override
    public Optional<Unit> getById(Long id) {
        return repo.findById(id);

    }

    @Override
    public void save(Unit item) {
        if(item == null)
            return;

        repo.saveAndFlush(item);
    }

    @Override
    public void delete(Unit item) {
        if(item == null)
            return;

        repo.delete(item);
    }

    @Override
    public void deleteById(Long id) {
        if(id == null)
            return;

        repo.deleteById(id);
    }
}
