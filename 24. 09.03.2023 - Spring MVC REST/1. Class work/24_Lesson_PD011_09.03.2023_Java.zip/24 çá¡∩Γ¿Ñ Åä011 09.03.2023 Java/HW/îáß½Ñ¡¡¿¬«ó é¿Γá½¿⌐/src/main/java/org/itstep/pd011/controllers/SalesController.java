package org.itstep.pd011.controllers;

import org.itstep.pd011.services.SalesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/sales")
public class SalesController {
    @Autowired
    private SalesService salesService;

    @GetMapping
    public String salesList(ModelMap model) {
        model.addAttribute("sales", salesService.getAll());

        return "sales";
    }

    @PostMapping("/by-price-range")
    public String salesByPriceRange(@RequestParam("from") Integer from,
                                    @RequestParam("to") Integer to,
                                    ModelMap model) {
        model.addAttribute("sales", salesService.getByPriceRange(from, to));

        return "sales";
    }

    @GetMapping("/profits")
    public String getSalesProfits(ModelMap model) {
        model.addAttribute("sales", salesService.getSalesProfits());

        return "query05";
    }

}
