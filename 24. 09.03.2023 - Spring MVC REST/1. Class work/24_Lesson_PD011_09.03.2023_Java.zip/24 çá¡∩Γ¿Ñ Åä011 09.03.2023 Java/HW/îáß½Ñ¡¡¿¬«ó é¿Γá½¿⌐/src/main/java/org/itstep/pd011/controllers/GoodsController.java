package org.itstep.pd011.controllers;

import org.itstep.pd011.entities.Goods;
import org.itstep.pd011.entities.Purchase;
import org.itstep.pd011.services.GoodsService;
import org.itstep.pd011.services.PurchasesService;
import org.itstep.pd011.services.UnitsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class GoodsController {
    @Autowired private GoodsService goodsService;
    @Autowired private PurchasesService purchasesService;
    @Autowired private UnitsService unitsService;

    @GetMapping("/goods")
    public String goodsList(ModelMap model) {
        model.addAttribute("goods", goodsService.getAll());
        model.addAttribute("unitsList", unitsService.getAll());
        return "goods";
    }

    @PostMapping("/goods/by-unit-and-price")
    public String goodsWhereUnitsAndPriceLessThen(@RequestParam("unit") String unit,
                                                  @RequestParam("price") Integer price,
                                                  ModelMap model) {

        List<Goods> items = purchasesService
                .getByUnitShortNameAndPriceLessThan(unit, price)
                .stream()
                .map(Purchase::getGoods)
                .toList();

        model.addAttribute("goods", items);
        model.addAttribute("unitsList", unitsService.getAll());
        return "goods";
    }

}
