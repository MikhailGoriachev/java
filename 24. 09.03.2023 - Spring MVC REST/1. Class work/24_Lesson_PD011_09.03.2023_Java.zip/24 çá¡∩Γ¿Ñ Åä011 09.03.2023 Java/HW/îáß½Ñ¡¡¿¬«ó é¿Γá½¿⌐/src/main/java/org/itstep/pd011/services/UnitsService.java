package org.itstep.pd011.services;

import org.itstep.pd011.entities.Unit;

import java.util.List;
import java.util.Optional;

public interface UnitsService {
    List<Unit> getAll();

    Optional<Unit> getById(Long id);

    void save(Unit item);

    void delete(Unit item);

    void deleteById(Long id);
}
