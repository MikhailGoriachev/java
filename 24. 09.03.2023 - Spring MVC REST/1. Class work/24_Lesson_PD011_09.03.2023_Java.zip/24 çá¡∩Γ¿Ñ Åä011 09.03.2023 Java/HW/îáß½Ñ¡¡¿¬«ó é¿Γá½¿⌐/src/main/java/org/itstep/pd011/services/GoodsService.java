package org.itstep.pd011.services;

import org.itstep.pd011.entities.Goods;

import java.util.List;
import java.util.Optional;

public interface GoodsService {
    List<Goods> getAll();

    Optional<Goods> getById(Long id);

    void save(Goods goods);

    void delete(Goods goods);

    void deleteById(Long id);
}
