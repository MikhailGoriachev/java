package org.itstep.pd011.controllers;

import org.itstep.pd011.services.UnitsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class UnitsController {
    @Autowired
    private UnitsService unitsService;

    @GetMapping("/units")
    public String unitsList(ModelMap model) {
        model.addAttribute("units", unitsService.getAll());

        return "units";
    }
}
