package org.itstep.pd011.services;

import org.itstep.pd011.entities.Seller;
import org.itstep.pd011.models.Query07;
import org.itstep.pd011.repositories.SellersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SellersServiceImpl implements SellersService{

    @Autowired
    private SellersRepository repo;

    @Override
    public List<Seller> getAll() {
        return repo.findAll();
    }

    @Override
    public Optional<Seller> getById(Long id) {
        return repo.findById(id);
    }

    @Override
    public List<Seller> getByInterest(Integer value) {
        return repo.findSellersByInterestEquals(value);
    }

    @Override
    public List<Query07> getSellersSummary() {
        return repo.getSellersSummary();
    }

    @Override
    public void save(Seller item) {
        if(item == null)
            return;

        repo.saveAndFlush(item);
    }

    @Override
    public void delete(Seller item) {
        if(item == null)
            return;

        repo.delete(item);
    }

    @Override
    public void deleteById(Long id) {
            if(id == null)
                return;

            repo.deleteById(id);
    }
}
