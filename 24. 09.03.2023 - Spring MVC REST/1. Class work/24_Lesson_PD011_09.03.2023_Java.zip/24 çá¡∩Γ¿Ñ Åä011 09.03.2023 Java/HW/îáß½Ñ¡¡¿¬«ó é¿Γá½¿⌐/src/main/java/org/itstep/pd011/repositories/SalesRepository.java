package org.itstep.pd011.repositories;

import org.itstep.pd011.entities.Sale;
import org.itstep.pd011.models.Query05;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface SalesRepository extends JpaRepository<Sale, Long> {
    // 4	Запрос с параметрами
    // Выбирает информацию обо всех зафиксированных фактах продажи товаров (Наименование товара, Цена закупки,
    // Цена продажи, дата продажи), для которых Цена продажи оказалась в некоторых заданных границах.
    // Значения задавать параметрами
    List<Sale> findSalesByPriceBetween(Integer lo, Integer hi);

    // 5	Запрос с вычисляемыми полями
    // Вычисляет прибыль от продажи за каждый проданный товар.
    // Включает поля Дата продажи, Наименование товара, Цена закупки, Цена продажи, Количество проданных единиц, Прибыль.
    // Сортировка по полю Наименование товара
    @Query("""
           SELECT
            new org.itstep.pd011.models.Query05(s.saleDate, s.purchase.goods.name, s.purchase.price, s.price, s.amount,
                                                (s.price - s.purchase.price) * s.amount)
            FROM Sale s ORDER BY s.purchase.goods.name
            """)
    List<Query05> getSalesProfits();
}
