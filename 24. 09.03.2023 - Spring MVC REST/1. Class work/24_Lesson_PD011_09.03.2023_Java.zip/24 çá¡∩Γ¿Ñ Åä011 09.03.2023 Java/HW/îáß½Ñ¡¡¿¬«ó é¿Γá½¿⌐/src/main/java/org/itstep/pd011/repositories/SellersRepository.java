package org.itstep.pd011.repositories;

import org.itstep.pd011.entities.Seller;
import org.itstep.pd011.models.Query07;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface SellersRepository extends JpaRepository<Seller, Long> {
    // 3	Запрос с параметрами
    // Выбирает информацию о продавцах с заданным значением процента комиссионных. Значение задавать параметром
    List<Seller> findSellersByInterestEquals(int value);


    // 7	Итоговый запрос с левым соединением
    // Для всех продавцов вывести сумму и количество продаж, минимальную и максимальную стоимости продаж
    @Query("""
           SELECT new org.itstep.pd011.models.Query07(
           p.surname,
           p.name,
           p.patronymic,
           p.passport,
           CAST(COALESCE(SUM(s.price * s.amount), 0) as int),
           COUNT(s.id),
           COALESCE(MIN(s.price * s.amount), 0),
           COALESCE(MAX(s.price * s.amount), 0))
           FROM Seller se
           JOIN se.person p
           LEFT JOIN Sale s on se.id=s.seller.id
           GROUP BY se.id, p.id
           """)
    List<Query07> getSellersSummary();

}
