package org.itstep.pd011.repositories;

import org.itstep.pd011.entities.Person;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PersonsRepository extends JpaRepository<Person, Long> {
}
