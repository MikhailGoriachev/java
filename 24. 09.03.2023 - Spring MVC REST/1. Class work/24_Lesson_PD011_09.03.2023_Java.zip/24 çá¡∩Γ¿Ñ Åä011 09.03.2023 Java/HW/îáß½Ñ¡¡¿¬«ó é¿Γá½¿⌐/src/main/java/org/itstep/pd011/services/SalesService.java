package org.itstep.pd011.services;

import org.itstep.pd011.entities.Sale;
import org.itstep.pd011.models.Query05;

import java.util.List;
import java.util.Optional;

// операции, предоставляемые сервисом
public interface SalesService {

	List<Sale> getAll();

	Optional<Sale> getById(Long id);

	List<Sale> getByPriceRange(Integer from, Integer to);

	List<Query05> getSalesProfits();

	void save(Sale item);

	void delete(Sale item);

	void deleteById(Long id);
}
