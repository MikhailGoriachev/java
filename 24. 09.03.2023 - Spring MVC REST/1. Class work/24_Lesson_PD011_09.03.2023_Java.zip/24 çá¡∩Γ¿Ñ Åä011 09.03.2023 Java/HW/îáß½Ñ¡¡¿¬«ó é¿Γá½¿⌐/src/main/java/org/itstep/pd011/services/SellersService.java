package org.itstep.pd011.services;

import org.itstep.pd011.entities.Seller;
import org.itstep.pd011.models.Query07;

import java.util.List;
import java.util.Optional;

public interface SellersService {
    List<Seller> getAll();

    Optional<Seller> getById(Long id);

    List<Seller> getByInterest(Integer value);

    void save(Seller item);

    void delete(Seller item);

    void deleteById(Long id);

    List<Query07> getSellersSummary();
}
