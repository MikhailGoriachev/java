package org.homework.app.services;

import org.homework.app.entries.Sale;
import org.springframework.stereotype.Service;

import java.util.List;


public interface SalesService {
    
    // все записи
    List<Sale> findAll();
    
    // запись по id
    Sale findById(Long id);
    
    // добавить запись
    void store(Sale item);
    
    // изменить запись
    void update(Sale item);
    
    // удалить запись
    void delete(Long id);
}
