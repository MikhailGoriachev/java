package org.homework.app.services;

import org.homework.app.entries.Seller;
import org.springframework.stereotype.Service;

import java.util.List;


public interface SellersService {
    
    // все записи
    List<Seller> findAll();
    
    // запись по id
    Seller findById(Long id);
    
    // добавить запись
    void store(Seller item);
    
    // изменить запись
    void update(Seller item);
    
    // удалить запись
    void delete(Long id);

    // 3	Запрос с параметрами	Выбирает информацию о продавцах с заданным значением процента комиссионных. 
    //                              Значение задавать параметром
    List<Seller> findAllByInterest(int interest);
}
