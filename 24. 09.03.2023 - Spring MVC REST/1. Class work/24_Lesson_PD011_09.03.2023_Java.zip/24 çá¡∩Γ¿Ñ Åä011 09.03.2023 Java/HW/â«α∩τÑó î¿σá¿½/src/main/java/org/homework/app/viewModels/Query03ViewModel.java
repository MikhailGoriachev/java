package org.homework.app.viewModels;

public record Query03ViewModel(int minSalePrice, int maxSalePrice) {}