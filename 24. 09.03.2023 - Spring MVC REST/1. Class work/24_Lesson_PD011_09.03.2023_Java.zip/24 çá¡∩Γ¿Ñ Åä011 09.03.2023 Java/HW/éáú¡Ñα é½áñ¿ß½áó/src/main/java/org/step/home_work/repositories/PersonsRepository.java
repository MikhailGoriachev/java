package org.step.home_work.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.step.home_work.models.Query7;
import org.step.home_work.models.entities.sellers.Person;
import org.step.home_work.models.entities.sellers.Seller;

import java.util.List;

@Repository
public interface PersonsRepository extends JpaRepository<Person, Long> {

}
