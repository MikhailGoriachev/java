package org.step.home_work.models;

import java.util.Date;


public interface Query5 {

    public Date getDate();

    public long getSaleId();


    public String getProductName();

    public int getSellingPrice();

    public int getPurchasePrice();


    public int getAmount();


    public int getProfit();

}
