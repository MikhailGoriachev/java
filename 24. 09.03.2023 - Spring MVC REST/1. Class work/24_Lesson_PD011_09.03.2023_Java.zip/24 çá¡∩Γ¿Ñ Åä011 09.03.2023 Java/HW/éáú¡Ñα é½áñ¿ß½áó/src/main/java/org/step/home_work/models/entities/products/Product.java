package org.step.home_work.models.entities.products;


import javax.persistence.*;

@Entity
@Table(name = "products")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    //Связное свойство с таблицей наименований
    @ManyToOne
    @JoinColumn(name = "name_id")
    private ProductName productName;

    //Связное свойство с таблицей единиц измерения
    @ManyToOne
    @JoinColumn(name = "unit_id")
    private Unit unit;

    @Column(name = "selling_price")
    private int sellingPrice;

    @Column(name = "purchase_price")
    private int purchasePrice;

    public Product() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public ProductName getProductName() {
        return productName;
    }

    public void setProductName(ProductName productName) {
        this.productName = productName;
    }

    public Unit getUnit() {
        return unit;
    }

    public void setUnit(Unit unit) {
        this.unit = unit;
    }

    public int getSellingPrice() {
        return sellingPrice;
    }

    public void setSellingPrice(int sellingPrice) {
        this.sellingPrice = sellingPrice;
    }

    public int getPurchasePrice() {
        return purchasePrice;
    }

    public void setPurchasePrice(int purchasePrice) {
        this.purchasePrice = purchasePrice;
    }


    public static String HEADER  = """
            <tr>
            <th>id</th>
            <th>Наименование товара</th>
            <th>Единица измерения</th>
            <th>Стоимость закупки</th>
            <th>Стоимость продажи</th>
            </tr>""";

    //Вывод в строку таблицы
    public String toTableRow(){
        return String.format("<tr><td> %d </td><td> %s </td><td> %s </td><td> %d </td><td> %d </td></tr>",
                id,productName.getName(),unit.getUnitName(),purchasePrice,sellingPrice);
    }//toTableRow

}
