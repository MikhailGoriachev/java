package org.step.home_work.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.step.home_work.infrastructure.Utils;
import org.step.home_work.middleware.Services;
import org.step.home_work.services.products.ProductsService;

@Controller
@RequestMapping("/queries")
public class QueriesController {

    //Запрос 1
    @RequestMapping ("/query1")
    public ModelAndView query1(ModelAndView mav, @RequestParam(value = "unit", defaultValue = "шт") String unit,
                               @RequestParam(value = "price", defaultValue = "200") Integer price){


        mav.addObject("message","Запрос 1");
        mav.addObject("unit", unit);
        mav.addObject("price",price);
        mav.setViewName("queries/query1-view");
        mav.addObject("result",Services.productsService.query1(unit,price));

        return mav;
    }//query1

    //Запрос 2
    @RequestMapping ("/query2")
    public ModelAndView query2(ModelAndView mav, @RequestParam(value = "price", defaultValue = "0") Integer price){


        mav.addObject("message","Запрос 2");
        mav.addObject("price",price);
        mav.setViewName("queries/query2-view");
        mav.addObject("result",Services.productsService.query2(price));

        return mav;
    }//query2

    //Запрос 3 - Выбирает информацию о продавцах с заданным значением процента комиссионных.
    // Значение задавать параметром
    @RequestMapping ("/query3")
    public ModelAndView query3(ModelAndView mav, @RequestParam(value = "percent", defaultValue = "0") Double percent){

        mav.addObject("message","Запрос 3");
        mav.addObject("percent", percent);
        mav.setViewName("queries/query3-view");
        mav.addObject("result", Services.sellersService.query3(percent));

        return mav;
    }//query3


    //Запрос 7 - Выбирает информацию о продавцах с заданным значением процента комиссионных.
    // Значение задавать параметром
    @RequestMapping ("/query7")
    public ModelAndView query7(ModelAndView mav){

        mav.addObject("message","Запрос 7");
        mav.setViewName("queries/query7-view");
        mav.addObject("result", Services.sellersService.query7());

        return mav;
    }//query3

}
