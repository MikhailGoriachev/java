package org.step.home_work.infrastructure;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.step.home_work.middleware.Services;
import org.step.home_work.models.entities.sellers.Seller;
import org.step.home_work.services.sales.SalesService;
import org.step.home_work.services.sellers.SellersService;
import org.step.home_work.services.units.UnitsService;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Random;
import java.util.*;

@Component("Utils")
public class Utils {

    //Генерация значений
    private static Random rand = new Random();


    //Формат вывода вещественных чисел
    public static DecimalFormat doubleFormatter = new DecimalFormat("#0.00");

    //Формат вывода чисел
    public static DecimalFormat numbersFormatter = new DecimalFormat("###,###,###");

    //Формат вывода даты
    public static SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");

    public Utils() {
    }

    //Получение случайных значений
    public static double getRandom(double lo, double hi) {
        return lo + rand.nextDouble() * (hi - lo);
    }

    public static int getRandom(int lo, int hi) {
        return lo + rand.nextInt(hi - lo);
    }

    //Выпадающий список единиц измерения
    public static StringBuilder getUnitsDropDown(String highlight){
        var units = Services.unitsService.getAll();
        StringBuilder sb = new StringBuilder();

        //Создать список
        units.forEach(u -> sb.append(String.format("<option %2$s value=\"%1$s\">%1$s</option>"
                ,u.getUnitName(),
                u.getUnitName().contains(highlight) ? "selected" : "")));

        return sb;
    }

    //Выпадающий список процентов оклада
    public static StringBuilder getPercentsDropDown(Double highlight){

        //Получить список процентов отчислений
        var percents = Services.sellersService.getAll()
                .stream()
                .map(Seller::getPercent)
                .distinct();


        StringBuilder sb = new StringBuilder();

        //Задать элементы списка
        percents.forEach(p -> sb.append(String.format("<option %2$s value=\"%1$.5f\">%1$.2f</option>"
                ,p,Objects.equals(p, highlight) ? "selected" : "")));

        return sb;
    }




}
