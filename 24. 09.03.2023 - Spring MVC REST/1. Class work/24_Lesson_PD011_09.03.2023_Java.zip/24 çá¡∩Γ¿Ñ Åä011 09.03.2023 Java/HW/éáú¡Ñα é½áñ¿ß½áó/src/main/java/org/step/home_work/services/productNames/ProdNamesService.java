package org.step.home_work.services.productNames;

import org.step.home_work.models.entities.products.ProductName;
import org.step.home_work.models.entities.sellers.Person;

import java.util.List;

//Операции с таблицей наименований товаров
public interface ProdNamesService {

    List<ProductName> getAll();

    ProductName  getById(Long id);

}
