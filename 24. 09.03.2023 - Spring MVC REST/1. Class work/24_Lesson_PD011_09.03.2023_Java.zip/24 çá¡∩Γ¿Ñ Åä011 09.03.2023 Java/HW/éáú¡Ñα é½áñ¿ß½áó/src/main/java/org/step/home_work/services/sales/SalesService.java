package org.step.home_work.services.sales;

import org.step.home_work.models.Query5;
import org.step.home_work.models.Query6;
import org.step.home_work.models.entities.Sale;

import java.util.List;

//Операции с таблицей фактов продаж
public interface SalesService {

    //Добавить/редактировать
    void save(Sale sale);

    //Удалить
    void delete(Sale sale);

    //Удалить по id
    void deleteById(Long id);

    List<Sale> getAll();

    Sale getById(Long id);

    //Запрос 4
    List<Sale> query4(int priceMin, int priceMax);

    //Запрос 5
    List<Query5> query5();

    //Запрос 6
    List<Query6> query6();


}
