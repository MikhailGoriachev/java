package org.step.home_work.services.units;

import org.step.home_work.models.entities.products.ProductName;
import org.step.home_work.models.entities.products.Unit;

import java.util.List;

//Операции с таблицей единиц измерения
public interface UnitsService {

    List<Unit> getAll();

    Unit  getById(Long id);

}
