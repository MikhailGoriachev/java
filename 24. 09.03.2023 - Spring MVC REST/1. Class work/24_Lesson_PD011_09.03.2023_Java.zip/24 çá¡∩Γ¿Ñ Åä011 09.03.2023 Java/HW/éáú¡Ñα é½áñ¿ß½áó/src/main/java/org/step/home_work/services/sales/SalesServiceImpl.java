package org.step.home_work.services.sales;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.step.home_work.models.Query5;
import org.step.home_work.models.Query6;
import org.step.home_work.models.entities.Sale;
import org.step.home_work.repositories.SalesRepository;

import java.util.List;

@Service
public class SalesServiceImpl implements SalesService {

    //Репозиторий
    private SalesRepository salesRepository;

    @Autowired
    //Интерфейс сервиса
    private SalesService salesService;

    @Autowired
    public void setSalesRepository(SalesRepository salesRepository) {
        this.salesRepository = salesRepository;
    }

    @Override
    public void save(Sale sale) {
        if (sale != null)
            salesRepository.save(sale);
    }

    @Override
    public void delete(Sale sale) {
        if (sale != null)
            salesRepository.delete(sale);
    }

    @Override
    public void deleteById(Long id) {
        if (id != null)
            salesRepository.deleteById(id);
    }

    @Override
    public List<Sale> getAll() {
        return salesRepository.findAll();
    }

    @Override
    public Sale getById(Long id) {
        return id != null ? salesRepository.findById(id).get() : null;
    }


    //Запрос 4
    @Override
    public List<Sale> query4(int priceMin, int priceMax) {

        //Если заданы параметры по умолчанию, то вернуть всю коллекцию
        if (priceMin <= 0 && priceMax <= 0)
            return getAll();

        return salesRepository.findSalesByProductSellingPriceBetween(priceMin,priceMax);
    }

    //Запрос 5
    @Override
    public List<Query5> query5() {

        return null;
        // return salesRepository.query5();
    }

    //Запрос 6
    @Override
    public List<Query6> query6() {

        return null;
        // return salesRepository.query6();
    }


}
