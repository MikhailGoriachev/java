package org.step.home_work.services.productNames;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.step.home_work.models.entities.products.ProductName;
import org.step.home_work.repositories.ProdNamesRepository;

import java.util.List;

@Service
public class ProdNamesServiceImpl implements ProdNamesService {

    //Репозиторий
    private ProdNamesRepository prodNamesRepository;

    @Autowired
    //Интерфейс сервиса
    private ProdNamesService prodNamesService;

    @Autowired
    public void setSalesRepository(ProdNamesRepository personsRepository) {
        this.prodNamesRepository = personsRepository;
    }

    @Override
    public List<ProductName> getAll() {
        return prodNamesRepository.findAll();
    }

    @Override
    public ProductName getById(Long id) {
        return id != null ? prodNamesRepository.findById(id).get() : null;
    }


}
