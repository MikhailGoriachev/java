package org.step.home_work.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.step.home_work.models.Query5;
import org.step.home_work.models.Query6;
import org.step.home_work.models.entities.Sale;

import java.util.List;

@Repository
public interface SalesRepository extends JpaRepository<Sale, Long> {

    //Запрос 4
    List<Sale> findSalesByProductSellingPriceBetween(int priceMin, int priceMax);


    //Запрос 5
//    @Query(nativeQuery = true ,value = """
//    select
//        sales.date,
//        sales.id as saleId,
//        product_name,
//        selling_price,
//        purchase_price,
//        amount,
//        (selling_price - product_name) * sales.amount as profit
//    from
//        view_sales as sales
//    order by
//        sales.product_name
//    """)
//    List<Query5> query5();

    //Запрос 6
//    @Query(nativeQuery = true, value = """
//    select
//        view_sales.product_name,
//        avg(view_sales.purchase_price) as avg_purchase_price,
//        count(*) as amount
//    from
//        view_sales
//    group by
//        view_sales.product_name
//    """)
//    List<Query6> query6();

}
