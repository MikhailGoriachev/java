package org.step.home_work.services.sellers;

import org.step.home_work.models.Query7;
import org.step.home_work.models.entities.products.Product;
import org.step.home_work.models.entities.sellers.Seller;

import java.util.List;

//Операции с таблицей продавцов
public interface SellersService {

    List<Seller> getAll();

    Seller  getById(Long id);

    // Запрос 3 - Выбирает информацию о продавцах с заданным значением процента комиссионных.
    // Значение задавать параметром
    List<Seller> query3(double percent);

    // Запрос 7 - Для всех продавцов вывести сумму и количество продаж,
    // минимальную и максимальную стоимости продаж
    List<Query7> query7();


}
