package org.step.home_work.services.sellers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.step.home_work.models.Query7;
import org.step.home_work.models.entities.sellers.Seller;
import org.step.home_work.repositories.SellersRepository;

import java.util.List;

@Service
public class SellersServiceImpl implements SellersService {

    //Репозиторий
    private SellersRepository sellersRepository;

    @Autowired
    //Интерфейс сервиса
    private SellersService sellersService;

    @Autowired
    public void setSalesRepository(SellersRepository sellersRepository) {
        this.sellersRepository = sellersRepository;
    }

    @Override
    public List<Seller> getAll() {
        return sellersRepository.findAll();
    }

    @Override
    public Seller getById(Long id) {
        return id != null ? sellersRepository.findById(id).get() : null;
    }

    // Запрос 3 - Выбирает информацию о продавцах с заданным значением процента комиссионных.
    // Значение задавать параметром
    @Override
    public List<Seller> query3(double interest) {

        if (interest <= 0)
            return getAll();

        return sellersRepository.findSellersByPercentEquals(interest);
    }

    // Запрос 7 - Для всех продавцов вывести сумму и количество продаж,
    // минимальную и максимальную стоимости продаж
    @Override
    public List<Query7> query7() {

        return null;
        // return sellersRepository.query7();
    }


}
