package org.step.home_work.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.step.home_work.models.entities.products.Unit;
import org.step.home_work.models.entities.sellers.Person;

@Repository
public interface UnitsRepository extends JpaRepository<Unit, Long> {

}
