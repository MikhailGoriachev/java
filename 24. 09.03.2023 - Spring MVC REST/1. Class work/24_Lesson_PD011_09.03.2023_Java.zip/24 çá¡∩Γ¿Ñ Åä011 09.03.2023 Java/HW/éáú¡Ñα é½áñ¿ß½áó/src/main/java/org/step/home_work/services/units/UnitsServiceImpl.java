package org.step.home_work.services.units;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.step.home_work.models.entities.products.Unit;
import org.step.home_work.repositories.UnitsRepository;

import java.util.List;

@Service
public class UnitsServiceImpl implements UnitsService {

    //Репозиторий
    private UnitsRepository unitsRepository;

    @Autowired
    //Интерфейс сервиса
    private UnitsService unitsService;

    @Autowired
    public void setSalesRepository(UnitsRepository unitsRepository) {
        this.unitsRepository = unitsRepository;
    }

    @Override
    public List<Unit> getAll() {
        return unitsRepository.findAll();
    }

    @Override
    public Unit getById(Long id) {
        return id != null ? unitsRepository.findById(id).get() : null;
    }


}
