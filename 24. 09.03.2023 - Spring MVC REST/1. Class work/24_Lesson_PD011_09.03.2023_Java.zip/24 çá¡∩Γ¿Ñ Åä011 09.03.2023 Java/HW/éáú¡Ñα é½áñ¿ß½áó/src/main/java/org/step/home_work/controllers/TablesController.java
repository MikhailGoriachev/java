package org.step.home_work.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.step.home_work.infrastructure.Utils;
import org.step.home_work.middleware.Services;
import org.step.home_work.services.persons.PersonsService;
import org.step.home_work.services.productNames.ProdNamesService;
import org.step.home_work.services.products.ProductsService;
import org.step.home_work.services.sellers.SellersService;
import org.step.home_work.services.units.UnitsService;

@Controller
@RequestMapping("/entities")
public class TablesController {

    //Сервис для работы с таблицей товаров


    /*
    @Autowired
    private ProductsService productsService;
    */

    //Сервис для работы с таблицей продавцов
    /*@Autowired
    private SellersService sellersService;*/

    //Сервис для работы с таблицей персон
    /*@Autowired
    private PersonsService personsService;*/

    //Сервис для работы с таблицей наименований товаров
    /*@Autowired
    private ProdNamesService prodNamesService;*/

    //Сервис для работы с таблицей единиц измерения
    /*@Autowired
    private UnitsService unitsService;*/

    @RequestMapping("/get-products")
    public ModelAndView getProducts(ModelAndView mav){
        mav.setViewName("entities/products-view");


        mav.addObject("message","Таблица товаров");
        mav.addObject("products",Services.productsService.getAll());

        return mav;
    }

    @RequestMapping("/get-sellers")
    public ModelAndView getSellers(ModelAndView mav){
        mav.setViewName("entities/sellers-view");


        mav.addObject("message","Таблица продавцов");
        mav.addObject("sellers",Services.sellersService.getAll());

        return mav;
    }

    @RequestMapping("/get-persons")
    public ModelAndView getPersons(ModelAndView mav){
        mav.setViewName("entities/persons-view");


        mav.addObject("message","Таблица персон");
        mav.addObject("persons",Services.personsService.getAll());

        return mav;
    }

    @RequestMapping("/get-prod-names")
    public ModelAndView getProdNames(ModelAndView mav){
        mav.setViewName("entities/products-names-view");


        mav.addObject("message","Таблица наименований");
        mav.addObject("prodNames",Services.prodNamesService.getAll());

        return mav;
    }
    @RequestMapping("/get-units")
    public ModelAndView getUnits(ModelAndView mav){
        mav.setViewName("entities/units-view");


        mav.addObject("message","Таблица единиц измерения");
        mav.addObject("units", Services.unitsService.getAll());

        return mav;
    }


}
