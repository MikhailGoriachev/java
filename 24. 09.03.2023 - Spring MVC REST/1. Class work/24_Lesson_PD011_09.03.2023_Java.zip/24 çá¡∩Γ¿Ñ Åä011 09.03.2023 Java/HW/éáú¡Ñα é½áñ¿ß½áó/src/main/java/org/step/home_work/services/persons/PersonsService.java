package org.step.home_work.services.persons;

import org.step.home_work.models.Query7;
import org.step.home_work.models.entities.sellers.Person;
import org.step.home_work.models.entities.sellers.Seller;

import java.util.List;

//Операции с таблицей персон
public interface PersonsService {

    List<Person> getAll();

    Person  getById(Long id);

}
