package org.step.home_work.models;


public interface Query6 {

    public String getProductName();

    public double getAvgPrice();

    public int getAmount();

}
