package org.step.home_work.services.persons;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.step.home_work.models.entities.sellers.Person;
import org.step.home_work.repositories.PersonsRepository;

import java.util.List;

@Service
public class PersonsServiceImpl implements PersonsService {

    //Репозиторий
    private PersonsRepository personsRepository;

    @Autowired
    //Интерфейс сервиса
    private PersonsService personsService;

    @Autowired
    public void setSalesRepository(PersonsRepository personsRepository) {
        this.personsRepository = personsRepository;
    }

    @Override
    public List<Person> getAll() {
        return personsRepository.findAll();
    }

    @Override
    public Person getById(Long id) {
        return id != null ? personsRepository.findById(id).get() : null;
    }


}
