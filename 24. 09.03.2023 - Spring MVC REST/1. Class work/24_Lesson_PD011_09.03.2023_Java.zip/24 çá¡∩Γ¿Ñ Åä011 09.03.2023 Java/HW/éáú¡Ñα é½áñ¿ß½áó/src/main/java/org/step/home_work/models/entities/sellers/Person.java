package org.step.home_work.models.entities.sellers;


import javax.persistence.*;

@Entity
@Table(name = "persons")
public class Person {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    //фамилия
    @Column(name = "surname")
    private String surname;

    //имя
    @Column(name = "name")
    private String name;

    //отчество
    @Column(name = "patronymic")
    private String patronymic;

    public Person() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPatronymic() {
        return patronymic;
    }

    public void setPatronymic(String patronymic) {
        this.patronymic = patronymic;
    }


    public static String HEADER  = """
            <tr>
                <th>id</th>
                <th>Фамилия</th>
                <th>Имя</th>
                <th>Отчество</th>
            </tr>
            """;

    public String toTableRow(){
        return String.format("""
                <tr>
                    <td> %d </td>
                    <td> %s </td>
                    <td> %s </td>
                    <td> %s </td>
                </tr>
                """,id,surname,name,patronymic);
    }//toTableRow

}
