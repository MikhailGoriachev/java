package org.step.home_work.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.step.home_work.middleware.Services;
import org.step.home_work.models.entities.Sale;
import org.step.home_work.services.sales.SalesService;

@Controller
@RequestMapping("/sales")
public class SalesController {


    @RequestMapping("/")
    public ModelAndView getSales(ModelAndView mav){
        mav.setViewName("entities/sales-view");


        mav.addObject("message","Таблица продаж");
        mav.addObject("sales",Services.salesService.getAll());

        return mav;
    }

    //Отправка формы в режиме создания записи
    @GetMapping ("/getAddingForm")
    public ModelAndView formAdd(ModelAndView mav){
        mav.addObject("isCreate",true);

        return new ModelAndView("entities/saleForm","sale",new Sale());
    }//form

    //Получение значений из формы и добавление цилиндра
    @PostMapping("/addSale")
    public ModelAndView addSale(@ModelAttribute(/*"sale"*/"SpringWeb") Sale sale, ModelAndView mav, BindingResult result){
        mav.setViewName("entities/sales-view");

        if (sale == null || result.hasErrors()){
            mav.addObject("message","Добавить факт продажи не удалось!");
            mav.addObject("sales",Services.salesService.getAll());

            return mav;
        }

        //Добавить полученный объект в таблицу
        Services.salesService.save(sale);

        mav.addObject("message",String.format("Добавлена запись с id %d",sale.getId()));
        mav.addObject("sales",Services.salesService.getAll());


        return mav;
    }//addSale

    //Отправка формы в режиме редактирования
    @GetMapping ("/getUpdatingForm")
    public ModelAndView formUpdate(@RequestParam(value = "id") Long id, ModelAndView mav){
        mav.addObject("isCreate",false);

        return new ModelAndView("entities/saleForm","sale",Services.salesService.getById(id));
    }//formUpdate

    //Получение значений из формы и добавление цилиндра
    @PostMapping("/update")
    public ModelAndView updateSale(@ModelAttribute(/*"sale"*/"SpringWeb") Sale sale, ModelAndView mav, BindingResult result){
        mav.setViewName("entities/sales-view");

        if (sale == null || result.hasErrors()){
            mav.addObject("message","Изменить факт продажи не удалось!");
            mav.addObject("sales",Services.salesService.getAll());

            return mav;
        }

        //Сохранить изменённый объект
        Services.salesService.save(sale);

        mav.addObject("message",String.format("Измена запись с id %d",sale.getId()));
        mav.addObject("sales",Services.salesService.getAll());


        return mav;
    }//updateSale

    //Удаление
    @RequestMapping ("/delete")
    public ModelAndView delete(@RequestParam(value = "id") Long id, ModelAndView mav){

        mav.setViewName("entities/sales-view");

        if (id == null || id <= 0){
            mav.addObject("message","Удалить запись не удалось. Id некорректен");
            mav.addObject("sales",Services.salesService.getAll());

            return mav;
        }

        Services.salesService.deleteById(id);

        mav.addObject("message",String.format("Удалена запись с id %d",id));
        mav.addObject("sales",Services.salesService.getAll());

        return mav;
    }//delete

    //Запрос 4
    @RequestMapping ("/query4")
    public ModelAndView query4(ModelAndView mav, @RequestParam(value = "pMin", defaultValue = "0") Integer priceMin,
                               @RequestParam(value = "pMax", defaultValue = "0") Integer priceMax){


        mav.addObject("message","Запрос 4");
        mav.addObject("priceMin",priceMin);
        mav.addObject("priceMax",priceMax);
        mav.setViewName("queries/query4-view");
        mav.addObject("result",Services.salesService.query4(priceMin,priceMax));

        return mav;
    }//query4


    //Запрос 5
    @RequestMapping ("/query5")
    public ModelAndView query5(ModelAndView mav){


        mav.addObject("message","Запрос 5");
        mav.setViewName("queries/query5-view");
        mav.addObject("result",Services.salesService.query5());

        return mav;
    }//query5

    //Запрос 6
    @RequestMapping ("/query6")
    public ModelAndView query6(ModelAndView mav){


        mav.addObject("message","Запрос 6");
        mav.setViewName("queries/query6-view");
        mav.addObject("result",Services.salesService.query6());

        return mav;
    }//query6


}
