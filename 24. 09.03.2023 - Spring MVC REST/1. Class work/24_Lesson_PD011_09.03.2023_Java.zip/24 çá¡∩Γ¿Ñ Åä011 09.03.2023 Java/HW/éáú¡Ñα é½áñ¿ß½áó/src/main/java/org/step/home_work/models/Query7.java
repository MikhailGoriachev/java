package org.step.home_work.models;

public interface Query7 {

   String getSellerSnp();

   int getProductsAmount();

   int getSalesCount();


   int getMaxSalePrice();

   int getMinSalePrice();

}
