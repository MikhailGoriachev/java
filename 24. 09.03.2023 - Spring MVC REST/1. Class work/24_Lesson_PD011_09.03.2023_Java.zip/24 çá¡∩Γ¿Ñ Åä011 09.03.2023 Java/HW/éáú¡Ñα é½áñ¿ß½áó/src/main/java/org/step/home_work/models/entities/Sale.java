package org.step.home_work.models.entities;
import org.step.home_work.models.entities.products.Product;
import org.step.home_work.models.entities.sellers.Seller;
import org.step.home_work.infrastructure.Utils;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "sales")
public class Sale {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;


    //Связное свойство с таблицей товаров
    @ManyToOne
    @JoinColumn(name = "product_id")
    private Product product;

    //Связное свойство с таблицей продавцов
    @ManyToOne
    @JoinColumn(name = "seller_id")
    private Seller seller;

    @Column(name = "products_amount")
    private int productsAmount;

    @Column(name = "sale_date")
    private Date saleDate;

    public Sale() {
    }

    public Sale(Product product, Seller seller, int productsAmount, Date saleDate) {
        this.product = product;
        this.seller = seller;
        this.productsAmount = productsAmount;
        this.saleDate = saleDate;
    }

    //region Аксессоры
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Seller getSeller() {
        return seller;
    }

    public void setSeller(Seller seller) {
        this.seller = seller;
    }

    public int getProductsAmount() {
        return productsAmount;
    }

    public void setProductsAmount(int productsAmount) {
        this.productsAmount = productsAmount;
    }

    public Date getSaleDate() {
        return saleDate;
    }

    public void setSaleDate(Date saleDate) {
        this.saleDate = saleDate;
    }
    //endregion


    public static String HEADER  = """
            <tr>
            <th>id</th>
            <th>Наименование товара</th>
            <th>Единица измерения</th>
            <th>Стоимость закупки</th>
            <th>Стоимость продажи</th>
            <th>ФИО продавца</th>
            <th>% отчислений за продажу</th>
            <th>кол-во проданных товаров</th>
            <th>дата продажи</th> </tr>""";

    public String toTableRow(){
        return String.format("<tr><td> %d </td><td> %s </td><td> %s </td><td> %d </td><td> %d </td><td> %s </td><td> %.2f </td> <td> %d </td> <td> %s </td> </tr> ",
                id,product.getProductName().getName(),product.getUnit().getUnitName(),product.getPurchasePrice(),product.getSellingPrice(),
                String.format("%s.%s.%s",seller.getPerson().getSurname(),
                        seller.getPerson().getName().charAt(0),
                        seller.getPerson().getPatronymic().charAt(0)),
                seller.getPercent(), productsAmount, Utils.dateFormat.format(saleDate)
        );
    }//toTableRow
}
