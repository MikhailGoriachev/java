package org.step.home_work.services.products;

import org.step.home_work.models.entities.products.Product;

import java.util.List;

//Операции с таблицей товаров
public interface ProductsService {

    List<Product> getAll();

    Product  getById(Long id);

    // Запрос 1 - Выбирает информацию о товарах, единицей измерения которых является «шт» (штуки)
    // и цена закупки составляет меньше 200 руб.
    // Значения задавать параметрами
    List<Product> query1(String unitName, int price);

    // Запрос 2 - Выбирает информацию о товарах, цена закупки которых меньше 500 руб. за единицу товара.
    // Значения задавать параметрами
    List<Product> query2(int price);


}
