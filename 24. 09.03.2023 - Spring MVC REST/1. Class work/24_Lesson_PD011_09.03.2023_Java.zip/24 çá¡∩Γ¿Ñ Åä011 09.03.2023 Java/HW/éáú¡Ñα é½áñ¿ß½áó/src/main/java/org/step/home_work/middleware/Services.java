package org.step.home_work.middleware;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.step.home_work.controllers.TablesController;
import org.step.home_work.infrastructure.Utils;
import org.step.home_work.services.persons.PersonsService;
import org.step.home_work.services.productNames.ProdNamesService;
import org.step.home_work.services.products.ProductsService;
import org.step.home_work.services.sales.SalesService;
import org.step.home_work.services.sellers.SellersService;
import org.step.home_work.services.units.UnitsService;


@Component("Services")
public class Services {

    //Сервис для продаж
    public static SalesService salesService;

    @Autowired
    public void setSalesService(SalesService salesService){
        Services.salesService = salesService;
    }

    //Сервис для работы с таблицей товаров

    public static ProductsService productsService;

    @Autowired
    public void setProductsService(ProductsService productsService) {
        Services.productsService = productsService;
    }

    //Единицы измерения
    public static UnitsService unitsService;

    @Autowired
    public void setUnitsService(UnitsService unitsService){
        Services.unitsService = unitsService;
    }


    //Продавцы
    public static SellersService sellersService;

    @Autowired
    public void setUnitsService(SellersService sellersService){
        Services.sellersService = sellersService;
    }


    //Сервис для работы с таблицей персон

    public static PersonsService personsService;

    @Autowired
    public void setPersonsService(PersonsService personsService){
        Services.personsService = personsService;
    }

    //Сервис для работы с таблицей наименований

    public static ProdNamesService prodNamesService;

    @Autowired
    public void setProdNamesService(ProdNamesService prodNamesService){
        Services.prodNamesService = prodNamesService;
    }

}

