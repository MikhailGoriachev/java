package org.step.home_work.services.products;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.step.home_work.models.entities.products.Product;
import org.step.home_work.repositories.ProductsRepository;

import java.util.List;

@Service
public class ProductsServiceImpl implements ProductsService {

    //Репозиторий
    private ProductsRepository productsRepository;

    @Autowired
    //Интерфейс сервиса
    private ProductsService productsService;

    @Autowired
    public void setSalesRepository(ProductsRepository prodsRepository) {
        this.productsRepository = prodsRepository;
    }

    @Override
    public List<Product> getAll() {
        return productsRepository.findAll();
    }

    @Override
    public Product getById(Long id) {
        return id != null ? productsRepository.findById(id).get() : null;
    }

    // Запрос 1 - Выбирает информацию о товарах, единицей измерения которых является «шт» (штуки)
    // и цена закупки составляет меньше 200 руб.
    // Значения задавать параметрами
    @Override
    public List<Product> query1(String unitName, int price) {

        if (unitName.isBlank() && price <= 0)
            return getAll();

        return productsRepository.findProductsByUnitUnitNameAndPurchasePriceLessThan(unitName,price);
    }

    // Запрос 2 - Выбирает информацию о товарах, цена закупки которых меньше 500 руб. за единицу товара.
    // Значения задавать параметрами
    @Override
    public List<Product> query2(int price) {
        if (price <= 0)
            return getAll();
        return productsRepository.findProductsByPurchasePriceLessThan(price);
    }


}
