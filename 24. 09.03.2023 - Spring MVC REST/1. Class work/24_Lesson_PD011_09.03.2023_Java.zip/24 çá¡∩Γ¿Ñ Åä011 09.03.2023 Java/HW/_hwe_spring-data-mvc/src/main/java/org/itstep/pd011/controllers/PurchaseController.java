package org.itstep.pd011.controllers;

import org.itstep.pd011.entities.Purchase;
import org.itstep.pd011.entities.Unit;
import org.itstep.pd011.services.PurchaseService;
import org.itstep.pd011.services.UnitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

// запросы к таблице закупок товаров
@Controller
public class PurchaseController {
    // указать сервис для доступа к данным
    // @Autowired - фреймворк сам ищет класс сервиса
    @Autowired
    private PurchaseService purchaseService;

    // отдать страницу вывода записей таблица фактов закупки товаров
    @RequestMapping(value="/purchase-list", method= RequestMethod.GET)
    public String unitsPage(Model model) {
        List<Purchase> purchases = purchaseService.getAll();
        model.addAttribute("purchases", purchases);

        return "purchases-view";
    } // purchasesPage
} // class PurchaseController
