package org.itstep.pd011.services;

import org.itstep.pd011.entities.Product;
import org.itstep.pd011.repositories.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

// реализация операций с таблицей-справочником товаров
@Service
public class ProductServiceImpl implements ProductService {
    private ProductRepository productRepository;

    /* ----  настройка фреймворка Spring */
    // @Autowired - фреймворк сам ищет поле сервиса
    @Autowired
    private ProductService productService;

    // @Autowired - фреймворк сам ищет метод сервиса
    @Autowired
    public void setProductRepository(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }
    /* ---- */

    @Override
    public List<Product> getAll() { return productRepository.findAll(); }

    @Override
    public Product getById(Integer id) {
        return id==null?null:productRepository.findById(id).get();
    }
} // class ProductServiceImpl
