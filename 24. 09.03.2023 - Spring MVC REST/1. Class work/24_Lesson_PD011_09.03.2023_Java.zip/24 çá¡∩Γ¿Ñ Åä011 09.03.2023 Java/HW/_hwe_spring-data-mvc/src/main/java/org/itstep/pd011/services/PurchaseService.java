package org.itstep.pd011.services;

import org.itstep.pd011.entities.Purchase;
import org.itstep.pd011.models.IQuery05;
import java.util.List;

// операции, предоставляемые сервисом доступа к таблице purchases
// (таблицей закупок товаров)
public interface PurchaseService {
    // получить все записи таблицы
    List<Purchase> getAll();

    // получить одну запись таблицы
    Purchase getById(Integer id);

    // Запрос 1.
    // Выбирает информацию о товарах, с заданной единицей измерения и ценой закупки
    List<Purchase> findPurchasesBy(String unit, Integer price);

    // Запрос 2.
    // Выбирает информацию о товарах, цена закупки которых меньше заданного знчения
    List<Purchase> findPurchasesByPriceLessThan(int value);

    // Запрос 5.
    // Выполняет группировку по наименованию закупленного товара.
    // Для каждого наименования вычисляет среднюю цену закупки
    // товара, количество закупок
    List<IQuery05> query05();
} // interface PurchaseService
