package org.itstep.pd011.services;

import java.util.List;

import org.itstep.pd011.entities.Unit;

// операции, предоставляемые сервисом доступа к таблице units
// (таблицей единиц измерения)
public interface UnitService {
	// получить все записи таблицы
	List<Unit> getAll();

	// получить одну запись из таблицы
	Unit getById(Integer id);
} // interface UnitService
