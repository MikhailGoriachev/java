package org.itstep.pd011.services;

import org.itstep.pd011.entities.Unit;
import org.itstep.pd011.repositories.UnitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

// реализация операций с таблицей сведений о единицах измерения товаров
@Service
public class UnitServiceImpl implements UnitService {
	private UnitRepository unitRepository;

	/* ----  настройка фреймворка Spring */
	// @Autowired - фреймворк сам ищет поле сервиса
	@Autowired
	private UnitService unitService;

	// @Autowired - фреймворк сам ищет метод сервиса
	@Autowired
	public void setUnitRepository(UnitRepository unitRepository) {
		this.unitRepository = unitRepository;
	}
	/* ---- */


	public List<Unit> getAll() {
		return unitRepository.findAll();
	}

	public Unit getById(Integer id) {
		return id==null?null:unitRepository.findById(id).get();
	}
} // class UnitServiceImpl
