package org.itstep.pd011.services;

import org.itstep.pd011.entities.Seller;

import java.util.List;

// операции, предоставляемые сервисом доступа к таблице sellers
// (таблицей сведений о продавцах)
public interface SellerService {
    // получить все записи таблицы
    List<Seller> getAll();

    // получить одну запись таблицы
    Seller getById(Integer id);
} // interface SellerService