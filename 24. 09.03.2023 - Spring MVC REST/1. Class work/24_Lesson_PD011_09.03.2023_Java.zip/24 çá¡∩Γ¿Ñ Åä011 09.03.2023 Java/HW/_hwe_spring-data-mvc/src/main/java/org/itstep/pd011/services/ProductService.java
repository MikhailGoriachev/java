package org.itstep.pd011.services;

import org.itstep.pd011.entities.Product;

import java.util.List;

// операции, предоставляемые сервисом доступа к таблице products
// (таблицей справочников товаров)
public interface ProductService {
    // получить все записи таблицы
    List<Product> getAll();

    // получить одну запись таблицы
    Product getById(Integer id);
} // interface ProductService
