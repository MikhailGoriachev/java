package org.itstep.pd011.controllers;

import org.itstep.pd011.entities.Unit;
import org.itstep.pd011.services.UnitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import java.util.List;

// вывод таблицы - справочника единиц измерения
@Controller
public class UnitController {
    // указать сервис для доступа к данным
    // @Autowired - фреймворк сам ищет класс сервиса
    @Autowired
    private UnitService unitService;

    // отдать страницу вывода справочника единиц измерения
    @RequestMapping(value="/unit-list", method= RequestMethod.GET)
    public String unitsPage(Model model) {
        List<Unit> units = unitService.getAll();
        model.addAttribute("units", units);

        return "units-view";
    } // unitsPage
} // class UnitController
