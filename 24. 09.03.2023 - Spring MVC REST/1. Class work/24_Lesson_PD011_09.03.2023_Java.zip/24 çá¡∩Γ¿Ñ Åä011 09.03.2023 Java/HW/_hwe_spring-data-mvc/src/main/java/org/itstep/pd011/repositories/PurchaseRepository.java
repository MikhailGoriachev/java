package org.itstep.pd011.repositories;

import org.itstep.pd011.entities.Purchase;
import org.itstep.pd011.models.IQuery05;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface PurchaseRepository extends JpaRepository<Purchase, Integer> {
    // Запрос 1.
    // Выбирает информацию о товарах, единицей измерения которых является «шт» (штуки)
    // и цена закупки составляет меньше 500 руб. Значения задавать параметрами
    List<Purchase> findPurchasesByUnitShortNameAndPriceLessThan(String unit, Integer price);

    // Запрос 2.
    // Выбирает информацию о товарах, цена закупки которых меньше 500 руб.
    // за единицу товара. Значения задавать параметрами
    List<Purchase> findPurchasesByPriceLessThan(int value);

    // Запрос 5.
    // Выполняет группировку по наименованию закупленного товара.
    // Для каждого наименования вычисляет среднюю цену закупки
	// !!! Масленников В.В., ПД-011                                      !!!
	// !!! Нативный SQL-запрос приводит к падению приложения при запуске !!!
	// !!! Решение - запрос к сущностям                                  !!!
    // товара, количество закупок
//    @Query(value= """
//        select
//            products.name            as name
//            , avg(purchases.price)   as averagePrice
//            , count(purchases.price) as amount
//        from
//            purchases join products on purchases.product_id = products.id
//        group by
//            products.name;
//        """, nativeQuery = false)
//    List<IQuery05> query05();
} // interface PurchaseRepository
