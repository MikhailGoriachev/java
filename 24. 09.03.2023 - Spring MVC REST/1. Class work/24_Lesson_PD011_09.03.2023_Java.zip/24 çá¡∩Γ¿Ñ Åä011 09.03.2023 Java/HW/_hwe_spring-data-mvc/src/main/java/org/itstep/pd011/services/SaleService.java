package org.itstep.pd011.services;

import org.itstep.pd011.entities.Sale;

import java.util.List;

// операции, предоставляемые сервисом доступа к таблице sales
// (таблицей фактов проодаж товаров)
public interface SaleService {
    // получить все записи таблицы
    List<Sale> getAll();

    // получить одну запись таблицы
    Sale getById(Integer id);
} // interface SaleService
