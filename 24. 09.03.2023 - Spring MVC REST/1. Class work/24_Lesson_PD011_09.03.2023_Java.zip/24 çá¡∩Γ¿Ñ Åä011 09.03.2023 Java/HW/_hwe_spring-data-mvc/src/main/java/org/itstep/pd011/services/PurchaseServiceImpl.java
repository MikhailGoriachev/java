package org.itstep.pd011.services;

import org.itstep.pd011.entities.Purchase;
import org.itstep.pd011.models.IQuery05;
import org.itstep.pd011.repositories.PurchaseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

// реализация операций с таблицей фактов закупок
@Service
public class PurchaseServiceImpl implements PurchaseService {
    private PurchaseRepository purchaseRepository;

    /* ----  настройка фреймворка Spring */
    // @Autowired - фреймворк сам ищет поле сервиса
    @Autowired
    private PurchaseService purchaseService;

    // @Autowired - фреймворк сам ищет метод сервиса
    @Autowired
    public void setPurchaseRepository(PurchaseRepository purchaseRepository) {
        this.purchaseRepository = purchaseRepository;
    } // setPurchaseRepository
    /* ---- */

    @Override
    public List<Purchase> getAll() {  return purchaseRepository.findAll(); } // getAll

    @Override
    public Purchase getById(Integer id) {
        return id==null?null:purchaseRepository.findById(id).get();
    } // getById

    @Override
    public List<Purchase> findPurchasesBy(String unit, Integer price) {
        return purchaseRepository.findPurchasesByUnitShortNameAndPriceLessThan(unit, price);
    } // findPurchasesBy

    @Override
    public List<Purchase> findPurchasesByPriceLessThan(int value) {
        return purchaseRepository.findPurchasesByPriceLessThan(value);
    } // findPurchasesByPriceLessThan

    @Override
    public List<IQuery05> query05() {
        // return purchaseRepository.query05();
        return null;
    } // query05
} // class PurchaseServiceImpl
