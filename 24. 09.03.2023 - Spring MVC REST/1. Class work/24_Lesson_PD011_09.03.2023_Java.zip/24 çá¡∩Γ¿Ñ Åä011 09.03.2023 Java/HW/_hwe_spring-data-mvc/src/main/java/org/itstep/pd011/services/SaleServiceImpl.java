package org.itstep.pd011.services;

import org.itstep.pd011.entities.Sale;
import org.itstep.pd011.repositories.SaleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

// реализация операций с таблицей фактов продаж
@Service
public class SaleServiceImpl implements SaleService {
    private SaleRepository saleRepository;

    /* ----  настройка фреймворка Spring */
    // @Autowired - фреймворк сам ищет поле сервиса
    @Autowired
    private SaleService saleService;

    // @Autowired - фреймворк сам ищет метод сервиса
    @Autowired
    public void setSaleRepository(SaleRepository saleRepository) {
        this.saleRepository = saleRepository;
    }
    /* ---- */

    @Override
    public List<Sale> getAll() { return saleRepository.findAll(); }

    @Override
    public Sale getById(Integer id) { return id==null?null:saleRepository.findById(id).get(); }
} // class SaleServiceImpl
