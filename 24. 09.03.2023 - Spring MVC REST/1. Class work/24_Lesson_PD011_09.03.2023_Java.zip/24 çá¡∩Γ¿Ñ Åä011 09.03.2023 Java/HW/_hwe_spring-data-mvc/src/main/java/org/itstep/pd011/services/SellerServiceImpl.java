package org.itstep.pd011.services;

import org.itstep.pd011.entities.Seller;
import org.itstep.pd011.repositories.SellerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

// реализация операций с таблицей сведений о продавцах
@Service
public class SellerServiceImpl implements SellerService {
    private SellerRepository sellerRepository;

    /* ----  настройка фреймворка Spring */
    // @Autowired - фреймворк сам ищет поле сервиса
    @Autowired
    private SellerService sellerService;

    // @Autowired - фреймворк сам ищет метод сервиса
    @Autowired
    public void setSellerRepository(SellerRepository sellerRepository) {
        this.sellerRepository = sellerRepository;
    }
    /* ---- */

    @Override
    public List<Seller> getAll() { return sellerRepository.findAll();  }

    @Override
    public Seller getById(Integer id) { return id==null?null:sellerRepository.findById(id).get(); }
} // class SellerServiceImpl
