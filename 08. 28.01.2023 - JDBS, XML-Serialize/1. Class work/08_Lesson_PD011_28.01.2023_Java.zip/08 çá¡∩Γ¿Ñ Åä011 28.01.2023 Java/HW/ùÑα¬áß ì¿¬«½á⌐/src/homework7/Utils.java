package homework7;

public class Utils {

}
