package homework7;

import homework7.controller.Task1Controller;
import homework7.controller.Task2Controller;

public class Main {
    public static void main(String[] args)
    {
        Task1Controller task1 = new Task1Controller();
        Task2Controller task2 = new Task2Controller();
        try {
            boolean flag = true;
            while (flag) {
                switch (Menu.showMenu()){
                    case 0 -> task1.task();
                    case 1 -> System.out.println("2");
                    case 2 -> System.out.println("3");
                    case 3 -> flag = false;
                }
            }
        } catch (Exception exc) {
            System.out.println(exc.getMessage());
        }
    }
}