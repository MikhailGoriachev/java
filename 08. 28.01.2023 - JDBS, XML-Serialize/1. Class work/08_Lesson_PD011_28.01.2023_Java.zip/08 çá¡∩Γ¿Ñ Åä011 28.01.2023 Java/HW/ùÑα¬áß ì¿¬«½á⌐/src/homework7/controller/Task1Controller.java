package homework7.controller;

import homework7.models.Resident;

import javax.swing.*;
import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

import static homework7.Menu.showMenu1;

public class Task1Controller {
    String fileName = "data/residents.bin";
    public Task1Controller() {
    }

    public void task(){
        try {
            boolean flag = true;
            while (flag) {
                switch (showMenu1()) {
                    case 0 -> {
                        //readBin();//
                        show(readBin());
                    }
                    case 1 -> {
                        System.out.println("\033[34m1.\tстатистика по городам – название городов, количество жителей из" +
                                " этих городов \nв коллекции, средний возраст, минимальный возраст, максимальный возраст жителя\033[0m");
                        query1();
                    }
                    case 2 -> {
                        System.out.println("\033[34m2.\tжители с заданной профессией, фамилия которых начинается с заданной строки \033[0m");
                        List<String> profs = new ArrayList<>();
                        readBin().forEach(e -> profs.add(e.getProfession()));
                        String profession = (String) JOptionPane.showInputDialog(
                                null,
                                "Выберите профессию",
                                "Профессия",
                                JOptionPane.QUESTION_MESSAGE,
                                null,
                                Arrays.stream(profs.toArray()).sequential().toArray(),
                                profs);
                        String surname = JOptionPane.showInputDialog("Введите фамилию");

                        query2(profession, surname);
                    }
                    case 3 -> {
                        System.out.println("\033[34m3.\tсписок фамилий и жители с такой фамилией\033[0m");
                        List<String> surnames = new ArrayList<>(Arrays.asList("Иванов", "Ефремов", "Деревянко"));
                        System.out.print("Список фамилий: ");
                        for (var item:surnames){
                            System.out.printf(" %s, ", item);
                        };
                        System.out.println();
                        query3(surnames);

                    }
                    case 4 -> {
                        System.out.println("\033[34m4.\tсписок профессий и жители с такой профессией\033[0m");
                        query4();
                    }
                    case 5 -> {
                        System.out.println("\033[34m5.\tсписок городов по убыванию количества проживающих в них людей\033[0m");
                        query5();
                    }
                    case 6 -> {
                        System.out.println("\033[34m6.\tстатистика по профессиям \033[0m");
                        query6();
                    }
                    case 7 -> flag = false;
                }
            }
        } catch (Exception exc) {
            System.out.println(exc.getMessage());
        }
    }
    // запись в бинарный файл
    public void writeBin(List<Resident> list) {
        try (var oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            oos.writeObject(list);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
    // чтение из бинарного файла
    public List<Resident> readBin(){
        try(var ois = new ObjectInputStream(new FileInputStream(fileName)))
        {
            return (List<Resident>) ois.readObject();
        }
        catch(Exception ex){
            System.out.println(ex.getMessage());
        }
        return null;
    }

    //public Resident parseResident(String str){
    //    String[] t = str.split(";");
    //    return new Resident(t[0], t[1], Integer.parseInt(t[2]), t[3], t[4], Integer.parseInt(t[5]));
    //}
    //public void readFileCsv(){
    //    try (Scanner sc = new Scanner(new File("data/residents.csv"))){
    //        while(sc.hasNext()) {
    //            residents.add(parseResident(sc.nextLine()));
    //        }
    //    }catch (IOException ex){
    //        ex.printStackTrace();
    //    }
    //}
    // вывод в консоль
    public void show(List<Resident> list){
        String top = """
                 ________________________________________________________________________________
                |      Фамилия    |    Имя     |  Возраст |   Город    |    Профессия    | Оклад |
                 --------------------------------------------------------------------------------
                """;
        System.out.print(top);
        list.forEach(System.out::println);
        String bottom = " --------------------------------------------------------------------------------";
        System.out.println(bottom);
    }
    // 1.	статистика по городам – название городов, количество жителей
    // из этих городов в коллекции, средний возраст, минимальный возраст,
    // максимальный возраст жителя
    public void query1() {
        Map<String, List<Resident>> citygroup = readBin().stream()
                .collect((Collectors.groupingBy(Resident::getCity)));
        for (var item : citygroup.entrySet()){
            System.out.printf(
                    "Город: %s\nКоличество жителей: %d\nСредний возраст: %.3f\nМинимальный возраст: %d\nМаксимальный возраст: %d\n",
                    item.getKey(),
                    (long) item.getValue().size(),
                    item.getValue().stream().mapToDouble(Resident::getAge).average().getAsDouble(),
                    item.getValue().stream().min(Comparator.comparing(Resident::getAge)).get().getAge(),
                    item.getValue().stream().max(Comparator.comparing(Resident::getAge)).get().getAge());
        }
    }
    // 2.	жители с заданной профессией, фамилия которых начинается с заданной строки
    public void query2(String profession, String surname){
        List<Resident> list;
        list = readBin().stream()
                .filter(a -> a.getProfession().equals(profession) && a.getSurname().startsWith(surname)).toList();
        show(list);
    }
    // 3.	список фамилий и жители с такой фамилией
    public void query3(List<String> str){
        List<Resident> list;
        list = readBin().stream().filter(e -> str.contains(e.getSurname())).toList();
        show(list);

    }
    // 4.	список профессий и жители с такой профессией
    public void query4(){
        Map<String, List<Resident>> list = readBin().stream()
                .collect(Collectors.groupingBy(Resident::getProfession));
        for (var item : list.entrySet()){
            System.out.printf("\033[32m%s\033[0m\n", item.getKey());
            for (var item2 : item.getValue()){
                System.out.printf("\t\t%s %s\n", item2.getSurname(), item2.getFirstName());
            }
        }
    }
    // 5.	список городов по убыванию количества проживающих в них людей
    public void query5(){
        Map<String, List<Resident>> list = readBin().stream()
                .collect(Collectors.groupingBy(Resident::getCity));
        list.entrySet().stream()
                .sorted(Comparator.comparingInt(a -> a.getValue().size()))
                .forEach(e -> System.out.printf("%s %d\n", e.getKey(), e.getValue().size()));
    }
    // 6.	статистика по профессиям – количество жителей с заданной профессией,
    //      минимальный оклад, средний оклад, максимальный оклад, сумма окладов
    public void query6(){
        Map<String, List<Resident>> list = readBin().stream()
                .collect(Collectors.groupingBy(Resident::getProfession));
        for (var item : list.entrySet()){
            System.out.printf("\t\t\033[32m%s\033[0m\n", item.getKey());
            System.out.printf("Количество жителей с этой профессией: %d\nМинимальный оклад: %d\nМаксимальный оклад: %d\nСредний оклад: %.3f\nСумма окладов: %.3f\n",
                    item.getValue().size(),
                    item.getValue().stream().min(Comparator.comparing(Resident::getSalary)).get().getSalary(),
                    item.getValue().stream().max(Comparator.comparing(Resident::getSalary)).get().getSalary(),
                    item.getValue().stream().mapToDouble(Resident::getSalary).average().getAsDouble(),
                    item.getValue().stream().mapToDouble(Resident::getSalary).summaryStatistics().getSum()
            );
        }
    }
}
