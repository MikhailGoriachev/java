package homework7.models;

import java.io.Serializable;
import java.security.InvalidParameterException;

public class Resident implements Serializable {
    String surname;
    String firstName;
    int age;
    String city;
    String profession;
    int salary;        // оклад

    public String getSurname() { return surname; }
    public void setSurname(String surname) {
        if (surname.isEmpty()){
            throw new InvalidParameterException("\033[32mНе указана фамилия\033[0m");
        }
        this.surname = surname;
    }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) {
        if (firstName.isEmpty()){
            throw new InvalidParameterException("\033[32mНе указано имя\033[0m");
        }
        this.firstName = firstName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if (age < 0) throw new InvalidParameterException("Неверный возраст");
        this.age = age;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        if (city.isEmpty()) throw new NullPointerException("Не указан город");
        this.city = city;
    }

    public String getProfession() {
        return profession;
    }

    public void setProfession(String profession) {
        if (profession.isEmpty()) throw new NullPointerException("Не указана профессия");
        this.profession = profession;
    }

    public int getSalary() { return salary; }
    public void setSalary(int salary) {
        this.salary = salary;
    }

    public Resident(String surname, String firstName, int age, String city, String profession, int salary) {
        this.setSurname(surname);
        this.setFirstName(firstName);
        this.setAge(age);
        this.setCity(city);
        this.setProfession(profession);
        this.setSalary(salary);
    }

    @Override
    public String toString() {
        return String.format(
                "| %-15s | %-10s | %8d | %-10s | %-15s | %5d |",
                surname, firstName, age, city, profession, salary);
    }
}
