package homework7;

import javax.swing.*;

public class Menu {
    public static int showMenu(){
        return  JOptionPane.showOptionDialog(
                null, "Меню", "Меню",
                JOptionPane.YES_NO_CANCEL_OPTION, 1, null,
                new Object[] {"задача 1", "", "", "выход"},
                "задача 1");
    }
    public static int showMenu1(){
        return  JOptionPane.showOptionDialog(
                null, "Меню задача 1", "Меню задача 1",
                JOptionPane.YES_NO_CANCEL_OPTION, 1, null,
                new Object[] {"Коллекция", "1", "2", "3", "4", "5", "6","Основное меню"},
                "Коллекция");
    }
}
