package homework7.controller;
import java.io.File;
import java.io.IOException;
import java.util.*;
public class Task2Controller {
    String fileName = "Data/text.txt";
    //List<String> list = new ArrayList<>();
    List<String> list = new ArrayList<>();

    public Task2Controller() {
        readFileTxt();
    }

    public void task(){
        System.out.println("\n\033[32mТекст из файла\033[0m");
        list.forEach(System.out::println);
        deleteDoubleSpace();
        System.out.println("\n\033[32mмежду словами по одному пробелу\033[0m");
        list.forEach(System.out::println);
        statistics();
    }
    public void readFileTxt(){
        try (Scanner sc = new Scanner(new File(fileName))){
            while(sc.hasNext()) {
                list.add(sc.nextLine());
            } ;
        }catch (IOException ex){
            ex.printStackTrace();
        }
    }
    // •	Преобразовать файл, оставив между словами по одному пробелу
    public void deleteDoubleSpace(){

    }
    // •	Для всех слов, из которых состоит текст определить: количество
    // слов, суммарное количество  букв в словах, минимальная длина слова,
    // максимальная длина слова, средняя длина слова
    public void statistics(){
        System.out.printf("количество слов: %d\n", list.size());
        int countChar = 0;
        for (var item : list){
            countChar += item.length();
        }
        System.out.printf("суммарное количество  букв в словах: %d\n", countChar);

        int min = list.stream().map(String::length).min(Integer::compareTo).get();
        System.out.printf("минимальная длина слова: %d\n", min);

        int max = list.stream().map(String::length).max(Integer::compareTo).get();
        System.out.printf("максимальная длина слова: %d\n", max);

    }

}
