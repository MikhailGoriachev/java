package org.step.home_work.models.gadgets;

import jakarta.servlet.http.HttpServletRequest;

import java.util.*;

public class GadgetsContainer {

    //Коллекция гаджетов
    public List<Gadget> gadgets;

    //Id последнего добавленного элемента
    public static int lastId;

    //Default генерация
    public GadgetsContainer() {
        this(new ArrayList<>(List.of(
                        new Gadget(),
                        new Gadget(),
                        new Gadget(),
                        new Gadget(),
                        new Gadget(),
                        new Gadget() ))
        );
    }

    public GadgetsContainer(List<Gadget> gadgets) {
        this.gadgets = gadgets;
    }


    //Сортировка по id
    public List<Gadget> sortById(){
        return gadgets.stream().sorted(Comparator.comparing(Gadget::getId)).toList();
    }

    //Сортировка по убыванию цены
    public List<Gadget> sortByPriceDesc(){
        return gadgets.stream().sorted((g1,g2) -> g2.getPrice() - g1.getPrice()).toList();
    }

    //Сортировка по типу
    public List<Gadget> sortByModel(){
        return gadgets.stream().sorted(Comparator.comparing(Gadget::getModel)).toList();
    }

    //Сортировка по операционной системе
    public List<Gadget> sortByOs(){
        return gadgets.stream().sorted(Comparator.comparing(Gadget::getOs)).toList();
    }

    //Сортировка по производителю
    public List<Gadget> sortByProducer(){
        return gadgets.stream().sorted(Comparator.comparing(Gadget::getBrand)).toList();
    }

}
