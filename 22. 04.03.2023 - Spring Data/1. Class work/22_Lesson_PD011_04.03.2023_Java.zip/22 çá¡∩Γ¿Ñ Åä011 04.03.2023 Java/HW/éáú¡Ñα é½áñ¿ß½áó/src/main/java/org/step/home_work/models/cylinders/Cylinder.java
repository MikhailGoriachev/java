package org.step.home_work.models.cylinders;

import org.step.home_work.Infrastructure.Utils;
import org.step.home_work.models.MaterialsEnum;

public class Cylinder {

    public int id;
    public double radius;
    public double height;
    public String material;

    public Cylinder(double radius, double height, String material) {
        this.id = ++CylindersContainer.lastCylinderId;
        this.radius = radius;
        this.height = height;
        this.material = material;
    }

    public Cylinder() {
        this.id = ++CylindersContainer.lastCylinderId;
        this.radius = 6;
        this.height = 9;
        this.material = Utils.getMaterial();
    }

    //Расчёт объёма
    public double volume(){
        double v = Math.PI * (radius*radius) * height;

        return !Double.isNaN(v) ? v : 0;
    }

    //Расчёт массы
    public double mass(){
        double v = volume();

        //Плотность
        double density = switch (material) {
            case "Copper" -> MaterialsEnum.COOPER.getValue();
            case "Steel" -> MaterialsEnum.STEEL.getValue();
            case "Basalt" -> MaterialsEnum.BASALT.getValue();
            case "Ice" -> MaterialsEnum.ICE.getValue();
            default -> 1;
        };

        double m = v * density;

        return !Double.isNaN(m) ? m : 0;
    }

    //Расчёт площади
    public double square(){
        double s = 2 * Math.PI * radius * (height+radius);

        return !Double.isNaN(s) ? s : 0;
    }

    public int getId() {
        return id;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }
}
