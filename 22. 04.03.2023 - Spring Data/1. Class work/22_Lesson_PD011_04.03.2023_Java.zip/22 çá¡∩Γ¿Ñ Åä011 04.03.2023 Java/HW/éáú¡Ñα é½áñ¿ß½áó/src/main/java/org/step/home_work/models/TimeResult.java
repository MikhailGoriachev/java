package org.step.home_work.models;


public record TimeResult(Long duration,String currentDate, String yearStart) {
}
