package org.step.home_work.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.step.home_work.Infrastructure.Utils;
import org.step.home_work.models.cylinders.Cylinder;
import org.step.home_work.models.cylinders.CylindersContainer;
import org.step.home_work.models.gadgets.Gadget;
import org.step.home_work.models.gadgets.GadgetsContainer;

import java.util.Date;


@Controller
@RequestMapping("gadgets")
public class GadgetsController {

    private static GadgetsContainer gadgetsContainer;

    static {
        gadgetsContainer = new GadgetsContainer();
    }
    @RequestMapping("/")
    public ModelAndView showGadgets(ModelAndView mav, @RequestParam(value = "sort", defaultValue = "default") String sortType){

        mav.setViewName("gadgets");


        String message = "Исходная коллекция";

        //Сортировка коллекции
        switch (sortType) {
            case "id" -> {
                mav.addObject("gadgets",gadgetsContainer.sortById());
                message = "Сортировка по идентификаторам";
            }
            case "os" -> {
                mav.addObject("gadgets",gadgetsContainer.sortByOs());
                message = "Сортировка по операционной системе";
            }
            case "price" -> {
                mav.addObject("gadgets",gadgetsContainer.sortByPriceDesc());
                message = "Сортировка по цене";
            }
            case "model" -> {
                mav.addObject("gadgets",gadgetsContainer.sortByModel());
                message = "Сортировка по типу";
            }
            case "producer" -> {
                mav.addObject("gadgets",gadgetsContainer.sortByProducer());
                message = "Сортировка по производителю";
            }
            default -> {
                mav.addObject("gadgets",gadgetsContainer.gadgets);
            }
        }


        mav.addObject("message",message);

        return mav;
    }

    //Вернуть форму и модель для привязки
    @RequestMapping("/getForm")
    public ModelAndView form(ModelAndView mav){
        mav.setViewName("gadgetForm");
        int listSize = gadgetsContainer.gadgets.size();

        //Задать корректный id
        GadgetsContainer.lastId = listSize > 0 ? gadgetsContainer.gadgets.get(listSize-1).id-1 : -1;

        return new ModelAndView("gadgetForm","gadget",new Gadget());
    }//form


    //Получение значений из формы и добавление цилиндра
    @PostMapping("/addGadget")
    public ModelAndView addGadget(@ModelAttribute("gadget"/*"SpringWeb"*/) Gadget gadget, ModelAndView mav){
        mav.setViewName("gadgets");

        if (gadget == null){
            mav.addObject("message","Добавить цилиндр не удалось!");
            mav.addObject("gadgets",gadgetsContainer.gadgets);

            return mav;
        }

        //Добавить полученный объект в коллекцию
        gadgetsContainer.gadgets.add(gadget);

        mav.addObject("message",String.format("Добавлен гаджет с id %d",gadget.id));
        mav.addObject("gadgets",gadgetsContainer.gadgets);

        //Если задан новый производитель
        if (!Utils.brands.contains(gadget.getBrand()))
            Utils.brands.add(gadget.getBrand());

        //Задана новая модель
        if (!Utils.models.contains(gadget.getModel()))
            Utils.models.add(gadget.getModel());

        //Задана новая ос
        if (!Utils.systems.contains(gadget.getOs()))
            Utils.systems.add(gadget.getOs());

        return mav;
    }//addGadget

    //Удаление
    @RequestMapping("/delete")
    public ModelAndView deleteGadget(ModelAndView mav,@RequestParam(value = "id",defaultValue = "0") Integer delId){

        mav.setViewName("gadgets");

        String message;

        //Если параметр не был задан
        if (delId <= 0){
            message = "Заданный id для удаления некорректен!";
            mav.addObject("message",message);
            mav.addObject("gadgets",gadgetsContainer.gadgets);

            return mav;

        }//if

        gadgetsContainer.gadgets.removeIf(g -> g.id == delId);

        message = String.format("Гаджет с id %d был удалён",delId);
        mav.addObject("message",message);
        mav.addObject("gadgets",gadgetsContainer.gadgets);

        return mav;
    }//deleteGadget


}
