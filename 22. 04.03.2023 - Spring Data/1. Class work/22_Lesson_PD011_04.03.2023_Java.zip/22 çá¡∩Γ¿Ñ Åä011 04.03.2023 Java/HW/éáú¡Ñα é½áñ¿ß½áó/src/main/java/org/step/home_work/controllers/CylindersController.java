package org.step.home_work.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.step.home_work.models.cylinders.Cylinder;
import org.step.home_work.models.cylinders.CylindersContainer;
import org.step.home_work.models.gadgets.Gadget;
import org.step.home_work.models.gadgets.GadgetsContainer;

import java.util.Date;


@Controller
@RequestMapping("cylinders")
public class CylindersController {

    private static CylindersContainer cylindersContainer;

    static {
        cylindersContainer = new CylindersContainer();
    }

    @RequestMapping("/")
    public ModelAndView showCylinders(ModelAndView mav){

        mav.setViewName("cylinders");


        mav.addObject("message","Исходная коллекция цилиндров");
        mav.addObject("cylinders",cylindersContainer.cylinders);

        return mav;
    }//


    //Вернуть форму и модель для привязки
    // @GetMapping("/getForm")
    @RequestMapping ("/getForm")
    public ModelAndView form(){

        //Получить текущий размер
        int listSize = cylindersContainer.cylinders.size();

        //Задать корректный id
        //Вычитаем, или задаём -1, поскольку при передаче модели инкремент происходит 2 раза
        CylindersContainer.lastCylinderId = listSize > 0 ? cylindersContainer.cylinders.get(listSize-1).id-1 : -1;

        return new ModelAndView("cylinderForm","cylinder",new Cylinder());
    }

    //Получение значений из формы и добавление цилиндра
    @PostMapping("/addCylinder")
    public ModelAndView addCylinder(@ModelAttribute(/*"cylinder"*/"SpringWeb") Cylinder cylinder, ModelAndView mav){
        mav.setViewName("cylinders");

        if (cylinder == null){
            mav.addObject("message","Добавить цилиндр не удалось!");
            mav.addObject("cylinders",cylindersContainer.cylinders);

            return mav;
        }

        //Добавить полученный объект в коллекцию
        cylindersContainer.cylinders.add(cylinder);

        mav.addObject("message",String.format("Добавлен цилиндр с id %d",cylinder.id));
        mav.addObject("cylinders",cylindersContainer.cylinders);

        return mav;
    }

    //Удаление
    @RequestMapping("/delete")
    public ModelAndView deleteCylinder(ModelAndView mav, @RequestParam(value = "id", defaultValue = "0") Integer delId){

        mav.setViewName("cylinders");

        String message;

        //Если параметр не был задан
        if (delId <= 0){
            message = "Заданный id для удаления некорректен!";
            mav.addObject("message",message);
            mav.addObject("cylinders",cylindersContainer.cylinders);

            return mav;

        }

        cylindersContainer.cylinders.removeIf(c -> c.id == delId);

        message = String.format("Цилиндр с id %d удалён",delId);

        mav.addObject("message",message);
        mav.addObject("cylinders",cylindersContainer.cylinders);

        return mav;
    }

}
