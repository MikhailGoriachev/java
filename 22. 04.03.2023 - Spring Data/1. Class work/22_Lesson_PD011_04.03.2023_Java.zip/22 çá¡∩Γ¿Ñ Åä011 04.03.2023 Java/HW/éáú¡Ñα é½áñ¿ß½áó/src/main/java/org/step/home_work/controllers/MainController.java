package org.step.home_work.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.step.home_work.models.TimeResult;
import org.step.home_work.models.cylinders.CylindersContainer;
import org.step.home_work.models.gadgets.GadgetsContainer;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Calendar;
import java.util.Date;


@Controller
public class MainController {

    //Главная страница
    @RequestMapping("/")
    public String showIndex(){


        return "index";
    }

    //Главная страница
    @RequestMapping("/about")
    public String showAbout(){


        return "about";
    }

    //Количество дней, прошедших с начала года
    @RequestMapping("/getTime")

    public ModelAndView getTimeDuration(ModelAndView mav){
        mav.setViewName("time-view");

        //Текущая дата
        Date currDate = new Date();

        //Получение первого дня года
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_YEAR,1);
        Date yearStart = calendar.getTime();

        long duration = Duration.between(yearStart.toInstant(),currDate.toInstant()).toDays()+1;
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");

        //Объект для представления
        TimeResult result = new TimeResult(duration,
                sdf.format(currDate),
                sdf.format(yearStart));

        //Получить текущую дату
        mav.addObject("timeResult",result);

        return mav;
    }


}
