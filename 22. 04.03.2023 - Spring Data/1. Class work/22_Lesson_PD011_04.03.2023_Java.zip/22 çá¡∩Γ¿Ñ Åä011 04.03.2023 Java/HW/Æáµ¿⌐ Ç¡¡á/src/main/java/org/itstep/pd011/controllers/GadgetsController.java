package org.itstep.pd011.controllers;

import org.itstep.pd011.models.Gadget;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@RequestMapping("/gadgets")
@Controller
public class GadgetsController {

    private static String sortField = "";
    private static String sortOrder = "";

    //(Гаджеты) просто статическое поле в классе контроллера.
    private static final List<Gadget> gadgets = new ArrayList<>(List.of(
            new Gadget(1,"Наушники", "Apple", 2022, "none", 15000),
            new Gadget(2,"Смартфон", "Apple", 2022, "IOS", 64399),
            new Gadget(3,"Наушники", "Xiaomi", 2020, "none", 3000),
            new Gadget(4,"Смартфон", "Xiaomi", 2020, "Android", 16000),
            new Gadget(5,"Смартфон", "POCO", 2021, "Android", 2200),
            new Gadget(6,"Наушники", "ZET GAMING", 2021, "none", 5500),
            new Gadget(7,"Наушники", "Razer", 2020, "none", 9000),
            new Gadget(8,"Смартфон", "Xiaomi", 2022, "Android", 20000),
            new Gadget(9,"Портативный аккумулятор", "Xiaomi", 2020, "none", 2500),
            new Gadget(10,"Портативный аккумулятор", "Accesstyle", 2019, "none", 1000),
            new Gadget(11,"Смарт-часы", "Apple", 2022, "IOS", 34500),
            new Gadget(12,"Смарт-часы", "Samsung", 2022, "Wear OS", 28000)));

    //Гаджеты – выводить в JSP-страницу с коллекцией сведений о гаджетах (тип, производитель, год выпуска,
    // операционная система, цена). Можно использовать не использовать бин для коллекции, просто статическое
    // поле в классе контроллера. Иниицилизация коллекции – также в классе контроллера. По ссылкам на JSP-странице
    // требуется упорядочивать коллекцию гаджетов:

    // вывод формы по GET-запросу
    @GetMapping("/add-gadget")
    public ModelAndView showForm(){
        return new ModelAndView("gadgets-form-view", "gadget" ,new Gadget());
    }

    // обработчик формы по post-запросу
    @PostMapping("/addGadget")
    public String addGadget(@ModelAttribute("SpringWeb") Gadget g, Model model){

        int max = gadgets.stream().max(Comparator.comparingInt(Gadget::getId)).stream().findFirst().get().getId();

        g.setId(++max);
        gadgets.add(g);

        model.addAttribute("gadgets", gadgets);
        return "gadgets-view";
    }

    //удаление
    @GetMapping("/delete")
    public String deleteGadget(@RequestParam(value = "id") int id, Model model){

        List<Gadget> list = gadgets.stream().filter(x->x.getId() == id).toList();

        if(list.size() != 0) {
        gadgets.remove(list.get(0));
        }

        model.addAttribute("gadgets", gadgets);
        return "gadgets-view";
    }

    //Исходная коллекция
    @GetMapping("/")
    public ModelAndView showGadgets(@RequestParam(value = "sortField", defaultValue = "id") String sortField,
                                    @RequestParam(value = "sortOrder", defaultValue = "asc") String sortOrder,
                                    ModelAndView mav) {

        mav.setViewName("gadgets-view");

        // если сортировка по последнему сортированному полю, то сменить порядок
        GadgetsController.sortOrder = GadgetsController.sortField.equals(sortField)
                ? toggleSortOrder(sortOrder)
                : sortOrder;

        GadgetsController.sortField = sortField;

        Comparator<Gadget> comparator = switch (sortField) {
            case "id" -> Comparator.comparing(Gadget::getId);
            case "type" -> Comparator.comparing(Gadget::getType);
            case "maker" -> Comparator.comparing(Gadget::getMaker);
            case "year" -> Comparator.comparingInt(Gadget::getYear);
            case "os" -> Comparator.comparing(Gadget::getOperatingSystem);
            default -> Comparator.comparingInt(Gadget::getPrice);
        };

        if (GadgetsController.sortOrder.equals("desc")) {
            comparator = comparator.reversed();
        }

        mav.addObject("gadgets", gadgets.stream().sorted(comparator).toList());
        mav.addObject("sortField", GadgetsController.sortField);
        mav.addObject("sortOrder", GadgetsController.sortOrder);
        return mav;
    }

    private String toggleSortOrder(String order) {
        return order.equalsIgnoreCase("asc") ? "desc" : "asc";
    }

    @GetMapping("/gadgets-order-by-price")
    public ModelAndView showGadgetsOrderByPrice(ModelAndView mav) {
        mav.setViewName("gadgets-view");

        mav.addObject("gadgets", gadgets.stream().sorted((x1, x2) -> x2.getPrice() - x1.getPrice()).toList());
        return mav;
    }

    //По типу
    @GetMapping("/gadgets-order-by-type")
    public ModelAndView showGadgetsOrderByType(ModelAndView mav) {
        mav.setViewName("gadgets-view");

        mav.addObject("gadgets", gadgets.stream().sorted(Comparator.comparing(Gadget::getType)).toList());
        return mav;
    }

    //По производителю
    @GetMapping("/gadgets-order-by-maker")
    public ModelAndView showGadgetsOrderByMaker(ModelAndView mav) {
        mav.setViewName("gadgets-view");

        mav.addObject("gadgets", gadgets.stream().sorted(Comparator.comparing(Gadget::getMaker)).toList());
        return mav;
    }

    //По идентификаторам
    @GetMapping("/gadgets-order-by-id")
    public ModelAndView showGadgetsOrderById(ModelAndView mav) {
        mav.setViewName("gadgets-view");

        mav.addObject("gadgets", gadgets.stream().sorted(Comparator.comparing(Gadget::getId)).toList());
        return mav;
    }
}
