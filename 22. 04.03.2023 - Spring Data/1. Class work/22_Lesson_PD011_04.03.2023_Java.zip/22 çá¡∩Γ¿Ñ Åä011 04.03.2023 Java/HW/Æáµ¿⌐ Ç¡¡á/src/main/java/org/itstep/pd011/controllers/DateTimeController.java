package org.itstep.pd011.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.Year;
import java.util.Date;

@Controller
public class DateTimeController {

    private static final SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

    //Дата и время – текущие дата и время на сервере передаются в JSP-страницу, а количество полных дней,
    // прошедших с начала года (используйте класс Duration)
    @GetMapping("/date-time")
    public ModelAndView showDateTime(ModelAndView mav) {
        mav.setViewName("date-time-view");

        //текущие дата и время
        mav.addObject("date", format.format(new Date()));

        //количество полных дней, прошедших с начала года
        Duration duration = Duration.between(LocalDateTime.of(Year.now().getValue(), 1, 1, 0, 0, 0)
                , LocalDateTime.now());
        mav.addObject("duration", duration.toDays());

        return mav;
    }
}
