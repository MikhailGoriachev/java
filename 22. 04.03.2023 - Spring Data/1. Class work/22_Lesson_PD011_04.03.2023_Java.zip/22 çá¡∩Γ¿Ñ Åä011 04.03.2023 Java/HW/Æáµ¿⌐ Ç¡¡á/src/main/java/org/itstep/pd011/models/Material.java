package org.itstep.pd011.models;

public enum Material {

    COPPER(8900,"Медь","copper.jpg"),
    STEEL(7800,"Сталь","steel.jpeg"),
    BASALT(2800,"Базальт","basalt.jpg"),
    ICE(900,"Лед","ice.jpg");

    private int p;

    private String title;

    private String image;

    Material(int p, String title, String image) {
        this.p = p;
        this.title = title;
        this.image = image;
    }

    public int getP() {
        return p;
    }

    public String getTitle() {
        return title;
    }

    public String getImage() {
        return image;
    }

    @Override
    public String toString() {
        return  title;
    }
}
