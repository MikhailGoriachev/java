package org.itstep.pd011.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {

    // вывод главной страницы
    @RequestMapping("/")
    public String showIndex() {
        return "index";
    }

    // отображение страницы сведений о разработчике
    @GetMapping(value = "/about")
    public String about(Model model) {
        return "about-view";
    } // about

}
