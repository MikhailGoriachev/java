package org.itstep.pd011.models;

/*(тип, производитель, год выпуска, операционная система, цена).*/

public class Gadget {

    private int id;
    private String type;
    private String maker;
    private int year;
    private String operatingSystem;
    private int price;

    public Gadget() {
    }

    public Gadget(int id, String type, String maker, int year, String operatingSystem, int price) {
        this.id = id;
        this.type = type;
        this.maker = maker;
        this.year = year;
        this.operatingSystem = operatingSystem;
        this.price = price;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setMaker(String maker) {
        this.maker = maker;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void setOperatingSystem(String operatingSystem) {
        this.operatingSystem = operatingSystem;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public String getType() {
        return type;
    }

    public String getMaker() {
        return maker;
    }

    public int getYear() {
        return year;
    }

    public String getOperatingSystem() {
        return operatingSystem;
    }

    public int getPrice() {
        return price;
    }

}
