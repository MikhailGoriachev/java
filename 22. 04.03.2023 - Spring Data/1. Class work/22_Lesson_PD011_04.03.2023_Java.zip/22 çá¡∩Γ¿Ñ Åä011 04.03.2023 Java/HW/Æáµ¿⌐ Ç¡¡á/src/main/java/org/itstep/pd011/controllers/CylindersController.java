package org.itstep.pd011.controllers;

import org.itstep.pd011.models.Cylinder;
import org.itstep.pd011.models.Gadget;
import org.itstep.pd011.models.Material;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@RequestMapping("/cylinders")
@Controller
public class CylindersController {

    private static final List<Cylinder> cylinders = new ArrayList<>(List.of(
            new Cylinder(Material.COPPER,1),
            new Cylinder(Material.STEEL,2),
            new Cylinder(Material.BASALT,3),
            new Cylinder(Material.ICE,4)
    ));

    //Цилиндры – по запросу формировать коллекцию цилиндров равного размера, но из разных материалов (медь, сталь,
    // базальт, водяной лед) вычислить площадь поверхности, объем, массу. Вывести исходные данные, изображение материала
    //и результаты расчета в JSP-страницу.
    @GetMapping("/")
    public ModelAndView showCylinders(ModelAndView mav) {
        mav.setViewName("cylinders-view");

        mav.addObject("cylinders", cylinders);

        return mav;
    }

    // вывод формы по GET-запросу
    @GetMapping("/add-cylinder")
    public ModelAndView showForm(ModelAndView mav){
        mav.setViewName("cylinders-form-view");

        mav.addObject("cylinder", new Cylinder());
        mav.addObject("materials", Material.values());

        return mav;
    }

    // обработчик формы по post-запросу
    @PostMapping("/addCylinder")
    public String addCylinder(@ModelAttribute("SpringWeb") Cylinder c, Model model){

        int max = cylinders.stream().max(Comparator.comparingInt(Cylinder::getId)).stream().findFirst().get().getId();

        c.setId(++max);
        cylinders.add(c);

        model.addAttribute("cylinders", cylinders);
        return "cylinders-view";
    }

    //При помощи передачи параметра в GET-запросе реализуйте удаление цилиндра.
    @GetMapping("/delete")
    public String deleteGadget(@RequestParam(value = "id") int id, Model model){

        cylinders.removeIf(c -> c.getId() == id);
        // List<Cylinder> list = cylinders.stream().filter(x->x.getId() == id).toList();
        // if(list.size() != 0) {
        //    cylinders.remove(list.get(0));
        // }

        model.addAttribute("cylinders", cylinders);
        return "cylinders-view";
    }
}
