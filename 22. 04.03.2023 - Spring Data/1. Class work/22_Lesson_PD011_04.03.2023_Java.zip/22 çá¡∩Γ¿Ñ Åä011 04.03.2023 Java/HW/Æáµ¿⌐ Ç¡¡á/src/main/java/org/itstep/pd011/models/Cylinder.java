package org.itstep.pd011.models;

public class Cylinder {

    private int id;
    private double r;
    private double h;
    private Material material;

    public Cylinder() {
    }

    public Cylinder(Material material, int id) {
        this(10, 5, material, id);
    }

    public Cylinder(double r, double h, Material material, int id) {
        this.r = r;
        this.h = h;
        this.material = material;
        this.id = id;
    }

    public Material getMaterial() {
        return material;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setR(double r) {
        this.r = r;
    }

    public void setH(double h) {
        this.h = h;
    }

    public void setMaterial(Material material) {
        this.material = material;
    }

    public int getId() {
        return id;
    }

    public double getR() {
        return r;
    }

    public double getH() {
        return h;
    }

    public double area() {
        return 2 * Math.PI * r * h + 2 * Math.PI * r * r;
    }

    public double volume() {
        return Math.PI * r * r * h;
    }

    public double weight() {
        return material.getP() * volume();
    }

}
