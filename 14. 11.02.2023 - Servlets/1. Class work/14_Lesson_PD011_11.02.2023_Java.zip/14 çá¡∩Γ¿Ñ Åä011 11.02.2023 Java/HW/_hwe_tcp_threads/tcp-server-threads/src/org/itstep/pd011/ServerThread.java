package org.itstep.pd011;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

class ServerThread extends Thread {
    private InetAddress address;     // IP адрес клиента

    public ServerThread(Socket socket) {
        address = socket.getInetAddress();
    } // ServerThread

    @Override
    public void run() {
        // цикл получения команд от клиентов
        while(true) {

            try (
                    // прием команды от клиента
                    Scanner reader = new Scanner(socket.getInputStream());

                    // поток для ответов клиенту
                    PrintWriter writer = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()))) {

                // читать строку от сервера целиком
                String inputText = reader.nextLine();

                // читать строку от сервера до первого разделителя
                // String inputText = reader.next();
                System.out.println("\033[1;32m" + inputText + "\033[0m");

                // выход из цикла - по команде shutdown
                if (inputText.equals("shutdown")) {
                    // вывод ответа клиенту в сеть
                    writer.println("завершение работы сервера");
                    writer.flush();
                    break;
                } // if

                if (inputText.equals("quit")) {
                    // вывод ответа клиенту в сеть
                    writer.println("завершение сеанса обмена с клиентом");
                    writer.flush();
                } // if

                // передача данных клиенту
                writer.println("Ответ сервера на запрос \"" + inputText + "\":  Java network is coming...");

                // гарантированная передача буфера
                writer.flush();
            } // try
        } // while
    } // run

} // class ServerThread

