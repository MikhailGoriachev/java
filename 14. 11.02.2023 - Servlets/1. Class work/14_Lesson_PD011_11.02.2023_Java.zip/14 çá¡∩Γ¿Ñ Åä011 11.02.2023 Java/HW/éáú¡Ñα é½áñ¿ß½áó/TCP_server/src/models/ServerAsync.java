package models;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

public class ServerAsync implements Runnable {

    //Ip-адрес клиента
    private InetAddress ipAddress;

    //Поток чтения
    private BufferedReader reader;

    //Поток записи для ответов
    private PrintWriter writer;
    String[] commands;

    public ServerAsync(Socket socket) {
        try {

            //Получатель команд - строковый поток чтения из сети
            reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            //Ответы от серака - поток записи в сеть
            writer = new PrintWriter(socket.getOutputStream());

            //Получить адресс из потока подключения
            ipAddress = socket.getInetAddress();

            commands = new String[]{
                    "time","date","files","solve","sin","udp","quit",
            };

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void run() {


        try {
            String command = "";

            while ((command = reader.readLine()) != null){

                System.out.printf("\nПолучил команду: %s\n",command);

                //Обработка команды, если она == заданной из массива
                executeCommand(command.toLowerCase(Locale.ROOT));

                //при завершении обработки - отослать ответ о готовности
                writer.println("Ready");
                writer.flush();

                /*command = reader.readLine();*/
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        finally {
            disconnect();
        }
    }

    //Обработка команды на сервак
    private void executeCommand(String command){
        SimpleDateFormat sdf;

        switch (command.split(" ")[0]) {
        //Time
        case "time":

            Date time = new Date();
            sdf = new SimpleDateFormat("HH:mm:ss");

            writer.println(String.format("\033[38;5;48m%s\033[0m",sdf.format(time)));
            writer.flush();
        break;

        //Date
            case "date":

            Date date = new Date();
            sdf = new SimpleDateFormat("dd.MM.yyyy");

            writer.println(String.format("\033[38;5;48m%s\033[0m",sdf.format(date)));
            writer.flush();
        break;

        //Files
        case "files":
            writer.println(getFiles("app_data"));
            writer.flush();
        break;

        //Solve abc
            case "solve":
            writer.println(solve(command));
            writer.flush();
            break;

        //Sin a
            case "sin":
            writer.println(sinA(command));
            writer.flush();
        break;

        //UDP
            case "udp":
            writer.println("\033[38;5;118mПередача файла по UDP в разработке!\033[0m");
            writer.flush();
            break;

        //quit
            case "quit":
            writer.println("\033[38;5;214mServer shut down\033[0m");
            writer.flush();

            //Завершение работы
            //System.exit(0);
        break;
            default:
            writer.printf("\033[38;5;16m\033[48;5;1mCommand \"%s\" doesn't exist!\033[0m\n", command);
            writer.flush();
        }
    }//restoreCommand

    //Вычисление sin a
    private String sinA(String command){

        String num = command.replaceAll("[^0-9,\\.\\-]","").replace(',','.');
        double a = Double.parseDouble(num);

        double sin = Math.sin(Math.toRadians(a));

        return Double.isNaN(sin) ? "\033[38;5;9m Ошибка выислений\033[0m" : String.format("\033[38;5;48m%.4f\033[0m",sin);
    }//sinA

    //Решение уравнения
    private String solve(String equation){

        //Очистка от лишних символов и замена "," на "."
        String cleaned = equation.replaceAll("[^0-9,\\.\\-\s]","")
                .replace(',','.')
                .trim();

        String[] coefficients = cleaned.split(" ");


        double[] parsed = new double[3];

        //Получение коэфициентов
        for (int i = 0, j = 0; i < coefficients.length; i++) {

            //Если строка непустая - парсим
            if (!coefficients[i].isBlank())
                parsed[j++] = Double.parseDouble(coefficients[i]);

            else if (j > 3) break;
        }
        double a = parsed[0];
        double b = parsed[1];
        double c = parsed[2];

        //Ошибке в формате числовых коэффициентов
        if (Double.isNaN(a) || Double.isNaN(b) || Double.isNaN(c))
            return "\033[38;5;9mSOLVE: ILLEGAL DATA\033[0m";

        //Вычисления
        double D = b*b-4*a*c;
        double x1;
        double x2;

        StringBuffer sbf = new StringBuffer("\033[38;5;48m");

        if (D>0){
            double sqrtD = Math.sqrt(D);
            x1 = (-b - sqrtD)/(2*a);
            x2 = (-b + sqrtD)/(2*a);
            sbf.append(String.format("x1 = %.4f, x2 = %.4f",x1,x2));
        }
        else if (D == 0){
            x1 = -b / (2*a);
            sbf.append(String.format("x1 = x2 = %.4f",x1));
        }
        else sbf.append("x1 = x2 = none");

        return sbf.append("\033[0m").toString();

    }//solve

    //Получить список файлов
    private StringBuffer getFiles(String directory){

        StringBuffer sbf = new StringBuffer();
        String noFiles = "\033[38;5;9m:: no files found ::\033[0m";

        //Если такого каталога нет
        if (!Files.exists(Paths.get(directory)))
            return sbf.append(noFiles);

        File dir = new File(directory);

        var files = dir.list();

        //Если файлов нет
        if (files == null || files.length == 0 )
            return sbf.append(noFiles);
        else
            Arrays.stream(files).forEach(fn -> sbf.append(String.format(" <%s> ",fn)));

        return sbf;
    }//getFiles

    // отключение сервера
    private void disconnect(){

        try {
            if (writer != null) {
                writer.close();
            }

            if (reader != null) {
                reader.close();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        System.out.printf("\n%s: disconnected",ipAddress.getHostName());

    } // disconnect
}
