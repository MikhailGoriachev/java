import models.ServerAsync;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Main {
    public static void main(String[] args) {

        int port = 7575;
        //Логика работы сервака здесь
        try(ServerSocket serverSocket = new ServerSocket(port)){

            System.out.printf("Server started, port: %d",port);

            //Выход произойдёт, когда будет выбрашено исключение
            while(true){

                //Блокирующий поток метод ожидания запроса от клиента
                Socket socket = serverSocket.accept();

                System.out.printf("\nConnected new client, IP: %s",socket.getInetAddress());

                //Обработка команды аснхронно
                Thread serverProc = new Thread(new ServerAsync(socket));
                serverProc.start();

            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}