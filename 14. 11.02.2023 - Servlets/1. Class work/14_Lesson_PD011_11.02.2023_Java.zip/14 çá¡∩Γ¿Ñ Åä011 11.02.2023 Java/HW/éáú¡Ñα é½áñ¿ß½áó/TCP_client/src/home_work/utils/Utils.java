package home_work.utils;


import javax.swing.*;
import java.util.Random;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class Utils {

    //Генерация значений
    private static Random rand = new Random();

    public Utils() {
    }

    //Получение слуйчаных значений
    public static double getRandom(double lo, double hi) {
        return lo + rand.nextDouble() * (hi - lo);
    }

    public static int getRandom(int lo, int hi) {
        return lo + rand.nextInt(hi - lo);
    }


    // вывод окна с кнопками
    public static int showWindowButtons (String message, String title, Object[] buttons, String initialValue, int windowType) {
        return JOptionPane.showOptionDialog(
                null,
                message,
                title,
                JOptionPane.DEFAULT_OPTION,
                windowType,
                null,
                buttons,
                initialValue
        );
    }

    //Окно с dropdown списком команд
    public static String showDropdownWindow(String message,String title,String selectedValue, String[] listItems){
        return (String) JOptionPane.showInputDialog(
                null,
                message,
                title,
                JOptionPane.DEFAULT_OPTION,
                null,
                listItems, selectedValue);
    }

    private static double lo = -5.;
    private static double hi = 15.;
    //Команда Sin a
    public static String getSinCommand(){
        return String.format("sin %.4f", getRandom(lo,hi));}

    //Команда Solve a b c
    public static String getSolveCommand(){
        return String.format("solve %.4f %.4f %.4f", getRandom(lo,hi),
                getRandom(lo,hi),
                getRandom(lo,hi));}

    //Команды серверу
    public static String[] commands = new String[]{
            "time",
            "date",
            "files",
            "UDP",
            getSinCommand(),
            getSolveCommand(),
            "quit"
    };



}//Utils
