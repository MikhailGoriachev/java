package home_work.interfaces;

public interface ControllerInterface {

    //Запуск выполнения задач
    void start() throws Exception;

}
