package home_work.controllers;



import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;

import home_work.interfaces.ControllerInterface;
import home_work.utils.Utils;

import javax.swing.*;


public class TaskController implements ControllerInterface {

    /*private String[] commands = new String[]{
            "time",
            "date",
            "files",
            String.format("Sin %.4f", Utils.getRandom(-5.,10.)),
            String.format("Solve %.4f %.4f %.4f", Utils.getRandom(-5.,10.),
                    Utils.getRandom(-5.,-10.),
                    Utils.getRandom(-5.,-10.)),
            "quit"
    };*/


    //Запуск  контроллера
    @Override
    public void start() throws Exception {

        System.out.println("Клиент начал работу!");

        int port = 7575;

        //Подключение к локальному серверу
        try(Socket socket = new Socket(InetAddress.getLocalHost(),port);
            //Поток для оптравки команд
            PrintStream ps = new PrintStream(socket.getOutputStream());
            //Чтение ответов
            BufferedReader bfr = new BufferedReader(new InputStreamReader(socket.getInputStream()))
        ){

            String prevCommand = "time";
            String readyResponse = "ready";

            //Вывод окна с выпадающим списком
            while (true){

                String command = Utils.showDropdownWindow ("Выберите команду","Клиент: выбор команды"
                        ,prevCommand,Utils.commands);

                //Топорное ветвление, через switch сделать не получилось
                if (command == null)
                    return;
                //Если выбрали передачу по UP
                else if(command.equalsIgnoreCase("udp")) {
                    String file = choseFile();
                    //Отправить команду по tcp
                    executeCommand(String.format("%s %s",command.toLowerCase(),file),ps,bfr,socket,"ready");

                    sendFile(InetAddress.getLocalHost(), port,file);
                }
                else
                    executeCommand(command,ps,bfr,socket,"ready");

                if (command.equalsIgnoreCase("quit"))
                    return;

                prevCommand = command;

                //Изменение значений в командах
                Utils.commands[4] = Utils.getSinCommand();
                Utils.commands[5] = Utils.getSolveCommand();
            }//while


        }//try()

    }//start


    //Дать комаду серверу
    private void executeCommand (String command, PrintStream ps, BufferedReader reader, Socket socket, String readyResponse) throws Exception {

        String response;

        System.out.printf("\t\nОтправлена команда: %s",command);

        //Отправить команду серверу
        ps.println(command);

        //Вывести ответ от сервера
        response = reader.readLine();
        System.out.printf("\t\nПолучен ответ от сервера: %s\n",response);

        //Ожидание завершения операции
        if (!response.equalsIgnoreCase(readyResponse)) {

            //Если сервер не отвечает в течении 20 сек - бросаем исключение и разрываем соединение
            socket.setSoTimeout(20_000);

            while (!reader.readLine().equalsIgnoreCase(readyResponse)) {}
        }


    }//executeCommand

    //Отправить файл по udp
    private void sendFile(InetAddress ip, int port,String file) throws Exception {

        String path = String.format("app_data/%s",file);

        try (FileInputStream inputStream = new FileInputStream(new File(path))) {
            byte[] data = new byte[1024];

            // UDP
            DatagramSocket datagramSocket = new DatagramSocket();

            DatagramPacket packet;

            while (inputStream.read(data) != -1) {
                packet = new DatagramPacket(data, data.length, ip, port);
                datagramSocket.send(packet);
            }

            System.out.println("\n\tФайл успешно отправлен");
        }

    }

    //Выбрать файл для передачи
    private String choseFile(){
        String directory = "app_data";

        //Если такого каталога нет
        if (!Files.exists(Paths.get(directory)))
            return null;

        File dir = new File(directory);

        var files = dir.list();

        if (files == null || files.length == 0) {
            System.out.printf("\n\tВ пакпке %s нет файлов\n",directory);
            return null;
        }

        String chosenFile =  Utils.showDropdownWindow("Выберите файл","Отпарвка файлов по UDP",files[0],files);

        if (chosenFile == null)
            return null;

        System.out.printf("\n\tВыбранный файл:%s\n",chosenFile);

       return chosenFile;
    }

}
