package home_work;

import home_work.controllers.TaskController;
import home_work.interfaces.ControllerInterface;
import home_work.utils.Utils;

import javax.swing.*;

public class Main {

    public static void main(String[] args){


        try {
            //Контроллеры
            ControllerInterface[] controllers = new ControllerInterface[]{
                    new TaskController()
            };

            //Вызов методов на контроллерах
            while (true) {
                switch (showMenu()) {
                    case 0 -> controllers[0].start();
                    case 1 -> System.exit(0);

                    default -> {
                        return;
                    }
                }
            }
        } catch (Exception e) {
            Utils.showWindowButtons(e.getMessage() + "\n","Ошибка!",new Object[]{"Выход"},"", JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage() + "\n");
            e.printStackTrace();
        }



    }//main

    //Вывод меню
    public static int showMenu(){

        //Задание значений для окна
        String title = "Задание на 11.02.23";
        String message = "<html><h1>Меню</h1>";
        Object[] buttons = new Object[]{
                "Задача 1",
                "Выход"
        };


        return Utils.showWindowButtons(message,title,buttons,"Выход",JOptionPane.DEFAULT_OPTION);
    }
}