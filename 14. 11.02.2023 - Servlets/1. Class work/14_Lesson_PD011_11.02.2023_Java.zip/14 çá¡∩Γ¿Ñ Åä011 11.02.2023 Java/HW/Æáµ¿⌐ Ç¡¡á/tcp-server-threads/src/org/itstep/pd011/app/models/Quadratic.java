package org.itstep.pd011.app.models;

public record Quadratic(
        double a,
        double b,
        double c
) {

    public double x1() {
        return -b+Math.sqrt(discriminant())/(2*a);
    }

    public double x2() {
        return -b-Math.sqrt(discriminant())/(2*a);
    }

    //Поиск дискриминанта
    private double discriminant(){
        return b*b - 4*a*c;
    }

    @Override
    public String toString() {
        return String.format("<table border='1'><thead>"+
                "<tr>"+
                "<th>a</th>"+
                "<th>b</th>"+
                "<th>c</th>"+
                "<th>x1</th>"+
                "<th>x2</th></tr></thead>"+
                "<tbody>"+
                "<tr>"+
                "<td>%.2f</td>"+
                "<td>%.2f</td>"+
                "<td>%.2f</td>"+
                "<td>%.4f</td>"+
                "<td>%.4f</td>"+
                "</tr></tbody></table>", a, b, c, x1(), x2());
    }
}
