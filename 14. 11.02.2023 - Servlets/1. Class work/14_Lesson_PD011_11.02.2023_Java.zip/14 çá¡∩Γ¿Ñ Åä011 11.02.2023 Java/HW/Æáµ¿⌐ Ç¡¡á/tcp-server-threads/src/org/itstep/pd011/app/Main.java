package org.itstep.pd011.app;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import org.itstep.pd011.app.services.ServerThread;
public class Main {
    public static void main(String[] args) {

        try (ServerSocket serverSocket = new ServerSocket(8071)) {
            System.out.println("Server started");

            while (true) {

                // ожидание входящего запроса клиента
                Socket socket = serverSocket.accept();
                System.out.printf("%s connected \n", socket.getInetAddress().getHostName());

                // создание нового потока исполнения для работы с запросом клиента
                ServerThread thread = new ServerThread(socket);
                thread.start();
            } // while
        } catch (IOException e) {
            e.printStackTrace();
        } // try-catch
    }
}