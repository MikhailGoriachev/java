package org.itstep.pd011.app.services;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Arrays;
import java.util.Date;
import java.util.Objects;

import org.itstep.pd011.app.models.Quadratic;

public class ServerThread extends Thread {

    private PrintStream printStream; // send
    private BufferedReader reader;   // receive
    private InetAddress address;     // client address

    final static int WAIT_TIMEOUT = 10_000;

    public ServerThread(Socket socket) {
        // TODO: перенести в run() при помощи try() {}
        try {
            printStream = new PrintStream(socket.getOutputStream());
            reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }  // try-catch

        address = socket.getInetAddress();
    } // ServerThread

    // функционал сервера - в отдельном потоке
    @Override
    public void run() {

        String message;

        try {
            // получение null - признак завершения обмена
            while (!Objects.equals(message = reader.readLine(), "quit")) {

                if(message.contains("sin") | message.contains("solve")){

                    if(message.contains("sin")) {
                        double value = Double.parseDouble(message.split(" ")[1]);
                        printStream.printf("sin %.2f = %.4f%n", value, Math.sin(Math.toRadians(value)));
                    }

                    if(message.contains("solve")) {

                        String[] arr = message.split(" ");

                        double value01 = Double.parseDouble(arr[1]);
                        double value02 = Double.parseDouble(arr[2]);
                        double value03 = Double.parseDouble(arr[3]);

                        printStream.println(new Quadratic(value01,value02,value03));
                    }

                }

                else {
                    switch (message){

                        case "time" -> printStream.println(String.format("Время на сервере: %1$tH:%1$tM:%1$tS", new Date().getTime()));
                        case "date" -> printStream.println(String.format("Дата на сервере: %1$td.%1$tm.%1$tY", new Date()));
                        case "files" ->printStream.println(doFiles());
                        case "udp" -> {
                            acceptFile(new File("app_data/music.mp3"), 8033, 1024);
                            printStream.println("работа с файлом завершена");
                        }
                    }
                }

                System.out.println(message + " from " + address.getHostName());
            } // while
        } catch (IOException e) {
            e.printStackTrace();
        }
        catch (NumberFormatException e){
            printStream.println("ILLEGAL DATA");
        }
        finally {
            disconnect();
        } // try-catch-finally
    } // run


    // отключение сервера
    private void disconnect() {

        try {

            if (printStream != null) {
                printStream.close();
            }

            if (reader != null) {
                reader.close();
            }

            System.out.println(address.getHostName() + " : disconnected");
        } catch (IOException e) {
            e.printStackTrace();
        }
    } // disconnect

    //files – сервер возвращает имена файлов папки app_data приложения, формат ответа сервера: имена файлов,
    // разделенные символом «;». Если файлов в папке нет – возвращаем строку «:: no files found ::»
    private StringBuilder doFiles(){

        StringBuilder sb = new StringBuilder();

        File[] listOfFiles = new File("app_data").listFiles();

        if(listOfFiles != null && listOfFiles.length > 0) {
            Arrays.stream(listOfFiles).forEach((x) -> sb.append(x.getName()).append(";"));
        }
        else {
            sb.append(":: no files found ::");
        }

        return sb;
    }

    // получение файла по UDP
    private static void acceptFile(File file, int port, int pacSize) throws IOException {
        System.out.println("получение данных...");

        byte data[] = new byte[pacSize];
        // построить пакет UDP, в качестве блока данных будет использоваться массив data
        // (пакет использует ссылку на массив)
        DatagramPacket packet = new DatagramPacket(data, data.length);

        try (FileOutputStream outputStream = new FileOutputStream(file)) {
            // сокет для получения информации
            DatagramSocket datagramSocket = new DatagramSocket(port);
            datagramSocket.setSoTimeout(WAIT_TIMEOUT);

            while (true) {
                datagramSocket.receive(packet);  // читаем пакет из сети
                outputStream.write(data);        // записать данные пакета в файл

                outputStream.flush();
            } // while

        }

    } // acceptFile

}
