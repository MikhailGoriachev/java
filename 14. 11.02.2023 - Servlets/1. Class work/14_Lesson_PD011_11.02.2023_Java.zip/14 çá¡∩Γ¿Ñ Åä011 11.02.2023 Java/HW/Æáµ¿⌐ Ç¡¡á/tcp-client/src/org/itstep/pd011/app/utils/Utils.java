package org.itstep.pd011.app.utils;

import javax.swing.*;
import java.util.Random;

public class Utils {

    // случайное целочисленное число
    public static int getInt(int min, int max) {
        return new Random().nextInt(min, max);
    }

    // случайное вещественное число
    public static double getDouble(double min, double max) {
        return min + (max - min) * new Random().nextDouble();
    }

    // вывод сообщения об ошибке
    public static void showErrorMessage(String message, String title) {
        JOptionPane.showMessageDialog(null, message, title, JOptionPane.ERROR_MESSAGE);
    }


    public static String getDouble(double start_value){
        return JOptionPane.showInputDialog(null, "Введите вещественное число (целое.дробное)", start_value);
    }

    public static String getInt(int start_value){
        return  JOptionPane.showInputDialog(null, "Введите целое число", start_value);
    }

    public static String getString(String start_value){
        return  JOptionPane.showInputDialog(null, "Введите строку", start_value);
    }

    // вывод данных в окно
    public static void showMessage(String message, String title) {
        JOptionPane.showOptionDialog(
                null,
                message,
                title,
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(),
                new Object[]{"Далее"},
                "Далее"
        );
    }


}
