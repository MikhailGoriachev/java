package org.itstep.pd011.app;

import javax.swing.*;
import java.io.*;
import java.net.*;

import org.itstep.pd011.app.utils.Utils;
public class Main {
    final static int TIMEOUT_IN_MILLIS = 1_000;
    final static int port = 8071;

    public static void main(String[] args) {

        // Еще один подход для работы с сервером - одно подключение с паузой
        // для готовности сервера
        // InetAddress.getLocalHost() - имеется в виду IP сервера
        try (Socket socket = new Socket(InetAddress.getLocalHost(), port);
             PrintStream printStream = new PrintStream(socket.getOutputStream());
             BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            while (true) {

                String msg = showMenu();
                switch (msg) {

                    case "time" -> printStream.println("time");
                    case "date" -> printStream.println("date");
                    case "files" -> printStream.println("files");
                    case "quit" -> printStream.println("quit");
                    case "sin a" -> {
                        String value = Utils.getDouble(45);
                        if(value == null) continue;
                        printStream.println("sin " + value);
                    }

                    case "solve a b c" -> {
                        String value01 = Utils.getDouble(2);
                        if(value01 == null) continue;

                        String value02 = Utils.getDouble(3);
                        if(value02 == null) continue;

                        String value03 = Utils.getDouble(1);
                        if(value03 == null) continue;

                        printStream.printf("solve %s %s %s%n",value01,value02,value03);
                    }

                    case "udp" -> {
                        printStream.println("udp");
                        udpTransmission();
                    }

                    // выход
                    default -> {
                        printStream.println("quit");
                        return;
                    }
                }

                // чтение ответа от сервера
                if(!msg.equals("quit")){
                Utils.showMessage("<html>"+reader.readLine(),"Ответ сервера");
                }

                // тайм-аут для сервера - чтобы сервер был готов к следующей команде
                Thread.sleep(TIMEOUT_IN_MILLIS);
            }

        } catch (UnknownHostException e) {
            System.err.println("Connection refused:" + e); // not connect to the server
        } catch (InterruptedException e) {   // InterruptedException - Thread.sleep()
            e.printStackTrace();
        } // try-catch
        catch (IOException e) {   // InterruptedException - Thread.sleep()
            Utils.showErrorMessage("<html><h3 style = 'color:red' >Ошибка сервера! Вероятно соединение было разорвано.</h3>","Ошибка");
        } // try-catch

    }

    public static String showMenu(){
        return (String) JOptionPane.showInputDialog(
                null,
                "Выберите команду",
                "Команды доступные на сервере",
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(),
                new Object[] {"time","date","quit", "files", "sin a", "solve a b c", "udp" ,"Выход"},
                "Выход"
        );
    }

    public static void udpTransmission() throws IOException {
        String fileName = "app_data/file.mp3";

        try (FileInputStream inputStream = new FileInputStream(new File(fileName))) {
            byte[] data = new byte[1024];

            // UDP - работа с датаграммами
            DatagramSocket datagramSocket = new DatagramSocket();

            // адрес и порт получателя
            InetAddress address = InetAddress.getLocalHost();
            int port = 8033;

            DatagramPacket packet;

            System.out.println("отправка файла...");
            while (inputStream.read(data) != -1) {                             // data reading...
                packet = new DatagramPacket(data, data.length, address, port); // packet making...
                datagramSocket.send(packet);                                   // data sending
            }

            System.out.println("файл успешно отправлен");
        }
    }
}