package org.itstep.pd011;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MainController {
    // вывод главной страницы
    @RequestMapping("/")
    public String showIndex() { return "index"; }

    //Времена года – названия времен года и входящих в них
    // месяцев. Должен быть переход на главную страницу
    @RequestMapping("/seasons")
    public String showSeasons() { return "seasons-view"; }

    //Дни недели – таблица с названиями дней недели на
    // русском, английском и немецком языках. Должен быть
    // переход на главную страницу
    @RequestMapping("/days-of-week")
    public String showDaysOfWeek() { return "days-of-week-view"; }

    //Океаны – названия океанов планеты Земля.
    // Должен быть переход на главную страницу
    @RequestMapping("/oceans")
    public String showOceans() { return "oceans-view"; }
}
