package org.itstep.pd011;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/*
* Разработайте Spring MVC приложение с единственным контроллером и набором
* методов действий. Данные в представления передавать не надо, стилизовать
* представления также не требуется. Методы должны вызывать следующие
* представления:
*     • Главная страница – запросы методов действия для переходов на остальные
*       страницы
*     • Времена года – названия времен года и входящих в них месяцев. Должен
*       быть переход на главную страницу
*     • Дни недели – таблица с названиями дней недели на русском, английском
*       и немецком языках. Должен быть переход на главную страницу
*     • Океаны – названия океанов планеты Земля. Должен быть переход на главную
*       страницу
* */
@Controller
public class HomeController {

    // метод действия для вывода главной страницы
    @RequestMapping("/")
    public String index() { return "index";}

    // метод действия для вывода
    @RequestMapping("/seasons")
    public String seasons() { return "seasons-views"; }

    // метод действия для вывода
    @RequestMapping("/days")
    public String days() { return "days-view"; }

    // метод действия
    @RequestMapping("/oceans")
    public String oceans() { return "oceans-view"; }
} // class HomeController
