package org.step.home_work;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MainController {

    //Главная страница
    @RequestMapping("/")
    public String showIndex(){
        return "index";
    }
    @RequestMapping("/seasons")
    public String showSeasons(){
        return "seasons";
    }

    @RequestMapping("/days")
    public String showDays(){
        return "days";
    }

    @RequestMapping("/oceans")
    public String showOceans(){
        return "oceans";
    }

}
