package org.itstep.pd011.maslennikov.hw19.routes;

public class Routes {
    public static final String HOST = "http://localhost:8010";


    public static final String HOME = "/homework_war";
    public static final String DAYS = "/days";
    public static final String SEASONS = "/seasons";
    public static final String OCEANS = "/oceans";
}
