package org.itstep.pd011.maslennikov.hw19;

import org.itstep.pd011.maslennikov.hw19.routes.Routes;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {

    @RequestMapping("/")
    public String showIndex() {
        return "index";
    }

    @RequestMapping(Routes.SEASONS)
    public String showSeasons() {
        return "seasons";
    }

    @RequestMapping(Routes.DAYS)
    public String showDaysOfWeek() {
        return "daysOfWeek";
    }

    @RequestMapping(Routes.OCEANS)
    public String showOceans() {
        return "oceans";
    }

}
