package app.controllers;

import app.interfaces.IController;
import app.models.task01.*;
import app.utils.Utils;

import javax.swing.*;


// Контроллер Задание 1
public class Task01Controller implements IController {

    // поликлиника
    PolyclinicDb polyclinic = PolyclinicDb.getInstance();

    public Task01Controller() throws Exception {}

    // работа по заданию
    public void run() {
        var buttons = new Object[]{
                "Данные",
                "Запросы",
                "Выход"
        };

        var initialValue = "Выход";
        var imageIcon = new ImageIcon();
        var title = "Задание 1. Поликлиника";

        IController[] commands = new IController[]{
                // данные
                this::dataMenu,
                
                // запросы
                () -> Utils.showWindow("<html><h2>В разработке!</h2>",
                        title, new Object[]{"Назад"}, initialValue, imageIcon),
        };

        int select;
        while (true) {
            try {
                select = Utils.showWindow("<html><h1 align='center'>Задание 1. Поликлиника</h1>", title, buttons, initialValue, imageIcon);

                if (select >= commands.length || select == -1)
                    return;

                commands[select].run();
            } catch (Exception exception) {
                Utils.showErrorMessage(exception.getMessage(), "Ошибка...");
            }
        }
    }

    // меню данных
    public void dataMenu() {
        var buttons = new Object[]{
                "Приёмы",
                "Врачи",
                "Пациенты",
                "Персоны",
                "Специальности",
                "Выход"
        };

        var initialValue = "Выход";
        var imageIcon = new ImageIcon();
        var title = "Задание 1. Поликлиника > Данные";

        IController[] commands = new IController[]{

                // приёмы
                () -> Utils.showWindow(polyclinic.appointmentsToTable(polyclinic.appointments(), "Приёмы"),
                        title + " > Приёмы", new Object[]{"Назад"}, initialValue, imageIcon),

                // врачи
                () -> Utils.showWindow(polyclinic.doctorsToTable(polyclinic.doctors(), "Врачи"),
                        title + " > Врачи", new Object[]{"Назад"}, initialValue, imageIcon),

                // пациенты
                () -> Utils.showWindow(polyclinic.patientsToTable(polyclinic.patients(), "Пациенты"),
                        title + " > Пациенты", new Object[]{"Назад"}, initialValue, imageIcon),

                // персоны
                () -> Utils.showWindow(polyclinic.peopleToTable(polyclinic.people(), "Персоны"),
                        title + " > Персоны", new Object[]{"Назад"}, initialValue, imageIcon),

                // специальности
                () -> Utils.showWindow(polyclinic.specialitiesToTable(polyclinic.specialities(), "Специальности"),
                        title + " > Специальности", new Object[]{"Назад"}, initialValue, imageIcon),
        };

        int select;
        while (true) {
            try {
                select = Utils.showWindow("<html><h1 align='center'>Задание 1. Поликлиника</h1>", title, buttons, initialValue, imageIcon);

                if (select >= commands.length || select == -1)
                    return;

                commands[select].run();
            } catch (Exception exception) {
                Utils.showErrorMessage(exception.getMessage(), "Ошибка...");
            }
        }
    }

//    // запросы
//    public void run() {
//        var buttons = new Object[]{
//                "Жители",
//                "<html>Запрос 1",
//                "<html>Запрос 2",
//                "<html>Запрос 3",
//                "<html>Запрос 4",
//                "<html>Запрос 5",
//                "<html>Запрос 6",
//                "<html>Запрос 7",
//                "Выход"
//        };
//
//        var initialValue = "Выход";
//        var imageIcon = new ImageIcon();
//        var title = "Задание 1. Поликлиника";
//
//        IController[] commands = new IController[]{
//
//                // все жители
//                () -> Utils.showWindow("<html><h2 align='center'>Жители</h2>" +
//                                PeopleList.peopleToTable(peopleList.personList),
//                        title, new Object[]{"Назад"}, initialValue, imageIcon),
//
//                // 1. статистика по городам – название городов, количество жителей из этих городов в коллекции, средний возраст,
//                // минимальный возраст, максимальный возраст жителя
//                () -> Utils.showWindow(
//                        "<html><h2 align='center'>Статистики по городам и возрасту</h2>" +
//                                PeopleList.point01ToTable(peopleList.point01()),
//                        title, new Object[]{"Назад"}, initialValue, imageIcon),
//
//                // 2. жители с заданной профессией, фамилия которых начинается с заданной строки 
//                () -> {
//                    var person = Utils.getItem(peopleList.personList);
//                    var profession = person.profession();
//                    var startWith = person.surname().substring(0, 2);
//
//                    Utils.showWindow(
//                            "<html><h2 align='center'>Жители с заданными данными: профессия - \"" +
//                                    person.profession() + "\"; фамилия начинается с — " + startWith + "\"</h2>" +
//                                    PeopleList.peopleToTable(peopleList.point02(profession, startWith)),
//                            title, new Object[]{"Назад"}, initialValue, imageIcon);
//                },
//
//                // 3. жители с заданной профессией, фамилия которых начинается с заданной строки 
//                () -> Utils.showWindow(
//                        "<html><h2 align='center'>Список жителей по фамилиям</h2>" +
//                                PeopleList.point03ToTable(peopleList.point03()),
//                        title, new Object[]{"Назад"}, initialValue, imageIcon),
//
//                // 4. список профессий и жители с такой профессией 
//                () -> Utils.showWindow(
//                        "<html><h2 align='center'>Список жителей по профессиям</h2>" +
//                                PeopleList.point04ToTable(peopleList.point04()),
//                        title, new Object[]{"Назад"}, initialValue, imageIcon),
//
//                // 5. список городов по убыванию количества проживающих в них людей 
//                () -> Utils.showWindow(
//                        "<html><h2 align='center'>Список городов по убыванию людей</h2>" +
//                                PeopleList.point05ToTable(peopleList.point05()),
//                        title, new Object[]{"Назад"}, initialValue, imageIcon),
//
//                // 6. статистика по профессиям – количество жителей с заданной профессией, минимальный оклад, средний оклад,
//                // максимальный оклад, сумма окладов 
//                () -> Utils.showWindow(
//                        "<html><h2 align='center'>Статистика по профессиям</h2>" +
//                                PeopleList.point06ToTable(peopleList.point06()),
//                        title, new Object[]{"Назад"}, initialValue, imageIcon),
//
//                // 7. среднее количество жителей города и города с количеством жителей ниже среднего
//                () -> Utils.showWindow(
//                        "<html><h2 align='center'>Города со средним количеством жителей ниже среднего: " +
//                                String.format("%.2f", peopleList.avgAmountPeople()) +
//                                "</h2>" +
//                                PeopleList.point07ToTable(peopleList.point07()),
//                        title, new Object[]{"Назад"}, initialValue, imageIcon),
//        };
//
//        int select;
//        while (true) {
//            try {
//                select = Utils.showWindow("<html><h1 align='center'>Задание 1. Поликлиника</h1>", title, buttons, initialValue, imageIcon);
//
//                if (select >= commands.length || select == -1)
//                    return;
//
//                commands[select].run();
//            } catch (Exception exception) {
//                Utils.showErrorMessage(exception.getMessage(), "Ошибка...");
//            }
//        }
//    }
}
