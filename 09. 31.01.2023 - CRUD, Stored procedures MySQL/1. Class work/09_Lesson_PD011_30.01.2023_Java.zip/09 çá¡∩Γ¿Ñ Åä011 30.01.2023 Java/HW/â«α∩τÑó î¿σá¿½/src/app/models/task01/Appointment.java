package app.models.task01;

// Класс Приём
public record Appointment(
        int id,
        String appointmentDate,
        String doctorSurname,
        String doctorName,
        String doctorPatronymic,
        String specialityName,
        int price,
        int percent,
        String patientSurname,
        String patientName,
        String patientPatronymic,
        String bornDate,
        String address,
        String passport) {

    // вывод персоны в строку таблицы
    public String toTableRow() {
        return String.format(
                "<tr>" +
                        "<th>%d</th>" +
                        "<td>%s</td>" +
                        "<td>%s</td>" +
                        "<td>%s</td>" +
                        "<td>%s</td>" +
                        "<td>%s</td>" +
                        "<td align='right'>%d</td>" +
                        "<td align='right'>%d</td>" +
                        "<td>%s</td>" +
                        "<td>%s</td>" +
                        "<td>%s</td>" +
                        "<td>%s</td>" +
                        "<td>%s</td>" +
                "</tr>",
                id,
                appointmentDate,
                doctorSurname,
                doctorName,
                doctorPatronymic,
                specialityName,
                price,
                percent,
                patientSurname,
                patientName,
                patientPatronymic,
                bornDate,
                passport
        );
    }
}
