package app.models.task01;

public record Patient(
        int id,
        String surname,
        String name,
        String patronymic,
        String bornDate,
        String address,
        String passport) {

    // вывод персоны в строку таблицы
    public String toTableRow() {
        return String.format(
                "<tr>" +
                        "<th>%d</th>" +
                        "<td>%s</td>" +
                        "<td>%s</td>" +
                        "<td>%s</td>" +
                        "<td>%s</td>" +
                        "<td>%s</td>" +
                        "<td>%s</td>" +
                        "</tr>",
                id,
                surname,
                name,
                patronymic,
                bornDate,
                address,
                passport
        );
    }
}
