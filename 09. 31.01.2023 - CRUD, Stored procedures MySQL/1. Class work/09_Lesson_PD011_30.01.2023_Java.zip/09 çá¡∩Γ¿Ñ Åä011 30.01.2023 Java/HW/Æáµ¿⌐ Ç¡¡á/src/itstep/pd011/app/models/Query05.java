package itstep.pd011.app.models;

public class Query05 {

    private String doctor;
    private String specialtie; //Специальность врача
    private int price; //Стоимость приема
    private double salary; //Зарплата

    public Query05(String doctor,String specialtie, int price, double salary) {
        this.doctor = doctor;
        this.specialtie = specialtie;
        this.price = price;
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "<tr>" +
                "<td>"+doctor+"</td>"+
                "<td>"+specialtie+"</td>"+
                "<td>"+price+"</td>"+
                "<td>"+String.format("%.2f",salary)+"</td>"+
                "</tr>";
    }
}
