package itstep.pd011.app.models;

public class Query06 {

    private String date;
    private int max;

    public Query06(String date, int max) {
        this.date = date;
        this.max = max;
    }

    @Override
    public String toString() {
        return "<tr>" +
                "<td>"+date+"</td>"+
                "<td>"+max+"</td>"+
                "</tr>";
    }
}
