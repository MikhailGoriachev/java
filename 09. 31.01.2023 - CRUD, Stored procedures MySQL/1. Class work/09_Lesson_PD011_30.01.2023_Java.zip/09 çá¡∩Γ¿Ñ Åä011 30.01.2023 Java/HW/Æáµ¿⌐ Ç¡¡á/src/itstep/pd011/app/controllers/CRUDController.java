package itstep.pd011.app.controllers;

import itstep.pd011.app.handlers.DbHandler;
import itstep.pd011.app.utils.Utils;
import itstep.pd011.app.Main;
import javax.swing.*;
import java.sql.SQLException;

public class CRUDController {

    public static void run(){
        try {

            // Создаем экземпляр по работе с БД, в этом экземпляре реализуем все запросы к БД
            DbHandler dbHandler = DbHandler.getInstance();

            dbHandler.addReceipt(); //добавление
            Utils.showReceipts(dbHandler.getAllReceipts(),"Добавили заипись о приеме");

            String param = "2023-01-30";
            int count = dbHandler.updateReceipt(param);
            Utils.showReceipts(dbHandler.getAllReceipts(),"Изменили стоимость приема на 5000 у всех записей, где указана дата " +param+". Количество измененных записей: "+count);

            count = dbHandler.deleteReceipt(param);
            Utils.showReceipts(dbHandler.getAllReceipts(),"Удалили всех записей, где указана дата " +param+". Количество удаленных записей: "+count);

        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch
    }
}
