package itstep.pd011.app.utils;

import itstep.pd011.app.models.*;

import javax.swing.*;
import java.util.List;
import java.util.Random;

public class Utils {

    // случайное целочисленное число
    public static int getInt(int min, int max) {
        return new Random().nextInt(min, max);
    }

    // случайное вещественное число
    public static double getDouble(double min, double max) {
        return min + (max - min) * new Random().nextDouble();
    }

    // вывод сообщения об ошибке
    public static void showErrorMessage(String message, String title) {
        JOptionPane.showMessageDialog(null, message, title, JOptionPane.ERROR_MESSAGE);
    }

    // вывод данных в окно
    public static void showMessage(String message, String title) {
        JOptionPane.showOptionDialog(
                null,
                message,
                title,
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(),
                new Object[]{"Далее"},
                "Далее"
        );
    }

    public static String showSelect(String message, String title, Object[] strings) {
      return (String) JOptionPane.showInputDialog(
                null,
                message,
                title,
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(),
                strings,
                "Отмена"
        );
    }

    public static String getDouble(double start_value){
        return JOptionPane.showInputDialog(null, "Введите вещественное число (целое.дробное)", start_value);
    }

    public static String getInt(int start_value){
        return  JOptionPane.showInputDialog(null, "Введите целое число", start_value);
    }

    public static String getString(String start_value){
        return  JOptionPane.showInputDialog(null, "Введите строку", start_value);
    }

    public static String[] firstNamesFemale = {
            "Екатерина","Елизавета","Медина","Василиса","Виктория",
            "Арина","Ника","Элина","Варвара","Полина"};
    public static String[] firstNamesMale = {
            "Константин","Илья","Андрей","Георгий","Артём",
            "Богдан","Кирилл","Ян","Марк","Алексей"};

    public static String[] secondNamesFemale = {
            "Степанова","Кузнецова","Антонова",
            "Щербакова"};

    public static String[] secondNamesMale = {
            "Морозов","Колесников","Абрамов",
            "Кузнецов"};

    public static String[] cityNames = {
            "Дебальцево","Докучаевск",
            "Донецк","Дружковка","Енакиево"};

    public static  String[]  professions = {
            "Терапевт","Педиатр","Отоларинголог","Рентгенолог","Офтальмолог",
            "Стоматолог"
    };

    public static String headerDoctors =
            "<table border='1' >" +
                    "<thead><tr>" +
                    "<th>Id</th>" +
                    "<th>Фамилия</th>" +
                    "<th>Имя</th>" +
                    "<th>Отчество</th>" +
                    "<th>Специальность</th>" +
                    "<th>Процент</th>" +
                    "</tr></thead><tbody>";

    public static String headerPatients =
            "<table border='1' >" +
                    "<thead><tr>" +
                    "<th>Id</th>" +
                    "<th>Фамилия</th>" +
                    "<th>Имя</th>" +
                    "<th>Отчество</th>" +
                    "<th>Дата рождения</th>" +
                    "<th>Адрес</th>" +
                    "</tr></thead><tbody>";

    public static String headerReceipts =
            "<table border='1' >" +
                    "<thead><tr>" +
                    "<th>Id</th>" +
                    "<th>Дата приема</th>" +
                    "<th>Стоимость</th>" +
                    "<th>Врач</th>" +
                    "<th>Специальность врача</th>" +
                    "<th>Пациент</th>" +
                    "</tr></thead><tbody>";

    public static String headerQuery05 =
            "<table border='1' >" +
                    "<thead><tr>" +
                    "<th>Врач</th>" +
                    "<th>Специальность врача</th>" +
                    "<th>Стоимость приема</th>" +
                    "<th>Зарплата</th>" +
                    "</tr></thead><tbody>";

    public static String headerQuery06 =
            "<table border='1' >" +
                    "<thead><tr>" +
                    "<th>Дата приема</th>" +
                    "<th>Максимальная стоимость приема</th>" +
                    "</tr></thead><tbody>";

    public static String headerQuery07 =
            "<table border='1' >" +
                    "<thead><tr>" +
                    "<th>Специальность</th>" +
                    "<th>Средний Процент</th>" +
                    "</tr></thead><tbody>";

    // вывести всех врачей из коллекции
    public static void showDoctors(List<Doctor> doctors, String caption) {

        StringBuilder sb = new StringBuilder("<html><h3>"+caption+"</h3>");
        sb.append(headerDoctors);
        doctors.forEach(sb::append);;
        showMessage(sb.append("</tbody></table>").toString(),caption);
    }

    // вывести всех пациентов из коллекции
    public static void showPatients(List<Patient> patients,String caption) {

        StringBuilder sb = new StringBuilder("<html><h3>"+caption+"</h3>");
        sb.append(headerPatients);
        patients.forEach(sb::append);
        showMessage(sb.append("</tbody></table>").toString(),caption);
    }

    // вывести всех пациентов из коллекции
    public static void showReceipts(List<Receipt> receipts, String caption) {

        StringBuilder sb = new StringBuilder("<html><h3>"+caption+"</h3>");
        sb.append(headerReceipts);
        receipts.forEach(sb::append);;
        showMessage(sb.append("</tbody></table>").toString(),caption);
    }

    public static void showQuery05(List<Query05> query05List, String caption) {

        StringBuilder sb = new StringBuilder("<html><h3>"+caption+"</h3>");
        sb.append(headerQuery05);
        query05List.forEach(sb::append);;
        showMessage(sb.append("</tbody></table>").toString(),caption);
    }

    public static void showQuery06(List<Query06> query06List, String caption) {

        StringBuilder sb = new StringBuilder("<html><h3>"+caption+"</h3>");
        sb.append(headerQuery06);
        query06List.forEach(sb::append);;
        showMessage(sb.append("</tbody></table>").toString(),caption);
    }

    public static void showQuery07(List<Query07> query07List, String caption) {

        StringBuilder sb = new StringBuilder("<html><h3>"+caption+"</h3>");
        sb.append(headerQuery07);
        query07List.forEach(sb::append);;
        showMessage(sb.append("</tbody></table>").toString(),caption);
    }
}
