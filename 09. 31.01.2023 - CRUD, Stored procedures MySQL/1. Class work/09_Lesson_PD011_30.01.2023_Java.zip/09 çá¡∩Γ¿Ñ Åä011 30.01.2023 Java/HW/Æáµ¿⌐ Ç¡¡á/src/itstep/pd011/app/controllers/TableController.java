package itstep.pd011.app.controllers;

import itstep.pd011.app.handlers.DbHandler;
import itstep.pd011.app.utils.Utils;
import itstep.pd011.app.Main;
import javax.swing.*;
import java.sql.SQLException;

public class TableController {

    public static void run(){
        try {

            // Создаем экземпляр по работе с БД, в этом экземпляре реализуем все запросы к БД
            DbHandler dbHandler = DbHandler.getInstance();

            while (true) {

                switch (showMenu()) {
                    case 0 -> Utils.showDoctors(dbHandler.getAllDoctors(),"Таблица врачи");
                    case 1 -> Utils.showPatients(dbHandler.getAllPatients(),"Таблица пациенты");
                    case 2 -> Utils.showReceipts(dbHandler.getAllReceipts(),"Таблица приемы");

                    // выход
                    default -> {
                        return;
                    }
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch
    }

    // вывод окна меню
    public static int showMenu() {
        return JOptionPane.showOptionDialog(
                null,
                "<html><h1>Меню</h1>",
                "Выбор таблицы",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(Main.class.getResource("../../../images/leopard.png")),
                new Object[] {"Врачи", "Пациенты","Приемы ", "Выход"},
                "Выход"
        );
    }


}
