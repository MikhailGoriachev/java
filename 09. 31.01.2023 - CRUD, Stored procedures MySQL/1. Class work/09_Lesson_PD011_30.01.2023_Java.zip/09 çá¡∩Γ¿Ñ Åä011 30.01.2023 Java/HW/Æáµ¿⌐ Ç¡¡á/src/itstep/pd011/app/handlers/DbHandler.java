package itstep.pd011.app.handlers;

import org.sqlite.JDBC;

import java.sql.*;
import java.util.*;

import itstep.pd011.app.models.*;

public class DbHandler {

    // Константа, в которой хранится адрес подключения
    private static final String CON_STR = "jdbc:sqlite:app_data/Appointment.db";

    // Используем шаблон одиночка, чтобы не плодить множество
    // экземпляров класса DbHandler
    private static DbHandler instance = null;

    // потокобезопасное создание подключения
    public static synchronized DbHandler getInstance() throws SQLException {
        if (instance == null)
            instance = new DbHandler();
        return instance;
    }

    // Объект, в котором будет храниться соединение с БД
    private Connection connection;

    // приватный конструктор - требование синглтона
    private DbHandler() throws SQLException {
        // Регистрируем драйвер, с которым будем работать
        // в нашем случае Sqlite (регистрация драйвера в д.с. не обязательна)
        DriverManager.registerDriver(new JDBC());
        // Выполняем подключение к базе данных
        this.connection = DriverManager.getConnection(CON_STR);
    } // DbHandler

    // пример операции выборки данных из таблицы - получить и вывести всех врачей
    public List<Doctor> getAllDoctors() {
        List<Doctor> doctors = new ArrayList<>();

        // Выполняем подключение к базе данных, создаем оператор для выборки данных
        try (Statement statement = connection.createStatement()) {

            // выполнить выборку данных
            ResultSet resultSet = statement.executeQuery("select * from ViewDoctors");

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                doctors.add(new Doctor(
                        resultSet.getInt("Id"), resultSet.getString("surname"),
                        resultSet.getString("name"), resultSet.getString("patronymic"),
                        resultSet.getString("Specialtie"), resultSet.getInt("tax")
                ));
            } // while
        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return doctors;
    }

    // пример операции выборки данных из таблицы - получить и вывести всех пациентов
    public List<Patient> getAllPatients() {
        List<Patient> patients = new ArrayList<>();

        // Выполняем подключение к базе данных, создаем оператор для выборки данных
        try (Statement statement = connection.createStatement()) {

            // выполнить выборку данных
            ResultSet resultSet = statement.executeQuery("select * from Patients");

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                patients.add(new Patient(
                        resultSet.getInt("Id"), resultSet.getString("surname"),
                        resultSet.getString("name"), resultSet.getString("patronymic"),
                        resultSet.getString("Date_of_Birth"), resultSet.getString("address")
                ));
            } // while
        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return patients;
    }

    // пример операции выборки данных из таблицы - получить и вывести всех приемы
    public List<Receipt> getAllReceipts() {
        List<Receipt> receipts = new ArrayList<>();

        // Выполняем подключение к базе данных, создаем оператор для выборки данных
        try (Statement statement = connection.createStatement()) {

            // выполнить выборку данных
            ResultSet resultSet = statement.executeQuery("select * from ViewReceipts");

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                receipts.add(new Receipt(
                        resultSet.getInt("Id"), resultSet.getString("date"),
                        resultSet.getInt("price"), resultSet.getString("Doctor"),
                        resultSet.getString("Specialtie"), resultSet.getString("Patient")
                ));
            } // while
        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return receipts;
    }

    //Выбирает информацию о пациентах с фамилиями, начинающимися на заданную последовательность символов
    public List<Patient> doQuery01(String param) {

        List<Patient> patients = new ArrayList<>();

        String sql = "select * from Patients where Patients.surname like ?";

        // выполнение запроса - получение данных из таблицы
        try (PreparedStatement ps = this.connection.prepareStatement(sql)) {
            ps.setString(1, param + "%");
            ResultSet resultSet = ps.executeQuery();

            while (resultSet.next()) {
                patients.add(new Patient(
                        resultSet.getInt("Id"), resultSet.getString("surname"),
                        resultSet.getString("name"), resultSet.getString("patronymic"),
                        resultSet.getString("Date_of_Birth"), resultSet.getString("address")
                ));
            } // while

        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return patients;
    }

    //Выбирает информацию о врачах, для которых значение в поле Процент отчисления на зарплату, больше заданного
    public List<Doctor> doQuery02(int param) {

        List<Doctor> doctors= new ArrayList<>();

        String sql = "select * from ViewDoctors where ViewDoctors.tax > ? ";

        // выполнение запроса - получение данных из таблицы
        try (PreparedStatement ps = this.connection.prepareStatement(sql)) {
            ps.setInt(1, param);
            ResultSet resultSet = ps.executeQuery();

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                doctors.add(new Doctor(
                        resultSet.getInt("Id"), resultSet.getString("surname"),
                        resultSet.getString("name"), resultSet.getString("patronymic"),
                        resultSet.getString("Specialtie"), resultSet.getInt("tax")
                ));
            } // while

        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return doctors;
    }

    //Выбирает информацию о приемах за некоторый период
    public List<Receipt> doQuery03(String param01, String param02) {

        List<Receipt> receipts= new ArrayList<>();

        String sql = "select * from ViewReceipts where [date] between ? and ?";

        // выполнение запроса - получение данных из таблицы
        try (PreparedStatement ps = this.connection.prepareStatement(sql)) {
            ps.setString(1, param01);
            ps.setString(2, param02);
            ResultSet resultSet = ps.executeQuery();

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                receipts.add(new Receipt(
                        resultSet.getInt("Id"), resultSet.getString("date"),
                        resultSet.getInt("price"), resultSet.getString("Doctor"),
                        resultSet.getString("Specialtie"), resultSet.getString("Patient")
                ));
            } // while

        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return receipts;
    }

    //Выбирает из таблицы информацию о врачах с заданной специальностью
    public List<Doctor> doQuery04(String param) {

        List<Doctor> doctors= new ArrayList<>();

        String sql = "select * from ViewDoctors where ViewDoctors.Specialtie like ? ";

        // выполнение запроса - получение данных из таблицы
        try (PreparedStatement ps = this.connection.prepareStatement(sql)) {
            ps.setString(1, param);
            ResultSet resultSet = ps.executeQuery();

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                doctors.add(new Doctor(
                        resultSet.getInt("Id"), resultSet.getString("surname"),
                        resultSet.getString("name"), resultSet.getString("patronymic"),
                        resultSet.getString("Specialtie"), resultSet.getInt("tax")
                ));
            } // while

        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return doctors;
    }

    //Вычисляет размер заработной платы врача за каждый прием. Включает поля
    // Фамилия врача, Имя врача, Отчество врача, Специальность врача, Стоимость приема, Зарплата. Сортировка по полю
    // Специальность врача
    public List<Query05> doQuery05() {

        List<Query05> query05List= new ArrayList<>();

        String sql = "select ViewReceipts.Doctor, " +
                            "ViewReceipts.Specialtie, " +
                            "ViewReceipts.price,"+
                            "ViewReceipts.price *(ViewReceipts.tax/100) - (ViewReceipts.tax/100)*ViewReceipts.price *13/100 as Salary " +
                    "from ViewReceipts " +
                    "order by ViewReceipts.Specialtie";

        // выполнение запроса - получение данных из таблицы
        try (PreparedStatement ps = this.connection.prepareStatement(sql)) {
            ResultSet resultSet = ps.executeQuery();

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                query05List.add(new Query05(
                        resultSet.getString("Doctor"), resultSet.getString("Specialtie"),
                        resultSet.getInt("price"), resultSet.getDouble("Salary")
                ));
            } // while

        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return query05List;
    }

    //Выполняет группировку по полю Дата приема. Для каждой даты вычисляет максимальную стоимость приема
    public List<Query06> doQuery06() {

        List<Query06> query06List= new ArrayList<>();

        String sql = "select Receipts.[date],MAX(price) as [max]" +
                    "from Receipts " +
                    "group by Receipts.[date]" +
                    "order by Receipts.[date]";

        // выполнение запроса - получение данных из таблицы
        try (PreparedStatement ps = this.connection.prepareStatement(sql)) {
            ResultSet resultSet = ps.executeQuery();

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                query06List.add(new Query06(
                        resultSet.getString("date"), resultSet.getInt("max")
                ));
            } // while

        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return query06List;
    }

    //Выполняет группировку по полю Специальность.
    // Для каждой специальности вычисляет средний Процент отчисления на зарплату от стоимости приема
    public List<Query07> doQuery07() {

        List<Query07> query07List= new ArrayList<>();

        String sql = "select Specialties.[name],AVG(tax) as [avg]" +
                "from Specialties left join  Doctors on Specialties.Id = Doctors.id_specialtie group by Specialties.[name]";

        // выполнение запроса - получение данных из таблицы
        try (PreparedStatement ps = this.connection.prepareStatement(sql)) {
            ResultSet resultSet = ps.executeQuery();

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                query07List.add(new Query07(
                        resultSet.getString("name"), resultSet.getDouble("avg")
                ));
            } // while

        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return query07List;
    }

    // добавить прием - Create (C)RUD
    public void addReceipt() {
        String sql = """
            INSERT INTO Receipts (
                                     date,
                                     price,
                                     id_patient,
                                     id_doctor
                                 )
                                 VALUES (
                                     ?,
                                     ?,
                                     ?,
                                     ?
                                 );;
            """;

        try (PreparedStatement ps = this.connection.prepareStatement(sql)) {
            // нумерация параметров - с 1
            ps.setString(1, "2023-01-30");
            ps.setInt(2, 2000);
            ps.setInt(3, 1);
            ps.setInt(4, 1);

            ps.executeUpdate();
            // ps.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch
    }

    // изменить запись о клиенте - Update CR(U)D
    public int updateReceipt(String param) {

        // количество измененных элементов
        int counterUpdated = 0;

        // запрос на изменение записи в таблице
        String sql = """
                UPDATE Receipts
                   SET 
                       price = ?
                 WHERE 
                       [date] like ?;
            """;

        // выполнение запроса на изменение
        try (PreparedStatement ps = this.connection.prepareStatement(sql)) {
            // установить параметры запроса
            ps.setInt(1, 5000);
            ps.setString(2, param);

            // собственно выполнить запрос
            counterUpdated = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return counterUpdated;
    }

    // удалить запись о клиенте - Delete CRU(D)
    public int deleteReceipt(String param) {
        // количество удаленных записей
        int counterDeleted = 0;

        // запрос на удаление
        String sql = """
            delete from
                Receipts
            where
                date = ?;
        """;

        // выполнение запроса
        try (PreparedStatement ps = this.connection.prepareStatement(sql)) {
            ps.setString(1, param);
            counterDeleted = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return counterDeleted;
    }
}
