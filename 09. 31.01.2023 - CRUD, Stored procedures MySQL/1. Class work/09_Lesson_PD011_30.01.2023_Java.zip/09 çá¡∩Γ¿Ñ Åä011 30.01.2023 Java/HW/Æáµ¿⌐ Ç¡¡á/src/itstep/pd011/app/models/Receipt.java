package itstep.pd011.app.models;

import java.sql.Date;

public class Receipt {

    private int id;
    private String date;
    private int price;
    private String doctor;
    private String specialtie;
    private String patient;

    public Receipt(int id, String date, int price, String doctor, String specialtie, String patient) {
        this.id = id;
        this.date = date;
        this.price = price;
        this.doctor = doctor;
        this.specialtie = specialtie;
        this.patient = patient;
    }

    @Override
    public String toString() {
        return "<tr>" +
                "<td>"+id+"</td>"+
                "<td>"+date+"</td>"+
                "<td>"+price+"</td>"+
                "<td>"+doctor+"</td>"+
                "<td>"+specialtie+"</td>"+
                "<td>"+patient+"</td>"+
                "</tr>";
    }
}
