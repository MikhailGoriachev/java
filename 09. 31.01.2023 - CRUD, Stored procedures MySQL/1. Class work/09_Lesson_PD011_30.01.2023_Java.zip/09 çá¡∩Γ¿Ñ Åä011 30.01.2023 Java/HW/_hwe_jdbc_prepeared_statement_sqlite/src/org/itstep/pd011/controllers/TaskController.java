package org.itstep.pd011.controllers;

import org.itstep.pd011.models.DbHandler;
import org.itstep.pd011.models.entities.Appointment;
import org.itstep.pd011.models.entities.Category;
import org.itstep.pd011.models.entities.Query07;

import java.sql.Date;
import java.sql.SQLException;
import java.util.Calendar;

// выполнение запросов по заданию, вывод результатов запросов
public class TaskController {


    private DbHandler dbHandler;

    public TaskController() throws SQLException {
        this(DbHandler.getInstance());
    }

    public TaskController(DbHandler dbHandler) {
        this.dbHandler = dbHandler;
    }

    public DbHandler getDbHandler() { return  dbHandler; }

    public void showCategories() {
        StringBuilder res = new StringBuilder(Category.HEADER);
        dbHandler.getAllCategories().forEach(t -> res.append("\t").append(t.toTableRow()).append("\n"));
        res.append(Category.FOOTER);

        System.out.println(res);
    } // showCategories

    public void showPersons() {

    } // showPersons

    public void showPatients() throws SQLException {
        var data = dbHandler.getAllPatients();

        StringBuilder body = new StringBuilder();
        data.forEach(t -> body.append(String.format("\t%s\n", t.toTableRow())));
        System.out.printf("\n\tСведения о пациентах%s\n", body);
    } // showPatients

    public void showDoctors() {

    } // showDoctors


    public void showAppointments() {

    } // showAppointments

    // -------------------------------------------------------------------------

    public void showQuery01() {

    } // showQuery01

    public void showQuery02() {

    } // showQuery02

    // Запрос 3. Запрос с параметрами
    // Выбирает информацию о приемах за некоторый период
    public void showQuery03() throws SQLException {
        var data = dbHandler.query03(new Date(2023, 1, 1), new Date(2023, 1, 12));

        StringBuilder res = new StringBuilder(Appointment.HEADER);
        data.forEach(t -> res.append("\t").append(t.toTableRow()).append("\n"));
        res.append(Appointment.FOOTER);

        System.out.println(res);
    } // showQuery03

    public void showQuery04() {

    } // showQuery04

    public void showQuery05() {

    } // showQuery05

    public void showQuery06() {

    } // showQuery06

    // Запрос 7. Итоговый запрос
    // Выполняет группировку по полю Специальность. Для каждой специальности
    // вычисляет средний Процент отчисления на зарплату от стоимости приема
    public void showQuery07() throws SQLException {
        var data = dbHandler.query07();

        StringBuilder body = new StringBuilder();
        data.forEach(t -> body.append(String.format("\t%s\n", t.toTableRow())));

        System.out.printf("%s%s%s", Query07.HEADER, body, Query07.FOOTER);
    } // showQuery07
} // class TaskController
