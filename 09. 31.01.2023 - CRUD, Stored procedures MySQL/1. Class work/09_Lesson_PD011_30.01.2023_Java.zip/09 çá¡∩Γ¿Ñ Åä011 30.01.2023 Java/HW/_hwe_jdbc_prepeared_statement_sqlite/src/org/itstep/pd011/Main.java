package org.itstep.pd011;


import org.itstep.pd011.controllers.TaskController;
import org.itstep.pd011.models.entities.Patient;

import java.sql.Date;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {

        try {
            Patient p = new Patient(100, "Иванов", "Иван", "Иванович",
                    new Date(1987 - 1900, 11, 30), "Донецк-34, ул. Ю, 6, 9");
            System.out.println(p.toTableRow());

            /*
            TaskController taskController = new TaskController();

            taskController.showCategories();
            taskController.showPersons();
            taskController.showPatients();
            taskController.showDoctors();
            taskController.showAppointments();

            taskController.showQuery01();
            taskController.showQuery02();
            taskController.showQuery03();
            taskController.showQuery04();
            taskController.showQuery05();
            taskController.showQuery06();
            taskController.showQuery07();
             */
        } // try

//        catch (SQLException ex) {
//            System.out.println(ex.getMessage());
//            ex.printStackTrace();
//        } // catch

        catch (Exception ex) {
            ex.printStackTrace();
        } // catch
    } // main
} // class Main