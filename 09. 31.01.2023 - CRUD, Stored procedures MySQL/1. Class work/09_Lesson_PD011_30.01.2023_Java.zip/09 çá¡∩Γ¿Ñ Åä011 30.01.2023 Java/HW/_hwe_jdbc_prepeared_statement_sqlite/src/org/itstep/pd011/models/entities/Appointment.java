package org.itstep.pd011.models.entities;

import java.sql.Date;

// сведения о факте врачебного приема
public record Appointment(
        int id,
        Date date,
        String patientSurname,
        String patientName,
        String patientPatronymic,
        Date dob,
        String address,
        String doctorSurname,
        String doctorName,
        String doctorPatronymic,
        String categoryName,
        double interest

){
    public String toTableRow() {
        // форматирование даты http://proglang.su/java/date-and-time#formatirovanie-daty-s-pomoschyu-printf
        return String.format("│ %1$3d │ %2$td.%2$tm.%2$tY  │ %3$-30s │ %4$-20s │ %5$-30s │ ",
                id, date,
                patientSurname, patientName, patientPatronymic, dob, address,
                doctorSurname, doctorName, doctorPatronymic, categoryName, interest);
    } // toTableRow

    public static final String HEADER =
        "\t┌─────┬──────────────┬──────────────┬──────────────┬──────────┬────────────┐\n"+
        "\t│  Ид │ Фамилия      │ Имя          │ Отчество     │ Паспорт  │ Дисконт, % │\n"+
        "\t├─────┼──────────────┼──────────────┼──────────────┼──────────┼────────────┤\n";

    public static final String FOOTER =
        "\t└─────┴──────────────┴──────────────┴──────────────┴──────────┴────────────┘\n";
} // record Appointment
