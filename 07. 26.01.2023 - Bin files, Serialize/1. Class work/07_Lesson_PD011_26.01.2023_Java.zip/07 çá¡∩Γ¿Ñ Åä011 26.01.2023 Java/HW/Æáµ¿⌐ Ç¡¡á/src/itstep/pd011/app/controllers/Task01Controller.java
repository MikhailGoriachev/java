package itstep.pd011.app.controllers;

import itstep.pd011.app.models.task01.Citizens;
import itstep.pd011.app.utils.Utils;
import itstep.pd011.app.Main;

import javax.swing.*;

public class Task01Controller {

    private Citizens citizens;

    public Task01Controller() {
        citizens = new Citizens();
    }

    // работа по заданию
    public void run() {

            while (true) {

                switch (showMenu()) {
                    case "Жители города" ->Utils.showMessage(Citizens.show(citizens.getCitizenList()),"Все записи:");
                    case "Статистика по городам" -> Utils.showMessage(citizens.doQuery01(),"Статистика по городам");
                    case "Жители с заданной профессией, фамилия которых начинается с заданной строки" -> {

                        String message = citizens.doQuery02();
                        if(message == null) break;

                        Utils.showMessage(message,"Жители с заданной профессией, фамилия которых начинается с заданной строки");
                    }
                    case "Список фамилий и жители с такой фамилией" -> Utils.showMessage(citizens.doQuery03(),"Список фамилий и жители с такой фамилией");
                    case "Список профессий и жители с такой профессией" -> Utils.showMessage(citizens.doQuery04(),"Список профессий и жители с такой профессией");
                    case "Список городов по убыванию количества проживающих в них людей" -> Utils.showMessage(citizens.doQuery05(),"Список городов по убыванию количества проживающих в них людей");
                    case "Статистика по профессиям" -> Utils.showMessage(citizens.doQuery06(),"Статистика по профессиям");
                    case "Cреднее количество жителей города и города с количеством жителей ниже среднего"
                        -> Utils.showMessage(citizens.doQuery07(),"Cреднее количество жителей города и города с количеством жителей ниже среднего");
                    // выход
                    default -> {
                        return;
                    }
                }
            }
    }

    // вывод окна меню
    public static String showMenu() {
        String s = (String) JOptionPane.showInputDialog(
                null,
                "<html><br><h2>Выберите вариант</h2>",
                "Меню первого задания",
                JOptionPane.QUESTION_MESSAGE,
                new ImageIcon(Main.class.getResource("../../../images/leopard.png")),
                new Object[] {"Жители города",
                        "Статистика по городам",
                        "Статистика по профессиям",
                        "Жители с заданной профессией, фамилия которых начинается с заданной строки",
                        "Список фамилий и жители с такой фамилией",
                        "Список профессий и жители с такой профессией",
                        "Список городов по убыванию количества проживающих в них людей",
                        "Cреднее количество жителей города и города с количеством жителей ниже среднего"
                        ,"Назад"},
                "Назад");

        if(s == null) return "Назад";

        return s;
    }
}
