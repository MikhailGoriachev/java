package itstep.pd011.app.controllers;

import itstep.pd011.app.models.task01.Citizens;
import itstep.pd011.app.models.task02.Store;
import itstep.pd011.app.utils.Utils;

import itstep.pd011.app.Main;
import javax.swing.*;

public class Task03Controller {

    private Store store;

    public Task03Controller() {
        store = new Store();
    }

    // работа по заданию
    public void run() {

        while (true) {

            switch (showMenu()) {

                case "Упорядочивание коллекции по убыванию стоимости товара" ->
                    Utils.showMessage(store.show(store.OrderByCostDesc()),"Упорядочивание коллекции по убыванию стоимости товара:");

                case "Упорядочивание коллекции по наименованию товара" ->
                    Utils.showMessage(store.show(store.OrderByTitle()),"Упорядочивание коллекции по наименованию товара:");

                case "Упорядочивание коллекции по возрастанию количества товара" ->
                        Utils.showMessage(store.show(store.OrderByAmount()),"Упорядочивание коллекции по возрастанию количества товара:");

                case "Количественный анализ" ->
                        Utils.showMessage(store.doQuery(),"Количественный анализ");

                case "Вывод коллекции в консоль с итогами по количеству и сумме товара" ->
                        Utils.showMessage(store.showStatistics(),"Вывод коллекции в консоль с итогами по количеству и сумме товара");

                // выход
                default -> {
                    return;
                }
            }
        }
    }

    // вывод окна меню
    public String showMenu() {
        String s = (String) JOptionPane.showInputDialog(
                null,
                "<html><br><h1>Склад: "+store.getName()+"</h1>" +
                        "<p>Адрес: "+store.getAddress()+"</p><br>",
                "Меню третьего задания",
                JOptionPane.QUESTION_MESSAGE,
                new ImageIcon(Main.class.getResource("../../../images/horse.png")),
                new Object[] {
                        "Вывод коллекции в консоль с итогами по количеству и сумме товара",
                        "Упорядочивание коллекции по убыванию стоимости товара",
                        "Упорядочивание коллекции по наименованию товара",
                        "Упорядочивание коллекции по возрастанию количества товара",
                        "Количественный анализ"
                        ,"Назад"},
                "Назад");

        if(s == null) return "Назад";

        return s;
    }
}
