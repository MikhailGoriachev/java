package itstep.pd011.app.models.task02;

import itstep.pd011.app.models.task01.Citizen;

import java.security.InvalidParameterException;

public class Good {

    private String title; //Наименование товара
    private int amount; //Количество
    private double price;//Цена ед. товара

    public String getTitle() {
        return title;
    }
    public int getAmount() {
        return amount;
    }
    public double getPrice() {
        return price;
    }

    public double getCost(){return price*amount;} //Стоимость

    public Good(String title, int amount, double price) {
        this.title = title;
        this.amount = amount;
        this.price = price;
    }

    // фабричный метод - формируем объект Person из строки файла данных
    public static Good parseGood(String str) throws InvalidParameterException {
        String[] tokens = str.split(";");

        if(tokens.length < 3) throw new InvalidParameterException("Не удалось получить нужное количество параметров");

        return new Good(tokens[0], Integer.parseInt(tokens[1]), Double.parseDouble(tokens[2]));
    } // parsePerson

    @Override
    public String toString() {
        return "<tr>" +
                "<td>"+title+"</td>"+
                "<td>"+amount+"</td>"+
                "<td>"+price+"</td>"+
                "<td>"+getCost()+"</td>"+
                "</tr>";
    }
}
