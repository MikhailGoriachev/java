package itstep.pd011.app.models.task01;

import itstep.pd011.app.utils.Utils;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

public class Citizens {
    private List<Citizen> citizenList;
    private static final String FILENAME = "app_data/citizens.csv";
    private static final int N = 15; //начальный размер коллекции

    public List<Citizen> getCitizenList() {
        return citizenList;
    }

    public Citizens() {

        citizenList = new ArrayList<>();

        try {
            if (Files.notExists(Paths.get(FILENAME))) {
                fill();
                write();
            } else {
                load();
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        } // try-catch
    }

    //заполнить
    private void fill(){

        for (int i = 0; i<N; i++){
            citizenList.add(new Citizen());
        }

    }

    // загрузка данных из файла в формате CSV
    private void load() throws IOException {
        List<String> text = new ArrayList<>();
        citizenList.clear();  // формируем новую коллекцию

        // читаем текстовый файл одной операцией
        text = Files.readAllLines(Paths.get(FILENAME), StandardCharsets.UTF_8);

        text.forEach(str -> citizenList.add(Citizen.parseCitizen(str)));
    }

    // ввод коллекции в файл формата CSV
    public void write() throws IOException {

        // если папки data нет - создать папку
        File dir = new File("app_data");
        if (!dir.exists()) dir.mkdir();

        List<String> lines = new ArrayList<>();
        citizenList.forEach(p->lines.add(
                String.format(Locale.UK, "%s;%s;%d;%s;%s;%d",p.getSecondName(),p.getFirstName(),p.getAge(),p.getCity(),p.getProfession(),p.getSalary())
        ));

        Files.write(Paths.get(FILENAME), lines, StandardCharsets.UTF_8);
    }

    //статистика по городам – название городов, количество жителей из этих городов в коллекции, средний возраст,
    // минимальный возраст, максимальный возраст жителя
    public String doQuery01(){

        StringBuilder sb = new StringBuilder("<html>");

        // Группировка по городам - для получения списка людей, входящих в группировку
        Map<String, IntSummaryStatistics> statisticsMap = citizenList
                .stream()
                .collect(Collectors.groupingBy(Citizen::getCity,
                        Collectors.summarizingInt(Citizen::getAge)));

        for (var entry : statisticsMap.entrySet()){
            IntSummaryStatistics value = entry.getValue();
            sb.append("<ol>"+entry.getKey()+"" +
                    "<li>Количество жителей: "+value.getCount()+"</li>" +
                    "<li>Средний возраст: "+ String.format("%.2f",value.getAverage()) +"</li>" +
                    "<li>Минимальный возраст: "+value.getMin()+"</li>" +
                    "<li>Максимальный возраст: "+value.getMax()+"</li>" +
                    "</ol");
        }

        return sb.toString();
    }

    //жители с заданной профессией, фамилия которых начинается с заданной строки
    public String doQuery02(){

        StringBuilder sb = new StringBuilder("<html>");

        String profession  = Utils.showSelect("<html><br><h2>Выберите профессию</h2>","Выбрать жителей с заданной профессией",
                citizenList.stream().map(Citizen::getProfession).distinct()
                        .sorted().toArray());

        if(profession == null) return null;

        String line = Utils.getString("А");
        if(line == null) return null;

        List<Citizen> list = citizenList
                .stream()
                .filter(c -> c.getProfession().equals(profession) && c.getSecondName().startsWith(line))
                .toList();

        if(list.size() == 0) return sb.append("<h3 style = 'color:red'>По вашему запросу ничего не найдено</h3>").toString();

        return sb.append(show(list)).toString();
    }

    //список фамилий и жители с такой фамилией
    public String doQuery03(){

        StringBuilder sb = new StringBuilder("<html>");

        Map<String, List<Citizen>> listMap = citizenList
                .stream()
                .collect(Collectors.groupingBy(Citizen::getSecondName));

        for (var entry : listMap.entrySet()){
            sb.append("<ol>").append(entry.getKey());

            for (Citizen citizen: entry.getValue()){
                sb.append("<li>").append(citizen.getFirstName() + " " + citizen.getAge() + "</li>");
            }

            sb.append("</ol>");
        }

        return sb.toString();
    }

    //список профессий и жители с такой профессией
    public String doQuery04(){

        StringBuilder sb = new StringBuilder("<html>");

        Map<String, List<Citizen>> listMap = citizenList
                .stream()
                .collect(Collectors.groupingBy(Citizen::getProfession));

        for (var entry : listMap.entrySet()){
            sb.append("<ol>").append(entry.getKey());

            for (Citizen citizen: entry.getValue()){
                sb.append("<li>").append( citizen.getSecondName() + " " + citizen.getFirstName() + " " + citizen.getAge() + "</li>");
            }

            sb.append("</ol>");
        }

        return sb.toString();
    }

    //список городов по убыванию количества проживающих в них людей
    public String doQuery05(){

        StringBuilder sb = new StringBuilder(Utils.headerCitizensQuery05);

        Map<String,Long> listMap = citizenList
                .stream()
                .collect(Collectors.groupingBy(Citizen::getCity, Collectors.counting()));

        for(var entry : listMap.entrySet().stream().sorted((p1, p2) -> (int)(p2.getValue() - p1.getValue())).collect(Collectors.toCollection(LinkedHashSet::new))){
            sb.append("<tr>" +
                    "<td>"+entry.getKey()+"</td>"+
                    "<td>"+entry.getValue()+"</td>"+
                    "</tr>");
        }

        return sb.append("</tbody></table>").toString();
    }

    //статистика по профессиям – количество жителей с заданной профессией, минимальный оклад, средний оклад,
    // максимальный оклад, сумма окладов
    public String doQuery06(){

        StringBuilder sb = new StringBuilder("<html>");

        // Группировка по профессиям - для получения списка людей, входящих в группировку
        Map<String, IntSummaryStatistics> statisticsMap = citizenList
                .stream()
                .collect(Collectors.groupingBy(Citizen::getProfession,
                        Collectors.summarizingInt(Citizen::getSalary)));

        for (var entry : statisticsMap.entrySet()){
            IntSummaryStatistics value = entry.getValue();
            sb.append("<ol>"+entry.getKey()+
                    "<li>Количество жителей: "+value.getCount()+"</li>" +
                    "<li>Средний оклад: "+ String.format("%.0f",value.getAverage()) +"</li>" +
                    "<li>Минимальный оклад: "+value.getMin()+"</li>" +
                    "<li>Максимальный оклад: "+value.getMax()+"</li>" +
                    "<li>Cумма окладов: "+value.getSum()+"</li>" +
                    "</ol");
        }

        return sb.toString();
    }

    //среднее количество жителей города и города с количеством жителей ниже среднего
    public String doQuery07(){

        Map<String,Long> listMap = citizenList
                .stream()
                .collect(Collectors.groupingBy(Citizen::getCity, Collectors.counting()));

        double avg = listMap.entrySet().stream().collect(Collectors.averagingLong(Map.Entry::getValue));

        StringBuilder sb = new StringBuilder("<html><h3>Среднее количество: "+String.format("%.2f",avg)+"</h3>");
        sb.append(Utils.headerCitizensQuery05);

        for(var entry : listMap.entrySet().stream().filter(p->p.getValue() < avg).collect(Collectors.toSet())){
            sb.append("<tr>" +
                    "<td>"+entry.getKey()+"</td>"+
                    "<td>"+entry.getValue()+"</td>"+
                    "</tr>");
        }

        return sb.append("</tbody></table>").toString();
    }

    //Табличный вывод
    public static String show(List<Citizen> list){

        StringBuilder sb = new StringBuilder(Utils.headerPeople);

        list.forEach(sb::append);
        sb.append("</tbody></table>");

        return sb.toString();
    }

}
