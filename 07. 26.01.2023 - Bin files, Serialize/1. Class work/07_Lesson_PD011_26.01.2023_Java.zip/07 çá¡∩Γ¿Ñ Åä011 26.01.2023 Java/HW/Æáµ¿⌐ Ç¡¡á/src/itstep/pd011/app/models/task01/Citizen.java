package itstep.pd011.app.models.task01;

import itstep.pd011.app.utils.Utils;

import java.security.InvalidParameterException;

public class Citizen {

    String secondName; //фамилия
    String firstName; //имя
    int age;//возраст
    String city;//название города
    String profession; //профессия
    int salary; //оклад

    public String getSecondName() {
        return secondName;
    }
    public String getFirstName() {
        return firstName;
    }
    public int getAge() {
        return age;
    }
    public String getCity() {
        return city;
    }
    public String getProfession() {
        return profession;
    }
    public int getSalary() {
        return salary;
    }

    public Citizen(String secondName, String firstName, int age, String city, String profession, int salary) {
        this.secondName = secondName;
        this.firstName = firstName;
        this.age = age;
        this.city = city;
        this.profession = profession;
        this.salary = salary;
    }

    public Citizen() {

        int g = Utils.getInt(0,2);

        if(g == 0){
            this.firstName = Utils.firstNamesMale[Utils.getInt(0,Utils.firstNamesMale.length)];
            this.secondName = Utils.secondNamesMale[Utils.getInt(0,Utils.secondNamesMale.length)];

        }else {
            this.firstName = Utils.firstNamesFemale[Utils.getInt(0,Utils.firstNamesFemale.length)];
            this.secondName = Utils.secondNamesFemale[Utils.getInt(0,Utils.secondNamesFemale.length)];
        }

        this.age = Utils.getInt(24,65);
        this.city = Utils.cityNames[Utils.getInt(0,Utils.cityNames.length)];
        this.profession = Utils.professions[Utils.getInt(0,Utils.professions.length)];
        this.salary = Utils.getInt(20,90) * 1000;

    }

    // фабричный метод - формируем объект Person из строки файла данных
    public static Citizen parseCitizen(String str) throws InvalidParameterException {
        String[] tokens = str.split(";");

        if(tokens.length < 5) throw new InvalidParameterException("Не удалось получить нужное количество параметров");

        return new Citizen(tokens[0], tokens[1], Integer.parseInt(tokens[2]), tokens[3],tokens[4],Integer.parseInt(tokens[5]));
    } // parsePerson

    @Override
    public String toString() {
        return "<tr>" +
                "<td>"+secondName+"</td>"+
                "<td>"+firstName+"</td>"+
                "<td>"+age+"</td>"+
                "<td>"+city+"</td>"+
                "<td>"+profession+"</td>"+
                "<td>"+salary+"</td>"+
                "</tr>";
    }
}
