package itstep.pd011.app.models.task02;

import itstep.pd011.app.utils.Utils;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

public class Store {

    private String name; //название
    private String address; //адрес склада
    private static final String FILENAME = "app_data/store.csv";
    List<Good> goodList; //данные о товарах

    public String getName() {
        return name;
    }
    public String getAddress() {
        return address;
    }

    public Store() {

        this.name = "Оптовый";
        this.address = " г. Донецк, ул. Циолковского, 21";

        goodList = new ArrayList<>();

        try {
            if (Files.notExists(Paths.get(FILENAME))) {
                goodList.addAll(List.of(initialization));
                write();
            } else {
                load();
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        } // try-catch

    }

    private static final Good[] initialization = new Good[]
    {
                new Good("Зонтик автоматический", 50, 750.),
                new Good("Портсигар импортный", 300, 1200.),
                new Good("Приставка игровая", 2, 15600.),
                new Good("Куртка замшевая", 12, 5100.),
                new Good("Чайник фарфоровый", 15, 750.),
                new Good("Кинокамера отечественная", 7, 3100.),
                new Good("Телевизор цветной", 7, 25100.),
                new Good("Фотоаппарат цифровой", 2, 12000.),
                new Good("Компьютер планшетный", 3, 15600.),
                new Good("Кофейник фарфоровый", 15, 750.)
    };

    // загрузка данных из файла в формате CSV
    private void load() throws IOException {
        List<String> text = new ArrayList<>();
        goodList.clear();  // формируем новую коллекцию

        // читаем текстовый файл одной операцией
        text = Files.readAllLines(Paths.get(FILENAME), StandardCharsets.UTF_8);

        String[] tokens =  text.get(0).split(";");

        this.name = tokens[0];
        this.address = tokens[1];

        text.remove(0);
        text.forEach(str -> goodList.add(Good.parseGood(str)));
    }

    // ввод коллекции в файл формата CSV
    public void write() throws IOException {

        // если папки data нет - создать папку
        File dir = new File("app_data");
        if (!dir.exists()) dir.mkdir();

        List<String> lines = new ArrayList<>();

        //первая строка содержит название и адрес склада,
        lines.add(String.format("%s;%s;",name,address));

        goodList.forEach(p->lines.add(
                String.format(Locale.UK, "%s;%d;%.2f",p.getTitle(),p.getAmount(),p.getPrice())
        ));

        Files.write(Paths.get(FILENAME), lines, StandardCharsets.UTF_8);
    }

    //Табличный вывод
    public String show(List<Good> list){

        StringBuilder sb = new StringBuilder(Utils.headerGoods);
        list.forEach(sb::append);
        return sb.append("</tbody></table>").toString();
    }

    //вывод коллекции в консоль с итогами по количеству и сумме товара (сумма товара вычисляется как по строке,
    // так и по столбцу);
    public String showStatistics(){

        StringBuilder sb = new StringBuilder(Utils.headerGoods);

        goodList.forEach(sb::append);

        int sumAmount = goodList.stream().mapToInt(Good::getAmount).sum();
        double sumCost = goodList.stream().mapToDouble(Good::getCost).sum();

        return sb.append("<b><tr>" +
                "<td>Итого</td>" +
                "<td>"+sumAmount+"</td>" +
                "<td style = 'background-color: #D3D3D3'></td>" +
                "<td>"+sumCost+"</td>" +
                "</b></tr></tbody></table>").toString();
    }

    //упорядочивание коллекции по убыванию стоимости товара;
    public List<Good> OrderByCostDesc(){
       return goodList.stream().sorted((p1,p2) -> Double.compare(p2.getCost(), p1.getCost())).toList();
    }

    //упорядочивание коллекции по наименованию товара;
    public List<Good> OrderByTitle(){
        return goodList.stream().sorted((p1,p2) -> p1.getTitle().compareTo(p2.getTitle())).toList();
    }

    //упорядочивание коллекции по возрастанию количества товара;
    public List<Good> OrderByAmount(){
        return goodList.stream().sorted((p1,p2) -> p1.getAmount() - p2.getAmount()).toList();
    }

    //выполните количественный анализ: суммарное количество товара, минимальное, максимальное,
    // среднее количество товара
    public String doQuery(){

        StringBuilder sb = new StringBuilder("<html>");

        int min = goodList.stream().min((p1,p2) -> p1.getAmount() - p2.getAmount()).get().getAmount();
        int max = goodList.stream().max((p1,p2) -> p1.getAmount() - p2.getAmount()).get().getAmount();

        //max = goodList.stream().collect(Collectors.minBy(Good::getAmount));

        double avg = goodList.stream().collect(Collectors.averagingLong(Good::getAmount));
        long sum = goodList.stream().mapToInt(Good::getAmount).sum();

        return sb.append("<p>" +
                    "Суммарное количество товара: "+sum+"<br>"+
                    "Минимальное количество товара: "+min+"<br>"+
                    "Максимальное количество товара: "+max+"<br>"+
                    "Cреднее количество товара: "+avg+"<br>"+
                    "</p>").toString();
    }
}
