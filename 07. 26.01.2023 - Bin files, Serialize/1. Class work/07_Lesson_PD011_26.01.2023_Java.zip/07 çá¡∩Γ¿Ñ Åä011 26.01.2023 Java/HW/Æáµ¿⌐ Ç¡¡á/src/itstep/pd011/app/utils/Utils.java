package itstep.pd011.app.utils;

import javax.swing.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class Utils {

    // случайное целочисленное число
    public static int getInt(int min, int max) {
        return new Random().nextInt(min, max);
    }

    // случайное вещественное число
    public static double getDouble(double min, double max) {
        return min + (max - min) * new Random().nextDouble();
    }

    // вывод сообщения об ошибке
    public static void showErrorMessage(String message, String title) {
        JOptionPane.showMessageDialog(null, message, title, JOptionPane.ERROR_MESSAGE);
    }

    // вывод данных в окно
    public static void showMessage(String message, String title) {
        JOptionPane.showOptionDialog(
                null,
                message,
                title,
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(),
                new Object[]{"Далее"},
                "Далее"
        );
    }

    public static String showSelect(String message, String title, Object[] strings) {
      return (String) JOptionPane.showInputDialog(
                null,
                message,
                title,
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(),
                strings,
                "Отмена"
        );
    }

    public static String getDouble(double start_value){
        return JOptionPane.showInputDialog(null, "Введите вещественное число (целое.дробное)", start_value);
    }

    public static String getInt(int start_value){
        return  JOptionPane.showInputDialog(null, "Введите целое число", start_value);
    }

    public static String getString(String start_value){
        return  JOptionPane.showInputDialog(null, "Введите строку", start_value);
    }

    public static String[] firstNamesFemale = {
            "Екатерина","Елизавета","Медина","Василиса","Виктория",
            "Арина","Ника","Элина","Варвара","Полина"};
    public static String[] firstNamesMale = {
            "Константин","Илья","Андрей","Георгий","Артём",
            "Богдан","Кирилл","Ян","Марк","Алексей"};

    public static String[] secondNamesFemale = {
            "Степанова","Кузнецова","Антонова",
            "Щербакова"};

    public static String[] secondNamesMale = {
            "Морозов","Колесников","Абрамов",
            "Кузнецов"};

    public static String[] cityNames = {
            "Дебальцево","Докучаевск",
            "Донецк","Дружковка","Енакиево"};

    public static  String[]  professions = {
            "Терапевт","Педиатр","Отоларинголог","Рентгенолог","Офтальмолог",
            "Стоматолог"
    };

    public static String headerPeople =
            "<html><table border='1' >" +
                    "<thead><tr>" +
                    "<th>Фамилия</th>" +
                    "<th>Имя</th>" +
                    "<th>Возраст</th>" +
                    "<th>Город</th>" +
                    "<th>Профессия</th>" +
                    "<th>Оклад</th>" +
                    "</tr></thead><tbody>";

    public static String headerCitizensQuery05 =
            "<html><table border='1' >" +
                    "<thead><tr>" +
                    "<th>Город</th>" +
                    "<th>Количество жителей</th>" +
                    "</tr></thead><tbody>";

    public static String headerGoods =
            "<html><table border='1' >" +
                    "<thead><tr>" +
                    "<th>Наименование товара </th>" +
                    "<th>Количество</th>" +
                    "<th>Цена ед. товара</th>" +
                    "<th>Стоимость</th>" +
                    "</tr></thead><tbody>";
}
