package itstep.pd011.app.controllers;

import itstep.pd011.app.utils.Utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

public class Task02Controller {

    private static final String textInit = "Дан  текстовый            \n файл из нескольких         строк слова \n в котором разделяются " +
            "пробелами \n символами конца строки  \n            Реализовать обработки";

    private String curText;

    private List<String> s;
    private static final String FILENAME = "app_data/text.txt";

    public Task02Controller() {

        s = new ArrayList<>();

        try {

            if (Files.notExists(Paths.get(FILENAME)))
                write(textInit);
            else
                load();

        } catch (Exception ex) {
            ex.printStackTrace();
        } // try-catch
    }

    private void load() throws IOException {

        StringBuilder sb = new StringBuilder();

        try (Scanner sc = new Scanner(new File(FILENAME))) {

            while (sc.hasNext()) {
                sb.append(sc.nextLine()).append("\n");
            }

        }
        curText = sb.toString();
    }

    public void write(String str) throws IOException {

        // если папки data нет - создать папку
        File dir = new File("app_data");
        if (!dir.exists()) dir.mkdir();

        try (PrintWriter pwr = new PrintWriter(FILENAME)) {
            pwr.printf(str);
        }
    }

    public void run(){

        //вывод исходной строки
        System.out.println("\n" + curText);

        //Преобразовать строку, оставив между словами по одному пробелу
        doTask02();


    }


    //Преобразовать строку, оставив между словами по одному пробелу
    private void doTask02(){

        StringTokenizer stz = new StringTokenizer(curText, " \t\n");

        // разбиение на токены
        for (int i = 0; stz.hasMoreTokens(); i++) {
            s.add(stz.nextToken());
        } // for i

        //склеиваем массив строк в одну строку через пробел
        curText = String.join(" ", s);

        System.out.println(curText);

    }

    //Для всех слов, из которых состоит текст определить: количество слов, суммарное количество букв в словах,
    // минимальная длина слова, максимальная длина слова, средняя длина слова
    private void doTask03(){

        //В разработке
    }
}
