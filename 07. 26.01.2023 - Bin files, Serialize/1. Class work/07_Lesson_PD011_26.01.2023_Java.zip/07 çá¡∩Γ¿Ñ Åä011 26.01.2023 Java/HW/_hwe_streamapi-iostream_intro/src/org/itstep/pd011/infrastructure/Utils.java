package org.itstep.pd011.infrastructure;

import java.security.InvalidParameterException;
import java.util.Arrays;
import java.util.Locale;
import java.util.Random;
import java.util.function.Predicate;

public class Utils {
    private static final Random random = new Random();

    // формирование случайных чисел типа int
    public static int getRandom(int lo, int hi) {
        return lo + random.nextInt(hi - lo);
    }  // getRandom

    // формирование случайных чисел типа double
    public static double getRandom(double lo, double hi) {
        return lo + (hi - lo)*random.nextDouble();
    }  // getRandom

    // заполнение массива целых чисел
    public static void fill(int[] data, int lo, int hi) {
        for (int i = 0; i < data.length; i++) {
            int temp = getRandom(lo, hi);
            if (Math.abs(temp) <= 2) temp = 0;
            data[i] = temp;
        } // for i
    } // fill

    // создание и заполнение массива целых чисел
    public static int[] create(int n, int lo, int hi) {
        if (n <= 0)
            throw new InvalidParameterException("Отрицательный размер массива");
        var data = new int[n];

        fill(data, lo, hi);
        return data;
    } // create


    // создание и заполнение массива вещественных чисел
    public static double[] create(int n, double lo, double hi) {
        if (n <= 0)
            throw new InvalidParameterException("Отрицательный размер массива");
        var data = new double[n];

        fill(data, lo, hi);
        return data;
    } // create

    // заполнение массива вещественных чисел
    public static void fill(double[] data, double lo, double hi) {

        // заполнение массива
        for (int i = 0; i < data.length; i++) {
            // генерация данных с формированием 0
            double temp = getRandom(lo, hi);
            if (Math.abs(temp) <= 1.5) temp = 0;
            data[i] = temp;
        } // for i
    } // fill


    // вывод массива в строку, выделяем цветом положительные элементы массива,
    // элементы массива, равные заданному предикатом
    public static StringBuilder arrayToStringBuilder(double[] arr, String title, Predicate<Double> predicate) {
        StringBuilder sbr = new StringBuilder(title);

        for (int i = 0; i < arr.length; i++) {
            var t = arr[i];
            sbr.append(String.format(Locale.UK,"  %s  %8.2f \033[0m", (predicate.test(t)?"\033[1;34m":t > 0?"\033[1;31m":""), t));
            if ((i+1) % 10 == 0) sbr.append("\n");
        } // for i
        if (arr.length % 10 != 0) sbr.append("\n");

        return sbr;
    } // arrayToStringBuilder


    // вывод массива в строку, выделяем цветом элементы массива,
    // размещенные по указанному индексу и после него
    public static StringBuilder arrayToStringBuilder(double[] arr, String title, int index) {
        StringBuilder sbr = new StringBuilder(title);

        for (int i = 0; i < arr.length; i++) {
            var t = arr[i];
            sbr.append(String.format(Locale.UK, " %s  %8.2f \033[0m", (i == index?"\033[1;34m":i > index?"\033[1;31m":""), t));
            if ((i+1) % 10 == 0) sbr.append("\n");
        } // for i
        if (arr.length % 10 != 0) sbr.append("\n");

        return sbr;
    } // arrayToStringBuilder

    // вывод массива в строку, выделяем цветом положительные элементы массива,
    // элементы массива, равные заданному предикатом
    public static StringBuilder arrayToStringBuilder(int[] arr, String title, Predicate<Integer> predicate) {
        StringBuilder sbr = new StringBuilder(title);

        for (int i = 0; i < arr.length; i++) {
            var t = arr[i];
            sbr.append(String.format("  %s  %8d \033[0m", (predicate.test(t)?"\033[1;34m":t > 0?"\033[1;31m":""), t));
            if ((i+1) % 10 == 0) sbr.append("\n");
        } // for i
        if (arr.length % 10 != 0) sbr.append("\n");

        return sbr;
    } // arrayToStringBuilder

    // вывод массива в строку, выделяем цветом элементы массива,
    // размещенные по указанному индексу и после него
    public static StringBuilder arrayToStringBuilder(int[] arr, String title, int index) {
        StringBuilder sbr = new StringBuilder(title);

        for (int i = 0; i < arr.length; i++) {
            var t = arr[i];
            sbr.append(String.format(Locale.UK, " %s  %8d \033[0m", (i == index?"\033[1;34m":i > index?"\033[1;31m":""), t));
            if ((i+1) % 10 == 0) sbr.append("\n");
        } // for i
        if (arr.length % 10 != 0) sbr.append("\n");

        return sbr;
    } // arrayToStringBuilder


    // проверка на равенствор для типов double и float, проверяем с тчоностью
    // до 6 знаков после запятой
    public static boolean equals(double a, double b) { return Math.abs(a - b) < 1e-6; }
    public static boolean equals(float a, float b) { return Math.abs(a - b) < 1e-6; }


    // преобразование массива int[] в массив Integer[]
    public static Integer[] toIntegerArray(int[] data) {
        Integer[] result = new Integer[data.length];

        int i = 0;
        for(var datum:data) {
            result[i++] = datum;
        }
        return result;
    } // toDoubleArray



    // преобразование массива Integer[] в массив int[]
    public static int[] intArray(Integer[] data) {
        var result = new int[data.length];

        int i = 0;
        for(var datum:data) {
            result[i++] = datum;
        }
        return result;
    } // intArray


} // class Utils
