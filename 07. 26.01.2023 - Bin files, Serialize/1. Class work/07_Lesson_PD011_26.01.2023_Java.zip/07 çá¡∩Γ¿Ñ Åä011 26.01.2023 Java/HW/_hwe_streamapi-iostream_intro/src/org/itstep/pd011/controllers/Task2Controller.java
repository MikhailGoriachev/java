package org.itstep.pd011.controllers;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

/*
* Задача 2.
* Дан текстовый файл из нескольких строк, слова в котором разделяются пробелами
* (одним или несколькими), символами конца строки. Реализовать обработки:
*     • Вывести текстовый файл в консоль, сохраняя разбивку текста на строки
*     • Преобразовать файл, оставив между словами по одному пробелу
*     • Для всех слов, из которых состоит текст определить: количество слов,
*       суммарное количество  букв в словах, минимальная длина слова,
*       максимальная длина слова, средняя длина слова
* */
public class Task2Controller {

    // выполнение всех обработок по заданию
    public void run() {
        String fileNameSrc = "app_data/src_test.txt";
        String fileName = "app_data/test.txt";
        try {

            // копировать файл для преобразований из резервной копии
            Path file = Paths.get(fileName);
            if (Files.exists(file)) {
                Files.delete(file);
            } // if
            Files.copy(Paths.get(fileNameSrc), file);

            // показать исходный файл
            showFile(fileName, "\nФайл до обработки:");

            // переформирование файла
            compressFile(fileName);
            showFile(fileName, "\nФайл преобразован, между словами оставили  по одному пробелу:");

            // статистика по длине слов текста
            doStatistics(fileName);
        } // try
        catch (IOException ex) {
            ex.printStackTrace();
        } // catch
    } // run

    // Вывести текстовый файл в консоль, сохраняя разбивку текста на строки
    public void showFile(String fileName, String title) {
        System.out.println("Файл \"" + fileName + "\" " + title);

        // Построчное чтение текстового файла, вывод его в консоль
        try (Scanner sc = new Scanner(new FileReader(fileName))) {
            String str;
            int lineNumber = 1;

            // пока не достигнут конец файла
            while (sc.hasNext()) {
                str = sc.nextLine();
                System.out.printf("    %04d | %-80s |\n", lineNumber++, str);
            } // while
        } catch (IOException ex) {
            ex.printStackTrace();
        } // try-catch
    } // showFile

    // Преобразовать файл, оставив между словами по одному пробелу
    // (ведущие и хвостовые пробелы тоже отбрасываем)
    public void compressFile(String fileName) {
        String fileNameTemp = fileName + ".tmp";
        // Построчное чтение текстового файла
        try (Scanner sc = new Scanner(new FileReader(fileName));
             PrintWriter pwr = new PrintWriter(fileNameTemp)) {
            String str;

            // пока не достигнут конец файла
            while (sc.hasNext()) {
                // читаем строку из файла, убираем ведущие и хвостовые пробелы
                str = sc.nextLine().trim();

                // порезать строку на токены по пробелам, убрать пустые строки
                var tokens = str.split(" ");
                tokens = Arrays.stream(tokens).filter(t -> !t.isEmpty() && !t.isBlank()).toArray(String[]::new);

                // соединить токены в строку, использовать один пробел для соединения
                str = String.join(" ", tokens);

                // вывести строку во временный файл
                pwr.println(str);
            } // while

            // закрыть оба файловых потока
            sc.close();
            pwr.close();

            // удалить исходный файл
            // Path path = Paths.get(fileName);
            // Files.delete(path);
            // переименовать временный файл в исходный
            // new File(fileNameTemp).renameTo(path.toFile());

            // через File
            var file = new File(fileName);
            file.delete();

            // переименовать временный файл в исходный
            new File(fileNameTemp).renameTo(file);
        } catch (IOException ex) {
            ex.printStackTrace();
        } // try-catch
    } // compressFile


    // Для всех слов, из которых состоит текст определить: количество слов,
    // суммарное количество букв в словах, минимальная длина слова,
    // максимальная длина слова, средняя длина слова
    public void doStatistics(String fileName) {
        try {
            // читаем текстовый файл одной операцией
            String text = Files.readString(Paths.get(fileName), StandardCharsets.UTF_8);
            text = text.replace("\t", " ");
            text = text.replace("\n", " ");
            text = text.replace("\r", " ");

            // разбить строку на токены (слова), удалить пустые токены
            var tokens = Arrays.stream(text.split(" "))
                .filter(t -> !t.isEmpty() && !t.isBlank())
                .sorted(Comparator.comparingInt(String::length))
                .toList();

            int i = 1;
            for(var t:tokens) {
                System.out.printf("%-22s", t);
                if (i++ % 6 == 0) System.out.println();
            } // for i

            // статистика по длине слов текста
            // вывод статистики
            System.out.printf("\n\n\tКоличество слов         : %5d\n", tokens.size());

            // суммарное количество букв в словах
            long sumLetters = tokens.stream()
                .map(String::length)
                .reduce((acc, t) -> acc + t).get();
            System.out.printf("\tВсего букв в словах     : %5d\n", sumLetters);

            // Минимальная длина слова
            long minLength = tokens.stream()
                .map(String::length)
                .min(Integer::compareTo).get();
            System.out.printf("\tМинимальная длина слова : %5d\n", minLength);

            // Максимальная длина слова
            long maxLength = tokens.stream()
                .map(String::length)
                .max(Integer::compareTo).get();
            System.out.printf("\tМаксимальная длина слова: %5d\n", maxLength);

            // Средняя длина слова
            double avgLength = (double)sumLetters / tokens.size();
            System.out.printf("\tСредняя длина слова     : %5.0f\n\n", avgLength);
        } catch (Exception ex) {
            ex.printStackTrace();
        } // try-catch
    } // doStatistics
} // class Task2Controller
