package org.itstep.pd011.models;

import java.security.InvalidParameterException;
import java.util.Locale;

/*
* Житель города описывается полями:
* фамилия, имя, возраст, рост, название города.
* */
public class Citizen {
    // фамилия
    private String surname;

    // имя
    private String name;

    // возраст
    private int age;

    // рост в см
    private double height;

    // название города
    private String city;

    public Citizen() {
        this("Локтионов", "Владимир", 67, 90, "Иловайск");
     } // Citizen

    public Citizen(String surname, String name, int age, double height, String city) {
        this.surname = surname;
        this.name = name;
        this.age = age;
        this.height = height;
        this.city = city;
    } // Citizen


    // создание объекта из строки в формате CSV
    public Citizen(String csv) {
        String[] tokens = csv.split("; ");
        if (tokens.length != 5) {
            throw new InvalidParameterException("Ошибка формата при разборе CSV-строки");
        } // if

        surname = tokens[0];
        name = tokens[1];
        age = Integer.parseInt(tokens[2]);
        height = Double.parseDouble(tokens[3]);
        city = tokens[4];
    } // Citizen

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public String toCsv() {
        return String.format(Locale.UK,
            "%s; %s; %d; %.2f; %s", surname, name, age, height, city);
    } // toCsv

    // костыльное решение - номер строки для вывода сведений
    // о книге в формате строки таблицы
    public static int row = 1;

    @Override
    public String toString() {
        return String.format(Locale.UK,
            "%s %s, %d %.2f см, %s", surname, name, age, height, city);
    } // toString

    // Формирование строки таблицы с инкрементом номера строки таблицы
    public String toTableRow() {
        return String.format(
            "│ %5d │ %-26s │ %-22s │ %7d │ %8.2f │ %-22s │", row++, surname, name, age, height, city);
    } // toTableRow

    // вывод заголовка таблицы вывода
    public static final String HEADER =
            "\t┌───────┬────────────────────────────┬────────────────────────┬─────────┬──────────┬────────────────────────┐\n" +
            "\t│ Номер │ Фамилия                    │ Имя                    │ Возраст │ Рост, см │ Город проживания       │\n" +
            "\t├───────┼────────────────────────────┼────────────────────────┼─────────┼──────────┼────────────────────────┤";

    // нижнаяя строка рамки таблицы вывода
    public static final String FOOTER =
            "\t└───────┴────────────────────────────┴────────────────────────┴─────────┴──────────┴────────────────────────┘";

} // class Citizen
