package org.itstep.pd011;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(name = "secondServlet", value="/second-servlet")
public class SecondServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        response.setContentType("text/html");

        // получить данные из формы (т.е. из заголовка post-запроса
        double r = Double.parseDouble(request.getParameter("r"));
        double h = Double.parseDouble(request.getParameter("h"));
        String material= request.getParameter("material");

        // массив значений
        String[] params = request.getParameterValues("param");

        String title = "";
        double p = 0;

        switch (material){
            case "copper" ->{
                title = "медь";
                p = 8933;
            }

            case "steel" ->{
                title = "сталь";
                p = 7900;
            }

            case "basalt" ->{
                title = "базальт";
                p = 2970;
            }

            case "ice" ->{
                title = "лед";
                p = 916;
            }
        }

        double area = 2*Math.PI*r*(r+h);
        double volume = Math.PI*r*r*h;
        double weight = volume*p;

        String param01 = "Площадь: не выбрано";
        String param02 = "Объем: не выбрано";
        String param03 = "Масса: не выбрано";

        for(String param: params){
            switch (param){
                case "area" -> param01 = String.format("Площадь: %.2f",area);
                case "volume" -> param02 = String.format("Объем: %.2f",volume);
                case "weight" -> param03 = String.format("Масса: %.2f, материал: %s, плотность %.2f кг/m3",weight,title,p);
            }
        }

        //ServletContext servletContext = getServletContext();
        request.setAttribute("r", String.format("%.2f",r));
        request.setAttribute("h", String.format("%.2f",h));

        request.setAttribute("area", param01);
        request.setAttribute("volume", param02);
        request.setAttribute("weight", param03);

        getServletContext()
                .getRequestDispatcher("/result.jsp")
                .forward(request, response);

    } // doPost

}
