package org.itstep.pd011;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.Arrays;
import java.util.Date;

@WebServlet(name = "firstServlet", value = "/first-servlet")
public class FirstServlet extends HttpServlet {

    // реакция на get-запрос
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        String msg = String.format("Дата: %1$td.%1$tm.%1$tY Время: %1$tH:%1$tM:%1$tS", new Date());

        //выдает ошибку когда: Cookie cookie = new Cookie("date", msg);
        Cookie cookie = new Cookie("date", "Дата:"); //
        cookie.setMaxAge(20);     // время жизни в секундах, -1: живет до закрытия браузера
        response.addCookie(cookie);

        request.setAttribute("date", String.format("%1$td.%1$tm.%1$tY",new Date()));
        request.setAttribute("time", String.format("%1$tH:%1$tM:%1$tS",new Date().getTime()));

        Cookie[] cookies = request.getCookies();
        String cookieName = "date";
        cookie = null;

        String answer = "";

        // если куки получены, пытаемся найти в ни куки с именем date
        if (cookies != null) {
            cookie = Arrays.stream(cookies).filter(c -> c.getName().equals(cookieName)).findFirst().get();
        } // if

        if (cookie != null) {
            answer = "Еще рано, подождите, ничего не изменилось";
        } else {
            answer = "20 секунд прошло";
        } //

        request.setAttribute("answer", answer);

        getServletContext()
                .getRequestDispatcher("/date.jsp")
                .forward(request, response);
    }
}
