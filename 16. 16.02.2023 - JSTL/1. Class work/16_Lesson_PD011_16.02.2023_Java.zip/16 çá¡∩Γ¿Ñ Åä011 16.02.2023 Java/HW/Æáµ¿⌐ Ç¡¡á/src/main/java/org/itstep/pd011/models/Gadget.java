package org.itstep.pd011.models;

/*(тип, производитель, год выпуска, операционная система, цена).*/

public class Gadget {

    private String type;
    private String maker;
    private int year;
    private String operatingSystem;
    private int price;

    public Gadget(String type, String maker, int year, String operatingSystem, int price) {
        this.type = type;
        this.maker = maker;
        this.year = year;
        this.operatingSystem = operatingSystem;
        this.price = price;
    }

    @Override
    public String toString() {
        return String.format("<tr>" +
                "<td>%s</td>"+
                "<td>%s</td>"+
                "<td>%s</td>"+
                "<td>%s</td>"+
                "<td>%s</td>"+
                "</tr>",type,maker,year, operatingSystem,price);
    }
}
