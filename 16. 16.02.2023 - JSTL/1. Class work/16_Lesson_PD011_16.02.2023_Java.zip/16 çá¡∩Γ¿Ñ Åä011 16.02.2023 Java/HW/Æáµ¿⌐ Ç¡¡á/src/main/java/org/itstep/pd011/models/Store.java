package org.itstep.pd011.models;

import java.util.ArrayList;
import java.util.List;

public class Store {

    // название склада
    private String name;

    List<Gadget> gadgetList;

    // Используем шаблон одиночка
    private static Store instance = null;

    public static synchronized Store getInstance() throws Exception {
        if(instance == null)
            instance = new Store();
        return instance;
    }

    public Store(){
        name = "Склад № 1";
        gadgetList = new ArrayList<>(List.of(
                new Gadget("фитнес-браслет", "Ritmix", 2021, "none", 2_110),
                new Gadget("фитнес-браслет", "Xiaomi", 2022, "none", 3_790),
                new Gadget("фитнес-браслет", "Xiaomi", 2020, "none", 1_490),
                new Gadget("фитнес-браслет", "Huawei", 2022, "Tizen", 4_590),
                new Gadget("беспроводные наушники", "Xiaomi", 2022, "none", 3_600),
                new Gadget("умный чайник", "Xiaomi", 2022, "none", 6_100),
                new Gadget("умный чайник", "Kitfort", 2022, "Tizen", 8_320),
                new Gadget("смарт-часы", "Xiaomi", 2022, "Tizen", 14_999),
                new Gadget("смарт-часы", "Realme", 2021, "Android", 3_590),
                new Gadget("весы напольные", "Polaris", 2022, "none", 1_290),
                new Gadget("весы кухонные", "Redmond", 2022, "none", 1_360),
                new Gadget("беспроводные наушники", "Accesstyle", 2021, "none", 1_490),
                new Gadget("проводные наушники", "Xiaomi", 2021, "none", 4_999)
        ));
    }

    public void add(String type, String maker, int year, String operatingSystem, int price){
        gadgetList.add(new Gadget(type,maker,year,operatingSystem,price));
    }

    public StringBuilder toTable(){
        StringBuilder sb = new StringBuilder("<table class=\"table\">" +
                "  <thead>" +
                "    <tr>" +
                "      <th>Тип</th>" +
                "      <th>Производитель</th>" +
                "      <th>Год выпуска</th>" +
                "      <th>Операционная система</th>" +
                "      <th>Цена</th>" +
                "    </tr>" +
                "  </thead>");

        gadgetList.forEach(sb::append);

        sb.append("</tbody>" +
                "</table>");

        return sb;
    }
}
