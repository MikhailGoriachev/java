package org.itstep.pd011;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import org.itstep.pd011.models.Store;

@WebServlet(name = "thirdServlet", value="/third-servlet")
public class ThirdServlet extends HttpServlet {

    private Store store;

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            store = Store.getInstance();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // реакция на get-запрос
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        request.setAttribute("store", store);

        request
                .getServletContext()
                .getRequestDispatcher("/gadgets.jsp")
                .forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        // получить данные из формы (т.е. из заголовка post-запроса
        String type = request.getParameter("type");
        String maker = request.getParameter("maker");
        String operatingSystem = request.getParameter("operatingSystem");

        int year = Integer.parseInt(request.getParameter("year"));
        int price = Integer.parseInt(request.getParameter("price"));

        store.add(type,maker,year,operatingSystem,price);

        doGet(request,response);
    }

}
