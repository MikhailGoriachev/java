package servlets;

import Infrastructure.Utils;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import models.gadgets.GadgetsContainer;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/gadgets")
public class GadgetsServlet extends HttpServlet {

    //Гаджеты
    static GadgetsContainer gadgetsContainer;

    static {
        gadgetsContainer = new GadgetsContainer();
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        //Настроить параметры ответа
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        request.setAttribute("gadgets",gadgetsContainer.gadgets);
        request.setAttribute("message","Исходная коллекция");

        //Переход в JSP
        getServletContext().getRequestDispatcher("/gadgetsTable.jsp")
                            .forward(request,response);
    } //doGet

    //Добавление элемента
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        //Настроить параметры ответа
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        //Производитель

        String dropDownValue = request.getParameter("brand");
        String brand = dropDownValue.contains("другое") ? request.getParameter("brandField") : dropDownValue;

        //Если значение введено из поля - добавить в список
        if (dropDownValue.contains("другое") && !Utils.brands.contains(brand) && !brand.isBlank())
            Utils.brands.add(brand);

        //Модель
        dropDownValue = request.getParameter("model");
        String model = dropDownValue.contains("другое")  ? request.getParameter("modelField") : dropDownValue;

        //Если значение введено из поля - добавить в список
        if (dropDownValue.contains("другое") && !Utils.models.contains(model) && !model.isBlank())
            Utils.models.add(model);

        //ОС
        String os = request.getParameter("system");

        //Год производства
        int produced =  Integer.parseInt(request.getParameter("prod_year"));

        //Стоимость
        int price =  Integer.parseInt(request.getParameter("price"));

        gadgetsContainer.addGadget(brand, model, produced, os, price);

        //Задать параметры
        request.setAttribute("gadgets",gadgetsContainer.gadgets);
        request.setAttribute("message",
                String.format("Добавлен элемент с id: %d",gadgetsContainer.gadgets.get(gadgetsContainer.gadgets.size()-1).id));

        //Переход в JSP
        getServletContext().getRequestDispatcher("/gadgetsTable.jsp")
                            .forward(request,response);

    }//doPost

}
