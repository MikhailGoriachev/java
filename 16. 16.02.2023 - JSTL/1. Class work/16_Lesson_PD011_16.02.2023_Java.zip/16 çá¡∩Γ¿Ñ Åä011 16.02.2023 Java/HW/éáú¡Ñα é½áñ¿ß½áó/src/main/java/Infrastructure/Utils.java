package Infrastructure;

import java.util.Random;
import java.util.*;
public class Utils {

    //Генерация значений
    private static Random rand = new Random();

    public Utils() {
    }

    //Получение слуйчаных значений
    public static double getRandom(double lo, double hi) {
        return lo + rand.nextDouble() * (hi - lo);
    }

    public static int getRandom(int lo, int hi) {
        return lo + rand.nextInt(hi - lo);
    }

    //Сфомрировать выпадающий ссписок
    public static StringBuilder createDropDown(int index){

        StringBuilder sb = new StringBuilder();
        String option = "<option value=\"%1$s\">%1$s</option>";
        switch (index) {
            case 0 -> brands.forEach(b ->  sb.append( String.format(option,b) ));
            case 1 -> models.forEach(m ->  sb.append( String.format(option,m) ));
            case 2 -> Arrays.stream(systems).forEach(s -> sb.append( String.format(option,s) ));
        }

        return sb;
    }


    public static List<String> brands = new ArrayList<>(List.of(
            "Asus","Lenovo","HP","Microsoft","Dell","Apple", "Samsung", "Philips"
    ));

    public static List<String> models = new ArrayList<>(List.of(
            "A5","A2","A72","Surface Book","Pavilion"
    ));

    public static String[] systems = new String[]{
            "Windows",
            "MacOS",
            "IOS",
            "Android",
            "Linux",
    };


    //Бренд ноутбука
    public static String getBrand(){
        return brands.get(getRandom(0,brands.size()))/*brands[getRandom(0,brands.length)]*/;
    }

    //модель ноутбука
    public static String getModel(){
        return models.get(getRandom(0,models.size()))/*models[getRandom(0,models.length)]*/;
    }


    //Дефект ноутбука
    public static String getSystem(){
        return systems[getRandom(0, systems.length)];
    }



    //Объём накопителя
    public static int getPrice(){
        return getRandom(20,120)*1000;
    }



}
