package models;

public class Cylinder {

    public double radius;
    public double height;
    public String material;

    public Cylinder(double radius, double height, String material) {
        this.radius = radius;
        this.height = height;
        this.material = material;
    }

    //Расчёт объёма
    public double volume(){
        double v = Math.PI * (radius*radius) * height;

        return !Double.isNaN(v) ? v : 0;
    }

    //Расчёт массы
    public double mass(){
        double v = volume();

        //Плотность
        double density = switch (material) {
            case "Copper" -> DensitiesEnum.COOPER.getValue();
            case "Steel" -> DensitiesEnum.STEEL.getValue();
            case "Basalt" -> DensitiesEnum.BASALT.getValue();
            case "Ice" -> DensitiesEnum.ICE.getValue();
            default -> 1;
        };

        double m = v * density;

        return !Double.isNaN(m) ? m : 0;
    }

    //Расчёт площади
    public double square(){
        double s = 2 * Math.PI * radius * (height+radius);

        return !Double.isNaN(s) ? s : 0;
    }


}
