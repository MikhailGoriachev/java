package org.itstyep.pd011;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {

        // SpringApplication.run(SpringInitlzrApplication.class, args);
        System.out.println( "Hello World!" );
    }
}
