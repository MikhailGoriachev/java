package org.itstep.pd011.springinitlzr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringInitlzrApplicationTests {

    @Test
    void contextLoads() {
    }

}
