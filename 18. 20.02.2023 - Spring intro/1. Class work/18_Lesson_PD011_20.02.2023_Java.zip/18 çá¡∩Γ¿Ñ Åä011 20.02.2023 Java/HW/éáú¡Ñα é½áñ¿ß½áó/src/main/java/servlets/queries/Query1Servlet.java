package servlets.queries;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import models.appointments.AppointmentsImpl;
import models.exceptions.DaoException;
import models.patients.PatientsImpl;

import java.io.IOException;

@WebServlet("/query1")
public class Query1Servlet extends HttpServlet {

    private static PatientsImpl patientsImpl;

    //Статическая инициализация
    static {
        patientsImpl = new PatientsImpl();
    }

    //Получение коллекции
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Настроить параметры ответа
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        getServletContext()
                .getRequestDispatcher("/queries/query1.jsp")
                .forward(request,response);
    }

    //Задание параметров
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        //Настроить параметры ответа
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        //Последовательноть символов
        String symbols = request.getParameter("symbols");

        //Получить выборку
        try {
            request.setAttribute("patients",patientsImpl.query1(symbols));
            request.setAttribute("message",String.format("Пациеты с фамилиями начинающимися на '%s'",symbols));
        } catch (DaoException e) {
            throw new RuntimeException(e);
        }

        getServletContext()
                .getRequestDispatcher("/queries/query1.jsp")
                .forward(request,response);
    }

}
