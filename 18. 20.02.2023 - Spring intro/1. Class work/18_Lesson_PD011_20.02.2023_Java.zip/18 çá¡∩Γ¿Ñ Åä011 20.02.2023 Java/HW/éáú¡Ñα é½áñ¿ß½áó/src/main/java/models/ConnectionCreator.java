package models;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

// Генератор подключения к БД
public class ConnectionCreator {


    private static final String DB_URL = "jdbc:mysql://localhost/polyclinic_wagner?serverTimezone=Europe/Moscow&useSSL=true";
    private static final String USERNAME = "root";
    // private static final String PASSWORD = "A123456Qw1";
    private static final String PASSWORD = "___sP123456890...";

    // Статическая инициализация
    static {

        try {

            String driverName = "com.mysql.cj.jdbc.Driver";

            Class.forName(driverName);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }


    }

    private ConnectionCreator(){}

    //Создание подключения
    public static Connection createConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, USERNAME,PASSWORD);
    }

}
