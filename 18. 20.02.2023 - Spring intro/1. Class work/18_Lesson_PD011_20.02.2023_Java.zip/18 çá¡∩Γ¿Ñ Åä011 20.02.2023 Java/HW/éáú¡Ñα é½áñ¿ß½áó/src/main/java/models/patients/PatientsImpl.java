package models.patients;



import interfaces.PatientsDAO;
import models.ConnectionCreator;
import models.doctors.Doctor;
import models.exceptions.DaoException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

//Реализация интерфейсов DAO
public class PatientsImpl implements PatientsDAO {

    //Создание записи
    @Override
    public boolean create(Patient entity) throws DaoException {
        return false;
    }

    //Получение записей
    @Override
    public List<Patient> getAll() throws DaoException {
        String query = "select * from view_patients";

        try (Connection connection = ConnectionCreator.createConnection()) {

            //Оператор запросов
            Statement state = connection.createStatement();
            return patientsToList(state.executeQuery(query));
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Patient getById(Integer id) throws DaoException {
        String query = """
            select 
                * 
            from 
                view_patients 
            where id = ?
            """;
        //Открыть соединение
        try (Connection connection = ConnectionCreator.createConnection()){

            //Оператор запросов
            PreparedStatement ps = connection.prepareStatement(query);

            ps.setInt(1,id);

            //Выполнение запроса
            ResultSet set = ps.executeQuery();

            //Полуачемый объект
            Patient tempPatient = null;

            //Получение объекта
            while (set.next()){
                tempPatient = new Patient(
                        set.getInt("id"),
                        set.getString("patient_surname"),
                        set.getString("patient_name"),
                        set.getString("patient_patronymic"),

                        set.getDate("born_date"),
                        set.getString("address"),
                        set.getString("passport"));

            }

            return tempPatient;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    //Редактирование записи
    @Override
    public Patient update(Patient entity) throws DaoException {

        String query = """
                update patients
                set
                    patients.born_date = ?,
                    patients.passport = ?,
                    patients.address = ?
                where
                    patients.id = ?;
                """;

        try (Connection connection = ConnectionCreator.createConnection()){

            PreparedStatement ps = connection.prepareStatement(query);

            //Задать дату
            ps.setDate(1,entity.date());
            ps.setString(2,entity.passport());
            ps.setString(2,entity.address());
            ps.setInt(3,entity.id());

            //Выполнение запроса
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DaoException(e);
        }

        return getById(entity.id());
    }

    //Удаление записи - не определяется
    @Override
    public boolean delete(Patient entity) throws DaoException {

        throw new UnsupportedOperationException();
    }

    @Override
    public boolean delete(Integer id) throws DaoException {

        throw new UnsupportedOperationException();
    }

    //Запрос 1 - информацию о пациентах с фамилиями, начинающимися на заданную последовательность символов
    @Override
    public List<Patient> query1(String patientSurname) throws DaoException {
        String query = """
                select
                    *
                from
                    view_patients
                where
                    view_patients.patient_surname regexp concat('^', ?);
                """;

        //Создать оператор запроса
        try(Connection connection = ConnectionCreator.createConnection()) {

            //Оператор запросов с параметрами
            PreparedStatement ps = connection.prepareStatement(query);

            ps.setString(1,patientSurname);

            //Выполнение запроса
            ResultSet set = ps.executeQuery();

            return patientsToList(set);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    //Перевести набор данных из таблицы в коллекцию пациентов
    public List<Patient> patientsToList(ResultSet resultSet) throws SQLException {
        List<Patient> collection = new ArrayList<>();

        //Сформировать коллекцию из набора данных полученного при запросе
        while (resultSet.next()){
            collection.add(new Patient(
                    resultSet.getInt(1),
                    resultSet.getString("patient_surname"),
                    resultSet.getString("patient_name"),
                    resultSet.getString("patient_patronymic"),

                    resultSet.getDate("born_date"),
                    resultSet.getString("address"),
                    resultSet.getString("passport")
            ));
        }
        return collection;
    }
}
