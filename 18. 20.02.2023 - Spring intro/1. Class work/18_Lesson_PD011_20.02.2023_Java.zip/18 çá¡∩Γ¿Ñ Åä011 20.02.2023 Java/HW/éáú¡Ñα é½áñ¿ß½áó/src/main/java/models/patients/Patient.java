package models.patients;



import models.Entity;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Objects;

public final class Patient extends Entity {

    //Заголовок таблицы
    public static String HEADER =
            "<th>ID</th>" +
                    "<th>Фамилия  пациента</th>" +
                    "<th>Имя пациента</th>" +
                    "<th>Отчество пациента</th>" +
                    "<th>Адрес пациента</th>" +
                    "<th>Дата рождения</th>" +
                    "<th>Паспорт пациента</th>" +
                    "</tr>";
    private final int id;
    private final String surname;
    private final String name;
    private final String patronymic;
    private final Date date;
    private static SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
    private final String address;
    private final String passport;

    public Patient(int id,
                   String surname,
                   String name,
                   String patronymic,
                   Date date,
                   String address,
                   String passport
    ) {
        this.id = id;
        this.surname = surname;
        this.name = name;
        this.patronymic = patronymic;
        this.date = date;
        this.address = address;
        this.passport = passport;
    }

    //Строка таблицы
    public String toTableRow() {
        return String.format("""
                        <tr>
                            <td class='text-center p-2'> %1$d </td>
                            <td class='p-2'> %2$s </td>
                            <td class='p-2'> %3$s </td>
                            <td class='p-2'> %4$s </td>
                            <td class='p-2'> %5$s </td>
                            <td class='p-2'> %6$s </td>
                            <td class='p-2'> %7$s </td>
                        </tr>
                        """,
                id,
                surname, name, patronymic, address, dateFormat.format(date) , passport);
    }

    public int id() {
        return id;
    }

    public String surname() {
        return surname;
    }

    public String name() {
        return name;
    }

    public String patronymic() {
        return patronymic;
    }

    public Date date() {
        return date;
    }

    public String address() {
        return address;
    }

    public String passport() {
        return passport;
    }


    ;

}
