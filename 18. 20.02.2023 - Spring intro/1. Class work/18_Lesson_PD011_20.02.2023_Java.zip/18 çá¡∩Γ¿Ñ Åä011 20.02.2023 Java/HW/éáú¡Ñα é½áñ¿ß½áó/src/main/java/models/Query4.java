package models;


public record Query4(
        String date,
        int amount,
        int maxPrice) {


    //Строка таблицы
    public  String toTableRow (){
        return String.format(
                """
                   <tr>
                      <td class="text-center p-2"> %1$s </td>
                      <td class="p-2"> %2$d </td>
                      <td class="p-2"> %3$d </td>
                   </tr>
                   """,
                date,amount, maxPrice);
    };

}

