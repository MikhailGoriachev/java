package servlets.entities;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import models.doctors.DoctorsImpl;
import models.exceptions.DaoException;
import models.patients.PatientsImpl;

import java.io.IOException;

@WebServlet("/patients")
public class PatientServlet extends HttpServlet {
    public static PatientsImpl patientsImpl;

    static {
        patientsImpl = new PatientsImpl();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //Настроить параметры овтета
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        //Запись коллекции в атрибут
        try {

            request.setAttribute("patients", patientsImpl.getAll());
            request.setAttribute("message","Исходная коллекция");

        } catch (DaoException e) {
            throw new RuntimeException(e);
        }

        getServletContext()
                .getRequestDispatcher("/entities/patientsTable.jsp")
                .forward(request,response);

    }//doGet

}
