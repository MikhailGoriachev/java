package servlets.queries;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import models.ConnectionCreator;
import models.Query3;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


@WebServlet("/query3")
public class Query3Servlet extends HttpServlet {



    @Override
    public void init() throws ServletException {
        super.init();

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //Настроить параметры овтета
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");


        List<Query3> collection = new ArrayList<>();

        //Запрос
        String query = """
                select
                        id
                     , view_appointments.appointment_date
                     , view_appointments.doctor_surname
                     , view_appointments.doctor_name
                     , view_appointments.doctor_patronymic
                     
                     , view_appointments.speciality
                     
                     , view_appointments.price
                     , view_appointments.percent
                     , view_appointments.price * percent / 100 as salary
                from
                    view_appointments
                order by
                    view_appointments.speciality
                """;

        //Запуск оператора запроса
        try {
            Connection connection = ConnectionCreator.createConnection();

            //Оператор запросов
            Statement state = connection.createStatement();

            ResultSet result = state.executeQuery(query);

            //Сформировать коллекцию
            while (result.next()){
                collection.add(new Query3(
                        result.getInt("id"),

                        result.getString("appointment_date"),

                        result.getString("doctor_surname"),
                        result.getString("doctor_name"),
                        result.getString("doctor_patronymic"),

                        result.getString("speciality"),

                        result.getInt("price"),
                        result.getDouble("percent"),
                        result.getDouble("salary")

                ));
            }//while

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        request.setAttribute("queryResult",collection);

        getServletContext()
                .getRequestDispatcher("/queries/query3.jsp")
                .forward(request,response);

    }

}
