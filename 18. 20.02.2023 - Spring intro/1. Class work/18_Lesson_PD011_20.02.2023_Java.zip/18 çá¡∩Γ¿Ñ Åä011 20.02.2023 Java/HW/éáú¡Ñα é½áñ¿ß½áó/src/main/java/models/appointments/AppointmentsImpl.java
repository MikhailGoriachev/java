package models.appointments;


import interfaces.AppointmentsDAO;
import models.ConnectionCreator;
import models.exceptions.DaoException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;

public class AppointmentsImpl implements AppointmentsDAO {

    //Создание записи
    @Override
    public boolean create(Appointment entity) throws DaoException {
        String query = """
                insert into appointments
                (appointment_date, id_patient, id_doctor)
                values
                    (?,?,?
                    );
                """;

        boolean created = false;

        //Создать оператор запроса
        try(Connection connection = ConnectionCreator.createConnection()) {

            //Оператор запросов с параметрами
            PreparedStatement ps = connection.prepareStatement(query);

            //Задаём дату и параметры для подзапросов
            ps.setString(1,String.format("%1$tY-%1$tm-%1$td",entity.date));
            ps.setInt(2, entity.patientId);
            ps.setInt(3, entity.doctorId);

            //Выполнение запроса
            created = ps.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new DaoException(e);
        }

        return created;
    }

    //Получение записей
    @Override
    public List<Appointment> getAll() throws DaoException {
        String query = """
               select
                   *
               from view_appointments
                """;

        //Создать оператор запроса
        try {
            Connection connection = ConnectionCreator.createConnection();

            //Оператор запросов
            Statement state = connection.createStatement();

            //Выполнение запроса
            ResultSet set = state.executeQuery(query);

            //Коллекция сущностеей
            return this.appointmentsToList(set);

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

    @Override
    public Appointment getById(Integer id) throws DaoException {
        String query = """
               select
                   *
               from
                   view_appointments
               where
                   view_appointments.id = ? limit 1;
                """;

        //Создать оператор запроса
        try(Connection connection = ConnectionCreator.createConnection()) {

            //Оператор запросов
            PreparedStatement ps = connection.prepareStatement(query);

            ps.setInt(1,id);

            //Выполнение запроса
            ResultSet set = ps.executeQuery();

            //Полуачемый объект
            Appointment tempAppointment = null;

            //Получение объекта
            while (set.next()){
                tempAppointment = new Appointment(
                        set.getInt("id"),
                        set.getDate("appointment_date"),

                        set.getString("patient_surname"),
                        set.getString("patient_name"),
                        set.getString("patient_patronymic"),
                        set.getInt("id_patient"),

                        set.getDate("born_date"),
                        set.getString("address"),

                        set.getString("doctor_surname"),
                        set.getString("doctor_name"),
                        set.getString("doctor_patronymic"),
                        set.getInt("id_doctor"),

                        set.getString("speciality"),

                        set.getString("passport"),

                        set.getDouble("percent"),
                        set.getInt("price")
                );

            }

            return tempAppointment;

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

    //Редактирование записи
    @Override
    public Appointment update(Appointment entity) throws DaoException {
        //Поменять доктора для приема за определённую дату
        String query = """
                update appointments
                set
                    appointments.appointment_date = ?,
                    appointments.id_doctor = ?,
                    appointments.id_patient = ?
                where
                    appointments.id = ?;
                """;

        try (Connection connection = ConnectionCreator.createConnection()) {

            PreparedStatement ps = connection.prepareStatement(query);

                //Задать дату
                ps.setString(1,String.format("%1$tY-%1$tm-%1$td",entity.date));
                ps.setInt(2,entity.doctorId);
                ps.setInt(3,entity.patientId);
                ps.setInt(4,entity.id);

                //Выполнение запроса
                ps.executeUpdate();

        } catch (SQLException e) {
            throw new DaoException(e);
        }

        return getById(entity.id);
    }

    //Удаление записи
    @Override
    public boolean delete(Appointment entity) throws DaoException {
        return delete(entity.id);
    }

    @Override
    public boolean delete(Integer id) throws DaoException {

        //Удалить прием по определённому ID
        String query = """
                delete 
                from 
                    appointments
                where 
                    appointments.id = ?;
                """;

        boolean deleted = false;

        //Создать оператор запроса и подключение
        try(Connection connection = ConnectionCreator.createConnection()) {

            //Оператор запросов с параметрами
            PreparedStatement ps = connection.prepareStatement(query);

            ps.setInt(1,id);

            //Выполнение запроса
            deleted = ps.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new DaoException(e);
        }

        return deleted;
    }

    //Запрос 3 - выбрать записи на прием к врачу за заданный период
    @Override
    public List<Appointment> query2(Date from, Date to) throws DaoException {

        String query = """
                select
                    *
                from
                    view_appointments
                where
                    view_appointments.appointment_date between ? and ?
                """;

        //Создать оператор запроса
        try(Connection connection = ConnectionCreator.createConnection()) {

            //Оператор запросов с параметрами
            PreparedStatement ps = connection.prepareStatement(query);

            ps.setString(1,String.format("%1$tY-%1$tm-%1$td",from));
            ps.setString(2,String.format("%1$tY-%1$tm-%1$td",to));

            //Выполнение запроса
            ResultSet set = ps.executeQuery();

            return appointmentsToList(set);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    //Перевести в список
    public List<Appointment> appointmentsToList(ResultSet resultSet) throws SQLException {
        List<Appointment> collection = new ArrayList<>();

        while (resultSet.next()){
            collection.add(new Appointment(
                    resultSet.getInt("id"),
                    resultSet.getDate("appointment_date"),

                    resultSet.getString("patient_surname"),
                    resultSet.getString("patient_name"),
                    resultSet.getString("patient_patronymic"),
                    resultSet.getInt("id_patient"),

                    resultSet.getDate("born_date"),
                    resultSet.getString("address"),

                    resultSet.getString("doctor_surname"),
                    resultSet.getString("doctor_name"),
                    resultSet.getString("doctor_patronymic"),
                    resultSet.getInt("id_doctor"),

                    resultSet.getString("speciality"),

                    resultSet.getString("passport"),

                    resultSet.getDouble("percent"),
                    resultSet.getInt("price"))
            );
        }
        return collection;
    }

}
