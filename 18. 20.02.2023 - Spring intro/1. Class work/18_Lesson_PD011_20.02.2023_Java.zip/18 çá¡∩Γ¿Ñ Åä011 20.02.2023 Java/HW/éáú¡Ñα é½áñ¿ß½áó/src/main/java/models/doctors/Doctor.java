package models.doctors;

import models.Entity;

public class Doctor extends Entity {

    private final int id;
    private final String surname;
    private final String name;
    private final String patronymic;
    private final String speciality;
    private double percent;
    private int payment;

    public void setPercent(double percent) {
        this.percent = percent;
    }

    public void setPayment(int payment) {
        this.payment = payment;
    }

    public Doctor(
            int id,
            String surname,
            String name,
            String patronymic,
            String speciality,
            double percent,
            int payment) {
        this.id = id;
        this.surname = surname;
        this.name = name;
        this.patronymic = patronymic;
        this.speciality = speciality;
        this.percent = percent;
        this.payment = payment;
    }

    //Строка таблицы
    public String toTableRow() {
        return String.format("""
                        <tr>
                            <td class='text-center p-2'> %1$d </td>
                            <td class='p-2'> %2$s </td>
                            <td class='p-2'> %3$s </td>
                            <td class='p-2'> %4$s </td>
                            <td class='p-2'> %5$s </td>
                            <td class='p-2'> %6$d </td>
                            <td class='p-2'> %7$.2f </td>
                        </tr>
                        """,
                id,
                surname, name, patronymic, speciality, payment,percent );
    }

    public int id() {
        return id;
    }

    public String surname() {
        return surname;
    }

    public String name() {
        return name;
    }

    public String patronymic() {
        return patronymic;
    }

    public String speciality() {
        return speciality;
    }

    public double percent() {
        return percent;
    }

    public int payment() {
        return payment;
    }


    ;

}
