package models;

public record Query5(
        String speciality,
        int amount,
        double avgPercent) {

    //Заголовок таблицы
    public static String HEADER ="<tr>" +
            "<th>Специальность</th>" +
            "<th>Количество докторов</th>" +
            "<th>Средний %</th>" +
            "</tr>";

    //Строка таблицы
    public  String toTableRow (){
        return String.format(
                        """
                        <tr>
                            <td class="p-2">%1$s</td>
                            <td class="p-2">%2$d</td>
                            <td class="p-2">%3$.2f</td>
                        </tr>
                        """,
                speciality,amount, avgPercent);
    };

}