package servlets.entities;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/persons")
public class PersonsServlet extends HttpServlet {

    //Получение коллекции
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Настроить параметры овтета
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        getServletContext()
                .getRequestDispatcher("/entities/personsTable.jsp")
                .forward(request,response);
    }

    //Добавление/Редактирование
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        //Настроить параметры овтета
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        getServletContext()
                .getRequestDispatcher("/entities/personsTable.jsp")
                .forward(request,response);
    }

}
