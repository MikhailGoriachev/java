package servlets.entities;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


@WebServlet("/appointmentsFormServlet")
public class AppointmentsForm extends HttpServlet {

    //Получение параметров ссылки и передача их дальше в форму
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Если id задан не был, то будет 0
        int entId = request.getParameter("id") != null ? Integer.parseInt(request.getParameter("id")) : 0;

        Date date = null;
        //Получить дату из параметра строки запроса
        try {
            date = request.getParameter("date") != null ? new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("date")) : new Date();
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

        //Для выпадающих списков
        int doctorId = request.getParameter("id") != null ? Integer.parseInt(request.getParameter("doctor_id")) : 0;
        int patientId = request.getParameter("id") != null ? Integer.parseInt(request.getParameter("patient_id")) : 0;

        request.setAttribute("entity_id",entId);
        request.setAttribute("doctor_id",doctorId);
        request.setAttribute("patient_id",patientId);
        request.setAttribute("date",date);

        getServletContext()
                .getRequestDispatcher("/entities/appointmentsForm.jsp")
                .forward(request,response);
    }
}
