package servlets.entities;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import models.appointments.Appointment;
import models.appointments.AppointmentsImpl;
import models.exceptions.DaoException;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet("/appointmentsServlet")
public class AppointmentsServlet extends HttpServlet {

    //Класс для работы с БД
    private static AppointmentsImpl appointmentsImpl;

    //Статическая инициализация
    static {
        appointmentsImpl = new AppointmentsImpl();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Настроить параметры ответа
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        String message = "Врачебные приёмы";

        //Если задан параметр для удаления
        if (request.getParameter("delete") != null){
            int id = Integer.parseInt(request.getParameter("delete"));

            try {
                appointmentsImpl.delete(id);
                message = String.format("Удалён прием с id = %d",id);
            }
            catch (DaoException e) {
                throw new RuntimeException(e);
            }

        }

        //Запись коллекции в атрибут
        try {

            request.setAttribute("appointments",appointmentsImpl.getAll());
            request.setAttribute("message",message);

        } catch (DaoException e) {
            throw new RuntimeException(e);
        }


        getServletContext()
                .getRequestDispatcher("/entities/appointmentsTable.jsp")
                .forward(request,response);
    }

    //Добавление/Редактирование
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        //Настроить параметры ответа
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        //Получение параметров для редактирования/добавления
        int doctor_id = Integer.parseInt(request.getParameter("doctor"));
        int patient_id = Integer.parseInt(request.getParameter("patient"));

        //Получить дату
        Date date = new Date();

        try {

            date = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("date"));

        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

        //Создание объета сущности для редактирования или добавления
        //Id приёма будет == 0 в случае добавления записи или == id редактируемой записи
        Appointment appointment = new Appointment(Integer.parseInt(request.getParameter("appointment_id")),date,
                "","","",patient_id,null,
                "","","","",doctor_id,"","",0,0);

        String operation = request.getParameter("operation");
        String message = "";
        try {
            //Если происходит добавление
            if (operation.equalsIgnoreCase("create")) {
                appointmentsImpl.create(appointment);
                message = "Запись успешно добавлена";
            }
            else {
                appointmentsImpl.update(appointment);
                message = String.format("Запись с id %d отредактирована",appointment.id);
            }
        } catch (DaoException e) {
            throw new RuntimeException(e);
        }


        //Вывод обновлённой коллекции
        try {

            request.setAttribute("appointments",appointmentsImpl.getAll());
            request.setAttribute("message",message);

        } catch (DaoException e) {
            throw new RuntimeException(e);
        }


        getServletContext()
                .getRequestDispatcher("/entities/appointmentsTable.jsp")
                .forward(request,response);
    }

}
