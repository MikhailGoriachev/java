package Infrastructure;

import models.doctors.Doctor;
import models.doctors.DoctorsImpl;
import models.exceptions.DaoException;
import models.patients.Patient;
import models.patients.PatientsImpl;

import java.util.Random;
import java.util.*;
public class Utils {

    //Генерация значений
    private static Random rand = new Random();

    private static DoctorsImpl doctorsImpl = new DoctorsImpl();
    private static PatientsImpl patientsImpl = new PatientsImpl();

    public Utils() {
    }

    //Получение слуйчаных значений
    public static double getRandom(double lo, double hi) {
        return lo + rand.nextDouble() * (hi - lo);
    }

    public static int getRandom(int lo, int hi) {
        return lo + rand.nextInt(hi - lo);
    }

    //Сфомировать выпадающий список докторов
    public static StringBuilder createDoctorsDropDown(int id_doctor)  {

        //Коллекцияя докторов
        List<Doctor> doctors = new ArrayList<>();
        try {
            doctors = doctorsImpl.getAll();
        } catch (DaoException e) {
            throw new RuntimeException(e);
        }

        StringBuilder sb = new StringBuilder();
        String option = "<option %3$s value=\"%2$d\">%1$s</option>";

        doctors.forEach(d -> sb.append(String.format(option, String.format("%s.%s.%s - %s",d.surname(),d.name().charAt(0),d.patronymic().charAt(0), d.speciality()),
                d.id(), d.id() == id_doctor ? "selected" : ""
        )));


        return sb;
    }
    //Сфомировать выпадающий список фамилий пациентов
    public static StringBuilder createPatientsDropDown(int id_patient)  {

        //Коллекцияя докторов
        List<Patient> patients = new ArrayList<>();
        try {
            patients = patientsImpl.getAll();
        } catch (DaoException e) {
            throw new RuntimeException(e);
        }

        StringBuilder sb = new StringBuilder();
        String option = "<option %3$s value=\"%2$d\">%1$s</option>";

        patients.forEach(p -> sb.append(String.format(option, String.format("%s.%s.%s",p.surname(),p.name().charAt(0),p.patronymic().charAt(0)),
                p.id(), p.id() == id_patient ? "selected" : ""
        )));


        return sb;
    }



}
