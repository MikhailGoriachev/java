package servlets.queries;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import models.appointments.AppointmentsImpl;
import models.exceptions.DaoException;

import java.io.IOException;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

@WebServlet("/query2")
public class Query2Servlet extends HttpServlet {

    //Класс для работы с БД
    private static AppointmentsImpl appointmentsImpl;

    //Статическая инициализация
    static {
        appointmentsImpl = new AppointmentsImpl();
    }
    //Получение коллекции
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Настроить параметры ответа
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");


        request.setAttribute("message","");

        getServletContext()
                .getRequestDispatcher("/queries/query2.jsp")
                .forward(request,response);
    }

    //Задание параметров
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        //Настроить параметры ответа
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        Date dateStart = null;
        Date dateEnd = null;

        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
        SimpleDateFormat sdfParse = new SimpleDateFormat("yyyy-MM-dd");

        try {
            dateStart = !request.getParameter("date_start").isBlank() ? sdfParse.parse(request.getParameter("date_start")) : new Date();
            dateEnd = !request.getParameter("date_end").isBlank() ? sdfParse.parse(request.getParameter("date_end")) : new Date();

            request.setAttribute("appointments",appointmentsImpl.query2(dateStart,dateEnd));
            request.setAttribute( "message",String.format("Заданный период: от %s до %s",sdf.format(dateStart),sdf.format(dateEnd)) );

        } catch (ParseException | DaoException e) {
            throw new RuntimeException(e);
        }

        getServletContext()
                .getRequestDispatcher("/queries/query2.jsp")
                .forward(request,response);
    }

}
