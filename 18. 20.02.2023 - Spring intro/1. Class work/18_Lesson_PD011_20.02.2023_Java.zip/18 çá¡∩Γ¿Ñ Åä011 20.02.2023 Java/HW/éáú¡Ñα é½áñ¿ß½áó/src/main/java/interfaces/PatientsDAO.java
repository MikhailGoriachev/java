package interfaces;


import models.exceptions.DaoException;
import models.patients.Patient;

import java.sql.ResultSet;
import java.util.List;

//Расширяющий интерфейс для всех запросов
public interface PatientsDAO extends BaseDAO<Integer, Patient> {

    //Запрос 1 - информацию о пациентах с фамилиями, начинающимися на заданную последовательность символов
    List<Patient> query1(String patientSurname) throws DaoException;

}
