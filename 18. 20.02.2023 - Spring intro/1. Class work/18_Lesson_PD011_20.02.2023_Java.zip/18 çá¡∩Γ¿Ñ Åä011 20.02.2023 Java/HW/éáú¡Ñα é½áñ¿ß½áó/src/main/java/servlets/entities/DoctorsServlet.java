package servlets.entities;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import models.doctors.DoctorsImpl;
import models.exceptions.DaoException;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

@WebServlet("/doctors")
public class DoctorsServlet extends HttpServlet {

    public static DoctorsImpl doctorsImpl;

    static {
        doctorsImpl = new DoctorsImpl();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //Настроить параметры овтета
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        //Запись коллекции в атрибут
        try {

            request.setAttribute("doctors",doctorsImpl.getAll());
            request.setAttribute("message","Исходная коллекция");

        } catch (DaoException e) {
            throw new RuntimeException(e);
        }

        getServletContext()
                .getRequestDispatcher("/entities/doctorsTable.jsp")
                .forward(request,response);

    }

}
