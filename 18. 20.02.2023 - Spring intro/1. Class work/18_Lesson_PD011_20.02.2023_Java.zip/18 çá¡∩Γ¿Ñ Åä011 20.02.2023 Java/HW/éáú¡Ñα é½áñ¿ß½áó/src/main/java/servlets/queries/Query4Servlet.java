package servlets.queries;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import models.ConnectionCreator;
import models.Query3;
import models.Query4;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@WebServlet("/query4")
public class Query4Servlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //Настроить параметры овтета
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        List<Query4> collection = new ArrayList<>();

        //Запрос
        String query = """
                select
                    view_appointments.appointment_date as date,
                    count(*) as amount,
                    max(view_appointments.price) as maxPrice
                from
                    view_appointments
                group by
                    view_appointments.appointment_date
                """;

        //Запуск оператора запроса
        try (Connection connection = ConnectionCreator.createConnection()) {

            //Оператор запросов
            Statement state = connection.createStatement();

            ResultSet result = state.executeQuery(query);

            //Сформировать коллекцию
            while (result.next()){
                collection.add(new Query4(
                        result.getString("date"),
                        result.getInt("amount"),
                        result.getInt("maxPrice")
                ));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        request.setAttribute("queryResult",collection.stream().sorted((el1, el2) -> el2.amount() - el1.amount()).toList() );

        getServletContext()
                .getRequestDispatcher("/queries/query4.jsp")
                .forward(request,response);

    }

}
