package models.appointments;



import models.Entity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

public class Appointment extends Entity {
    public final int id;

    public Date date;
    public String patientSurname;
    public String patientName;
    public String patientPatronymic;

    public int patientId;
    public Date dob;
    public String address;
    public String doctorSurname;
    public String doctorName;

    public int doctorId;

    public String doctorPatronymic;
    public String speciality;
    public String passport;
    public double percent;
    public int price;

    public Appointment(
            int id,
            Date date,
            String patientSurname,
            String patientName,
            String patientPatronymic,
            int idPatient,
            Date dob,
            String address,
            String doctorSurname,
            String doctorName,
            String doctorPatronymic,
            int idDoctor,
            String speciality,

            String passport,
            double percent,
            int price

    ) {
        this.id = id;
        this.date = date;
        this.patientSurname = patientSurname;
        this.patientName = patientName;
        this.patientPatronymic = patientPatronymic;
        this.patientId = idPatient;
        this.dob = dob;
        this.address = address;
        this.doctorSurname = doctorSurname;
        this.doctorName = doctorName;
        this.doctorPatronymic = doctorPatronymic;
        this.doctorId = idDoctor;
        this.speciality = speciality;
        this.passport = passport;
        this.percent = percent;
        this.price = price;
    }

    public String toTableRow() {
        return String.format("""
                        <tr>
                            <td class='text-center p-2'>%1$d</td>
                            <td class='p-2'>%2$s</td>
                            <td class='p-2'>%3$s</td>
                            <td class='p-2'>%4$s</td>
                            <td class='p-2'>%5$s</td>
                            <td class='p-2'>%6$s</td>
                            <td class='p-2'>%7$s</td>
                            <td class='p-2'>%8$s</td>
                            <td class='p-2'>%9$d</td>
                            <td class='p-2'>%10$.2f</td>
                        </tr>
                        """,
                id,String.format("%s.%s.%s",doctorSurname,doctorName.charAt(0),doctorPatronymic.charAt(0)),
                speciality, String.format("%s.%s.%s",patientSurname,patientName.charAt(0),patientPatronymic.charAt(0)),
                new SimpleDateFormat("dd.MM.yyyy").format(date) ,address, new SimpleDateFormat("dd.MM.yyyy").format(dob),
                passport, price, percent);
    } // toTableRow

}
