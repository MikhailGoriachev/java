package servlets.queries;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import models.ConnectionCreator;
import models.Query4;
import models.Query5;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/query5")
public class Query5Servlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //Настроить параметры овтета
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        List<Query5> collection = new ArrayList<>();

        //Запрос
        String query = """
                select
                    view_appointments.speciality,
                    count(*) as amount,
                    avg(view_appointments.percent) as avgPercent
                from
                    view_appointments
                group by
                    view_appointments.speciality
                """;

        //Открыть соединение с БД
        try (Connection connection = ConnectionCreator.createConnection()) {

            //Оператор запросов
            Statement state = connection.createStatement();

            ResultSet result = state.executeQuery(query);

            //Сформировать коллекцию
            while (result.next()){
                collection.add(new Query5(
                        result.getString("speciality"),
                        result.getInt("amount"),
                        result.getInt("avgPercent")
                ));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        request.setAttribute("queryResult",collection);

        getServletContext()
                .getRequestDispatcher("/queries/query5.jsp")
                .forward(request,response);

    }

}
