package interfaces;



import models.appointments.Appointment;
import models.exceptions.DaoException;

import java.util.Date;
import java.util.List;

//Расширяющий интерфейс для всех запросов
public interface AppointmentsDAO extends BaseDAO<Integer, Appointment> {

    //Запрос 2 - выбрать записи на прием к врачу за заданный период
    List<Appointment> query2(Date from, Date to) throws DaoException;

}
