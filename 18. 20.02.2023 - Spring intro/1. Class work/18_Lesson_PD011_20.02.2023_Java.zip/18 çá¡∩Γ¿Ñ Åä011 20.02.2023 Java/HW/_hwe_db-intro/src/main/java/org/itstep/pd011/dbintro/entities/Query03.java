package org.itstep.pd011.dbintro.entities;

import java.sql.Date;

// сведения о приемах с вычисляемым полем - размером оплаты
public record Query03(
    int id,
    Date date,
    String doctorSurname,
    String doctorName,
    String doctorPatronymic,
    String categoryName,
    double price,
    double interest,

    // вычисляемое при выполнении запроса поле - начисление доктору за прием
    double salary
) {
} // record Query03
