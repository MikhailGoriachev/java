package org.itstep.pd011.dbintro.entities;

import org.itstep.pd011.dbintro.dao.Entity;

import java.sql.Date;

// пациенты
public class Patient extends Entity {
    private int id;
    private String surname;
    private String name;
    private String patronymic;
    private Date dob;
    private String address;

    public Patient() {
    }

    public Patient(int id, String surname, String name, String patronymic, Date dob, String address) {
        this.id = id;
        this.surname = surname;
        this.name = name;
        this.patronymic = patronymic;
        this.dob = dob;
        this.address = address;
    }

    public int getId() {
        return id;
    }

    public String getSurname() {
        return surname;
    }

    public String getName() {
        return name;
    }

    public String getPatronymic() {
        return patronymic;
    }

    public Date getDob() {
        return dob;
    }

    public String getAddress() {
        return address;
    }

    // представление объекта класса в виде стоки таблицы
    public String toTableRow() {
        // форматирование даты http://proglang.su/java/date-and-time#formatirovanie-daty-s-pomoschyu-printf
        // %td - день   %tm - месяц   %tY - год
        return String.format(
            "│ %1$3d │ %2$-20s │ %3$-16s │ %4$-22s │    %5$td.%5$tm.%5$tY │ %6$-34s │",
            // "│ %3d │ %-20s │ %-15s │ %-20s │ %-20s │ %6$-36s │",
            id, surname, name, patronymic, dob, address
        );
    } // toTableRow

    public static final String HEADER =
        "\t┌─────┬──────────────────────┬──────────────────┬────────────────────────┬───────────────┬────────────────────────────────────┐\n"+
        "\t│  Ид │ Фамилия              │ Имя              │ Отчество               │ Дата рождения │ Адрес проживания                   │\n"+
        "\t├─────┼──────────────────────┼──────────────────┼────────────────────────┼───────────────┼────────────────────────────────────┤\n";

    public static final String FOOTER =
        "\t└─────┴──────────────────────┴──────────────────┴────────────────────────┴───────────────┴────────────────────────────────────┘\n";
} // record Patient
