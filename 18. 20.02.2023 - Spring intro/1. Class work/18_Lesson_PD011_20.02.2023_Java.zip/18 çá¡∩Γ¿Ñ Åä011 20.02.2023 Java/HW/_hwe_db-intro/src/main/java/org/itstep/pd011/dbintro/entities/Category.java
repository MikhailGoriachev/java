package org.itstep.pd011.dbintro.entities;

import org.itstep.pd011.dbintro.dao.Entity;

// сведения о врачебных специальностях
public class Category extends Entity {

    private int id;
    private String categoryName;

    public int getId() {
        return id;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public String toTableRow() {
        return String.format("│ %3d │ %-28s │", id, categoryName);
    } // toTableRow

    public static final String HEADER =
        "\t┌─────┬──────────────────────────────┐\n"+
        "\t│  Ид │ Врачебная специальность      │\n"+
        "\t├─────┼──────────────────────────────┤\n";

    public static final String FOOTER =
        "\t└─────┴──────────────────────────────┘\n";
} // class Category
