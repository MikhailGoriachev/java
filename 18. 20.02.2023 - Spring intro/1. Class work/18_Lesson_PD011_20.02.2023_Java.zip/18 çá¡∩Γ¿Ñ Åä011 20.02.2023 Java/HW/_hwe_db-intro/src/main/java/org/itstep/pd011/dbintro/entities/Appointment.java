package org.itstep.pd011.dbintro.entities;

import java.sql.Date;
import java.util.Objects;

// сведения о факте врачебного приема
public final class Appointment {

    public String toTableRow() {
        // получить фамилию и инициалы для пациента, доктора
        String patient = patientSurname + " " + patientName.charAt(0) + "." + patientPatronymic.charAt(0) + ".";
        String doctor = doctorSurname + " " + doctorName.charAt(0) + "." + doctorPatronymic.charAt(0) + ".";
        // форматирование даты http://proglang.su/java/date-and-time#formatirovanie-daty-s-pomoschyu-printf
        return String.format("│ %1$3d │  %2$td.%2$tm.%2$tY │ %3$-20s │    %4$td.%4$tm.%4$tY │ %5$-20s │ %6$-22s │ %7$15.2f │ %8$12.2f │",
                id, date,
                patient, dob,
                doctor, categoryName, price, interest);
    } // toTableRow


    @Override
    public int hashCode() {
        return Objects.hash(id, date, patientSurname, patientName, patientPatronymic, dob, address, doctorSurname, doctorName, doctorPatronymic, categoryName, price, interest);
    }

    public static final String HEADER =
        "\t┌─────┬─────────────┬──────────────────────┬───────────────┬──────────────────────┬────────────────────────┬─────────────────┬──────────────┐\n" +
        "\t│  Ид │ Дата приема │ Пациент              │ Дата рождения │ Доктор на приеме     │ Специальность          │ Стоимость, руб. │ % отчислений │\n" +
        "\t├─────┼─────────────┼──────────────────────┼───────────────┼──────────────────────┼────────────────────────┼─────────────────┼──────────────┤\n";

    public static final String FOOTER =
        "\t└─────┴─────────────┴──────────────────────┴───────────────┴──────────────────────┴────────────────────────┴─────────────────┴──────────────┘\n";

    private int id;
    private Date date;
    private String patientSurname;
    private String patientName;
    private String patientPatronymic;
    private final Date dob;
    private String address;
    private String doctorSurname;
    private String doctorName;
    private String doctorPatronymic;
    private String categoryName;
    private double price;
    private double interest;

    public Appointment(
            int id,
            Date date,
            String patientSurname,
            String patientName,
            String patientPatronymic,
            Date dob,
            String address,
            String doctorSurname,
            String doctorName,
            String doctorPatronymic,
            String categoryName,
            double price,
            double interest

    ) {
        this.id = id;
        this.date = date;
        this.patientSurname = patientSurname;
        this.patientName = patientName;
        this.patientPatronymic = patientPatronymic;
        this.dob = dob;
        this.address = address;
        this.doctorSurname = doctorSurname;
        this.doctorName = doctorName;
        this.doctorPatronymic = doctorPatronymic;
        this.categoryName = categoryName;
        this.price = price;
        this.interest = interest;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getPatientSurname() {
        return patientSurname;
    }

    public void setPatientSurname(String patientSurname) {
        this.patientSurname = patientSurname;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getPatientPatronymic() {
        return patientPatronymic;
    }

    public void setPatientPatronymic(String patientPatronymic) {
        this.patientPatronymic = patientPatronymic;
    }

    public Date getDob() {
        return dob;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDoctorSurname() {
        return doctorSurname;
    }

    public void setDoctorSurname(String doctorSurname) {
        this.doctorSurname = doctorSurname;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public String getDoctorPatronymic() {
        return doctorPatronymic;
    }

    public void setDoctorPatronymic(String doctorPatronymic) {
        this.doctorPatronymic = doctorPatronymic;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getInterest() {
        return interest;
    }

    public void setInterest(double interest) {
        this.interest = interest;
    }
} // record Appointment
