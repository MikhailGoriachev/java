--
-- Файл сгенерирован с помощью SQLiteStudio v3.4.3 в Ср фев 1 23:55:45 2023
--
-- Использованная кодировка текста: UTF-8
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Таблица: appointments
DROP TABLE IF EXISTS appointments;
CREATE TABLE IF NOT EXISTS appointments (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, id_doctor REFERENCES doctors (id) NOT NULL, id_patient REFERENCES patients (id) NOT NULL, date DATE NOT NULL);
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (1, 10, 9, '2023-01-12');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (2, 10, 1, '2023-01-12');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (3, 4, 5, '2023-01-12');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (4, 9, 7, '2023-01-13');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (5, 9, 8, '2023-01-13');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (6, 10, 9, '2023-01-13');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (7, 6, 2, '2023-01-13');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (8, 2, 7, '2023-01-13');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (9, 4, 4, '2023-01-14');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (10, 2, 9, '2023-01-14');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (11, 4, 8, '2023-01-14');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (12, 1, 5, '2023-01-14');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (13, 5, 8, '2023-01-15');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (14, 3, 7, '2023-01-15');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (15, 9, 6, '2023-01-15');
INSERT INTO appointments (id, id_doctor, id_patient, date) VALUES (16, 1, 4, '2023-01-15');

-- Таблица: categories
DROP TABLE IF EXISTS categories;
CREATE TABLE IF NOT EXISTS categories (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    category_name TEXT    NOT NULL
);
INSERT INTO categories (id, category_name) VALUES (1, 'терапевт');
INSERT INTO categories (id, category_name) VALUES (2, 'хирург');
INSERT INTO categories (id, category_name) VALUES (3, 'офтальмолог');
INSERT INTO categories (id, category_name) VALUES (4, 'уролог');
INSERT INTO categories (id, category_name) VALUES (5, 'акушер-гинеколог');
INSERT INTO categories (id, category_name) VALUES (6, 'семейный врач');
INSERT INTO categories (id, category_name) VALUES (7, 'оториноларинголог');
INSERT INTO categories (id, category_name) VALUES (8, 'стоматолог-терапевт');
INSERT INTO categories (id, category_name) VALUES (9, 'стоматолог-хирург');
INSERT INTO categories (id, category_name) VALUES (10, 'инфекционист');
INSERT INTO categories (id, category_name) VALUES (11, 'пульманолог');

-- Таблица: doctors
DROP TABLE IF EXISTS doctors;
CREATE TABLE IF NOT EXISTS doctors (id INTEGER PRIMARY KEY AUTOINCREMENT, id_person INTEGER REFERENCES persons (id), id_category INTEGER REFERENCES categories (id), price DOUBLE NOT NULL CHECK (price > 0), interest DOUBLE NOT NULL CHECK (interest BETWEEN 1 AND 100));
INSERT INTO doctors (id, id_person, id_category, price, interest) VALUES (1, 11, 1, 1500.0, 20.0);
INSERT INTO doctors (id, id_person, id_category, price, interest) VALUES (2, 12, 1, 1500.0, 30.0);
INSERT INTO doctors (id, id_person, id_category, price, interest) VALUES (3, 13, 1, 1500.0, 25.0);
INSERT INTO doctors (id, id_person, id_category, price, interest) VALUES (4, 14, 3, 1600.0, 20.0);
INSERT INTO doctors (id, id_person, id_category, price, interest) VALUES (5, 15, 3, 1600.0, 30.0);
INSERT INTO doctors (id, id_person, id_category, price, interest) VALUES (6, 16, 2, 2000.0, 20.0);
INSERT INTO doctors (id, id_person, id_category, price, interest) VALUES (7, 17, 2, 2000.0, 30.0);
INSERT INTO doctors (id, id_person, id_category, price, interest) VALUES (8, 18, 10, 1200.0, 20.0);
INSERT INTO doctors (id, id_person, id_category, price, interest) VALUES (9, 18, 8, 2000.0, 25.0);
INSERT INTO doctors (id, id_person, id_category, price, interest) VALUES (10, 20, 8, 2300.0, 30.0);

-- Таблица: patients
DROP TABLE IF EXISTS patients;
CREATE TABLE IF NOT EXISTS patients (id INTEGER PRIMARY KEY AUTOINCREMENT, id_person INTEGER REFERENCES persons (id), dob DATE NOT NULL, address TEXT NOT NULL);
INSERT INTO patients (id, id_person, dob, address) VALUES (1, 10, '1956--11-22', 'Донецк, ул. Куйбышева, 34, 12');
INSERT INTO patients (id, id_person, dob, address) VALUES (2, 9, '1987-10-16', 'Донецк, ул. Воинская, 23, 2');
INSERT INTO patients (id, id_person, dob, address) VALUES (3, 8, '2000-11-08', 'Донецк, ул. Гоголя, 121, 11');
INSERT INTO patients (id, id_person, dob, address) VALUES (4, 1, '1977-12-30', 'Донецк, ул. Гоголя, 121, 89');
INSERT INTO patients (id, id_person, dob, address) VALUES (5, 2, '1965-05-11', 'Донецк, ул. Куйбышева, 34, 87');
INSERT INTO patients (id, id_person, dob, address) VALUES (6, 7, '1951-11-22', 'Донецк, ул. Гоголя, 121, 100');
INSERT INTO patients (id, id_person, dob, address) VALUES (7, 6, '1993-04-08', 'Донецк, ул. Воинская, 23, 5');
INSERT INTO patients (id, id_person, dob, address) VALUES (8, 3, '1971-02-24', 'Донецк, ул. Куйбышева, 34, 19');
INSERT INTO patients (id, id_person, dob, address) VALUES (9, 5, '1945-05-09', 'Донецк, ул. Воинская, 23, 11');
INSERT INTO patients (id, id_person, dob, address) VALUES (10, 4, '1967-03-30', 'Донецк, ул. Куйбышева, 34, 19');

-- Таблица: persons
DROP TABLE IF EXISTS persons;
CREATE TABLE IF NOT EXISTS persons (id INTEGER PRIMARY KEY AUTOINCREMENT, surname TEXT NOT NULL, name TEXT NOT NULL, patronymic TEXT NOT NULL);
INSERT INTO persons (id, surname, name, patronymic) VALUES (1, 'Иванова', 'Вероника', 'Денисовна');
INSERT INTO persons (id, surname, name, patronymic) VALUES (2, 'Сергеева', 'Серафима', 'Степановна');
INSERT INTO persons (id, surname, name, patronymic) VALUES (3, 'Денисов', 'Дмитрий', 'Денисович');
INSERT INTO persons (id, surname, name, patronymic) VALUES (4, 'Жир', 'Владислав', 'Леонидович');
INSERT INTO persons (id, surname, name, patronymic) VALUES (5, 'Молодцова', 'Марина', 'Романовна');
INSERT INTO persons (id, surname, name, patronymic) VALUES (6, 'Шляховая', 'Татьяна', 'Евгеньевна');
INSERT INTO persons (id, surname, name, patronymic) VALUES (7, 'Пожар', 'Илья', 'Олегович');
INSERT INTO persons (id, surname, name, patronymic) VALUES (8, 'Соломаха', 'Алина', 'Николаевна');
INSERT INTO persons (id, surname, name, patronymic) VALUES (9, 'Биленко', 'Артем', 'Дмитриевич');
INSERT INTO persons (id, surname, name, patronymic) VALUES (10, 'Сенько', 'Юлия', 'Игнатьевна');
INSERT INTO persons (id, surname, name, patronymic) VALUES (11, 'Васечко', 'Ирина', 'Даниловна');
INSERT INTO persons (id, surname, name, patronymic) VALUES (12, 'Коробка', 'Елена', 'Денисовна');
INSERT INTO persons (id, surname, name, patronymic) VALUES (13, 'Зачипиленко', 'Валерий', 'Григорьевич');
INSERT INTO persons (id, surname, name, patronymic) VALUES (14, 'Гаврилов', 'Дмитрий', 'Валерьевич');
INSERT INTO persons (id, surname, name, patronymic) VALUES (15, 'Ловда', 'Михаил', 'Максимович');
INSERT INTO persons (id, surname, name, patronymic) VALUES (16, 'Ястремский', 'Антон', 'Артемьевич');
INSERT INTO persons (id, surname, name, patronymic) VALUES (17, 'Ермолина', 'Алина', 'Николаевна');
INSERT INTO persons (id, surname, name, patronymic) VALUES (18, 'Кленцарь', 'Татьяна', 'Ильинична');
INSERT INTO persons (id, surname, name, patronymic) VALUES (19, 'Васечко', 'Татьяна', 'Даниловна');
INSERT INTO persons (id, surname, name, patronymic) VALUES (20, 'Корнецкий', 'Алексей', 'Александрович');

-- Представление: view_appointments
DROP VIEW IF EXISTS view_appointments;
CREATE VIEW IF NOT EXISTS view_appointments AS select
    appointments.id
    , appointments.date
    , view_patients.patient_surname
    , view_patients.patient_name
    , view_patients.patient_patronymic
    , view_patients.dob
    , view_patients.address
    , view_doctors.doctor_surname
    , view_doctors.doctor_name
    , view_doctors.doctor_patronymic
    , view_doctors.category_name
    , view_doctors.price
    , view_doctors.interest
from
    appointments join view_doctors on appointments.id_doctor = view_doctors.id
                 join view_patients on appointments.id_patient = view_patients.id;

-- Представление: view_doctors
DROP VIEW IF EXISTS view_doctors;
CREATE VIEW IF NOT EXISTS view_doctors AS select
    doctors.id
    , persons.surname as doctor_surname
    , persons.name as doctor_name
    , persons.patronymic as doctor_patronymic
    , categories.category_name
    , doctors.price
    , doctors.interest 
from
     doctors join persons on doctors.id_person = persons.id
             join categories on doctors.id_category = categories.id;

-- Представление: view_patients
DROP VIEW IF EXISTS view_patients;
CREATE VIEW IF NOT EXISTS view_patients AS select
    patients.id
    , persons.surname as patient_surname
    , persons.name as patient_name
    , persons.patronymic as patient_patronymic
    , patients.dob
    , patients.address 
from
     patients join persons on patients.id_person = persons.id;

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
