package org.itstep.pd011.dbintro.entities;

import org.itstep.pd011.dbintro.dao.Entity;

// персональные данные - модель для таблицы persons
public class Person extends Entity {
    private int id;
    private String surname;
    private String name;
    private String patronymic;

    public Person() {
    }

    public Person(int id, String surname, String name, String patronymic) {
        this.id = id;
        this.surname = surname;
        this.name = name;
        this.patronymic = patronymic;
    }

    public int getId() {
        return id;
    }

    public String getSurname() {
        return surname;
    }

    public String getName() {
        return name;
    }

    public String getPatronymic() {
        return patronymic;
    }
} // record Person
