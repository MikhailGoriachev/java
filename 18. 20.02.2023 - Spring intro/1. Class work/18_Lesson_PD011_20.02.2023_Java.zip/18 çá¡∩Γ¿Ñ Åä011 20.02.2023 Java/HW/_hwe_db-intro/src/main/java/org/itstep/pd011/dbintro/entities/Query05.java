package org.itstep.pd011.dbintro.entities;


import java.io.Serializable;

// тип для отображения итогового запроса - средний процент
// отчислений на зарплату по специальностям
public final class Query05  implements Serializable {
    private String categoryName;    // врачебная специальность
    private int quantity;           // количество врачей этой специальности в базе данных
    private double avgInterest;      // средний процент отчислений на ЗП


    public Query05(String categoryName, int quantity, double avgInterest) {
        this.categoryName = categoryName;
        this.quantity = quantity;
        this.avgInterest = avgInterest;
    } // Query05

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getAvgInterest() {
        return avgInterest;
    }

    public void setAvgInterest(double avgInterest) {
        this.avgInterest = avgInterest;
    }

    // представление объекта класса в виде строки таблицы
    public String toTableRow() {
        return String.format(
                "│ %-28s │ %20d │ %9.2f │",
                categoryName, quantity, avgInterest
        );
    } // toTableRow

} // class Query05
