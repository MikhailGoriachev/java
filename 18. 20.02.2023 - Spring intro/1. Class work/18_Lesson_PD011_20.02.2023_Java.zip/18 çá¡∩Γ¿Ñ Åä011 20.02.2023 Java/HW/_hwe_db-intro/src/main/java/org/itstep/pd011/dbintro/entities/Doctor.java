package org.itstep.pd011.dbintro.entities;


import org.itstep.pd011.dbintro.dao.Entity;

// сведения о докторе
public class Doctor extends Entity {
    private int id;
    private String surname;
    private String name;
    private String patronymic;
    private String categoryName;
    private double interest;

    public Doctor() {  }

    public Doctor(int id, String surname, String name, String patronymic, String categoryName, double interest) {
        this.id = id;
        this.surname = surname;
        this.name = name;
        this.patronymic = patronymic;
        this.categoryName = categoryName;
        this.interest = interest;
    } // Doctor

    public int getId() {
        return id;
    }

    public String getSurname() {
        return surname;
    }

    public String getName() {
        return name;
    }

    public String getPatronymic() {
        return patronymic;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public double getInterest() {
        return interest;
    }
} // class Doctor
