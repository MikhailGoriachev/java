package org.itstep.pd011;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        double a, b;

        System.out.println("\n\tВычисления по варианта A");
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("\n\t\033[1mВведите a, b (дробную часть от целой отделяем запятой): \033[0m");
            a = sc.nextDouble();
            b = sc.nextDouble();

            // вычисление по варианту A
            calcPointA(a, b);

            System.out.print("\n\t\033[1mВведите a (дробную часть от целой отделяем запятой): \033[0m");
            a = sc.nextDouble();

            // вычисление по варианту B
            calcPointB(b);
        } // try

        // обработка одномерного массива
        processArray();

        // обработка двумерного массива
        processMatrix();
    } // main

    // вычисление по варианту A
    private static void calcPointA(double a, double b) {

        double t = 2*b - a;
        double z1 = (Math.sin(a) + Math.cos(t)) / (Math.cos(a) - Math.sin(t));
        double z2 = (1+ Math.sin(2 * b)) / Math.cos(2 * b);

        System.out.printf("\n\ta = %.3f; b = %.3f\n\tz1 = %.7f\n\tz2 = %.7f\n", a, b, z1, z2);
        boolean equals = Math.abs(z1 - z2) <= 1e-7;
        String answer;
        if (equals)
            answer = "\t\033[32;1mРасчет верный\033[0m";
        else
            answer = "\t\031[32;1mРасчет не верный\033[0m";
        System.out.println(answer);
    } // calcPointA

    // вычисление по варианту B
    private static void calcPointB(double a) {
        System.out.println("\n\tВычисления по варианта B");

        double t = Math.sqrt(2*a);
        double z1 = (((a + 2)/t) - (a / (2 + t) ) + (2 / (a - t))) * ((Math.sqrt(a) - Math.sqrt(2))/(a + 2));
        double z2 = 1 / (Math.sqrt(a) + Math.sqrt(2));

        System.out.printf("\n\ta = %.3f\n\tz1 = %.7f\n\tz2 = %.7f\n", a, z1, z2);
        boolean equals = Math.abs(z1 - z2) <= 1e-7;
        String answer;
        if (equals)
            answer = "\t\033[32;1mРасчет верный\033[0m";
        else
            answer = "\t\033[31;1mРасчет не верный\033[0m";
        System.out.println(answer);
    } // calcPointB



    // передача массива в метод
    private static void fill(int[] arr, int lo, int hi) {
        for (int i = 0; i < arr.length; i++) {
            arr[i] = Utils.getRandom(lo, hi);
        } // for i
    } // fill

    // вывод массив в переменную типа String, при помощи объекта
    // класса StringBuilder
    private static String arrToString(int[] arr, String title) {
        StringBuilder sbf = new StringBuilder(title);

        for (int x : arr) {
            // bgr --> 31 это красный
            sbf.append(String.format("\033[%sm%6d\033[0m", (x >= 0 ? "31;1" : "34"), x));
        } // for i
        sbf.append("\n");

        return sbf.toString();
    } // arrToString

    // обработка одномерного массива
    private static void processArray() {
        System.out.println("\tprocessArray - в разработке");
    } // processArray

    // обработка двумерного массива
    private static void processMatrix() {
        System.out.println("\tprocessMatrix - в разработке");
    } // processMatrix

} // class Main