package homework;

import javax.swing.*;
import java.util.Arrays;
import java.util.Objects;
import java.util.concurrent.ThreadLocalRandom;

public class Main {
    public static void main(String[] args) {
        System.out.println("\033[34mВычисление формулы A\033[0m");
        double a, b;
        do {
            a = getInputNumber("Введите число а: ");
            b = getInputNumber("Введите число b: ");
        }while (a == 0 || b == 0);
        double z1 = aZ1(a, b);
        double z2 = aZ2(a, b);
        String str = """
                     \033[31msin a + cos(2b - a)       1 + sin 2b
                Z1 = -------------------; Z2 = -----------
                     cos a - sin(2b - a)         cos 2b\033[0m 
                """;
        System.out.println(str);
        System.out.printf("a = %.1f b = %.1f\n", a, b);

        System.out.printf("\033[34mОтвет\n\033[0mZ1 = %.7f Z2 = %.7f\n\n", z1, z2);
        System.out.println("\033[34mВычисление формулы B\033[0m");
        str = """
                     \033[31m(  a + 2       a         2    )    √a - √2            1
                Z1 = ( ------- - ------- + ------- ) * ---------; Z2 = ---------
                     (   √2a     2 + √2a   a - √2a )     a + 2          √a + √2\033[0m
                """;
        z1 = bZ1(a);
        z2 = bZ2(a);
        System.out.println(str);
        System.out.printf("\033[34mОтвет\n\033[0mZ1 = %.7f Z2 = %.7f\n\nМассив\n", z1, z2);


        // •	Заполнение массива случайными числами
        int[] arr = createArr();
        int min = minValue(arr);
        int max = maxValue(arr);
        show(arr);
        System.out.printf("\nПроизведения положительных элементов: %d\n\n", positiveNum(arr));
        System.out.printf("суммы элементов массива, расположенных между минимальным %d и максимальным %d: \033[34m%d\033[0m\n\n",min, max, sumaBetweenMinMax(arr, min, max));
        System.out.println("массив по возрастанию.");
        Arrays.sort(arr);
        show(arr);
    }

    // получение числа  c клавиатуры
    static double getInputNumber(String str){
        String num = JOptionPane.showInputDialog(null, str, 0);
        return num.equals("0") ? 0 : Double.parseDouble(num);
    }
    // вычисление A.Z1
    static double aZ1(double a, double b){
        return (Math.sin(a) + Math.cos(2 * b - a)) / (Math.cos(a) - Math.sin(2 * b - a));
    }
    // вычисление A.Z2
    static double aZ2(double a, double b){
        return (1 + Math.sin(2 * b)) / Math.cos(2 * b);
    }
    // вычесление B.Z1
    static double bZ1(double a){
        return (((a + 2)/Math.sqrt(2 * a)) - (a / (2 + Math.sqrt(2 * a))) + (2 / (a - Math.sqrt(2 * a)))) * ((Math.sqrt(a) - Math.sqrt(2)) / (a + 2));
    }
    // вычисление B.Z2
    static double bZ2(double a){
        return 1 / (Math.sqrt(a) + Math.sqrt(2));
    }
    // •	Заполнение массива случайными числами
    static int[] createArr(){
        int[] arr = new int[(int)getRand(10, 30)];
        for (int i = 0; i < arr.length; i++){
            arr[i] = getRand(-10, 30);
        }
        return arr;
    }
    // вывод в консоль
    static void show(int[] arr){
        System.out.println("\033[32m----------------------------------------------------");
        for (int i = 0; i < arr.length; i++){
            if (i % 10 == 0 && i != 0) System.out.println(" |\n----------------------------------------------------");
            System.out.printf("| %d ", arr[i]);
        }
        System.out.println("\n----------------------------------------------------\033[0m");
    }
    // случайное число
    static int getRand(int lo, int hi){
        return (int)(Math.random()*((hi-lo)+1))+lo;
    }
    // •	Вычсление произведения положительных элементов массива
    static long positiveNum(int[] arr){
        long sum = 1;
        for (var item: arr){
            if (item > 0) sum *= item;
        }
        return sum;
    }
    // max
    static int maxValue(int[] arr) {
        int max = arr[0];
        for (int j : arr) {
            if (j > max) {
                max = j;
            }
        }
        return max;
    }
    // min
    static int minValue(int[] arr) {
        int min = arr[0];
        for (int j : arr) {
            if (j < min) {
                min = j;
            }
        }
        return min;
    }
    // суммы элементов массива, расположенных между минимальным и максимальным
    static int sumaBetweenMinMax(int[] arr, int min, int max) {
        int sum = 0;
        for (var item: arr){
            if (item > min && item < max) sum += item;
        }
        return sum;
    }
}