
package step140123;

import javax.swing.*;
// обратите внимание на статический импорт
import java.util.Arrays;

import static step140123.Utils.getRandom;

public class Main {
    public static void main(String[] args) {

        doTask01();
        doTask02();
        doTask03();

    }

    // метод без параметров
    private static void doTask01() {

        int a = 5;
        int b = 5;

        String str = "Ошибка ввода";

        try {
            str = JOptionPane.showInputDialog(null, "Введите α (целое число)", a);
            a = Integer.parseInt(str);

            str = JOptionPane.showInputDialog(null, "Введите β (целое число)", b);
            b = Integer.parseInt(str);

            str = String.format("Вы ввели: α = %d, β = %d\n", a, b);

            double a_z1 = (Math.sin(a) + Math.cos(2*b-a))/(Math.cos(a) - Math.sin(2*b-a));
            double a_z2 = (1+Math.sin(2*b))/(Math.cos(2*b));

            double b_z1 = ((a+2)/(Math.sqrt(2*a)) - a/(2+Math.sqrt(2*a)) + 2/(a - (Math.sqrt(2*a)))) * (Math.sqrt(a) - Math.sqrt(2))/(a+2);
            double b_z2 = 1/(Math.sqrt(a) + Math.sqrt(2));

            JOptionPane.showMessageDialog(null,
                    "<html><h3> A: z1 = " + a_z1 + "</h3>"+
                    "<h3> A: β = " + a_z2 + "</h3>"+
                    "<h3> B: α = " + b_z1 + "</h3>"+
                    "<h3> B: β = " + b_z2 + "</h3>", "К сведению", JOptionPane.PLAIN_MESSAGE);
        }
        catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "<html><h3> Ошибка ввода", "К сведению", JOptionPane.ERROR_MESSAGE);
        }

        System.out.println(str);

    } // doTask01

    private static void doTask02(){

        int n = 12;

        // работа методов с массивами
        double[] arr = new double[n];;
        fill(arr, -10f, 10f);

        System.out.println(arrToString(arr, "\nИсходный массив:\n"));

        findMul(arr);
        findSum(arr);

        Arrays.sort(arr);
        System.out.println(arrToString(arr, "\nМассив отсортирован по возрастанию:\n"));

    }

    private static void doTask03(){

        int m = 3;
        int n = 5;

        double[][] matrix = new double[m][n];

        fill(matrix, -10f, 3f);
        show("\nИсходная матрица:\n", matrix);

        findSum01(matrix);
        System.out.print("\n");
        findSum02(matrix);

    }

    //заполнение массива случайными числами
    private static void fill(double[] arr, double lo, double hi) {
        for (int i = 0; i < arr.length; i++) {
            arr[i] = getRandom(lo, hi);
        } // for i
    } // fill

    // вывод массив в переменную типа String, при помощи объекта
    // класса StringBuilder
    private static String arrToString(double[] arr, String title) {
        StringBuilder sbf = new StringBuilder(title);

        for (double x:arr) {
            
            sbf.append(String.format("\033[%sm%8.2f\033[0m", (x >= 0?"31;1":"34"), x));
        } // for i
        sbf.append("\n");

        return sbf.toString();
    } // arrToString

    //Вычсление произведения положительных элементов массива
    private static void findMul(double[] arr){

        double mul = 1;

        for (double x:arr) {

            if(x >= 0){
                mul *= x;
            }
        } // for i

        System.out.printf("Произведение положительных элементов массива: %3.4f%n", mul);
    }

    //Вычисление суммы элементов массива, расположенных между минимальным и максимальным элементами
    private static void findSum(double[] arr){

        int min = findMin(arr);
        int max = findMax(arr);

        double sum = 0;

        if(max < min) {
            int temp = min;
            min = max;
            max = temp;
        }

        for (int i = min + 1; i < max; i++) {
            sum += arr[i];
        } // for i

        System.out.printf("Сумма элементов массива, расположенных между минимальным и максимальным элементами: %3.4f%n", sum);
    }

    //Находим индекс мин
    private static int findMin(double[] arr){

        int i_min = 0;

        for (int i = 1; i < arr.length-1; i++) {

            if(arr[i_min] > arr[i]){
                i_min = i;
            }

        } // for i

        return i_min;
    }

    //Находим индекс макс
    private static int findMax(double[] arr){

        int i_max = 0;

        for (int i = 1; i < arr.length-1; i++) {

            if(arr[i_max] < arr[i]){
                i_max = i;
            }

        } // for i

        return i_max;
    }

    // заполнение матрицы случайными числами в диапазоне от lo до hi
    private static void fill(double[][] matrix, double lo, double hi) {
        // получение размерности матрицы
        int rows = matrix.length;
        int cols = matrix[0].length;

        for (int i = 0; i < rows; i++) {       // строк в матрице     matrix.length
            for (int j = 0; j < cols; j++) {   // столбцов в матрице  matrix[0].length
                matrix[i][j] = getRandom(lo, hi);
            } // for j
        } // for i
    } // fill

    // вывод матрицы в консоль
    private static void show(String title, double[][] matrix) {
        System.out.print(title);

        for (double[] row:matrix) {    // для каждой строки матрицы
            for (double item:row) {    // для каждого элемента в строке

                System.out.printf("%s%8.2f", (item < 0)?"\033[1;34m":"\033[1;32m", item);
            } // for item
            System.out.println();
        } // for row
        System.out.print("\n\033[0m");  // перевод строки и сброс форматирования
    } // show

    //Вычисление суммы элементов в тех строках, которые содержат хотя бы один отрицательный элемент,
    // вывести матрицу с этими суммами
    private static void findSum01(double[][] matrix){

        for (int i = 0; i < matrix.length; i++) {

            if(checkNeg(matrix[i])){

                double sum = 0;

                for (int j = 0; j < matrix[0].length; j++) {   // столбцов в матрице  matrix[0].length
                    sum += matrix[i][j];
                } // for j

                System.out.printf("Сумма элементов в строке %d : %3.4f\n", i, sum);
            }

        } // for i
    }

    //Проверка соджержит ли строка хотя бы один отрицательный элемент
    private static boolean checkNeg(double[] row){

        for (double item:row) {    // для каждого элемента в строке

           if (item < 0){
               return true;
           }
        } // for item

        return false;
    }

    //Вычисление суммы элементов в тех столбцах, которые содержат хотя бы один положительный элемент, вывести матрицу с этими суммами
    private static void findSum02(double[][] matrix){

        // получение размерности матрицы
        int rows = matrix.length;
        int cols = matrix[0].length;

        double[] arr = new double[rows];

        for (int i = 0; i < cols; i++){

            for (int j = 0; j < rows; j++) {
                arr[j] = matrix[j][i];
            } // for j

                if (checkPos(arr)) {

                    double sum = 0;

                    for (int m = 0; m < rows; m++) {
                        sum += matrix[m][i];
                    } // for j

                    System.out.printf("Сумма элементов в столбце %d : %3.4f\n", i, sum);
               }

        }

    }

    //Проверка соджержит ли столбец хотя бы один положительный элемент
    private static boolean checkPos(double[] col){

        for (double item:col) {

            if (item >= 0){
                return true;
            }
        } // for item

        return false;
    }
}

