package org.itstep.pd011.maslennikov.hw1;

import static org.fusesource.jansi.Ansi.ansi;
import static org.fusesource.jansi.Ansi.Color.*;

public class TwoDimArraysTask {
    public static void demo() {

        System.out.println(ansi()
                .fgBrightCyan().bold().a("Двумерные массивы.\n\n").boldOff()
                .a(matrixWithRowsSumsToString(createFilledMatrix(10, 10, -2, 20),
                        "Матрица с суммами строк, содержащими отрицательные элементы:")).newline()
                .a(matrixWithColumnSumToString(createFilledMatrix(10, 10, -20, 2),
                        "Матрица с суммами столбцов, содержащими положительные элементы:")));

    }

    // Вывод в строку матрицы с суммами строк, содержащими отрицательные элементы
    private static String matrixWithRowsSumsToString(double[][] matrix, String title) {
        StringBuilder sb = new StringBuilder(ansi()
                .fgCyan().a(title).newline()
                .fgGreen().toString());

        for (double[] row : matrix) {
            boolean hasNegative = checkArrayForNegatives(row);

            for (double item : row) {
                sb.append(ansi().fg(hasNegative ? GREEN : BLUE));

                if (item < 0)
                    sb.append(ansi().fgRed());

                sb.append(String.format("%8.1f", item));
            }

            sb.append(ansi().fgCyan().a(" | "));

            if (hasNegative)
                sb.append(ansi().fgCyan().format("%4.1f", arraySum(row)));

            sb.append("\n");
        }
        return sb.toString();
    }

    // Вывод в строку матрицы с суммами её строк, содержащими отрицательные элементы
    private static String matrixWithColumnSumToString(double[][] matrix, String title) {
        StringBuilder sb = new StringBuilder(ansi()
                .fgCyan().a(title).newline()
                .fgGreen().toString());

        boolean[] columnsHasPositivesMap = matrixColumnsHasPositiveMap(matrix);

        for (double[] row : matrix) {
            for (int i = 0; i < row.length; i++) {
                sb.append(ansi().fg(columnsHasPositivesMap[i] ? GREEN : BLUE));

                if (row[i] >= 0)
                    sb.append(ansi().fgRed());

                sb.append(String.format("%8.1f", row[i]));
            }
            sb.append("\n");
        }

        sb.append(ansi().fgCyan().a("_".repeat(columnsHasPositivesMap.length * 8)).newline());

        for (int i = 0; i < columnsHasPositivesMap.length; i++) {
            sb.append(ansi().fgCyan().a(columnsHasPositivesMap[i]
                    ? String.format("%8.1f", matrixColumnSum(matrix, i))
                    : " ".repeat(8)));
        }

        return sb.toString();
    }

    // Вернуть матрицу
    private static double[][] createMatrix(int rows, int cols) {
        return new double[rows][cols];
    }

    // Заполнение вещественного массива случайными значениями
    private static double[] fill(double[] arr, double lo, double hi) {
        for (int i = 0; i < arr.length; i++) {
            arr[i] = Utils.getRandom(lo, hi);
        }
        return arr;
    }

    // Заполнение матрицы случайными значениями
    private static double[][] fillMatrix(double[][] matrix, double lo, double hi) {
        for (double[] doubles : matrix) {
            fill(doubles, lo, hi);
        }
        return matrix;
    }

    // Создать и заполнить матрицу
    private static double[][] createFilledMatrix(int rows, int cols, double lo, double hi) {
        return fillMatrix(createMatrix(rows, cols), lo, hi);
    }


    // Сума массива вещественных чисел
    private static double arraySum(double[] array) {
        double sum = 0;
        for (double value : array) {
            sum += value;
        }
        return sum;
    }

    // Проверка массива вещественных чисел на содержание отрицательных элементов
    private static boolean checkArrayForNegatives(double[] array) {
        for (double value : array) {
            if (value < 0)
                return true;
        }
        return false;
    }

    // Проверка строки матрица вещественных чисел на содержание положительных элементов
    private static boolean checkMatrixColumnForPositive(double[][] matrix, int column) {
        for (double[] row : matrix) {
            if (row[column] > 0)
                return true;
        }
        return false;
    }

    // Сумма столбца матрица
    private static double matrixColumnSum(double[][] matrix, int column) {
        double sum = 0;
        for (double[] row : matrix) {
                sum += row[column];
        }
        return sum;
    }

    // Булевая карта содержания столбцов матрица положительных элементов
    private static boolean[] matrixColumnsHasPositiveMap(double[][] array) {
        int columns = array[0].length;

        boolean[] map = new boolean[columns];

        for (int i = 0; i < columns; i++) {
            map[i] = checkMatrixColumnForPositive(array, i);
        }

        return map;
    }
}
