
package org.itstep.pd011.maslennikov.hw1;


import java.util.InputMismatchException;
import java.util.Objects;

// В проекте используется библиотека
// https://github.com/fusesource/jansi


public class Main {
    public static void main(String[] args) {
        // если не работают ANSI последовательности
        // AnsiConsole.systemInstall();

        try {
            MathsTask.demo();

            OneDimArraysTask.demo();

            TwoDimArraysTask.demo();

        } catch (InputMismatchException ex) {
            if (Objects.equals(ex.getMessage(), "Canceled"))
                System.out.println("Отменено");
            else
                ex.printStackTrace();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

}


