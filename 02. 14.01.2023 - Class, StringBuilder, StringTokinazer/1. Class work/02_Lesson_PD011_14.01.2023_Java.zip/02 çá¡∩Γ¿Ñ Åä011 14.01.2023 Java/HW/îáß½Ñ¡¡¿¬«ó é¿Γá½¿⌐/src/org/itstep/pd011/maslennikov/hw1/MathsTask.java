package org.itstep.pd011.maslennikov.hw1;

import static org.fusesource.jansi.Ansi.ansi;
import static org.itstep.pd011.maslennikov.hw1.Utils.inputDoubleDialog;

public class MathsTask {
    public static void demo() {
        double a, b, z1, z2;

        StringBuffer sb = new StringBuffer(ansi().
                fgBrightCyan().bold().a("\nМетоды класса Math.\n\n").boldOff().toString());

        a = inputDoubleDialog("Введите a");
        b = inputDoubleDialog("Введите b");

        z1 = (Math.sin(a) + Math.cos(2 * b - a)) / (Math.cos(a) - Math.sin(2 * b - a));
        z2 = (1 + Math.sin(2 * b)) / Math.cos(2 * b);

        sb.append(ansi()
                .fgCyan().a("А) ")
                .fgGreen().a("z1 = ").fgBlue().format("%.7f", z1).newline()
                .fgGreen().a("   z2 = ").fgBlue().format("%.7f", z2).newline());

        z1 = (((a + 2) / (Math.sqrt(2 * a))) - (a / (2 + Math.sqrt(2 * a))) + (2 / (a - Math.sqrt(2 * a))))
                * (Math.sqrt(a) - Math.sqrt(2)) / (a + 2);

        z2 = 1 / (Math.sqrt(a) + Math.sqrt(2));

        sb.append(ansi()
                .fgCyan().newline().a("B) ")
                .fgGreen().a("z1 = ").fgBlue().format("%.7f", z1).newline()
                .fgGreen().a("   z2 = ").fgBlue().format("%.7f", z2).newline());

        System.out.println(sb);
    }

}
