package org.itstep.pd011.maslennikov.hw1;

import java.util.Arrays;

import static org.fusesource.jansi.Ansi.Color.*;
import static org.fusesource.jansi.Ansi.ansi;

public class OneDimArraysTask {

    public static void demo() {
        int[] array = createFilledArray(10, -20, 20);

        int minValuePos = arrayMinValuePos(array);
        int maxValuePos = arrayMaxValuePos(array);

        System.out.println(ansi()
                .fgBrightCyan().bold().a("Одномерные массивы.\n\n").boldOff()
                .fgCyan().a("Произведение положительных элементов:\n")
                .a(arrToStringHighlightPositives(array))
                .fgCyan().a("\tпроизведение: ").fgGreen().a(arrayPositivesProduct(array)).newline()
                .fgCyan().a("\nСумма между минимальным и максимальным элементами:\n")
                .a(arrToStringHighlightBetween(array, minValuePos, maxValuePos))
                .fgCyan().a("\tсумма: ").fgGreen().a(arraySumBetweenPositions(array, minValuePos, maxValuePos)).newline()
                .a(arrToString(sortArray(array), "\nМассив упорядочен по возрастанию:")).newline()
        );
    }


    // Произведение положительных элементов массива
    private static int arrayPositivesProduct(int[] array) {
        int product = 1;

        for (int elem : array) {
            if (elem > 0)
                product *= elem;
        }

        return product;
    }

    // Сумма элементов массива между указанных позиций
    private static int arraySumBetweenPositions(int[] array, int from, int to) {
        int sum = 0;

        if (from > to)
            from = from ^ to ^ (to = from); // смена значений местами

        for (int i = from + 1; i < to; i++) {
            sum += array[i];
        }

        return sum;
    }

    // Позиция минимального элемента массива
    private static int arrayMinValuePos(int[] array) {
        int value = array[0];
        int pos = 0;

        for (int i = 1; i < array.length; i++) {
            if (array[i] < value) {
                value = array[i];
                pos = i;
            }
        }

        return pos;
    }

    // Позиция максимального элемента массива
    private static int arrayMaxValuePos(int[] array) {
        int value = array[0];
        int pos = 0;

        for (int i = 1; i < array.length; i++) {
            if (array[i] > value) {
                value = array[i];
                pos = i;
            }
        }

        return pos;
    }

    // Вывод массива в переменную
    private static String arrToString(int[] array, String title) {
        StringBuilder sb = new StringBuilder(ansi().fgCyan().a(title).fgGreen().newline().toString());

        for (int x : array) {
            sb.append(String.format("%6d", x));
        }
        sb.append(ansi().reset().a("\n"));

        return sb.toString();
    }

    // Вывод массива в переменную, выделение положительных элементов
    private static String arrToStringHighlightPositives(int[] array) {
        StringBuilder sb = new StringBuilder();

        for (int x : array) {
            sb.append(ansi()
                    .fg(x >= 0 ? RED : GREEN)
                    .format("%6d", x));
        }

        sb.append(ansi().reset().newline());

        return sb.toString();
    }

    // Вывод массива в переменную, выделение элементов, расположенных между позиций
    private static String arrToStringHighlightBetween(int[] array, int from, int to) {
        StringBuilder sb = new StringBuilder();

        if (from > to)
            from = from ^ to ^ (to = from); // смена значений местами

        for (int i = 0; i < array.length; i++) {
            sb.append(ansi()
                    .fg(i == from || i == to
                            ? BLUE : i > from && i < to
                            ? RED : GREEN)
                    .format("%6d", array[i]));
        }

        sb.append(ansi().reset().newline());

        return sb.toString();
    }

    // Создание одномерного массива целочисленных значений
    private static int[] createArray(int n) {
        return new int[n];
    }

    // Заполнение массива случайными целочисленными значениями
    private static int[] fill(int[] arr, int lo, int hi) {
        for (int i = 0; i < arr.length; i++) {
            arr[i] = Utils.getRandom(lo, hi);
        }
        return arr;
    }

    // Создание и заполнение массива целочисленными значениями
    private static int[] createFilledArray(int length, int lo, int hi) {
        /*
        int[] arr = createArray(length);
        fill(arr, lo, hi);
        return arr;
        */
        return fill(createArray(length), lo, hi);
    }

    // Оболочка, возвращающая отсортированный массив
    private static int[] sortArray(int[] array) {
        Arrays.sort(array);
        return array;
    }
}
