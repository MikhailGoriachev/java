package org.itstep.pd011.maslennikov.hw1;

import javax.swing.*;
import java.util.InputMismatchException;
import java.util.Random;

import static org.fusesource.jansi.Ansi.ansi;

public class Utils {
    private static final Random rand = new Random();

    // метод, возвращающий случайное вещественное число,
    // передаются нижнее и верхнее значения
    public static double getRandom(double lo, double hi){
        return lo + rand.nextDouble() * (hi - lo);
    }

    // перегруженный метод, возвращающий случайное целое число,
    // передаются нижнее и верхнее значения
    public static int getRandom(int lo, int hi) {
        return lo + rand.nextInt(hi - lo);
    }


    // Метод, реализующий ввод double через диалоговое окно
    public static double inputDoubleDialog(String prompt) {
        Double parsed;

        do {
            var str = JOptionPane.showInputDialog(null, prompt);

            if (str == null)
                throw new InputMismatchException("Canceled");

            str = str.replace(',', '.');

            parsed = tryParseDouble(str);
        } while (parsed == null);

        return parsed;
    }

    // Метод, пытающийся распарсить double. Возвращает null в случае неудачи.
    public static Double tryParseDouble(String str) {
        try {
            return Double.parseDouble(str);
        } catch (NumberFormatException e) {
            return null;
        }
    }


}
