

package org.itstep.pd011.hw001;
import javax.swing.*;
import java.security.InvalidParameterException;

public class Main {
    public static void main(String[] args) {
        while(true) {
            String result = (String)JOptionPane.showInputDialog(null,
                    "<html><h3>Выберите <u>пункт</u> меню:</h3>",
                    "Вариант для решения",
                    JOptionPane.QUESTION_MESSAGE,
                    new ImageIcon(Main.class.getResource("comparing.png")),
                    new Object[]{"Методы класса Math", "Одномерные массивы", "Двумерные массивы", "Выход"},
                    "Методы класса Math");
            System.out.printf("\nВы выбрали пункт меню \033[1;4m  %s  \033[0m\n", result==null?"Выход":result);
            if (result == null || result.equals("Выход")) break;

            /*
            switch (result) {
                case "Методы класса Math":
                Functions.task1();
                break;
                case "Одномерные массивы":
                Functions.task2();
                break;
                case "Двумерные массивы":
                Functions.task3();
                break;
            } // switch
             */

            switch (result) {
                case "Методы класса Math" -> Functions.task1();
                case "Одномерные массивы" -> Functions.task2();
                case "Двумерные массивы" -> Functions.task3();
            } // switch
        } // while
    }
}