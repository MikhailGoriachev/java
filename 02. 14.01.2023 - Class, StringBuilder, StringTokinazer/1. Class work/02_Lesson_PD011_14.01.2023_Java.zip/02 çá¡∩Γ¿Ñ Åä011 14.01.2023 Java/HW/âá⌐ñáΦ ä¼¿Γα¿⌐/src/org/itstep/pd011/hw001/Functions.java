package org.itstep.pd011.hw001;

import javax.swing.*;
import java.text.DecimalFormat;
import java.util.Arrays;

public class Functions {

    public static void task1(){
        String str;
        double a = 0, b = 0;
        str = JOptionPane.showInputDialog(null, "Введите вещественное число a", a);
        a = Double.parseDouble(str);
        str = JOptionPane.showInputDialog(null, "Введите вещественное число b", b);
        b = Double.parseDouble(str);
        task1A(a,b);
        task1B(a);
    } // task1

    private static void task1A(double a, double b){
        System.out.println("A:");
        double z1 = (Math.sin(a)+Math.cos(2*b-a))/(Math.cos(a)-Math.sin(2*b-a));
        double z2 = (1+Math.sin(2*b))/(Math.cos(2*b));
        String str = String.format("a = %.3f\nb = %.7f\nz1 = %.7f\nz2 = %.7f", a, b, z1, z2);
        System.out.println(str);
        JOptionPane.showMessageDialog(null, str, "Решение пункта A", JOptionPane.INFORMATION_MESSAGE);
    } // task1A
    private static void task1B(double a){
        System.out.println("\nB:");
        double z1 = ((a+2)/(Math.sqrt(2*a))-a/(2+Math.sqrt(2*a))+2/(a-Math.sqrt(2*a)))*(Math.sqrt(a)-Math.sqrt(2))/(a+2);
        double z2 = 1/(Math.sqrt(a)+Math.sqrt(2));
        String str = String.format("a = %.3f\n\nz1 = %.7f\nz2 = %.7f", a, z1, z2);
        System.out.println(str);
        JOptionPane.showMessageDialog(null, str, "Решение пунка B", JOptionPane.INFORMATION_MESSAGE);
    } // task1B

    public static void task2() {
        int n = Utils.getRandom(10,15);
        double[] arr = new double[n];
        fill(arr, -10, 15);
        System.out.println(arrToString(arr, "Исходный массив("+n+")\n"));
        System.out.println("Произведение положительных элементов массива> "+multiplyElementsArr(arr));
        System.out.println("Сумма элементов массива, расположенных между мин. и макс. элементами> "+sumMinMaxArr(arr));
        Arrays.sort(arr);
        System.out.println(arrToString(arr, "Отсортированный массив\n"));
    } // task2
    private static void fill(double[] arr, double lo, double hi) {
        for (int i = 0; i < arr.length; i++) {
            arr[i] = Utils.getRandom(lo, hi);
        } // for i
    } // fill
    private static String arrToString(double[] arr, String title) {
        StringBuilder sbf = new StringBuilder(title);

        for (double x:arr) {
            sbf.append(String.format("\033[%sm%10.3f\033[0m", (x >= 0?"34":"31"), x));
        } // for i
        sbf.append("\n");

        return sbf.toString();
    } // arrToString

    private static double multiplyElementsArr(double arr[]){
        double res =1;
        for (double x:arr)
            if(x>0)res*=x;
        return res;
    } // multiplyElementsArr

    private static int indexMin(double[] arr) {
        int indexMin = 0;
        for(int i = 1;i<arr.length;i++)
            if (arr[i] < arr[indexMin])
                indexMin = i;
        return  indexMin;
    }

    private static double sumMinMaxArr(double arr[]){

        int indexMin = indexMin(arr), indexMax = 0;
        for(int i = 1; i<arr.length;i++)
            if (arr[i] > arr[indexMax])
                indexMax=i;
        System.out.println("Минимум> "+arr[indexMin]);
        System.out.println("Максимум> "+arr[indexMax]);

        if(indexMax<indexMin) {
            int temp = indexMin;
            indexMin = indexMax;
            indexMax = temp;
        }

        double res = 0.0;
        for (int i = indexMin+1; i <= indexMax-1; i++)
            res += arr[i];
        return res;

    } // sumMinMaxArr

    public static void task3(){
        int m = Utils.getRandom(5, 8), n=Utils.getRandom(5,8);
        double[][] matrix = new double[m][n];

        fill(matrix, -5, 1);
        System.out.println(matrixToString(matrix, "Исходная матрица("+m+"x"+n+")\n"));
        sumRowNeg(matrix,m,n);
        sumColsPos(matrix,m,n);
    } // task3
    private static void fill(double[][] matrix, double lo, double hi) {
        int rows = matrix.length;
        int cols = matrix[0].length;

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                matrix[i][j] = Utils.getRandom(lo, hi);
            } // for j
        } // for i
    } // fill
    private static String matrixToString(double[][] matrix, String title) {
        StringBuilder sb = new StringBuilder(title);
        for (var row:matrix) {
            for (double item:row) {
                sb.append(String.format("\033[%sm%7f  \033[0m", (item >= 0?"34":"31"), item));
            } // for item
            sb.append("\n");
        } // for row
        sb.append("\n\033[0m");

        return sb.toString();
    } // matrixToString
    private static void sumRowNeg(double[][] matrix, int m, int n){
        StringBuilder sb = new StringBuilder();

        boolean flag = false;
        for (int i=0; i<m; i++) {
            for (int j=0; j<n; j++) {
                sb.append(String.format("\033[%sm%10.3f\033[0m", (matrix[i][j] >= 0 ? "34" : "31"), matrix[i][j]));
                if (matrix[i][j] < 0)
                    flag = true;
            } // for j
            if (flag){
                double sum=0;
                for (int j=0; j<n; j++) {
                    sum += matrix[i][j];
                }
                sb.append("\t").append(sum);
            }
            sb.append("\n");
            flag=false;

        }
        System.out.println(sb.toString());
    } // sumRowNeg

    private static void sumColsPos(double[][] matrix, int m, int n){
        DecimalFormat df = new DecimalFormat("#.####");
        double arr[] = new double[n];
        System.out.print(matrixToString(matrix, "\n"));
        StringBuilder sb = new StringBuilder();
        double sum=0;
        boolean flag = false;
        for (int j=0; j<n; j++) {
            arr[j]=0;
            for (int i=0; i<m; i++) {
                if (matrix[i][j] > 0) {
                    flag = true;
                    break;
                }
            } // for j
            if (flag){
                for (int i=0; i<m; i++)
                    sum += matrix[i][j];
                arr[j]=sum;
                sum = 0;
            }
            flag=false;
        } // for j
        for(int j = 0;j<n;j++){
            if(Math.abs(arr[j])<0.00001) {
                sb.append("\t\t   ");
                continue;
            }
            sb.append(String.format("%10.3f", arr[j]));
        } // for j
        System.out.println(sb.toString());
    } // sumColsPos

} // Functions
