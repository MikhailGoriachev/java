package org.itstep.pd011;

// пример интерфейса
public interface IBase {
    int twice();
    String text(double x);
} // IBase
