package org.itstep.pd011.controllers;

import org.itstep.pd011.models.Kettle;
import org.itstep.pd011.utils.Utils;
import org.springframework.context.ApplicationContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class KettleController {

    private final List<Kettle> list;

    public KettleController(ApplicationContext ctx) {
        list = new ArrayList<>();

        list.add(ctx.getBean("kettle1",Kettle.class));
        list.add(ctx.getBean("kettle2",Kettle.class));
        list.add(ctx.getBean("kettle3",Kettle.class));
    }

    private StringBuilder show(List<Kettle> list){

        StringBuilder sb = new StringBuilder(Utils.headerKettles);
        list.forEach(sb::append);
        return sb.append("</tbody>").append("</table>");
    }

    //найти чайник с минимальным временем нагрева
    private List<Kettle> findMin(){
        return list.stream().min(Comparator.comparingInt(Kettle::getSeconds)).stream().toList();
    }

    public void run(){

        Utils.showMessage(show(list).toString(),"Коллекция чайников:");

        Utils.showMessage(show(findMin()).toString(),"Чайники с минимальным временем нагрева:");
    }
}
