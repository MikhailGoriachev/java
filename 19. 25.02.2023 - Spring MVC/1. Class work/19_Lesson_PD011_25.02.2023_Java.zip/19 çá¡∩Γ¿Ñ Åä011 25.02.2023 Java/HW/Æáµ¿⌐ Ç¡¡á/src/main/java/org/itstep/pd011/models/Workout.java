package org.itstep.pd011.models;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Workout implements Serializable, Cloneable {

    private Date begin; //дата и время начала
    private Date end; //дата и время завершения
    private String trainer; //фамилия и инициалы тренера
    private boolean isSpecialInventory; //есть ли особые требования к инвентарю
    private boolean isSpecialRoom; //есть ли особые требования к помещению

    private static final SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

    public Workout() {
    }

    public Workout(String begin, String end, String trainer, boolean isSpecialInventory, boolean isSpecialRoom) throws ParseException {

        this.begin = format.parse(begin);
        this.end = format.parse(end);

        this.trainer = trainer;
        this.isSpecialInventory = isSpecialInventory;
        this.isSpecialRoom = isSpecialRoom;
    }

    public Date getBegin() {
        return begin;
    }

    public void setBegin(Date begin) {
        this.begin = begin;
    }

    public Date getEnd() {
        return end;
    }

    public void setEnd(Date end) {
        this.end = end;
    }

    public String getTrainer() {
        return trainer;
    }

    public void setTrainer(String trainer) {
        this.trainer = trainer;
    }

    public boolean isSpecialInventory() {
        return isSpecialInventory;
    }

    public void setSpecialInventory(boolean specialInventory) {
        isSpecialInventory = specialInventory;
    }

    public boolean isSpecialRoom() {
        return isSpecialRoom;
    }

    public void setSpecialRoom(boolean specialRoom) {
        isSpecialRoom = specialRoom;
    }

    @Override
    public String toString() {
        return String.format("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"
                , format.format(begin)
                , format.format(end)
                , trainer
                , isSpecialInventory ? "Да" : "Нет"
                , isSpecialRoom ? "Да" : "Нет"
        );
    }
}
