package org.itstep.pd011.controllers;

import org.itstep.pd011.models.Workout;
import org.itstep.pd011.utils.Utils;
import org.springframework.context.ApplicationContext;

import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

public class WorkoutController {

    private final List<Workout> list;

    public WorkoutController(ApplicationContext ctx) {
        list = new ArrayList<>();

        list.add(ctx.getBean("workout1",Workout.class));
        list.add(ctx.getBean("workout2",Workout.class));
    }

    private StringBuilder show(List<Workout> list){

        StringBuilder sb = new StringBuilder(Utils.headerWorkouts);
        list.forEach(sb::append);
        return sb.append("</tbody>").append("</table>");
    }

    //найти суммарную продолжительность тренировок
    private Time findSum(){

        // нашли разницу конца и начала времени тренировки в миллисекундах и просуммировали
       long sum = list.stream().mapToLong(x-> x.getEnd().getTime() - x.getBegin().getTime()).sum();

       //погрешность на 3 часа больше
       sum -= 3*3600000;

       //перевели в формат часы:минуты:секунды
       return new Time(sum);
    }

    public void run(){

        Utils.showMessage(show(list).toString(),"Коллекция тренировок:");
        Utils.showMessage(String.format("<html><h3>Суммарная продолжительность тренировок: %s </h3>",findSum()),"Найти суммарную продолжительность тренировок:");

    }
}
