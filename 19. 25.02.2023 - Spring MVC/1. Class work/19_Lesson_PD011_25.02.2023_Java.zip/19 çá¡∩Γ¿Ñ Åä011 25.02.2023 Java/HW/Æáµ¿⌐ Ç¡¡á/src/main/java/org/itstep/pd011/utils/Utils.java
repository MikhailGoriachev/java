package org.itstep.pd011.utils;

import javax.swing.*;
import java.sql.Time;
import java.util.Date;

public class Utils {

    // вывод данных в окно
    public static void showMessage(String message, String title) {
        JOptionPane.showOptionDialog(
                null,
                message,
                title,
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(),
                new Object[]{"Далее"},
                "Далее"
        );
    }

    public static String headerBooks =
            "<html><table border='1'>" +
                    "<thead><tr>" +
                    "<th>Формат</th>" +
                    "<th>Автор</th>" +
                    "<th>Название</th>" +
                    "<th>Размер в байтах</th>" +
                    "<th>Год создания</th>" +
                    "</tr></thead><tbody>";

    public static String headerWorkouts =
            "<html><table border='1'>" +
                    "<thead><tr>" +
                    "<th>Дата и время начала</th>" +
                    "<th>Дата и время завершения</th>" +
                    "<th>Тренер</th>" +
                    "<th>Особые требования к инвентарю</th>" +
                    "<th>Особые требования к помещению</th>" +
                    "</tr></thead><tbody>";

    public static String headerKettles =
            "<html><table border='1'>" +
                    "<thead><tr>" +
                    "<th>Производитель</th>" +
                    "<th>Модель</th>" +
                    "<th>Мощность Вт</th>" +
                    "<th>Нагрев в секундах</th>" +
                    "<th>Удержание в минутах</th>" +
                    "</tr></thead><tbody>";

}
