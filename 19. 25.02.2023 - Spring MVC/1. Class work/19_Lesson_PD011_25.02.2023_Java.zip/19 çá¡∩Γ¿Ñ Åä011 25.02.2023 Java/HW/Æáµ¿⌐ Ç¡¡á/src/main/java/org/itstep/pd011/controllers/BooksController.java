package org.itstep.pd011.controllers;

import org.itstep.pd011.models.Book;
import org.itstep.pd011.utils.Utils;
import org.springframework.context.ApplicationContext;

import java.util.ArrayList;
import java.util.List;

public class BooksController {

    private final List<Book> list;

    public BooksController(ApplicationContext ctx) {
        list = new ArrayList<>();

        list.add(ctx.getBean("book1",Book.class));
        list.add(ctx.getBean("book2",Book.class));
        list.add(ctx.getBean("book3",Book.class));
    }

    private StringBuilder show(){

        StringBuilder sb = new StringBuilder(Utils.headerBooks);
        list.forEach(sb::append);
        return sb.append("</tbody>").append("</table>");
    }

    //средний размер книги в байтах
    private double findAvg(){
       return list.stream().mapToInt(Book::getSize).average().orElse(0);
    }

    public void run(){
        Utils.showMessage(show().toString(),"Коллекция книг:");
        Utils.showMessage(String.format("<html><h3>Средний размер книги в байтах: %.2f </h3>",findAvg()) ,"Средний размер книги:");
    }
}
