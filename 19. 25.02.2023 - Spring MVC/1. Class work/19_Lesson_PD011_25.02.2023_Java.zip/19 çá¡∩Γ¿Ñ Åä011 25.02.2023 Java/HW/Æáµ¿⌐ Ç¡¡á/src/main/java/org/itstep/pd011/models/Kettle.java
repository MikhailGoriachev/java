package org.itstep.pd011.models;
import java.io.Serializable;

public class Kettle implements Serializable, Cloneable {

    private String maker; //производитель
    private String model; //модель
    private int power; //мощность, Вт
    private int seconds; //время нагрева в секундах
    private int minutes; //время удержания температуры в минутах

    private Kettle(){}

    public Kettle(String maker, String model, int power, int seconds, int minutes) {
        this.maker = maker;
        this.model = model;
        this.power = power;
        this.seconds = seconds;
        this.minutes = minutes;
    }

    public String getMaker() {
        return maker;
    }

    public void setMaker(String maker) {
        this.maker = maker;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getPower() {
        return power;
    }

    public void setPower(int power) {
        this.power = power;
    }

    public int getSeconds() {
        return seconds;
    }

    public void setSeconds(int seconds) {
        this.seconds = seconds;
    }

    public int getMinutes() {
        return minutes;
    }

    public void setMinutes(int minutes) {
        this.minutes = minutes;
    }

    @Override
    public String toString() {
        return  String.format("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>",maker,model,power,seconds,minutes);
    }
}
