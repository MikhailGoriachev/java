package org.itstep.pd011;
import org.itstep.pd011.models.Workout;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import org.itstep.pd011.controllers.*;

import javax.swing.*;

public class App 
{
    public static void main( String[] args )
    {

        // получить контекст приложения, из контекста будем брать бины
        ApplicationContext ctx = new ClassPathXmlApplicationContext("context.xml");

        KettleController k = new KettleController(ctx);
        BooksController b = new BooksController(ctx);
        WorkoutController w = new WorkoutController(ctx);

        try {

            while (true) {

                switch (showMenu()) {

                    case 0 -> k.run();
                    case 1 -> w.run();
                    case 2 -> b.run();

                    // выход
                    default -> {
                        return;
                    }
                }
            }

        } catch (Exception e){
            e.getStackTrace();
        }

    }

    // вывод окна меню
    public static int showMenu() {
        return JOptionPane.showOptionDialog(
                null,
                "<html><h1>Меню</h1>",
                "Домашнее задание на 25.02.2023",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(),
                new Object[] {"Чайники", "Тренировки","Книги", "Выход"},
                "Выход"
        );
    }
}
