package org.itstep.pd011.models;
import java.io.Serializable;

public class Book implements Serializable, Cloneable {

    private String format; //формат
    private String author; //автор
    private String title; //название
    private int size;  //размер в байтах
    private int year; //год создания

    public Book() {
    }

    public Book(String format, String author, String title, int size, int year) {
        this.format = format;
        this.author = author;
        this.title = title;
        this.size = size;
        this.year = year;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    @Override
    public String toString() {
        return String.format("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>",format,author,title,size,year);
    }
}
