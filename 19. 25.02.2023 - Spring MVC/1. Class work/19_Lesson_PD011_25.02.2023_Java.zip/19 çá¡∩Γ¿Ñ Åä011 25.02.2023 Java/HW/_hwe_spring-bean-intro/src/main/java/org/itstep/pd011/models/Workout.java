package org.itstep.pd011.models;

import java.io.Serializable;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/*
* Тренировка – дата и время начала (с точностью до секунды); дата
* и время завершения (с точностью до секунды); фамилия и инициалы
* тренера, проводящего тренировку (пустая строка, если тренировка
* самостоятельная); есть ли особые требования к инвентарю; есть ли
* особые требования к помещению
* */
public class Workout implements Serializable, Cloneable {
    // дата и время начала (с точностью до секунды)
    private Date startTime;

    // дата и время завершения (с точностью до секунды)
    private Date endTime;

    // фамилия и инициалы тренера, проводящего тренировку (пустая строка
    // если тренировка самостоятельная)
    private String coach;

    // есть ли особые требования к инвентарю
    private boolean specialEquipment;

    // есть ли особые требования к помещению
    private boolean specialRoom;


    // форматтер для парсинга даты и времени
    private static final SimpleDateFormat dtf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");

    // конструкторы
    public Workout() { } // Workout
    public Workout(String startTime, String endTime, String coach, boolean specialEquipment, boolean specialRoom) throws ParseException {
        this.startTime = dtf.parse(startTime);
        this.endTime = dtf.parse(endTime);
        this.coach = coach;
        this.specialEquipment = specialEquipment;
        this.specialRoom = specialRoom;
    } // Workout

    // вычисление времени продолжительности тренировки в миллисекундах
    public long duration() {
//        Timestamp end = Timestamp.from(endTime.toInstant());
//        Timestamp start = Timestamp.from(startTime.toInstant());
//        return end - start;
        return endTime.getTime() - startTime.getTime();
    } // duration

    // геттеры и сеттеры
    public Date getStartTime() {  return startTime; }
    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() { return endTime; }
    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getCoach() {
        return coach;
    }

    public void setCoach(String coach) {
        this.coach = coach;
    }

    public boolean isSpecialEquipment() {
        return specialEquipment;
    }

    public void setSpecialEquipment(boolean specialEquipment) {
        this.specialEquipment = specialEquipment;
    }

    public boolean isSpecialRoom() {
        return specialRoom;
    }

    public void setSpecialRoom(boolean specialRoom) {
        this.specialRoom = specialRoom;
    }

    @Override
    public String toString() {
        return "Workout{" +
                "startTime=" + startTime +
                ", endTime=" + endTime +
                ", coach='" + coach + '\'' +
                ", specialEquipment=" + specialEquipment +
                ", specialRoom=" + specialRoom +
                '}';
    }
} // class Workout
