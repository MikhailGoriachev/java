package org.itstep.pd011;

import org.itstep.pd011.models.Book;
import org.itstep.pd011.models.Kettle;
import org.itstep.pd011.models.Workout;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.sql.Time;

/**
 * Разработайте консольное приложение с использованием фреймворка Spring
 * с заданием контекста приложения при помощи XML-файла.
 * Разработайте три класса, Spring Bean, для представления сведений
 * о следующих сущностях:
 *     • Чайник – производитель; модель; мощность, Вт; время нагрева от 20оС
 *       до 100оС в секундах; время удержания температуры 80оС, в минутах
 *     • Тренировка – дата и время начала (с точностью до секунды); дата
 *       и время завершения (с точностью до секунды); фамилия и инициалы
 *       тренера, проводящего тренировку (пустая строка, если тренировка
 *       самостоятельная); есть ли особые требования к инвентарю; есть ли
 *       особые требования к помещению
 *     • Книга – формат (EPUB, FB2, PDF, DJVU, …), автор, название, размер
 *       в байтах, год создания
 * Создайте в конфигурационном файле бины с инициализацией в конструкторе,
 * выполните обработку по заданию в коде приложения.
 *     1. Три бина для объектов класса Чайник, найти чайник с минимальным
 *        временем нагрева
 *     2. Два бина для объектов класса Тренировка, найти суммарную
 *        продолжительность тренировок
 *     3. Три бина для объектов класса Книга,  средний размер книги в байтах
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        // получить контекст приложения, из контекста будем брать бины
        var ctx = new ClassPathXmlApplicationContext("context.xml");

        System.out.println("\n\033[1mВывод данных бинов Kettle, Workout, Book полученных из контекста приложения\033[0m");

        kettleProcess(ctx);
        workoutProcess(ctx);
        bookProcess(ctx);

        System.out.println("\n\n\033[1mРабота приложения завершена\033[0m\n\n");
    } // main


    // Три бина для объектов класса Чайник, найти чайник с минимальным
    // временем нагрева
    private static void kettleProcess(ApplicationContext ctx) {
        var kettle1 = ctx.getBean("kettle1", Kettle.class);
        var kettle2 = ctx.getBean("kettle2", Kettle.class);
        var kettle3 = ctx.getBean("kettle3", Kettle.class);
        Kettle fastest;

        System.out.printf("\n\t%s\n\t%s\n\t%s\n\n", kettle1, kettle2, kettle3);

        if (kettle1.getHeatingTime() < kettle2.getHeatingTime() && kettle1.getHeatingTime() < kettle3.getHeatingTime())
            fastest = kettle1;
        else if (kettle2.getHeatingTime() < kettle3.getHeatingTime())
            fastest = kettle2;
        else
            fastest = kettle3;

        System.out.printf("\n\tСамый быстрый чайник: %s\n", fastest);
    } // kettleProcess


    // Два бина для объектов класса Тренировка, найти суммарную
    // продолжительность тренировок
    private static void workoutProcess(ApplicationContext ctx) {
        var workout1 = ctx.getBean("workout1", Workout.class);
        var workout2 = ctx.getBean("workout2", Workout.class);

        System.out.printf("\n\t%s\n\t%s\n", workout1, workout2);

        Time sum = new Time(workout1.duration() + workout2.duration());
        System.out.println("\tСуммарная продолжительность тренировок: " + sum);
    } // workoutProcess


    // Три бина для объектов класса Книга, средний размер книги в байтах
    private static void bookProcess(ApplicationContext ctx) {
        var book1 = ctx.getBean("book1", Book.class);
        var book2 = ctx.getBean("book2", Book.class);
        var book3 = ctx.getBean("book3", Book.class);

        System.out.printf("\n\t%s\n\t%s\n\t%s\n", book1, book2, book3);

        int avgSize = (book1.getSize() + book2.getSize() + book3.getSize()) / 3;

        System.out.printf("\n\tСредний размер книги в байтах: %d\n", avgSize);
    } // bookProcess
} // class App
