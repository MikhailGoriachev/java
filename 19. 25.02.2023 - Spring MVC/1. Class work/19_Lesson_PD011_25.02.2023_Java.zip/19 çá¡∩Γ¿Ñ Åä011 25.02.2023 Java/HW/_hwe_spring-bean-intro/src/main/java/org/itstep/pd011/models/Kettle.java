package org.itstep.pd011.models;

import java.io.Serializable;

/*
*  Чайник – производитель; модель; мощность, Вт; время нагрева от 20оС
* до 100оС в секундах; время удержания температуры 80оС, в минутах
*
* */
public class Kettle implements Serializable, Cloneable {
    // производитель
    private String brand;

    // модель
    private String model;

    // мощность, Вт
    private int power;

    // время нагрева от 20оС до 100оС в секундах
    private int heatingTime;

    // время удержания температуры 80оС, в минутах
    private int retentionTime;

    // конструкторы

    public Kettle() { } // Kettle

    public Kettle(String brand, String model, int power, int heatingTime, int retentionTime) {
        this.brand = brand;
        this.model = model;
        this.power = power;
        this.heatingTime = heatingTime;
        this.retentionTime = retentionTime;
    } // Kettle

    // геттеры и сеттеры
    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getPower() {
        return power;
    }

    public void setPower(int power) {
        this.power = power;
    }

    public int getHeatingTime() {
        return heatingTime;
    }

    public void setHeatingTime(int heatingTime) {
        this.heatingTime = heatingTime;
    }

    public int getRetentionTime() {
        return retentionTime;
    }

    public void setRetentionTime(int retentionTime) {
        this.retentionTime = retentionTime;
    }

    @Override
    public String toString() {
        return "Kettle{" +
                "brand='" + brand + '\'' +
                ", model='" + model + '\'' +
                ", power=" + power +
                ", heatingTime=" + heatingTime +
                ", retentionTime=" + retentionTime +
                '}';
    }
} // Kettle
