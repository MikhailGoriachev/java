package org.itstep.pd011.models;

import java.io.Serializable;

/*
* Книга – формат (EPUB, FB2, PDF, DJVU, …), автор, название, размер
* в байтах, год создания
*
* */
public class Book implements Serializable, Cloneable {
    // формат (EPUB, FB2, PDF, DJVU, …)
    private String format;

    // автор
    private String author;

    // название
    private String title;

    // размер в байтах
    private int size;

    // год создания
    private int year;


    // Конструкторы
    public Book() { } // Book

    public Book(String format, String author, String title, int size, int year) {
        this.format = format;
        this.author = author;
        this.title = title;
        this.size = size;
        this.year = year;
    } // Book


    // Геттеры и сеттеры

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    @Override
    public String toString() {
        return "Book{" +
                "format='" + format + '\'' +
                ", author='" + author + '\'' +
                ", title='" + title + '\'' +
                ", size=" + size +
                ", year=" + year +
                '}';
    }
} // class Book
