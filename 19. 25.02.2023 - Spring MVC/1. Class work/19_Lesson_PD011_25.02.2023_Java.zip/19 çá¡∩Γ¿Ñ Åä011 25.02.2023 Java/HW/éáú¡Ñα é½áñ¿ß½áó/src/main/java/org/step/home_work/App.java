package org.step.home_work;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.step.home_work.models.Book;
import org.step.home_work.models.Exercise;
import org.step.home_work.models.Teapot;
import org.step.home_work.utils.Utils;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;


public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");

        try {

            //Вызов методов обработок
            while (true) {
                switch (showMenu()) {
                    case 0 -> findKettle(context);
                    case 1 -> exercisedDuration(context);
                    case 2 -> countBooksSize(context);
                    case 3 -> System.exit(0);

                    default -> {
                        return;
                    }
                }
            }
        } catch (Exception e) {
            Utils.showWindowButtons(e.getMessage() + "\n","Ошибка!",new Object[]{"Выход"},"", JOptionPane.ERROR_MESSAGE);

            System.out.printf("\n\tУпало исключение:\n%s\n",e.getMessage());
            System.out.println(e.getMessage() + "\n");
            e.printStackTrace();
        }
    }//main

    //Вывод меню
    public static int showMenu(){

        //Задание значений для окна
        String title = "Spring beginning";
        String message = "<html><h1>Выбирете пункт меню</h1>";
        Object[] buttons = new Object[]{
                "Чайники",
                "Тренировки",
                "Книги",
                "Выход"
        };


        return Utils.showWindowButtons(message,title,buttons,"Выход",JOptionPane.DEFAULT_OPTION);
    }//showMenu

    //Поиск чайника с мин.временем нагрева
    public static void findKettle(ApplicationContext ctx){

        List<Teapot> teapots = new ArrayList<>(List.of(
                (Teapot) ctx.getBean("teapot1",Teapot.class),
                (Teapot) ctx.getBean("teapot2",Teapot.class),
                (Teapot) ctx.getBean("teapot3",Teapot.class)
        ));

        int min = teapots.stream().mapToInt(Teapot::getTimeToHeat).min().getAsInt();

        //Получить id чайника с мин. временм нагрева
        int idMin= teapots.stream().filter(t -> t.getTimeToHeat() == min)
                .findFirst()
                .get().id;

        Utils.showTeapots(teapots,idMin);

    }//findKettle

    //Поиск суммарной продолжительности тренировок
    public static void exercisedDuration(ApplicationContext ctx){

        //Получить bean-объекты
        Exercise exercise1 = ctx.getBean("exercise1", Exercise.class);
        Exercise exercise2 = ctx.getBean("exercise2", Exercise.class);

        //Вычисления + вывод
        Utils.processExercises(exercise1,exercise2);

    }//exercisedDuration

    // Вычисление среднего размера книги в байтах
    public static void countBooksSize(ApplicationContext ctx){

        //Получить bean-объекты из context.xml
        List<Book> books = new ArrayList<>(List.of(
                (Book) ctx.getBean("book1", Book.class),
                (Book) ctx.getBean("book2",Book.class),
                (Book) ctx.getBean("book3",Book.class)
        ));

        Utils.processBooks(books);

    }//countBooksSize
}
