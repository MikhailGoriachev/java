package org.step.home_work.models;

public enum Formats {

    EPUB, PDF, FB2, DJVU;

}
