package org.step.home_work.utils;

import org.step.home_work.models.Book;
import org.step.home_work.models.Exercise;
import org.step.home_work.models.Teapot;

import javax.swing.*;
import java.text.DecimalFormat;
import java.util.Random;
import java.util.*;

public class Utils {

    //Генерация значений
    private static Random rand = new Random();

    //Формат вывода чисел
    public static DecimalFormat numbersFormatter = new DecimalFormat("###,###,###");

    public Utils() {
    }

    //Получение слуйчаных значений
    public static double getRandom(double lo, double hi) {
        return lo + rand.nextDouble() * (hi - lo);
    }

    public static int getRandom(int lo, int hi) {
        return lo + rand.nextInt(hi - lo);
    }


    // вывод окна с кнопками
    public static int showWindowButtons (String message, String title, Object[] buttons, String initialValue, int windowType) {
        return JOptionPane.showOptionDialog(
                null,
                message,
                title,
                JOptionPane.DEFAULT_OPTION,
                windowType,
                null,
                buttons,
                initialValue
        );
    }

    public static String tableHtmlHeader = "<html><table align='center' border='1' cellspacing='0' cellpadding='4'>";
    public static String tableHtmlFooter = "</table>";

    //Вывод чайников
    public static void showTeapots(List<Teapot> teapots, int highlightId){
        String task = """
                <html><span>Чайник с мин.временем нагрева выделен <span style='background-color:#c0beef'>цветом</span></span><br><br>
                """;

        //Общая строка вывода
        StringBuilder sb = new StringBuilder(task);


        //Создание заголовка таблицы
        sb.append(tableHtmlHeader);
        sb.append("<html><tr><th>Производитель</th><th>Модель</th><th>Мощность, ВТ</th><th>Время нагрева</th><th>Время удержания 80°c</th></tr> ");

        //Проверка на валидность
        if (teapots == null || teapots.size() == 0) {

            sb.append("<tr><td colspan='5'>Что-то пошло не так.!</td></tr>");
            sb.append(tableHtmlFooter);

            //Вывод сообщения
            somethingGoneWrong("Чайники",sb);

            return;
        }

        //Вывод с выделеннием
        teapots.forEach((d) -> sb.append(d.toTableRow(d.id == highlightId)));

        sb.append(tableHtmlFooter);

        showWindowButtons(sb.toString(), "Чайники", new Object[]{"Назад"}, "", JOptionPane.DEFAULT_OPTION);
    }//showTeapots

    // Вывод тренировок
    public static void processExercises(Exercise exercise1, Exercise exercise2){

        String task = """
                <html><span>Сумма длительностей тренировок</span><br><br>
                """;

        //Общая строка вывода
        StringBuilder sb = new StringBuilder(task);


        //Создание заголовка таблицы
        sb.append(tableHtmlHeader);
        sb.append("<tr><th>Время начала тренировки</th><th>Время конца тренировки</th><th>ФИО тренера</th><th>Требования к инвентарю</th><th>Требования к помещению</th></tr>");

        //Проверка на валидность
        if (exercise1 == null || exercise2 == null) {

            sb.append("<tr><td colspan='5'>Что-то пошло не так. Один из объектов null!</td></tr>");
            sb.append(tableHtmlFooter);

            //Вывод сообщения об ошибке
            somethingGoneWrong("Тренировки",sb);


            return;
        }

        //Вычисление длительностей
        long duration1 = exercise1.getEnding().getTime() - exercise1.getBeginning().getTime();
        long duration2 = exercise2.getEnding().getTime() - exercise2.getBeginning().getTime();

        //Поучение суммы длительностей
        long sum = duration1+duration2;

        //Миллисекунды в часы, минуты и секунды - Time(), Date()
        long hours = (sum/(3600*1000)) % 24;
        long minutes = (sum/(60*1000)) % 60;
        long seconds = (sum/(1000)) % 60;

        //Вывод
        sb.append(exercise1.toTableRow())
            .append(exercise2.toTableRow())
                    .append(String.format("<tr><td colspan='2'>Суммарная продолжительность тренировок</td><td colspan='3'>%dч. %d мин. %d сек.</td></tr>",hours,minutes,seconds));

        sb.append(tableHtmlFooter);

        showWindowButtons(sb.toString(), "Тренировки", new Object[]{"Назад"}, "", JOptionPane.DEFAULT_OPTION);
    }//processExercises

    // Вывод книг + расчёт размера
    public static void processBooks(List<Book> books){

        String task = """
                <html><span>Вычисление среднего размера книг</span><br><br>
                """;

        //Общая строка вывода
        StringBuilder sb = new StringBuilder(task);

        //Создание заголовка таблицы
        sb.append(tableHtmlHeader);
        sb.append("<tr><th>Формат книги</th><th>Автор</th><th>Название книги</th><th>Год издания</th><th>Размер, байт</th></tr>");

        //Проверка на валидность
        if (books == null || books.size() == 0) {

            sb.append("<tr><td colspan='5'>Что-то пошло не так.!</td></tr>");
            sb.append(tableHtmlFooter);

            //Вывод сообщения
            somethingGoneWrong("Книги",sb);

            return;
        }

        //Вывод
        books.forEach((d) -> sb.append(d.toTableRow()));


        long avgSize = (long)books.stream().mapToLong(Book::getSize).average().getAsDouble();

        //Вычисление среднего размера книги в байтах
        sb.append(String.format("<tr><td colspan='3'>Средний разме книг в байтах </td><td colspan='2'> %s </td></tr>"
                ,numbersFormatter.format(avgSize)));

        sb.append(tableHtmlFooter);

        showWindowButtons(sb.toString(), "Книги", new Object[]{"Назад"}, "", JOptionPane.DEFAULT_OPTION);
    }//processBooks

    //Вывод окна с сообщением об ощибке
    private static void somethingGoneWrong(String title, StringBuilder currentResult){
        System.out.println("\n\t\u001b[38;5;9mЧто-то пошло не так! Данные не загрузились\u001b[0m");
        showWindowButtons(currentResult.toString(),
                title,
                new Object[]{"Назад"},
                "", JOptionPane.WARNING_MESSAGE);
    }

}//Utils
