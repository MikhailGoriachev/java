package org.step.home_work.models;

import org.step.home_work.utils.Utils;

import java.text.DecimalFormat;
import java.util.Locale;

public class Book {

    //Формат книги
    private Formats format;

    //Автор
    private String author;

    //Название
    private String name;

    //Размер в байтах
    private long size;

    //Год публикации
    private int year;


    public Book() {
    }

    public Book(Formats format, String author, String name, int year, long size) {
        this.format = format;
        this.author = author;
        this.name = name;
        this.year = year;
        this.size = size;
    }

    //В строку таблицы
    public StringBuilder toTableRow(){

        StringBuilder sb = new StringBuilder();

        sb.append(String.format(Locale.US,"<tr><td> %s </td> <td> %s </td>",format,author));
        sb.append(String.format("<td> %s </td><td> %d </td><td> %s </td></tr>",name,year, Utils.numbersFormatter.format(size)));

        return sb;
    }

    //Формат
    public Formats getFormat() {
        return format;
    }

    public void setFormat(Formats format) {
        this.format = format;
    }

    //Размер в байтах
    public long getSize() {
        return size;
    }

    public void setSize(long size) {
        this.size = size;
    }

    //Автор
    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }


    //Название
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    //Год публикаци
    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
}
