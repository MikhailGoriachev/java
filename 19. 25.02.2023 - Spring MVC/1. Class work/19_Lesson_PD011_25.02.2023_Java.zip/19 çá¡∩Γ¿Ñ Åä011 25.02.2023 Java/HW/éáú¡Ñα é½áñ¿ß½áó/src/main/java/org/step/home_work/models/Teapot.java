package org.step.home_work.models;

public class Teapot {

    public int id;

    //Производитель
    private String brand;

    //Модель
    private String model;

    //Мощноть
    private int power;

    //Время нагрева от 20С до 100С. В секундах
    private int timeToHeat;

    //Время удержания 80 градусов. В минутах
    private int retentionTime;


    public Teapot() {
    }

    public Teapot(int id,String brand, String model, int power, int timeToHeat, int retentionTime) {
        this.id = id;
        this.brand = brand;
        this.model = model;
        this.power = power;
        this.timeToHeat = timeToHeat;
        this.retentionTime = retentionTime;
    }

    //Формирование таблицы
    public StringBuilder toTableRow(boolean highlight){

        //выделение, если задан флаг
        StringBuilder sb = new StringBuilder(String.format("<tr style='%s'>",highlight ? "background-color:#c0beef" : ""));

        sb.append(String.format("<td> %s </td> <td> %s </td>",brand,model));
        sb.append(String.format("<td> %d, Вт </td><td> %d сек </td><td> %d сек </td>",power,timeToHeat,retentionTime));


        return sb;
    }

    public int getId() {
        return id;
    }

    public void setId(int val) {

        if (val <= 0)
            throw new RuntimeException("Id чайника введён некорректно!");

        this.id = val;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getPower() {
        return power;
    }

    public void setPower(int power) {
        this.power = power;
    }

    public int getTimeToHeat() {
        return timeToHeat;
    }

    public void setTimeToHeat(int timeToHeat) {
        this.timeToHeat = timeToHeat;
    }

    public int getRetentionTime() {
        return retentionTime;
    }

    public void setRetentionTime(int retentionTime) {
        this.retentionTime = retentionTime;
    }
}
