package org.step.home_work.models;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class Exercise {

    //Время начала
    private Date beginning;

    //Время завершения
    private Date ending;

    //ФИО тренера
    private String trainerSnp;

    //Требования к инвентарю
    private String requirementsToInventory;

    //Требования к помощенеию
    private String requirementsToRoom;

    //Формат вывода времени
    public static SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");

    public Exercise() {
    }

    //Ctor - получение даты из context.xml в строковом формате, далее парсим дату из строки
    public Exercise(String beginning, String ending, String trainerSnp, String requirementsToInventory, String requirementsToRoom) throws Exception {
        this.beginning = timeFormat.parse(beginning);
        this.ending = timeFormat.parse(ending);
        this.trainerSnp = trainerSnp;
        this.requirementsToInventory = requirementsToInventory;
        this.requirementsToRoom = requirementsToRoom;
    }

    //Формирование строки таблицы
    public StringBuilder toTableRow(){

        StringBuilder sb = new StringBuilder();

        sb.append(String.format("<tr><td> %s </td> <td> %s </td>",timeFormat.format(beginning),timeFormat.format(ending)));
        sb.append(String.format("<td> %s </td><td> %s </td><td> %s </td>",trainerSnp,requirementsToInventory,requirementsToRoom));


        return sb;
    }

    public Date getBeginning() {
        return beginning;
    }

    public void setBeginning(Date beginning) {
        this.beginning = beginning;
    }

    public Date getEnding() {
        return ending;
    }

    public void setEnding(Date ending) {
        this.ending = ending;
    }

    public String getTrainerSnp() {
        return trainerSnp;
    }

    public void setTrainerSnp(String trainerSnp) {
        this.trainerSnp = trainerSnp;
    }

    public String getRequirementsToInventory() {
        return requirementsToInventory;
    }

    public void setRequirementsToInventory(String requirementsToInventory) {
        this.requirementsToInventory = requirementsToInventory;
    }

    public String getRequirementsToRoom() {
        return requirementsToRoom;
    }

    public void setRequirementsToRoom(String requirementsToRoom) {
        this.requirementsToRoom = requirementsToRoom;
    }
}
