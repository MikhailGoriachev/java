package org.itstep.pd011.maslennikov.models;

public record Gadget(String type, String manufacturer, int year, String os, int price) {
}
