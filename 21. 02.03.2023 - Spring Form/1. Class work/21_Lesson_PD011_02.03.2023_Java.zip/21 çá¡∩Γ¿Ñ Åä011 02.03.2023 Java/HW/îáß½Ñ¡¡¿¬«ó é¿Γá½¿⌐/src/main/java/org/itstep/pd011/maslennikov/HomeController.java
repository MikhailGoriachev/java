package org.itstep.pd011.maslennikov;

import org.itstep.pd011.maslennikov.models.Cylinder;
import org.itstep.pd011.maslennikov.models.Gadget;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

@Controller
public class HomeController {

    private static String sortField = "";
    private static String sortOrder = "";

    private static List<Gadget> gadgets = Arrays.asList(
            new Gadget("Smartphone", "Apple", 2022, "iOS", 1000),
            new Gadget("Tablet", "Samsung", 2021, "Android", 800),
            new Gadget("Laptop", "Dell", 2020, "Windows", 1200),
            new Gadget("Smartwatch", "Samsung", 2022, "Tizen", 500),
            new Gadget("Headphones", "Bose", 2021, "None", 300),
            new Gadget("Smart speaker", "Google", 2020, "Google Assistant", 100),
            new Gadget("Fitness tracker", "Fitbit", 2021, "None", 150),
            new Gadget("E-reader", "Amazon", 2022, "Kindle OS", 200),
            new Gadget("Gaming console", "Sony", 2020, "PlayStation OS", 400),
            new Gadget("Smart TV", "LG", 2021, "WebOS", 700),
            new Gadget("Wireless charger", "Belkin", 2022, "None", 50),
            new Gadget("Virtual assistant", "Amazon", 2020, "Alexa", 80)
    );

    @RequestMapping(value = {"/", "/home"})
    public String index() {
        return "index";
    }

    @RequestMapping("/date-time")
    public ModelAndView dateTime() {
        ModelAndView mav = new ModelAndView("date-time");

        mav.addObject("date", new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(new Date()));
        mav.addObject("days",
                Duration.between(LocalDate.now().withDayOfYear(1).atStartOfDay(), LocalDateTime.now()).toDays());

        return mav;
    }

    @RequestMapping("/cylinders")
    public String cylinders(Model model) {
        List<Cylinder> cylinders = Arrays.asList(
                new Cylinder(5, 5, "copper", 8.9),
                new Cylinder(5, 5, "steel", 7.8),
                new Cylinder(5, 5, "basalt", 2.9),
                new Cylinder(5, 5, "ice", 0.92));

        model.addAttribute("cylinders", cylinders);

        return "cylinders";
    }

    @RequestMapping("/gadgets")
    public String gadgets(@RequestParam(value = "sortField", defaultValue = "type") String sortField,
                          @RequestParam(value = "sortOrder", defaultValue = "asc") String sortOrder,
                          Model model) {

        // если сортировка по последнему сортированному полю, то сменить порядок
        HomeController.sortOrder = HomeController.sortField.equalsIgnoreCase(sortField)
                ? this.toggleSortOrder(sortOrder)
                : sortOrder;

        HomeController.sortField = sortField;

        Comparator<Gadget> comparator = switch (sortField) {
            case "type" -> Comparator.comparing(Gadget::type);
            case "manufacturer" -> Comparator.comparing(Gadget::manufacturer);
            case "year" -> Comparator.comparingInt(Gadget::year);
            case "os" -> Comparator.comparing(Gadget::os);
            default -> Comparator.comparingInt(Gadget::price);
        };

        if (HomeController.sortOrder.equalsIgnoreCase("desc")) {
            comparator = comparator.reversed();
        }

        gadgets.sort(comparator);

        model.addAttribute("gadgets", gadgets);
        model.addAttribute("sortField", HomeController.sortField);
        model.addAttribute("sortOrder", HomeController.sortOrder);

        return "gadgets";
    }

    private String toggleSortOrder(String order) {
        return order.equalsIgnoreCase("asc") ? "desc" : "asc";
    }
}
