package org.itstep.pd011.maslennikov.models;

public record Cylinder(double radius, double height, String material, double density) {
    public double getSurfaceArea() {
        return 2 * Math.PI * radius * (radius + height);
    }

    public double getVolume() {
        return Math.PI * radius * radius * height;
    }

    public double getMass() {
        return density * getVolume();
    }
}