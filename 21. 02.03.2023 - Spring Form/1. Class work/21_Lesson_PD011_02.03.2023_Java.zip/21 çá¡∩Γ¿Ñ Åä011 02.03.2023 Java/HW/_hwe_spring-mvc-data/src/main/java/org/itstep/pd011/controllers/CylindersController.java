package org.itstep.pd011.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

// обработка коллекции цилиндров
@Controller
public class CylindersController {

    @GetMapping(value = "/cylinders")
    public String showCylinders(Model model) {
        return "cylinders-view";
    } // showCylinders
} // class CylindersController
