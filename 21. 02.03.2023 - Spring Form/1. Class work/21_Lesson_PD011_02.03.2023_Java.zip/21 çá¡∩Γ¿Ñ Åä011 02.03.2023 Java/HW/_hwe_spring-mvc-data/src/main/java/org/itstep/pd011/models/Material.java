package org.itstep.pd011.models;

// описание материала: название и плотность
public class Material {
    // название
    private String name;

    // плотность
    private double density;

    // конструкторы

    public Material() {
    }

    public Material(String name, double density) {
        this.name = name;
        this.density = density;
    }

    // аксессоры

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getDensity() {
        return density;
    }

    public void setDensity(double density) {
        this.density = density;
    }
} // class Material
