package org.itstep.pd011.models;

// Данные о цилиндре, изготовленном из некоторого материала
public class Cylinder {
    // радиус основания
    private double r;

    // высота
    private double h;

    // материал: название, плотность
    private Material material;

    // конструкторы

    // методы

    // вычисление площади поверхности
    // вычисление объема
    // вычисление массы

} // class Cylinder
