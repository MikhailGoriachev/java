package org.itstep.pd011.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

// вывод главной страницы, страницы сведений о разработчике
@Controller
public class HomeController {

    // отображение главной страницы, приведем полную аннотацию
    // для обслуживаемого HTTP-запроса
    @RequestMapping(value="/", method = RequestMethod.GET)
    public String index() {
        return "index";
    } // index

    // отображение страницы сведений о разработчике
    @GetMapping(value = "/about")
    public String about(Model model) {
        return "about-view";
    } // about

} // class HomeController
