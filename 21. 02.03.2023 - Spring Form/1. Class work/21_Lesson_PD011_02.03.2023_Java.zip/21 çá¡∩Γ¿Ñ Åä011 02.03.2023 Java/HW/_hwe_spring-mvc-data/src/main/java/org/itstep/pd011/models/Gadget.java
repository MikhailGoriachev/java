package org.itstep.pd011.models;

// класс сведений о гаджете
// тип, производитель, год выпуска, операционная система, цена
public class Gadget {
    // тип
    private String type;

    // производитель
    private String brand;

    // год выпуска
    private int year;

    // операционная система
    private String os;

    // цена
    private int price;

    // конструкторы

    public Gadget() {
    } // Gadget

    public Gadget(String type, String brand, int year, String os, int price) {
        this.type = type;
        this.brand = brand;
        this.year = year;
        this.os = os;
        this.price = price;
    }

    // аксесссоры

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getOs() {
        return os;
    }

    public void setOs(String os) {
        this.os = os;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
} // class Gadget
