package org.itstep.pd011.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

// Обработка коллекции гаджетов
@Controller
public class GadgetsController {
    // статическая коллекция

    @GetMapping(value = "/gadgets")
    public String showGadgets(Model model) {
        return "gadgets-view";
    } // showGadgets

    // упорядочить коллекцию гаджетов по убыванию цены
    @GetMapping(value = "/gadgets-by-price-desc")
    public String orderByPriceDesc(Model model) {
        return "gadgets-view";
    } // orderByPriceDesc

    // упорядочить коллекцию гаджетов по типу
    @GetMapping(value = "/gadgets-by-type")
    public String orderByType(Model model) {
        return "gadgets-view";
    } // orderByType


    // упорядочить коллекцию гаджетов по производителю
    @GetMapping(value = "/gadgets-by-brand")
    public String orderByPrice(Model model) {
        return "gadgets-view";
    } // orderByBrand

} // class GadgetsController
