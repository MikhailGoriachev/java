package org.step.home_work.models.cylinders;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class CylindersContainer {

    //Id последнего добавле
    public static int lastCylinderId = 0;

    //Коллекция цицлиндров
    public List<Cylinder> cylinders;

    public CylindersContainer(List<Cylinder> cylinders) {
        this.cylinders = cylinders;
    }

    //Инициализация коллекции
    public CylindersContainer() {
        this.cylinders = new ArrayList<>(Stream.generate(Cylinder::new).limit(5).toList());
    }


}
