package org.step.home_work;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.step.home_work.models.cylinders.CylindersContainer;
import org.step.home_work.models.gadgets.GadgetsContainer;

import java.util.Date;


@Controller
public class MainController {

    private static CylindersContainer cylindersContainer;
    private static GadgetsContainer gadgetsContainer;

    static {
        cylindersContainer = new CylindersContainer();
        gadgetsContainer = new GadgetsContainer();
    }

    //Главная страница
    @RequestMapping("/")
    public String showIndex(){


        return "index";
    }

    //Количество дней, прошедших с начала года
    @RequestMapping("/getTime")

    public ModelAndView getTimeDuration(ModelAndView mav){
        mav.setViewName("time-view");

        //Получить текущую дату
        mav.addObject("currentDate",new Date());

        return mav;
    }

    @RequestMapping("/cylinders")
    public ModelAndView showDays(ModelAndView mav){

        mav.setViewName("cylinders");


        mav.addObject("message","Исходная коллекция цилиндров");
        mav.addObject("cylinders",cylindersContainer.cylinders);

        return mav;
    }

    //Коллекция гаджетов
    @RequestMapping("/gadgets")
    public ModelAndView showGadgets(ModelAndView mav, @RequestParam("sort") String sortType){

        mav.setViewName("gadgets");


        String message = "Исходная коллекция";

        //Зать отсортиованную коллекцияю
        switch (sortType) {
            case "price" -> {
                mav.addObject("gadgets",gadgetsContainer.sortByPriceDesc());
                message = "Сортировка по цене";
            }
            case "model" -> {
                mav.addObject("gadgets",gadgetsContainer.sortByModel());
                message = "Сортировка по типу";
            }
            case "producer" -> {
                mav.addObject("gadgets",gadgetsContainer.sortByProducer());
                message = "Сортировка по производителю";
            }
            default -> {
                mav.addObject("gadgets",gadgetsContainer.gadgets);
            }
        }


        mav.addObject("message",message);

        return mav;
    }


}
