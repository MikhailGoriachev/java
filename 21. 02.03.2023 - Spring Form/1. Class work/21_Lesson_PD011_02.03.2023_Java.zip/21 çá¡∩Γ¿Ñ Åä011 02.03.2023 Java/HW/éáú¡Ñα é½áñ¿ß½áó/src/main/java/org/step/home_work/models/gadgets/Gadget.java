package org.step.home_work.models.gadgets;

import org.step.home_work.Infrastructure.Utils;
import jakarta.servlet.http.HttpServletRequest;

public class Gadget {

    public int id;

    //Наименование
    private String brand;

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    //Модель
    private String model;

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    //Год выпуска
    private int prod_year;

    public int getProdYear() {
        return prod_year;
    }

    public void setProdYear(int year) {
        this.prod_year = year;
    }


    //Операционная система
    private String os;

    public String getOs() {
        return os;
    }

    public void setOs(String value) {
        this.os = value;
    }

    //Цена
    private int price;

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }


    public Gadget(String brand, String model, int prod_year, String os, int price) {
        //Задание id
        this.id = ++GadgetsContainer.lastId;
        this.brand = brand;
        this.model = model;
        this.prod_year = prod_year;
        this.os = os;
        this.price = price;
    }

    //Инициализация
    public Gadget() {
        this(Utils.getBrand(),Utils.getModel(),Utils.getRandom(2009,2022),Utils.getSystem(),Utils.getPrice());
    }

    @Override
    public String toString() {
        return this.toTableRow();
    }

    //Вывод в строку таблицы
    public String toTableRow(){

        String row = String.format("""
                <tr>
                    <td class='text-center p-2'>%d</td>
                    <td  class='p-2' >%s</td>
                    <td  class='p-2' >%s</td>
                    <td  class='p-2' >%d</td>
                    <td  class='p-2' >%s</td>
                    <td  class='p-2' >%d</td>
                </tr>
                """,
                this.id,
                this.brand,
                this.model,
                this.prod_year,
                this.os,
                this.price
                );

        return row;
    }


}
