package org.step.home_work.models;

//Константы плотнотей
public enum MaterialsEnum {

    //Плотность в г/см^3
    COOPER(8.92),BASALT(2.6),ICE(0.9167),STEEL(7.9);

    MaterialsEnum(double val) {
        this.value = val;
    }

    private double value;
    public double getValue() { return value; }

    public static String getMaterialName(String material){
        return switch (material) {
            case "Copper" -> "Медь";
            case "Steel" -> "Сталь";
            case "Basalt" -> "Базальт";
            case "Ice" -> "Водяной лед";
            default -> "Ненайден";
        };
    }

}
