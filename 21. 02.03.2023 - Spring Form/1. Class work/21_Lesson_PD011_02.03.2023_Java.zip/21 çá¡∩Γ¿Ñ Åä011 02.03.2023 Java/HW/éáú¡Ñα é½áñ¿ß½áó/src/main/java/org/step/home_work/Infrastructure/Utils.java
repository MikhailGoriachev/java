package org.step.home_work.Infrastructure;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Random;
import java.util.*;
public class Utils {

    //Генерация значений
    private static Random rand = new Random();

    public static DecimalFormat doubleFormatter = new DecimalFormat("#0.00");

    public Utils() {
    }

    //Получение слуйчаных значений
    public static double getRandom(double lo, double hi) {
        return lo + rand.nextDouble() * (hi - lo);
    }

    public static int getRandom(int lo, int hi) {
        return lo + rand.nextInt(hi - lo);
    }


    //Список имён материалов
    public static String[] materials = new String[]{
                "Copper",
                "Steel" ,
                "Basalt",
                "Ice"
        };

    public static String getMaterial(){
        return materials[getRandom(0,materials.length)];
    }


    public static List<String> brands = new ArrayList<>(List.of(
            "Asus","Lenovo","HP","Microsoft","Dell","Apple", "Samsung", "Philips"
    ));

    public static List<String> models = new ArrayList<>(List.of(
            "A5","A2","A72","Surface Book","Pavilion"
    ));

    public static String[] systems = new String[]{
            "Windows",
            "MacOS",
            "IOS",
            "Android",
            "Linux",
    };


    //Бренд ноутбука
    public static String getBrand(){
        return brands.get(getRandom(0,brands.size()));
    }

    //модель ноутбука
    public static String getModel(){
        return models.get(getRandom(0,models.size()));
    }


    //Дефект ноутбука
    public static String getSystem(){
        return systems[getRandom(0, systems.length)];
    }



    //Объём накопителя
    public static int getPrice(){
        return getRandom(20,120)*1000;
    }




}
