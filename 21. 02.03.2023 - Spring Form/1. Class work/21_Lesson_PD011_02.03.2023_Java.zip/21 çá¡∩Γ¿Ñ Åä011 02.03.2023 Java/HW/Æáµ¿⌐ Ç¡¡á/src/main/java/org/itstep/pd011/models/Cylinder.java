package org.itstep.pd011.models;

public class Cylinder {

    private final double r;
    private final double h;
    private final Material material;

    public Cylinder(Material material) {
        this(10, 5, material);
    }

    public Cylinder(double r, double h, Material material) {
        this.r = r;
        this.h = h;
        this.material = material;
    }

    public Material getMaterial() {
        return material;
    }

    public double area() {
        return 2 * Math.PI * r * h + 2 * Math.PI * r * r;
    }

    public double volume() {
        return Math.PI * r * r * h;
    }

    public double weight() {
        return material.getP() * volume();
    }

    @Override
    public String toString() {

        return String.format("<tr><td>%.2f</td><td>%.2f</td><td>%.2f</td><td>%.2f</td><td>%.2f</td><td>%s</td><td>%d</td>" +
                        "<td><img src=\"<c:url value=\"/resources/images/copper.jpg\" />\" /></td></tr>",
                r,h,area(),volume(),weight(),material.getTitle(),material.getP());
    }

}
