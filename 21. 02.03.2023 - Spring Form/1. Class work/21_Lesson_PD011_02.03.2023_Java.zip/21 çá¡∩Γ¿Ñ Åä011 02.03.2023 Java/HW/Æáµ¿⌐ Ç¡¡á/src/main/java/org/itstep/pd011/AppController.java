package org.itstep.pd011;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.Year;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.itstep.pd011.models.*;

@Controller
public class AppController {

    private static final SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

    //(Гаджеты) просто статическое поле в классе контроллера.
    private static final List<Gadget> gadgets = new ArrayList<>(List.of(
            new Gadget("Наушники", "Apple", 2022, "none", 15000),
            new Gadget("Смартфон", "Apple", 2022, "IOS", 64399),
            new Gadget("Наушники", "Xiaomi", 2020, "none", 3000),
            new Gadget("Смартфон", "Xiaomi", 2020, "Android", 16000),
            new Gadget("Смартфон", "POCO", 2021, "Android", 2200),
            new Gadget("Наушники", "ZET GAMING", 2021, "none", 5500),
            new Gadget("Наушники", "Razer", 2020, "none", 9000),
            new Gadget("Смартфон", "Xiaomi", 2022, "Android", 20000),
            new Gadget("Портативный аккумулятор", "Xiaomi", 2020, "none", 2500),
            new Gadget("Портативный аккумулятор", "Accesstyle", 2019, "none", 1000),
            new Gadget("Смарт-часы", "Apple", 2022, "IOS", 34500),
            new Gadget("Смарт-часы", "Samsung", 2022, "Wear OS", 28000)));

    // вывод главной страницы
    @RequestMapping("/")
    public String showIndex() {
        return "index";
    }

    //Дата и время – текущие дата и время на сервере передаются в JSP-страницу, а количество полных дней,
    // прошедших с начала года (используйте класс Duration)
    @RequestMapping("/date-time")
    public ModelAndView showDateTime(ModelAndView mav) {
        mav.setViewName("date-time-view");

        //текущие дата и время
        mav.addObject("date", format.format(new Date()));

        //количество полных дней, прошедших с начала года
        Duration duration = Duration.between(LocalDateTime.of(Year.now().getValue(), 1, 1, 0, 0, 0)
                , LocalDateTime.now());
        mav.addObject("duration", duration.toDays());

        return mav;
    }

    //Цилиндры – по запросу формировать коллекцию цилиндров равного размера, но из разных материалов (медь, сталь,
    // базальт, водяной лед) вычислить площадь поверхности, объем, массу. Вывести исходные данные, изображение материала
    //и результаты расчета в JSP-страницу.
    @RequestMapping("/cylinders")
    public ModelAndView showCylinders(ModelAndView mav) {
        mav.setViewName("cylinders-view");

        List<Cylinder> cylinders = new ArrayList<>(List.of(
                new Cylinder(Material.COPPER),
                new Cylinder(Material.STEEL),
                new Cylinder(Material.BASALT),
                new Cylinder(Material.ICE)
        ));

        mav.addObject("cylinders", cylinders);

        /*
        mav.addObject("cylinder01", new Cylinder(Material.COPPER));
        mav.addObject("cylinder02", new Cylinder(Material.STEEL));
        mav.addObject("cylinder03", new Cylinder(Material.BASALT));
        mav.addObject("cylinder04", new Cylinder(Material.ICE));*/

        return mav;
    }

    //Гаджеты – выводить в JSP-страницу с коллекцией сведений о гаджетах (тип, производитель, год выпуска,
    // операционная система, цена). Можно использовать не использовать бин для коллекции, просто статическое
    // поле в классе контроллера. Иниицилизация коллекции – также в классе контроллера. По ссылкам на JSP-странице
    // требуется упорядочивать коллекцию гаджетов:

    //По убыванию цены
    @RequestMapping("/gadgets-order-by-price")
    public ModelAndView showGadgetsOrderByPrice(ModelAndView mav) {
        mav.setViewName("gadgets-view");

        mav.addObject("msg", "По убыванию цены:");
        mav.addObject("gadgets", gadgets.stream().sorted((x1, x2) -> x2.getPrice() - x1.getPrice()).toList());
        return mav;
    }

    //По типу
    @RequestMapping("/gadgets-order-by-type")
    public ModelAndView showGadgetsOrderByType(ModelAndView mav) {
        mav.setViewName("gadgets-view");

        mav.addObject("msg", "По типу:");
        mav.addObject("gadgets", gadgets.stream().sorted(Comparator.comparing(Gadget::getType)).toList());
        return mav;
    }

    //По производителю
    @RequestMapping("/gadgets-order-by-maker")
    public ModelAndView showGadgetsOrderByMaker(ModelAndView mav) {
        mav.setViewName("gadgets-view");

        mav.addObject("msg", "По производителю:");
        mav.addObject("gadgets", gadgets.stream().sorted(Comparator.comparing(Gadget::getMaker)).toList());
        return mav;
    }
}
