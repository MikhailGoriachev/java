let $ = function (id) {
    return document.getElementById(id);
}

window.onload = loadHandler;

function loadHandler() {

    let brandsList = $("brands_list");
    let brandField = $("brand_field");
    let modelsList = $("models_dropDown");
    let modelField = $("model_field");

    //Ввод производиетля
    brandsList.addEventListener("change",(e) =>{

        if (e.target.value.toLowerCase().includes("другое")) {

            brandsList.classList.toggle("visually-hidden");
            brandField.classList.toggle("visually-hidden");
        }
    },false);

    //Ввод модели
    modelsList.addEventListener("change",(e) =>{
        if (e.target.value.toLowerCase().includes("другое")) {

            modelsList.classList.toggle("visually-hidden");
            modelField.classList.toggle("visually-hidden");
        }
    },false);




}