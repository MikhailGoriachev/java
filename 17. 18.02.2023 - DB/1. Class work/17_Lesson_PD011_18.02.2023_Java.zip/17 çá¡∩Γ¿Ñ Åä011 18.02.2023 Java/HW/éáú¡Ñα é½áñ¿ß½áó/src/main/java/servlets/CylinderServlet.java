package servlets;

import Infrastructure.Utils;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import models.Cylinder;
import models.DensitiesEnum;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;

@WebServlet("/cylinder-calc")
public class CylinderServlet extends HttpServlet {

    Cylinder cylinder;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        //Настроить параметры овтета
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        //Получение параметров
        String material = request.getParameter("material");


        String[] accounting = request.getParameterValues("calculation");

        //Парсинг значений
        double radius = Double.parseDouble(request.getParameter("radius").replace(',','.'));
        double height = Double.parseDouble(request.getParameter("height").replace(',','.'));


        cylinder = new Cylinder(radius,height,material);

        request.setAttribute("material",DensitiesEnum.getMaterialName(material));
        request.setAttribute("accounting",accounting);
        request.setAttribute("radius",String.format("%.3f",radius));
        request.setAttribute("height",String.format("%.3f",height));

        //Вычисляемые значения
        request.setAttribute("volume",String.format("%.3f",cylinder.volume()));
        request.setAttribute("mass",String.format("%.3f",cylinder.mass()));
        request.setAttribute("square",String.format("%.3f",cylinder.square()));

        getServletContext()
                .getRequestDispatcher("/cylinderResult.jsp")
                .forward(request,response);
    }

}
