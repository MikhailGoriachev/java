package models.gadgets;

import jakarta.servlet.http.HttpServletRequest;

import java.util.*;

public class GadgetsContainer {

    //Коллекция гаджетов
    public List<Gadget> gadgets;

    //Id последнего добавленного элемента
    public static int lastId;

    //Default генерацияя
    public GadgetsContainer() {
        this(new ArrayList<>(List.of(
                        new Gadget(),
                        new Gadget(),
                        new Gadget(),
                        new Gadget(),
                        new Gadget(),
                        new Gadget() ))
        );
    }

    public GadgetsContainer(List<Gadget> gadgets) {
        this.gadgets = gadgets;
    }

    //Формирование таблицы
    public StringBuilder toTable(){
        String tableHeader = String.format("""
                <table class="table-bordered table-settings w-75 mx-auto mt-4">
                
                    <tr>
                        <th colspan='6' class='justify-content-center'>
                            <div class="d-flex justify-content-center">
                                <b>Гаджеты</b>
                            </div>
                        </th>
                    </tr>
                    <tr>
                        <th colspan='6'>
                            <div class="d-flex justify-content-center">
                                <a class="btn btn-outline-success my-2 w-38" href="gadgetForm.jsp">Добавить</a>
                            </div>
                        </th>
                    </tr>
                    <tr>
                        <th>
                            Id
                        </th>
                        <th>
                            Производитель
                        </th>
                        <th>
                            Модель
                        </th>
                        <th>
                            Год производства
                        </th>
                        <th>
                            ОС
                        </th>
                        <th>
                            Цена
                        </th>
                    </tr>
                """);

        StringBuilder sb = new StringBuilder(tableHeader);

        gadgets.forEach(g -> sb.append(g.toTableRow()));

        return sb.append("</table>");

    }//ToTable

    //Добавление элемента в список
    public void addGadget(String brand, String model, int produced, String os, int price){

        if (brand == null || model == null || os == null || brand.isBlank() || model.isBlank())
            throw new RuntimeException("Некорректные параметры гаджета");

        gadgets.add(new Gadget(
                brand,
                model,
                produced,
                os,
                price
        ));

    }

    //Сортировка по убыванию цены
    public List<Gadget> sortByPriceDesc(){
        return gadgets.stream().sorted((g1,g2) -> g2.getPrice() - g1.getPrice()).toList();
    }

    //Сортировка по типу
    public List<Gadget> sortByModel(){
        return gadgets.stream().sorted(Comparator.comparing(Gadget::getModel)).toList();
    }

    //Сортировка по производителю
    public List<Gadget> sortByProducer(){
        return gadgets.stream().sorted(Comparator.comparing(Gadget::getBrand)).toList();
    }

}
