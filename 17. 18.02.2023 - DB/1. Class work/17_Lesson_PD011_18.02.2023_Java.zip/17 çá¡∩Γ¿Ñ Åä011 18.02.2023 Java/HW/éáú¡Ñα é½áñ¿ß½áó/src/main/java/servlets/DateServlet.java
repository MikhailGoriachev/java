package servlets;

import Infrastructure.Utils;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Date;

@WebServlet("/date")
public class DateServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //Настроить параметры овтета
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        String result = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss").format(new Date());

        //Запись cookies
        String name = "dateTime";
        Cookie[] cookies = request.getCookies();
        Cookie cookie= null;

        //Получение куки
        if (cookies != null) {
            boolean isFound = Arrays.stream(cookies).anyMatch(c -> c.getName().equals(name));
            cookie = isFound ? Arrays.stream(cookies).filter(c -> c.getName().equals(name)).findFirst().get() : null;
        }

        //Проверка куки на существование
        if (cookie != null)
            result = "Еще рано, подождите, ничего не изменилось";
        else {
            cookie = new Cookie(name, URLEncoder.encode( result, StandardCharsets.UTF_8));
            cookie.setMaxAge(20);
            response.addCookie(cookie);
        }

        request.setAttribute(name,result);

        getServletContext()
                .getRequestDispatcher("/dateTime.jsp")
                .forward(request,response);

    }

}
