package home_task.models;


public record Query6(
        String date,
        int amount,
        int maxPrice) {

    //Заголовок таблицы
    public static String HEADER ="<tr>" +
            "<th>Дата приема</th>" +
            "<th>Количество записей</th>" +
            "<th>Максимальня стоимость приема</th>" +
            "</tr>";

    //Строка таблицы
    public  String toTableRow (){
        return String.format(
                "<tr>" +
                        "<td> %1$s </td>" +
                        "<td> %2$d </td>" +
                        "<td> %3$d </td>" +
                        "</tr>", date,amount, maxPrice);
    };

}

