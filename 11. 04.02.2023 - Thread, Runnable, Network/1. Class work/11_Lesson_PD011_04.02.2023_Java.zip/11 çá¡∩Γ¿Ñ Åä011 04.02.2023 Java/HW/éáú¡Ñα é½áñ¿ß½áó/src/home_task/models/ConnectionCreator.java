package home_task.models;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

// Генератор подключения к БД
public class ConnectionCreator {

    //Данные из файла
    private static final Properties properties = new Properties();

    private static final String DB_URL;

    // Статическая инициализация
    static {

        try {
            properties.load(new FileReader("app_data/PolyclinicDB.properties"));

            String driverName = "com.mysql.cj.jdbc.Driver";

            Class.forName(driverName);
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

        DB_URL = (String) properties.get("url");

    }

    private ConnectionCreator(){}

    //Создание подключения
    public static Connection createConnection() throws SQLException {
        String username = properties.getProperty("username");
        String password = properties.getProperty("password");

        return DriverManager.getConnection(DB_URL, properties);
        /*return DriverManager.getConnection(DB_URL, username,password);*/
    }

}
