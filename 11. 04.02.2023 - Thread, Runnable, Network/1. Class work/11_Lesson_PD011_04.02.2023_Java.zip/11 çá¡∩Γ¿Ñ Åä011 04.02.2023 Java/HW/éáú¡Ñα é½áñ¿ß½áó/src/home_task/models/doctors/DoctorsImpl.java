package home_task.models.doctors;

import home_task.interfaces.IDoctors;
import home_task.middleware.DBHandler;
import home_task.models.ConnectionCreator;
import home_task.models.exceptions.DaoException;

import java.sql.*;
import java.util.List;

public class DoctorsImpl implements IDoctors {

    @Override
    public boolean create(Doctor entity) throws DaoException {
        return false;
    }

    //Получение записей
    @Override
    public List<Doctor> getAll() throws DaoException {
        String query = """
               select
                   *
               from view_doctors
                """;

        //Создать оператор запроса
        try {
            Connection connection = ConnectionCreator.createConnection();

            //Оператор запросов
            Statement state = connection.createStatement();

            //Выполнение запроса
            ResultSet set = state.executeQuery(query);

            return DBHandler.doctorsToList(set);

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

    @Override
    public Doctor getById(Integer id) throws DaoException {
        String query = """
               select
                   *
               from
                   view_doctors
               where
                   view_doctors.id = ? limit 1;
                """;

        //Создать оператор запроса
        try {
            Connection connection = ConnectionCreator.createConnection();

            //Оператор запросов
            PreparedStatement ps = connection.prepareStatement(query);

            ps.setInt(1,id);

            //Выполнение запроса
            ResultSet set = ps.executeQuery();

            //Полуачемый объект
            Doctor tempDoctor = null;

            //Получение объекта
            while (set.next()){
                tempDoctor = new Doctor(
                        set.getInt("id"),
                        set.getString("doctor_surname"),
                        set.getString("doctor_name"),
                        set.getString("doctor_patronymic"),

                        set.getString("speciality"),
                        set.getDouble("percent"),
                        set.getInt("price"));

            }

            return tempDoctor;

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }


    //Редактирование записи
    @Override
    public Doctor update(Doctor entity) throws DaoException {
        //Поменять доктора для приема за определённую дату
        String query = """
                update doctors
                set
                    doctors.price = ?,
                    doctors.percent = ?
                where
                    doctors.id = ?;
                """;

        try {
            Connection connection = ConnectionCreator.createConnection();

            PreparedStatement ps = connection.prepareStatement(query);

            //Задать дату
            ps.setInt(1,entity.payment());
            ps.setDouble(2,entity.percent());
            ps.setInt(3,entity.id());

            //Выполнение запроса
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DaoException(e);
        }

        return getById(entity.id());
    }

    //Удаление записи - не определяется
    @Override
    public boolean delete(Doctor entity) throws DaoException {

        throw new UnsupportedOperationException();
    }

    @Override
    public boolean delete(Integer id) throws DaoException {

        throw new UnsupportedOperationException();
    }

    //Запрос 2 - информацию о врачах, для которых значение в поле Процент отчисления на зарплату, больше заданного
    @Override
    public ResultSet query2(Double percent) throws DaoException {
        return null;
    }

    //Запрос 4 - выбирает из таблицы информацию о врачах с заданной специальностью
    @Override
    public ResultSet query4(String speciality) throws DaoException {
        return null;
    }
}
