package home_task.models.appointments;

import home_task.models.Entity;

import java.util.Date;
import java.util.Objects;

public class Appointment extends Entity {
    private final int id;

    private Date date;
    private final String patientSurname;
    private final String patientName;
    private final String patientPatronymic;
    private final Date dob;
    private final String address;
    private final String doctorSurname;
    private final String doctorName;
    private final String doctorPatronymic;
    private final String speciality;
    private final String passport;
    private final double percent;
    private final int price;

    public static final String HEADER = "<tr>" +
            "<th>ID</th>" +
            "<th>Дата приема</th>" +
            "<th>Фамилия пациента</th>" +
            "<th>Имя пациента</th>" +
            "<th>Отчество пациента</th>" +
            "<th>Адрес пациента</th>" +
            "<th>Дата рождения</th>" +
            "<th>Фамилия доктора</th>" +
            "<th>Имя доктора</th>" +
            "<th>Отчество доктора</th>" +
            "<th>Специалист</th>" +
            "<th>Паспорт пациента</th>" +
            "<th>Стоимость приема</th>" +
            "<th>% отчислений</th>" +
            "</tr>";

    public Appointment(
            int id,
            Date date,
            String patientSurname,
            String patientName,
            String patientPatronymic,
            Date dob,
            String address,
            String doctorSurname,
            String doctorName,
            String doctorPatronymic,
            String speciality,

            String passport,
            double percent,
            int price

    ) {
        this.id = id;
        this.date = date;
        this.patientSurname = patientSurname;
        this.patientName = patientName;
        this.patientPatronymic = patientPatronymic;
        this.dob = dob;
        this.address = address;
        this.doctorSurname = doctorSurname;
        this.doctorName = doctorName;
        this.doctorPatronymic = doctorPatronymic;
        this.speciality = speciality;
        this.passport = passport;
        this.percent = percent;
        this.price = price;
    }

    public String toTableRow() {
        return String.format("<tr>" +
                        "<td> %1$d </td>" +
                        "<td> %2$td.%2$tm.%2$tY </td>" +
                        "<td> %3$s </td>" +
                        "<td> %4$s </td>" +
                        "<td> %5$s </td>" +
                        "<td> %6$s </td>" +
                        "<td> %7$td.%7$tm.%7$tY </td>" +
                        "<td> %8$s </td>" +
                        "<td> %9$s </td>" +
                        "<td> %10$s </td>" +
                        "<td> %11$s </td>" +
                        "<td> %12$s </td>" +
                        "<td> %13$d </td>" +
                        "<td> %14$.2f </td>" +
                        "</tr>",
                id, date,
                patientSurname, patientName, patientPatronymic, address, dob,
                doctorSurname, doctorName, doctorPatronymic, speciality, passport, price, percent);
    } // toTableRow

    public Date date() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int id() {
        return this.id;
    }
    public String patientSurname() {
        return patientSurname;
    }

    public String patientName() {
        return patientName;
    }

    public String patientPatronymic() {
        return patientPatronymic;
    }

    public Date dob() {
        return dob;
    }

    public String address() {
        return address;
    }

    public String doctorSurname() {
        return doctorSurname;
    }

    public String doctorName() {
        return doctorName;
    }

    public String doctorPatronymic() {
        return doctorPatronymic;
    }

    public String speciality() {
        return speciality;
    }

    public String passport() {
        return passport;
    }

    public double percent() {
        return percent;
    }

    public int price() {
        return price;
    }


}
