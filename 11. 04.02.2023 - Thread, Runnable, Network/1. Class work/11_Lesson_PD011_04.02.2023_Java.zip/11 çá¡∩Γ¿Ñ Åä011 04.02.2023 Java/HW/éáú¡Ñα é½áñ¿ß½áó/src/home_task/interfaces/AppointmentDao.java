package home_task.interfaces;

import home_task.models.appointments.Appointment;
import home_task.models.exceptions.DaoException;

import java.util.Date;
import java.util.List;

//Расширяющий интерфейс для всех запросов
public interface AppointmentDao extends BaseDAO<Integer, Appointment> {

    //Запрос 4 - выбрать записи на прием к врачу за заданный период
    List<Appointment> query4(Date from, Date to) throws DaoException;

}
