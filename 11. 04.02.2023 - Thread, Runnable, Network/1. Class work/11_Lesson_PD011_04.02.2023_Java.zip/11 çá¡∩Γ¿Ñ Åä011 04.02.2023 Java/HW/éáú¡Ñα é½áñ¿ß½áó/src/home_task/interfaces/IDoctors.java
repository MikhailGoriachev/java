package home_task.interfaces;

import home_task.models.appointments.Appointment;
import home_task.models.doctors.Doctor;
import home_task.models.exceptions.DaoException;

import java.sql.ResultSet;

//Расширяющий интерфейс для всех запросов
public interface IDoctors extends BaseDAO<Integer, Doctor> {

    //Запрос 2 - информацию о врачах, для которых значение в поле Процент отчисления на зарплату, больше заданного
    ResultSet query2(Double percent) throws DaoException;


    //Запрос 4 - выбирает из таблицы информацию о врачах с заданной специальностью
    ResultSet query4(String speciality) throws DaoException;
}
