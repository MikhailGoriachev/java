package home_task.models;

import java.io.Serializable;

public abstract class Entity implements Serializable, Cloneable {
}
