package home_task.models.patients;

import home_task.models.Entity;

import java.util.Objects;

public final class Patient extends Entity {

    //Заголовок таблицы
    public static String HEADER =
            "<th>ID</th>" +
                    "<th>Фамилия  пациента</th>" +
                    "<th>Имя пациента</th>" +
                    "<th>Отчество пациента</th>" +
                    "<th>Адрес пациента</th>" +
                    "<th>Дата рождения</th>" +
                    "<th>Паспорт пациента</th>" +
                    "</tr>";
    private final int id;
    private final String surname;
    private final String name;
    private final String patronymic;
    private final String date;
    private final String address;
    private final String passport;

    public Patient(int id,
                   String surname,
                   String name,
                   String patronymic,
                   String date,
                   String address,
                   String passport
    ) {
        this.id = id;
        this.surname = surname;
        this.name = name;
        this.patronymic = patronymic;
        this.date = date;
        this.address = address;
        this.passport = passport;
    }

    //Строка таблицы
    public String toTableRow() {
        return String.format("<tr>" +
                        "<td> %1$d </td>" +
                        "<td> %2$s </td>" +
                        "<td> %3$s </td>" +
                        "<td> %4$s </td>" +
                        "<td> %5$s </td>" +
                        "<td> %6$s </td>" +
                        "<td> %7$s </td>" +
                        "</tr>",
                id,
                surname, name, patronymic, address, date, passport);
    }

    public int id() {
        return id;
    }

    public String surname() {
        return surname;
    }

    public String name() {
        return name;
    }

    public String patronymic() {
        return patronymic;
    }

    public String date() {
        return date;
    }

    public String address() {
        return address;
    }

    public String passport() {
        return passport;
    }


    ;

}
