package home_task.models.patients;

import home_task.interfaces.IPatients;
import home_task.models.appointments.Appointment;
import home_task.models.exceptions.DaoException;

import java.sql.ResultSet;
import java.util.List;

//Реализация интерфейсов DAO
public class PatientsImpl implements IPatients {

    //Создание записи
    @Override
    public boolean create(Patient entity) throws DaoException {
        return false;
    }

    //Получение записей
    @Override
    public List<Patient> getAll() throws DaoException {
        return null;
    }

    @Override
    public Patient getById(Integer id) throws DaoException {
        return null;
    }

    //Редактирование записи
    @Override
    public Patient update(Patient entity) throws DaoException {

        return null;
    }

    //Удаление записи - не определяется
    @Override
    public boolean delete(Patient entity) throws DaoException {

        throw new UnsupportedOperationException();
    }

    @Override
    public boolean delete(Integer id) throws DaoException {

        throw new UnsupportedOperationException();
    }

    //Запрос 1 - информацию о пациентах с фамилиями, начинающимися на заданную последовательность символов
    @Override
    public ResultSet query1(String patientSurname) throws DaoException {
        return null;
    }
}
