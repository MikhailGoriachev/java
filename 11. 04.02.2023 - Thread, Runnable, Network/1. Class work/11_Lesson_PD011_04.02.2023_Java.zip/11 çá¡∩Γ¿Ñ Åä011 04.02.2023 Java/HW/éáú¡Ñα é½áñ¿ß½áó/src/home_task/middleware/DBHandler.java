package home_task.middleware;

import home_task.models.*;
import home_task.models.appointments.*;
import home_task.models.doctors.*;
import home_task.models.exceptions.DaoException;
import home_task.models.patients.Patient;
import home_task.utils.Utils;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.*;
import java.util.ArrayList;
import java.util.*;
import java.util.Date;

//Класс для запросов к БД
public class DBHandler {
    //Соединение с БД
    private final Connection connection;

    //Объект этого же класса для работы с БД
    private static DBHandler instance = null;

    //Создание объекта только 1 раз
    public static synchronized DBHandler getInstance() throws Exception {
        if (instance == null)
            instance = new DBHandler();

        return instance;
    }

    //CRUD + прикладные запросы для Appointments
    private final AppointmentDaoImpl appointmentsImpl;
    private final DoctorsImpl doctorsImpl;

    private DBHandler() throws Exception {
        //Регистрация драйвера SQLLite
       /* DriverManager.registerDriver(new JDBC());*/

        //Регистрация драйвера MySQL
        Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();

        //Создаём подключение к БД
        this.connection = loadConnection();

        //Создаётся объект для работы с сущностями Appointment
        appointmentsImpl = new AppointmentDaoImpl();
        doctorsImpl = new DoctorsImpl();
    }

    //Загрузка конфигурации для подключения к БД MySQL
    private static Connection loadConnection() throws Exception {
        Properties properties = new Properties();

        try(InputStream is = Files.newInputStream(Paths.get("app_data/PolyclinicDB.properties"))){
            properties.load(is);
        }

        //Чтение параметров из файла
        String url = properties.getProperty("url");
        String username = properties.getProperty("user");
        String password = properties.getProperty("password");

        //Получаем подключение
        return DriverManager.getConnection(url,username,password);
    }

    //Получить приемы пациентов
    public List<Appointment> getAppointments() throws SQLException, DaoException {
        return appointmentsImpl.getAll();

    }

    //Получить всех докторов
    public List<Doctor> getDoctors() throws SQLException, DaoException {

        return doctorsImpl.getAll();

       /* String query = """
               select
                   *
               from view_doctors
                """;

        //Создать оператор запроса
        try(Statement state = connection.createStatement()) {

            //Выполнение запроса
            ResultSet set = state.executeQuery(query);

            return doctorsToList(set);

        }*/
    }

    //Получить всех пациентов
    public List<Patient> getPatients() throws SQLException{

        String query = """
               select
                   *
               from view_patients
                """;

        //Создать оператор запроса
        try(Statement state = connection.createStatement()) {

            //Выполнение запроса
            ResultSet set = state.executeQuery(query);

            return patientsToList(set);

        }
    }

    //region Перевод набора данных таблицы в коллекцию
    //Перевести набор данных из таблицы в коллекцию приемов
    public static List<Appointment> appointmentsToList(ResultSet resultSet) throws SQLException {
        List<Appointment> collection = new ArrayList<>();

        while (resultSet.next()){
            collection.add(new Appointment(
                    resultSet.getInt("id"),
                    resultSet.getDate("appointment_date"),

                    resultSet.getString("patient_surname"),
                    resultSet.getString("patient_name"),
                    resultSet.getString("patient_patronymic"),

                    resultSet.getDate("born_date"),
                    resultSet.getString("address"),

                    resultSet.getString("doctor_surname"),
                    resultSet.getString("doctor_name"),
                    resultSet.getString("doctor_patronymic"),

                    resultSet.getString("speciality"),

                    resultSet.getString("passport"),

                    resultSet.getDouble("percent"),
                    resultSet.getInt("price"))
            );
        }
        return collection;
    }

    //Перевести набор данных из таблицы в коллекцию докторов
    public static List<Doctor> doctorsToList(ResultSet resultSet) throws SQLException {
        List<Doctor> collection = new ArrayList<>();

        while (resultSet.next()){
            collection.add(new Doctor(
                    resultSet.getInt("id"),
                    resultSet.getString("doctor_surname"),
                    resultSet.getString("doctor_name"),
                    resultSet.getString("doctor_patronymic"),

                    resultSet.getString("speciality"),
                    resultSet.getDouble("percent"),
                    resultSet.getInt("price"))); //add
        }
        return collection;
    }

    //Перевести набор данных из таблицы в коллекцию пациентов
    public List<Patient> patientsToList(ResultSet resultSet) throws SQLException {
        List<Patient> collection = new ArrayList<>();

        //Сформировать коллекцию из набора данных полученного при запросе
        while (resultSet.next()){
            collection.add(new Patient(
                    resultSet.getInt(1),
                    resultSet.getString("patient_surname"),
                    resultSet.getString("patient_name"),
                    resultSet.getString("patient_patronymic"),

                    resultSet.getString("born_date"),
                    resultSet.getString("address"),
                    resultSet.getString("passport")
            ));
        }
        return collection;
    }
    //endregion

    //region Запросы
    //Запрос 1 -
    public List<Patient> query1(String patientSurname) throws SQLException{

        String query = """
               select
                   *
               from
                   view_patients
               where
                   /*view_patients.patient_surname like ? || '%';*/
                   view_patients.patient_surname like ?
                """;

        //Создать оператор запроса
        try(PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setString(1,patientSurname+"%");

            //Выполнение запроса
            ResultSet set = ps.executeQuery();

            return patientsToList(set);

        }
    }

    //Запрос 2 - Выбирает информацию о врачах, для которых значение в поле.
    // Процент отчисления на зарплату, больше заданного
    public List<Doctor> query2(Double percent) throws SQLException{

        String query = """
               select
                   *
               from
                   view_doctors
               where
                   view_doctors.percent > ?;
                """;

        //Создать оператор запроса
        try(PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setDouble(1,percent);

            //Выполнение запроса
            ResultSet set = ps.executeQuery();

            return doctorsToList(set);

        }
    }

    //Запрос 3 - Выбирает информацию о приемах за некоторый период
    public List<Appointment> query3(Date from,Date to) throws SQLException, DaoException {

        return appointmentsImpl.query4(from,to);
    }

    //Запрос 4 - Выбирает из таблицы информацию о врачах с заданной специальностью
    public List<Doctor> query4(String speciality) throws SQLException{

        String query = """
               select
                   *
               from 
                view_doctors
               where view_doctors.speciality like ?
                """;

        //Создать оператор запроса
        try(PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setString(1,speciality);

            //Выполнение запроса
            ResultSet set = ps.executeQuery();

            return doctorsToList(set);

        }
    }


    //Запрос 5
    public List<Query5> query5() throws Exception{
        List<Query5> collection = new ArrayList<>();

        //Запрос
        String query = """
                select
                        id
                     , view_appointments.appointment_date
                     , view_appointments.doctor_surname
                     , view_appointments.doctor_name
                     , view_appointments.doctor_patronymic
                     , view_appointments.speciality
                     , view_appointments.price
                     , view_appointments.percent
                     , view_appointments.price * percent / 100 as salary
                from
                    view_appointments
                order by
                    view_appointments.speciality
                """;

        //Запуск оператора запроса
        try(Statement statement = connection.createStatement()){

            ResultSet result = statement.executeQuery(query);

            //Сформировать коллекцию
            while (result.next()){
                collection.add(new Query5(
                        result.getInt("id"),

                        result.getString("appointment_date"),

                        result.getString("doctor_surname"),
                        result.getString("doctor_name"),
                        result.getString("doctor_patronymic"),

                        result.getString("speciality"),

                        result.getInt("price"),
                        result.getDouble("percent"),
                        result.getDouble("salary")

                ));
            }

        }

        return collection;
    }

    //Запрос 6
    public List<Query6> query6() throws Exception{
        List<Query6> collection = new ArrayList<>();

        //Запрос
        String query = """
                select
                    view_appointments.appointment_date as date,
                    count(*) as amount,
                    max(view_appointments.price) as maxPrice
                from
                    view_appointments
                group by
                    view_appointments.appointment_date
                """;

        //Запуск оператора запроса
        try(Statement statement = connection.createStatement()){

            ResultSet result = statement.executeQuery(query);

            //Сформировать коллекцию
            while (result.next()){
                collection.add(new Query6(
                        result.getString("date"),
                        result.getInt("amount"),
                        result.getInt("maxPrice")
                ));
            }

        }

        return collection;
    }

    //Запрос 7
    public List<Query7> query7() throws Exception{
        List<Query7> collection = new ArrayList<>();

        //Запрос
        String query = """
                select
                    view_appointments.speciality,
                    count(*) as amount,
                    avg(view_appointments.percent) as avgPercent
                from
                    view_appointments
                group by
                    view_appointments.speciality
                """;

        //Запуск оператора запроса
        try(Statement statement = connection.createStatement()){

            ResultSet result = statement.executeQuery(query);

            //Сформировать коллекцию
            while (result.next()){
                collection.add(new Query7(
                        result.getString("speciality"),
                        result.getInt("amount"),
                        result.getDouble("avgPercent")
                ));
            }

        }

        return collection;
    }
    //endregion

    //Добавление записи
    public List<Appointment> addAppointment() throws SQLException, DaoException {

        //Временная коллекция сущностей приемов
        var tempAppointments = getAppointments();

        var addingAppointment = tempAppointments.get(Utils.getRandom(0,tempAppointments.size()-1));

        //Изменение даты
        Date date = addingAppointment.date();

        //Увеличить дату
        date.setDate(date.getDate()+15);

        addingAppointment.setDate(date);

        appointmentsImpl.create(addingAppointment);

        return getAppointments();
    } //addAppointment

    // Редактирование записи
    public Object[] updates(Appointment appointment, Doctor doctor) throws SQLException, DaoException {

        appointmentsImpl.update(appointment);
        doctorsImpl.update(doctor);

        return new Object[] {getAppointments(), getDoctors()};
    } //editAppointment

    // Удаление записи
    public List<Appointment> deleteAppointment(Appointment entity) throws SQLException, DaoException {
        appointmentsImpl.delete(entity);

        return getAppointments();
    } //deleteAppointment


}
