package home_task.controllers;

import home_task.middleware.DBHandler;
import home_task.models.appointments.Appointment;
import home_task.models.doctors.Doctor;
import home_task.models.exceptions.DaoException;
import home_task.utils.Utils;

import javax.print.Doc;
import javax.swing.*;
import java.sql.SQLException;
import java.util.*;


public class Task1Controller {

    //Создается объект для работы с БД
    DBHandler handler = DBHandler.getInstance();

    public Task1Controller() throws Exception {
    }

    //Запуск меню контроллера
    public void run() throws Exception {

        //Задание значений для окна
        String title = "База данных: поликлиника";
        String message = "<html><h1>Задача 1</h1>";
        Object[] buttons = new Object[]{
                "Запросы",
                "Таблицы",
                "CRUD-операци",
                "Выход"
        };

        //Вызов методов на контроллерах
        while (true) {
            switch (Utils.showWindowButtons(message,title,buttons,"Выход",JOptionPane.DEFAULT_OPTION)) {
                case 0 -> queries();
                case 1 -> tables();
                case 2 -> crud();
                default -> {
                    return;
                }
            }
        }
    }

    //Запросы. Меню
    public void queries() throws Exception{
        //Кнопки меню
        var buttons = new Object[]{"Запрос 1","Запрос 2","Запрос 3","Запрос 4","Запрос 5","Запрос 6","Запрос 7","Выход"};

        //Меню
        while (true) {

            //Выбранный пункт
            var point = Utils.showWindowButtons("Выберете запрос","",buttons,"Выход", JOptionPane.DEFAULT_OPTION);

            //Вывод зазпросов
            switch (point) {
                //Зпапрос 1
                case 0 -> {

                    var patients = handler.getPatients();

                    //Получить случайню первую букву фамилии
                    String firstLettre = patients.get(Utils.getRandom(0,patients.size()))
                            .surname().substring(0,2);

                    System.out.printf("\n\tПараметр запроса 1: \u001b[38;5;34m%s\u001b[0m \n",firstLettre);

                    //Вывод таблицы докторов
                    if (Utils.showPatients(handler.query1(firstLettre)) == 0) {
                        break;
                    }
                }

                case 1 -> {
                    var doctors = handler.getDoctors();

                    //Получить случайню специальность
                    double percent = doctors.stream().mapToDouble(Doctor::percent).average().getAsDouble();

                    System.out.printf(Locale.UK,"\n\tОтчисление врачу за прием для запроса 2: \u001b[38;5;34m%.2f\u001b[0m \n",percent);

                    //Вывод таблицы докторов
                    if (Utils.showDoctors(handler.query2(percent)) == 0) {
                        break;
                    }
                }

                //Запрос 3
                case 2 -> {

                    var collection = handler.getAppointments();

                    Appointment appointment = collection.get(Utils.getRandom(0,collection.size()));

                    Date from = appointment.date();
                    Date to = new Date(from.getTime());

                    from.setDate(from.getDate()-10);
                    to.setDate(to.getDate()+20);

                    System.out.printf(Locale.UK,"\n\tДиапазон дат для запроса 3: от%3$s %1$td.%1$tm.%1$tY \u001b[0m до%3$s %2$td.%2$tm.%2$tY \u001b[0m\n",from,to,"\u001b[38;5;34m");

                    //Для выхода обратно в меню
                    if (Utils.showAppointments(handler.query3(from, to)) == 0) {
                        break;
                    }
                }

                //Запрос 4
                case 3 -> {

                    var doctors = handler.getDoctors();

                    //Получить случайню специальность
                    String speciality = doctors.get(Utils.getRandom(0,doctors.size()))
                                        .speciality();

                    System.out.printf("\n\tСпециальность для запроса 4: \u001b[38;5;34m%s\u001b[0m \n",speciality);

                    //Вывод таблицы докторов
                    if (Utils.showDoctors(handler.query4(speciality)) == 0) {
                        break;
                    }
                }

                //Запрос 5
                case 4 -> {

                    //Для выхода обратно в меню
                    if (Utils.showQuery5(handler.query5()) == 0) {
                        break;
                    }
                }

                //Запрос 6
                case 5 -> {
                    //Для выхода обратно в меню
                    if (Utils.showQuery6(handler.query6()) == 0) {
                        break;
                    }
                }

                //Запрос 7
                case 6 -> {
                    //Для выхода обратно в меню
                    if (Utils.showQuery7(handler.query7()) == 0) {
                        break;
                    }
                }
                default -> {
                    return;
                }
            }
        }//while

    }//run

    //Вывод таблиц
    public void tables() throws Exception{

        var buttons = new Object[]{"Приемы","Врачи","Пациенты","Выход"};

        //Меню
        while (true) {

            //Выбранный пункт
            var point = Utils.showWindowButtons("Выберете таблицу","",buttons,"Выход", JOptionPane.DEFAULT_OPTION);


            switch (point) {

                case 0 -> {
                    //Для выхода обратно в меню
                    if (Utils.showAppointments(handler.getAppointments()) == 0) {
                        break;
                    }
                }

                case 1 -> {
                    //Для выхода обратно в меню
                    if (Utils.showDoctors(handler.getDoctors()) == 0) {
                        break;
                    }
                }

                case 2 -> {
                    //Для выхода обратно в меню
                    if (Utils.showPatients(handler.getPatients()) == 0) {
                        break;
                    }
                }
                default -> {
                    return;
                }
            }
        }//while
    }

    //Вывод CRUD-операций
    public void crud() throws Exception{

        var buttons = new Object[]{"Добавление","Редактирование","Удаление","Выход"};

        //Меню
        while (true) {

            //Выбранный пункт
            var point = Utils.showWindowButtons("Выберете операцию","CRUD",buttons,"Выход", JOptionPane.DEFAULT_OPTION);


            switch (point) {

                case 0 -> {

                    var appointments = handler.addAppointment();
                    int addedId = appointments.get(appointments.size()-1).id();

                    System.out.printf("\n\tId добавленного приема: \u001b[38;5;34m%s\u001b[0m \n",addedId);

                    //Для выхода обратно в меню
                    if (Utils.showAppointments(appointments) == 0) {
                        break;
                    }
                }

                case 1 -> {

                    Appointment appointment = changeAppointment(handler);

                    Doctor doctor = changeDoctor(handler);


                    //System.out.printf("\n\tЗаменили дату приема на :%3$s %1$td.%1$tm.%1$tY\u001b[0m \n\tДля записи с ID: %3$s %2$d\u001b[0m\n",date, appointment.id(),"\u001b[38;5;34m");

                    System.out.printf("\n\tПоменяли прием с ID:%3$s %1$d\u001b[0m \n\tПоменяли запись о враче с ID: %3$s %2$d\u001b[0m\n",appointment.id(),doctor.id(),"\u001b[38;5;34m");

                    Object[] results = handler.updates(appointment,doctor);

                    //Для выхода обратно в меню
                    if (Utils.showAppointments((List<Appointment>)results[0]) == 0) {
                        if (Utils.showDoctors((List<Doctor>)results[1]) == 0) {
                            break;
                        }
                    }

                }
                case 2 -> {
                    var appointments = handler.getAppointments();

                    Appointment entity = appointments.get(Utils.getRandom(0,appointments.size()));

                    System.out.printf("\n\tУдалили прием к врачу с ID: %2$s%1$s\u001b[0m \n",entity.id(),"\u001b[38;5;34m");

                    //Для выхода обратно в меню
                    if (Utils.showAppointments(handler.deleteAppointment(entity)) == 0) {
                        break;
                    }
                }

                default -> {
                    return;
                }
            }
        }//while
    }

    //Изменить прием
    private Appointment changeAppointment(DBHandler handler) throws SQLException, DaoException {
        //Получение всей коллекции
        var appointments = handler.getAppointments();

        //Случайный элемент
        Appointment appointment = appointments.get(Utils.getRandom(0,appointments.size()));

        var date = appointment.date();

        date.setDate(date.getDate() + 5);

        appointment.setDate(date);

        return appointment;
    }

    //Изменить доктора
    private Doctor changeDoctor(DBHandler handler) throws SQLException, DaoException {

        //Получение всей коллекции
        var doctors = handler.getDoctors();

        //Случайный элемент
        Doctor doctor = doctors.get(Utils.getRandom(0,doctors.size()));

        doctor.setPayment(doctor.payment()+Utils.getRandom(100,300));
        doctor.setPercent(doctor.percent()+Utils.getRandom(0.5,3));

        return doctor;
    }



}
