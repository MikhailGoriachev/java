package home_task.utils;

import home_task.models.*;
import home_task.models.appointments.Appointment;
import home_task.models.doctors.Doctor;
import home_task.models.patients.Patient;

import javax.swing.*;
import java.util.Random;
import java.util.*;
public class Utils {

    //Генерация значений
    private static Random rand = new Random();

    public Utils() {
    }

    //Получение слуйчаных значений
    public static double getRandom(double lo, double hi) {
        return lo + rand.nextDouble() * (hi - lo);
    }

    public static int getRandom(int lo, int hi) {
        return lo + rand.nextInt(hi - lo);
    }


    // вывод окна с кнопками
    public static int showWindowButtons (String message, String title, Object[] buttons, String initialValue, int windowType) {
        return JOptionPane.showOptionDialog(
                null,
                message,
                title,
                JOptionPane.DEFAULT_OPTION,
                windowType,
                null,
                buttons,
                initialValue
        );
    }


    public static String tableHtmlHeader = "<html><table align='center' border='1' cellspacing='0' cellpadding='4'>";
    public static String tableHtmlFooter = "</table>";


    //Вывод приемов
    public static int showAppointments(List<Appointment> appointments){
        String task = """
                <html><span>Таблица приемов</span><br><br>
                """;

        //Общая строка вывода
        StringBuilder sb = new StringBuilder(task);


        //Создание заголовка таблицы
        sb.append(tableHtmlHeader);
        sb.append(Appointment.HEADER);

        //Проверка на валидность
        if (appointments == null || appointments.size() == 0) {

            sb.append("<tr><td colspan='14'>Что-то пошло не так. Таблица приемов не подгрузилась!</td></tr>");
            sb.append(tableHtmlFooter);

            System.out.println("\n\t\u001b[38;5;9mЧто-то пошло не так. Таблица приемов не подгрузилась!\u001b[0m");
            return showWindowButtons(sb.toString(),
                    "Приемы",
                    new Object[]{"Назад"},
                    "", JOptionPane.WARNING_MESSAGE);
        }

        //Контент таблицы
        appointments.forEach((a) -> sb.append(a.toTableRow()));

        sb.append(tableHtmlFooter);

        return showWindowButtons(sb.toString(), "Приемы", new Object[]{"Назад"}, "", JOptionPane.PLAIN_MESSAGE);
    }

    //Вывод врачей
    public static int showDoctors(List<Doctor> doctors){

        String task = """
                <html><span>Таблица врачей</span><br><br>
                """;

        //Общая строка вывода
        StringBuilder sb = new StringBuilder(task);


        //Создание заголовка таблицы
        sb.append(tableHtmlHeader);
        sb.append(Doctor.HEADER);

        //Проверка на валидность
        if (doctors == null || doctors.size() == 0) {

            sb.append("<tr><td colspan='6'>Что-то пошло не так. Таблица врачей не подгрузилась!</td></tr>");
            sb.append(tableHtmlFooter);

            System.out.println("\n\t\u001b[38;5;9mЧто-то пошло не так. Таблица врачей не подгрузилась!\u001b[0m");
            return showWindowButtons(sb.toString(),
                    "Врачи",
                    new Object[]{"Назад"},
                    "", JOptionPane.WARNING_MESSAGE);
        }

        doctors.forEach((d) -> sb.append(d.toTableRow()));

        sb.append(tableHtmlFooter);

        return showWindowButtons(sb.toString(), "Врачи", new Object[]{"Назад"}, "", JOptionPane.DEFAULT_OPTION);
    }

    //Вывод пациентов
    public static int showPatients(List<Patient> patients){
        String task = """
                <html><span>Таблица пациентов</span><br><br>
                """;

        //Общая строка вывода
        StringBuilder sb = new StringBuilder(task);

        //Создание заголовка таблицы
        sb.append(tableHtmlHeader);
        sb.append(Patient.HEADER);

        //Проверка на валидность
        if (patients == null || patients.size() == 0) {

            sb.append("<tr><td colspan='7'>Что-то пошло не так. Таблица пациентов не подгрузилась!</td></tr>");
            sb.append(tableHtmlFooter);

            System.out.println("\n\t\u001b[38;5;9mЧто-то пошло не так. Таблица пациентов не подгрузилась!\u001b[0m");
            return showWindowButtons(sb.toString(),
                    "Пациенты",
                    new Object[]{"Назад"},
                    "", JOptionPane.WARNING_MESSAGE);
        }

        //Добавлнеие строк таблицы в StringBuilder
        patients.forEach((p) -> sb.append(p.toTableRow()));

        sb.append(tableHtmlFooter);

        return showWindowButtons(sb.toString(), "Пациенты", new Object[]{"Назад"}, "", JOptionPane.DEFAULT_OPTION);
    }

    //Вывод запроса 7
    public static int showQuery7(List<Query7> queryCollection){
        String tableHeader = tableHtmlHeader + Query7.HEADER;

        String task = """
                <html><span>Группировка по полю Специальность.</span>
                <html><span>Для каждой специальности вычислить средний процент отчисления на зарплату от стоимости приема.</span><br><br>
                """;


        //Общая строка вывода
        StringBuilder sb = new StringBuilder(task);

        sb.append(tableHeader);

        //Проверка на валидность
        if (queryCollection == null || queryCollection.size() == 0) {

            sb.append("<tr><td colspan='3'>Что-то пошло не так. Запрос 7 не отработал!</td></tr>");
            sb.append(tableHtmlFooter);

            System.out.println("\n\t\u001b[38;5;9mЧто-то пошло не так. Запрос 7 не отработал\u001b[0m");
            return showWindowButtons(sb.toString(),
                    "Запрос 7",
                    new Object[]{"Назад"},
                    "", JOptionPane.WARNING_MESSAGE);
        }

        queryCollection.forEach((q7) -> sb.append(q7.toTableRow()));

        sb.append(tableHtmlFooter);

        return showWindowButtons(sb.toString(), "Запрос 7", new Object[]{"Назад"}, "", JOptionPane.DEFAULT_OPTION);
    }

    //Вывод запроса 6
    public static int showQuery6(List<Query6> queryCollection){
        String tableHeader = tableHtmlHeader + Query6.HEADER;

        String task = """
                <html><span>Группировка по полю Дата приема. Для каждой даты вычисляет максимальную стоимость приема</span><br><br>
                """;


        //Общая строка вывода
        StringBuilder sb = new StringBuilder(task);

        sb.append(tableHeader);

        //Проверка на валидность
        if (queryCollection == null || queryCollection.size() == 0) {

            sb.append("<tr><td colspan='3'>Что-то пошло не так. Запрос 6 не отработал!</td></tr>");
            sb.append(tableHtmlFooter);

            System.out.println("\n\t\u001b[38;5;9mЧто-то пошло не так. Запрос 6 не отработал!\u001b[0m");
            return showWindowButtons(sb.toString(),
                    "Запрос 6",
                    new Object[]{"Назад"},
                    "", JOptionPane.WARNING_MESSAGE);
        }

        queryCollection.forEach((q6) -> sb.append(q6.toTableRow()));

        sb.append(tableHtmlFooter);

        return showWindowButtons(sb.toString(), "Запрос 6", new Object[]{"Назад"}, "", JOptionPane.DEFAULT_OPTION);
    }

    //Вывод запроса 5
    public static int showQuery5(List<Query5> queryCollection){
        String tableHeader = tableHtmlHeader + Query5.HEADER;

        String task = """
                <html><span>Включает поля Фамилия врача, Имя врача, Отчество врача, </span>
                <html><span>Специальность врача, Стоимость приема, Зарплата. </span>
                <html><span>Сортировка по полю Специальность врача</span><br><br>
                """;


        //Общая строка вывода
        StringBuilder sb = new StringBuilder(task);

        sb.append(tableHeader);

        //Проверка на валидность
        if (queryCollection == null || queryCollection.size() == 0) {

            sb.append("<tr><td colspan='9'>Что-то пошло не так. Запрос 5 не отработал!</td></tr>");
            sb.append(tableHtmlFooter);

            System.out.println("\n\t\u001b[38;5;9mЧто-то пошло не так. Запрос 5 не отработал!\u001b[0m");
            return showWindowButtons(sb.toString(),
                    "Запрос 5",
                    new Object[]{"Назад"},
                    "", JOptionPane.WARNING_MESSAGE);
        }


        queryCollection.forEach((q5) -> sb.append(q5.toTableRow()));

        sb.append(tableHtmlFooter);

        return showWindowButtons(sb.toString(), "Запрос 5", new Object[]{"Назад"}, "", JOptionPane.DEFAULT_OPTION);
    }

}
