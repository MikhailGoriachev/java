package home_task.interfaces;

import home_task.models.appointments.Appointment;
import home_task.models.doctors.Doctor;
import home_task.models.exceptions.DaoException;
import home_task.models.patients.Patient;

import java.sql.Date;
import java.sql.ResultSet;

//Расширяющий интерфейс для всех запросов
public interface IPatients extends BaseDAO<Integer, Patient> {

    //Запрос 1 - информацию о пациентах с фамилиями, начинающимися на заданную последовательность символов
    ResultSet query1(String patientSurname) throws DaoException;

}
