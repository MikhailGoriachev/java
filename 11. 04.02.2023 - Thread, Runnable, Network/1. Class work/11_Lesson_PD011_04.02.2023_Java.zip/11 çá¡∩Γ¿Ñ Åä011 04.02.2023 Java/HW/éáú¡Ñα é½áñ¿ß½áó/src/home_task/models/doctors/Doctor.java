package home_task.models.doctors;

import home_task.models.Entity;

public class Doctor extends Entity {

    //Заголовок таблицы
    public static String HEADER = "<tr>" +
            "<th>ID</th>" +
            "<th>Фамилия доктора</th>" +
            "<th>Имя доктора</th>" +
            "<th>Отчество доктора</th>" +
            "<th>Специальность доктора</th>" +
            "<th>% отчислений</th>" +
            "</tr>";
    private final int id;
    private final String surname;
    private final String name;
    private final String patronymic;
    private final String speciality;
    private double percent;
    private int payment;

    public void setPercent(double percent) {
        this.percent = percent;
    }

    public void setPayment(int payment) {
        this.payment = payment;
    }

    public Doctor(
            int id,
            String surname,
            String name,
            String patronymic,
            String speciality,
            double percent,
            int payment) {
        this.id = id;
        this.surname = surname;
        this.name = name;
        this.patronymic = patronymic;
        this.speciality = speciality;
        this.percent = percent;
        this.payment = payment;
    }

    //Строка таблицы
    public String toTableRow() {
        return String.format("<tr>" +
                        "<td> %1$d </td>" +
                        "<td> %2$s </td>" +
                        "<td> %3$s </td>" +
                        "<td> %4$s </td>" +
                        "<td> %5$s </td>" +
                        "<td> %6$.2f </td>" +
                        "<td> %7$d </td>" +
                        "</tr>",
                id,
                surname, name, patronymic, speciality, percent, payment);
    }

    public int id() {
        return id;
    }

    public String surname() {
        return surname;
    }

    public String name() {
        return name;
    }

    public String patronymic() {
        return patronymic;
    }

    public String speciality() {
        return speciality;
    }

    public double percent() {
        return percent;
    }

    public int payment() {
        return payment;
    }


    ;

}
