package home_task.interfaces;


import home_task.models.Entity;
import home_task.models.exceptions.DaoException;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

//Базовый интерфейс
public interface BaseDAO<Key, E extends Entity> {

    //Добавление записи
    boolean create(E entity) throws DaoException;

    //Чтение коллекции сущностей
    List<E> getAll() throws DaoException;

    //Получить сущность из таблицы
    E getById(Key id) throws DaoException;

    //Обновление записи
    E update (E entity) throws DaoException;

    //Удаление записи
    boolean delete (E entity) throws DaoException;
    boolean delete (Key id) throws DaoException;


    // закрытие оператора запросов
    default void close(Statement statement) throws SQLException {
        if (statement != null) {
            statement.close();
        }
    }// close

    // закрытие подключения
    default void close(Connection connection) throws SQLException {
        if (connection != null) {
            connection.close();
        }
    }// close
}
