package home_task.models.exceptions;

public class DaoException extends Exception {

    public DaoException() { }

    //ctor: сообщение исключения
    public DaoException(String message) {
        super(message);
    }

    //ctor: сообщение + причина исключения
    public DaoException(String message, Throwable cause) {
        super(message, cause);
    }

    public DaoException(Throwable cause) {
        super(cause);
    }

}
