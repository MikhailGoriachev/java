package org.itstep.pd011.app.controllers;

import org.itstep.pd011.app.exceptions.DaoException;
import org.itstep.pd011.app.utils.Utils;
import org.itstep.pd011.app.Main;
import javax.swing.*;

import org.itstep.pd011.app.models.*;

public class TableController {

    public static void run(){

        DoctorDaoImpl doctorDao = new DoctorDaoImpl();
        PatientDaoImpl patientDao = new PatientDaoImpl();
        ReceiptDaoImpl receiptDao = new ReceiptDaoImpl();

        try {

            while (true) {

                switch (showMenu()) {
                    case 0 -> Utils.showDoctors(doctorDao.getAll(),"Таблица врачи");
                    case 1 -> Utils.showPatients(patientDao.getAll(),"Таблица пациенты");
                    case 2 -> Utils.showReceipts(receiptDao.getAll(),"Таблица приемы");

                    // выход
                    default -> {
                        return;
                    }
                }
            }

        } catch (DaoException e) {
            e.printStackTrace();
        } // try-catch
    }

    // вывод окна меню
    public static int showMenu() {
        return JOptionPane.showOptionDialog(
                null,
                "<html><h1>Меню</h1>",
                "Выбор таблицы",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(Main.class.getResource("../../../../images/leopard.png")),
                new Object[] {"Врачи", "Пациенты","Приемы ", "Выход"},
                "Выход"
        );
    }


}
