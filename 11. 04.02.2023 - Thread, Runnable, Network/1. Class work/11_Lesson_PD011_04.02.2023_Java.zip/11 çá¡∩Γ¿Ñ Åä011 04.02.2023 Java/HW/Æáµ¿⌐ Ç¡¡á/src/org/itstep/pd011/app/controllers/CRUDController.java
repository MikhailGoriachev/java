package org.itstep.pd011.app.controllers;

import org.itstep.pd011.app.exceptions.DaoException;
import org.itstep.pd011.app.services.ConnectionCreator;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import org.itstep.pd011.app.utils.Utils;

public class CRUDController {

    public static void run() throws SQLException {

        Connection connection = null;

        try {

            connection = ConnectionCreator.createConnection();

             // отключение автоматических транзакций - отмена автоматического выполнения
             // commit после каждого оператора
            connection.setAutoCommit(false);

            Statement statement = connection.createStatement();

            ////о врачебном приеме – изменение даты приема
            String sql01 = """
                UPDATE receipts
                   SET
                       date = '2023-02-04'
                 WHERE 
                       id = 2;
            """;

            //о пациенте (изменение фамилии)
            String sql02 = """
                UPDATE patients
                   SET 
                       surname = 'Измененная'
                 WHERE 
                       id = 1;
            """;

            //о докторе (увеличение платы за прием, процента отчислений)
            String sql03 = """
                UPDATE doctors
                   SET 
                       tax = 100
                 WHERE 
                       id = 1;
            """;

            // добавить запросы в пакет - запросы могут выполняться к различным таблицам
            statement.addBatch(sql01);
            statement.addBatch(sql02);
            statement.addBatch(sql03);

            // выполнение пакета, возвращается количество измененных строк
            // по каждому из запросов пакета
            int[] updateCounts = statement.executeBatch();

            // закрыть транзакцию - завершить пакет
            connection.commit();

            Utils.showMessage("<html><h3>Таблица Приемы: затронуто "+ updateCounts[0] +" запись <br>" +
                    "Таблица Пациенты: затронуто "+ updateCounts[1] +" запись <br>" +
                    "Таблица Врачи: затронуто "+ updateCounts[2] +" запись <br></h3>","Результат выполнения обновления записей в таблицах");

        } catch (SQLException e) {
            // !! откат транзакции при возникновении ошибок !!
            System.err.println("\t\tОшибки при выполнении пакета");
            if(connection != null) {
                connection.rollback();
            } // if
        } // try-catch
        finally {
            // вернуть автоматические транзакции
            if(connection != null) {
                connection.setAutoCommit(true);
            } // if
        } // try-finally
    }
}
