package org.itstep.pd011.app.interfaces;

import java.util.List;
import org.itstep.pd011.app.models.Doctor;
import org.itstep.pd011.app.exceptions.*;

public interface DoctorDao extends BaseDao <Long, Doctor> {

    //Выбирает информацию о врачах, для которых значение в поле
    // Процент отчисления на зарплату, больше заданного
    List<Doctor> findByPercentMore(int param)throws  DaoException;

    //Выбирает из таблицы информацию о врачах с заданной специальностью
    List<Doctor> findBySpecialtie(String param) throws DaoException;
}
