package org.itstep.pd011.app.interfaces;

import  org.itstep.pd011.app.exceptions.*;
import  org.itstep.pd011.app.models.*;

import java.util.List;

public interface PatientDao extends BaseDao <Long, Patient>{

    //Выбирает информацию о пациентах с фамилиями, начинающимися на заданную последовательность символов
    List<Patient> findBySurname(String param) throws DaoException;
}
