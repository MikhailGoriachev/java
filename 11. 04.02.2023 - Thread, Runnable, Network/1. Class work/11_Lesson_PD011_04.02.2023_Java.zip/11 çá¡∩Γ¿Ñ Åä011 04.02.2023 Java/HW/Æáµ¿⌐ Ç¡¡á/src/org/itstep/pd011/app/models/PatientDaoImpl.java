package org.itstep.pd011.app.models;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import org.itstep.pd011.app.interfaces.PatientDao;
import org.itstep.pd011.app.services.ConnectionCreator;
import org.itstep.pd011.app.exceptions.DaoException;

public class PatientDaoImpl implements PatientDao {

    public List<Patient> getAll() throws DaoException {
        List<Patient> patients = new ArrayList<>();

        Connection connection = null;
        Statement statement = null;

        // Выполняем подключение к базе данных, создаем оператор для выборки данных
        try {

            // получение соединения из фабрики соединенй
            connection = ConnectionCreator.createConnection();
            statement = connection.createStatement();

            // выполнить выборку данных
            ResultSet resultSet = statement.executeQuery("select * from patients");

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                patients.add(new Patient(
                        resultSet.getInt("Id"), resultSet.getString("surname"),
                        resultSet.getString("name"), resultSet.getString("patronymic"),
                        resultSet.getDate("Date_of_Birth"), resultSet.getString("address")
                ));
            } // while
        } catch (SQLException e) {
            throw new DaoException(e);
        } // try-catch
        finally {
            // вызов реализаций по умолчанию
            close(statement);
            close(connection);
        }

        return patients;
    }

    //Выбирает информацию о пациентах с фамилиями, начинающимися на заданную последовательность символов
    public List<Patient> findBySurname(String param) throws DaoException {

        List<Patient> patients = new ArrayList<>();

        Connection connection = null;
        PreparedStatement statement = null;

        // выполнение запроса - получение данных из таблицы
        try {

            connection = ConnectionCreator.createConnection();
            statement = connection.prepareStatement("select * from patients where patients.surname like ?");

            statement.setString(1, param + "%");
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                patients.add(new Patient(
                        resultSet.getInt("id"), resultSet.getString("surname"),
                        resultSet.getString("name"), resultSet.getString("patronymic"),
                        resultSet.getDate("date_of_birth"), resultSet.getString("address")
                ));
            } // while

        } catch (SQLException e) {
            throw new DaoException(e);
        } // try-catch
        finally {
            // вызов реализаций по умолчанию
            close(statement);
            close(connection);
        }

        return patients;
    }

    // методы, которые не нужны по логике работы, но мы обязаны их реализовать
    @Override
    public Patient findEntityById(Long id) throws DaoException {

        Connection connection = null;
        PreparedStatement statement = null;

        // выполнение запроса на изменение
        try {

            connection = ConnectionCreator.createConnection();
            statement = connection.prepareStatement("select * from patients where id = ?;");

            // установить параметры запроса
            statement.setLong(1, id);

            // собственно выполнить запрос
            ResultSet resultSet = statement.executeQuery();

            return new Patient(
                    resultSet.getInt("id"), resultSet.getString("surname"),
                    resultSet.getString("name"), resultSet.getString("patronymic"),
                    resultSet.getDate("date_of_birth"), resultSet.getString("address")
            );

        } catch (SQLException e) {
            throw new DaoException(e);
        } // try-catch
        finally {
            // вызов реализаций по умолчанию
            close(statement);
            close(connection);
        }
    }
    @Override
    public boolean delete(Patient patient) throws DaoException {
        throw new UnsupportedOperationException();
    }
    @Override
    public boolean delete(Long id) throws DaoException {
        throw new UnsupportedOperationException();
    }
    @Override
    public boolean create(Patient patient) throws DaoException {
        throw new UnsupportedOperationException();
    }
    @Override
    //о пациенте (изменение фамилии)
    public Patient update(Patient patient) throws DaoException {
        throw  new UnsupportedOperationException();
    }
}
