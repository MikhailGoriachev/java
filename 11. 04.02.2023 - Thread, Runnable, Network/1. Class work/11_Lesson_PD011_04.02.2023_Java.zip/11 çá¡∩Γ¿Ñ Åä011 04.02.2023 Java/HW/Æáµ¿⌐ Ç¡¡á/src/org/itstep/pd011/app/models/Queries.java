package org.itstep.pd011.app.models;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.itstep.pd011.app.services.ConnectionCreator;
import org.itstep.pd011.app.exceptions.DaoException;

// прикладные запросы к нескольким таблицам
// итоговые запросы
public class Queries {

    //Вычисляет размер заработной платы врача за каждый прием. Включает поля
    // Фамилия врача, Имя врача, Отчество врача, Специальность врача, Стоимость приема, Зарплата. Сортировка по полю
    // Специальность врача
    public static List<Query05> doQuery05() throws SQLException {

        List<Query05> query05List= new ArrayList<>();

        Connection connection = null;
        Statement statement = null;

        String sql = "select view_receipts.doctor, " +
                "view_receipts.specialtie, " +
                "view_receipts.price,"+
                "view_receipts.price *(view_receipts.tax/100) - (view_receipts.tax/100)*view_receipts.price *13/100 as Salary " +
                "from view_receipts " +
                "order by view_receipts.specialtie";

        // выполнение запроса - получение данных из таблицы
        try {

            // получение соединения из фабрики соединенй
            connection = ConnectionCreator.createConnection();
            statement = connection.createStatement();

            ResultSet resultSet = statement.executeQuery(sql);

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                query05List.add(new Query05(
                        resultSet.getString("doctor"), resultSet.getString("specialtie"),
                        resultSet.getInt("price"), resultSet.getDouble("Salary")
                ));
            } // while

        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return query05List;
    }

    //Выполняет группировку по полю Дата приема. Для каждой даты вычисляет максимальную стоимость приема
    public static List<Query06> doQuery06() throws SQLException {

        List<Query06> query06List= new ArrayList<>();

        Connection connection = null;
        Statement statement = null;

        String sql = "select receipts.date,MAX(price) as max from receipts group by receipts.date order by receipts.date";

        // выполнение запроса - получение данных из таблицы
        try {

            // получение соединения из фабрики соединенй
            connection = ConnectionCreator.createConnection();
            statement = connection.createStatement();

            ResultSet resultSet = statement.executeQuery(sql);

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                query06List.add(new Query06(
                        resultSet.getDate("date"), resultSet.getInt("max")
                ));
            } // while

        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return query06List;
    }

    //Выполняет группировку по полю Специальность.
    // Для каждой специальности вычисляет средний Процент отчисления на зарплату от стоимости приема
    public static List<Query07> doQuery07() throws SQLException {

        List<Query07> query07List= new ArrayList<>();

        Connection connection = null;
        Statement statement = null;

        String sql = "select specialties.name, AVG(tax) as avg from specialties join doctors on specialties.Id = doctors.id_specialtie group by specialties.name";

        // выполнение запроса - получение данных из таблицы
        try {

            // получение соединения из фабрики соединенй
            connection = ConnectionCreator.createConnection();
            statement = connection.createStatement();

            ResultSet resultSet = statement.executeQuery(sql);

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                query07List.add(new Query07(
                        resultSet.getString("name"), resultSet.getDouble("avg")
                ));
            } // while

        } catch (SQLException e) {
            e.printStackTrace();
        } // try-catch

        return query07List;
    }
}
