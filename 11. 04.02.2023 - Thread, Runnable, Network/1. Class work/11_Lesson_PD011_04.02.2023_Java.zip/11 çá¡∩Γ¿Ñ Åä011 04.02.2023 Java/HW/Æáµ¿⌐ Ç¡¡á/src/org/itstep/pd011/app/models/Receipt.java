package org.itstep.pd011.app.models;

import java.sql.Date;

public class Receipt extends Entity{
    private int id;
    private Date date;
    private int price;
    private String doctor;
    private String specialtie;
    private String patient;

    public int getId() {
        return id;
    }

    public Date getDate() {
        return date;
    }

    public int getPrice() {
        return price;
    }

    public String getDoctor() {
        return doctor;
    }

    public String getSpecialtie() {
        return specialtie;
    }

    public String getPatient() {
        return patient;
    }

    public Receipt(int id, Date date, int price, String doctor, String specialtie, String patient) {
        this.id = id;
        this.date = date;
        this.price = price;
        this.doctor = doctor;
        this.specialtie = specialtie;
        this.patient = patient;
    }

    @Override
    public String toString() {
        return "<tr>" +
                "<td>"+id+"</td>"+
                "<td>"+String.format("%1$td.%1$tm.%1$tY",date)+"</td>"+
                "<td>"+price+"</td>"+
                "<td>"+doctor+"</td>"+
                "<td>"+specialtie+"</td>"+
                "<td>"+patient+"</td>"+
                "</tr>";
    }
}
