package org.itstep.pd011.app.interfaces;

import  org.itstep.pd011.app.exceptions.*;
import  org.itstep.pd011.app.models.*;

import java.sql.Date;
import java.util.List;

public interface ReceiptDao  extends BaseDao <Long, Receipt> {

    //Выбирает информацию о приемах за некоторый период
    List<Receipt> findByPeriod(Date param01, Date param02) throws DaoException;
}
