package org.itstep.pd011.app.models;

import java.io.Serializable;

// базовый класс сущностей таблиц БД
public abstract class Entity implements Serializable, Cloneable {
}
