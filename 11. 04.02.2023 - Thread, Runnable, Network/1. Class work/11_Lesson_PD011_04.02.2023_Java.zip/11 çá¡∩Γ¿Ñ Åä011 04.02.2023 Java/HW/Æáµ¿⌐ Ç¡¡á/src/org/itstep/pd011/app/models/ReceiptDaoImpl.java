package org.itstep.pd011.app.models;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import org.itstep.pd011.app.interfaces.ReceiptDao;
import org.itstep.pd011.app.services.ConnectionCreator;
import org.itstep.pd011.app.exceptions.DaoException;

public class ReceiptDaoImpl implements ReceiptDao {

    // пример операции выборки данных из таблицы - получить и вывести всех приемы
    public List<Receipt> getAll() throws DaoException {
        List<Receipt> receipts = new ArrayList<>();

        Connection connection = null;
        Statement statement = null;

        // Выполняем подключение к базе данных, создаем оператор для выборки данных
        try{

            // получение соединения из фабрики соединенй
            connection = ConnectionCreator.createConnection();
            statement = connection.createStatement();

            // выполнить выборку данных
            ResultSet resultSet = statement.executeQuery("select * from view_receipts");

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                receipts.add(new Receipt(
                        resultSet.getInt("Id"), resultSet.getDate("date"),
                        resultSet.getInt("price"), resultSet.getString("Doctor"),
                        resultSet.getString("Specialtie"), resultSet.getString("Patient")
                ));
            } // while
        } catch (SQLException e) {
            throw new DaoException(e);
        } // try-catch
        finally {
            // вызов реализаций по умолчанию
            close(statement);
            close(connection);
        }

        return receipts;
    }

    //Выбирает информацию о приемах за некоторый период
    public List<Receipt> findByPeriod(Date param01, Date param02) throws DaoException {

        List<Receipt> receipts= new ArrayList<>();

        Connection connection = null;
        PreparedStatement statement = null;

        // выполнение запроса - получение данных из таблицы
        try {

            connection = ConnectionCreator.createConnection();
            statement = connection.prepareStatement("select * from view_receipts where date between ? and ?");

            statement.setDate(1, param01);
            statement.setDate(2, param02);
            ResultSet resultSet = statement.executeQuery();

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                receipts.add(new Receipt(
                        resultSet.getInt("id"), resultSet.getDate("date"),
                        resultSet.getInt("price"), resultSet.getString("doctor"),
                        resultSet.getString("specialtie"), resultSet.getString("patient")
                ));
            } // while

        } catch (SQLException e) {
            throw new DaoException(e);
        } // try-catch
        finally {
            // вызов реализаций по умолчанию
            close(statement);
            close(connection);
        }

        return receipts;
    }

    // методы, которые не нужны по логике работы, но мы обязаны их реализовать
    @Override
    public Receipt findEntityById(Long id) throws DaoException {
        Connection connection = null;
        PreparedStatement statement = null;

        // выполнение запроса на изменение
        try {

            connection = ConnectionCreator.createConnection();
            statement = connection.prepareStatement("select * from receipts where id = ?;");

            // установить параметры запроса
            statement.setLong(1, id);

            // собственно выполнить запрос
            ResultSet resultSet = statement.executeQuery();

            return new Receipt(
                    resultSet.getInt("id"), resultSet.getDate("date"),
                    resultSet.getInt("price"), resultSet.getString("doctor"),
                    resultSet.getString("specialtie"), resultSet.getString("patient"));

        } catch (SQLException e) {
            throw new DaoException(e);
        } // try-catch
        finally {
            // вызов реализаций по умолчанию
            close(statement);
            close(connection);
        }
    }
    @Override
    public boolean delete(Receipt receipt) throws DaoException {
        return delete((long) receipt.getId());
    }
    @Override
    public boolean delete(Long id) throws DaoException {

        // количество удаленных записей
        int counterDeleted = 0;

        Connection connection = null;
        PreparedStatement statement = null;

        // запрос на удаление
        String sql = """
            delete from
                receipts
            where
                id = ?;
        """;

        // выполнение запроса
        try {

            connection = ConnectionCreator.createConnection();
            statement = connection.prepareStatement(sql);

            statement.setLong(1, id);

            counterDeleted = statement.executeUpdate();
        } catch (SQLException e) {
            throw new DaoException(e);
        } // try-catch
        finally {
            // вызов реализаций по умолчанию
            close(statement);
            close(connection);
        }

        return counterDeleted > 0;
    }

    @Override
    public boolean create(Receipt receipt) throws DaoException {
        throw new UnsupportedOperationException();
    }

    //о врачебном приеме – изменение даты приема
    @Override
    public Receipt update(Receipt receipt) throws DaoException {
        throw new UnsupportedOperationException();
    }
}
