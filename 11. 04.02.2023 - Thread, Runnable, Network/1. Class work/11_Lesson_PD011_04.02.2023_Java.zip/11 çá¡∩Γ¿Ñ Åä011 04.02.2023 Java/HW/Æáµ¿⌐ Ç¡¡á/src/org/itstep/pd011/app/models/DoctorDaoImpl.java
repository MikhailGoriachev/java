package org.itstep.pd011.app.models;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import org.itstep.pd011.app.interfaces.DoctorDao;
import org.itstep.pd011.app.services.ConnectionCreator;
import org.itstep.pd011.app.exceptions.DaoException;

public class DoctorDaoImpl implements DoctorDao {

    // пример операции выборки данных из таблицы - получить и вывести всех врачей
    public List<Doctor> getAll() throws DaoException {
        List<Doctor> doctors = new ArrayList<>();

        Connection connection = null;
        Statement statement = null;

        try {

            // получение соединения из фабрики соединенй
            connection = ConnectionCreator.createConnection();
            statement = connection.createStatement();

            // выполнить выборку данных
            ResultSet resultSet = statement.executeQuery("select * from view_doctors");

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                doctors.add(new Doctor(
                        resultSet.getInt("Id"), resultSet.getString("surname"),
                        resultSet.getString("name"), resultSet.getString("patronymic"),
                        resultSet.getString("Specialtie"), resultSet.getInt("tax")
                ));
            } // while
        } catch (SQLException e) {
            throw new DaoException(e);
        } // try-catch
        finally {
        // вызов реализаций по умолчанию
        close(statement);
        close(connection);
        }

        return doctors;
    }

    //Выбирает из таблицы информацию о врачах с заданной специальностью
    public List<Doctor> findBySpecialtie(String param) throws DaoException {

        List<Doctor> doctors= new ArrayList<>();

        Connection connection = null;
        PreparedStatement statement = null;

        // выполнение запроса - получение данных из таблицы
        try {

            connection = ConnectionCreator.createConnection();
            statement = connection.prepareStatement("select * from view_doctors where view_doctors.specialtie like ? ");

            statement.setString(1, param);
            ResultSet resultSet = statement.executeQuery();

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                doctors.add(new Doctor(
                        resultSet.getInt("id"), resultSet.getString("surname"),
                        resultSet.getString("name"), resultSet.getString("patronymic"),
                        resultSet.getString("specialtie"), resultSet.getInt("tax")
                ));
            } // while

        } catch (SQLException e) {
            throw new DaoException(e);
        } // try-catch
        finally {
            // вызов реализаций по умолчанию
            close(statement);
            close(connection);
        }

        return doctors;
    }

    //Выбирает информацию о врачах, для которых значение в поле Процент отчисления на зарплату, больше заданного
    public List<Doctor> findByPercentMore(int param) throws DaoException {

        List<Doctor> doctors= new ArrayList<>();

        Connection connection = null;
        PreparedStatement statement = null;

        // выполнение запроса - получение данных из таблицы
        try {

            connection = ConnectionCreator.createConnection();
            statement = connection.prepareStatement("select * from view_doctors where view_doctors.tax > ? ");

            statement.setInt(1, param);
            ResultSet resultSet = statement.executeQuery();

            // Проходим по выборке, формируя коллекцию записей типа Client
            while (resultSet.next()) {
                doctors.add(new Doctor(
                        resultSet.getInt("id"), resultSet.getString("surname"),
                        resultSet.getString("name"), resultSet.getString("patronymic"),
                        resultSet.getString("specialtie"), resultSet.getInt("tax")
                ));
            } // while

        } catch (SQLException e) {
            throw new DaoException(e);
        } // try-catch
        finally {
            // вызов реализаций по умолчанию
            close(statement);
            close(connection);
        }

        return doctors;
    }

    // методы, которые не нужны по логике работы, но мы обязаны их реализовать
    @Override
    public Doctor findEntityById(Long id) throws DaoException {

        Connection connection = null;
        PreparedStatement statement = null;

        // выполнение запроса на изменение
        try {

            connection = ConnectionCreator.createConnection();
            statement = connection.prepareStatement("select * from doctors where id = ?;");

            // установить параметры запроса
            statement.setLong(1, id);

            // собственно выполнить запрос
            ResultSet resultSet = statement.executeQuery();

            return new Doctor(
                    resultSet.getInt("id"), resultSet.getString("surname"),
                    resultSet.getString("name"), resultSet.getString("patronymic"),
                    resultSet.getString("specialtie"), resultSet.getInt("tax"));

        } catch (SQLException e) {
            throw new DaoException(e);
        } // try-catch
        finally {
            // вызов реализаций по умолчанию
            close(statement);
            close(connection);
        }
    }
    @Override
    public boolean delete(Doctor doctor) throws DaoException {
        throw new UnsupportedOperationException();
    }
    @Override
    public boolean delete(Long id) throws DaoException {
        throw new UnsupportedOperationException();
    }
    @Override
    public boolean create(Doctor doctor) throws DaoException {
        throw new UnsupportedOperationException();
    }
    @Override
    //о докторе (увеличение платы за прием, процента отчислений)
    public Doctor update(Doctor doctor) throws DaoException {
        throw  new UnsupportedOperationException();
    }
}
