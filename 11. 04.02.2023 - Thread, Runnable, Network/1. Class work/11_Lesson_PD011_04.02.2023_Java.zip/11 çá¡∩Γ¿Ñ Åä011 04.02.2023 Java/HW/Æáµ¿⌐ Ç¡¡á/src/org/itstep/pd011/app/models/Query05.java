package org.itstep.pd011.app.models;

public record Query05(
        String doctor,
        String specialtie, //Специальность врача
        int price, //Стоимость приема
        double salary //Зарплата
) {
    public Query05(String doctor,String specialtie, int price, double salary) {
        this.doctor = doctor;
        this.specialtie = specialtie;
        this.price = price;
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "<tr>" +
                "<td>"+doctor+"</td>"+
                "<td>"+specialtie+"</td>"+
                "<td>"+price+"</td>"+
                "<td>"+String.format("%.2f",salary)+"</td>"+
                "</tr>";
    }
}
