package app.models.dao;

import java.io.Serializable;

// базовый класс сущностей таблиц БД
public abstract class Entity implements Serializable, Cloneable {
}
