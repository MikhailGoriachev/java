package org.itstep.pd011;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;

import org.itstep.pd011.utils.Utils;

@WebServlet(name = "secondServlet", value="/second-servlet")
public class SecondServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        // получить параметры ответа
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        // получить данные из формы (т.е. из заголовка post-запроса
        double r = Double.parseDouble(request.getParameter("r"));
        double h = Double.parseDouble(request.getParameter("h"));
        String material= request.getParameter("material");

        // массив значений
        String[] params = request.getParameterValues("param");

        String title = "";
        double p = 0;

        switch (material){
            case "copper" ->{
                title = "медь";
                p = 8933;
            }

            case "steel" ->{
                title = "сталь";
                p = 7900;
            }

            case "basalt" ->{
                title = "базальт";
                p = 2970;
            }

            case "ice" ->{
                title = "лед";
                p = 916;
            }
        }

        double area = 2*Math.PI*r*(r+h);
        double volume = Math.PI*r*r*h;
        double weight = volume*p;

        // вывод ответа - полученных из формы данных
        try (PrintWriter writer = response.getWriter()) {

            Utils.head(writer);

            writer.println("<p class=\"mb-2 ms-2 fs-4 mt-3\">Результаты вычислений:");

            writer.println("<ul class=\"lead ms-3 mt-3 fs-6\">");

            writer.printf("<li>Радиус: %.2f</li>",r);
            writer.printf("<li>Высота: %.2f</li>",h);

            // вывод массива значений чекбокса
            for(String param: params){
                switch (param){
                    case "area" -> writer.printf("<li>Площадь: %.2f</li>",area);
                    case "volume" -> writer.printf("<li>Объем: %.2f</li>",volume);
                    case "weight" -> writer.printf("<li>Масса: %.2f, материал: %s, плотность %.2f кг/m3</li>",weight,title,p);
                }
            }
            writer.println("</ul>");

            Utils.footer(writer);

        } // try
    } // doPost

}
