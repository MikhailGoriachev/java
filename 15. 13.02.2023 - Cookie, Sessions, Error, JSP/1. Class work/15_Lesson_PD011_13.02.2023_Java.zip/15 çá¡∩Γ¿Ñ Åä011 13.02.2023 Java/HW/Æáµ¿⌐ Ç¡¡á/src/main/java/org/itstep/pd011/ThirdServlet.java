package org.itstep.pd011;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import org.itstep.pd011.utils.Utils;

@WebServlet(name = "thirdServlet", value="/third-servlet")
public class ThirdServlet extends HttpServlet {

    // реакция на get-запрос
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        try (PrintWriter out = response.getWriter()) {

            Utils.head(out);
            out.println("<p class=\"mb-2 ms-2 fs-4 mt-3\"> В разработке...");
            Utils.footer(out);
        }
    }
}
