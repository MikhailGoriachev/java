package org.itstep.pd011;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import org.itstep.pd011.utils.Utils;

@WebServlet(name = "firstServlet", value="/first-servlet")
public class FirstServlet extends HttpServlet {

    // реакция на get-запрос
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        try (PrintWriter out = response.getWriter()) {

            Utils.head(out);
            out.printf("""
                <p class="mb-2 ms-2 fs-4 mt-3">Дата на сервере: %1$td.%1$tm.%1$tY<br> 
                Время на сервере: %1$tH:%1$tM:%1$tS</p>""", new Date());
            Utils.footer(out);
        }
    }
}
