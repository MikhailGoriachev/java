package org.itstep.pd011.utils;

import java.io.PrintWriter;

public class Utils {

    public static void footer(PrintWriter writer){
        writer.println("""
            </div></div></div></main>
            <div class='mt-5 p-3 bg-dark text-white-50 text-center footer'>
            <p>Выполнила: Таций Анна ВПД011 Донецк 2023</p>
            </div>
            </body>
            </html>
        """);
    }

    public static void head(PrintWriter writer){
        writer.println("<!DOCTYPE html>");
        writer.println("<html>");
        writer.println("<head>");
        writer.println("<title>JSP</title>");
        writer.println("<meta charset='utf-8'>");
        writer.println("<meta name='viewport' content='width=device-width, initial-scale=1'>");

        writer.println("<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css' rel='stylesheet' integrity='sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC' crossorigin='anonymous'>");
        writer.println("<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js' integrity='sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM' crossorigin='anonymous'></script>");
        writer.println("<link href='resources/style.css' rel='stylesheet'/>");
        writer.println("</head>");
        writer.println("<body>");
        writer.println("<nav class='navbar navbar-expand-sm bg-dark navbar-dark sticky-top'>");
        writer.println("<div class='container-fluid'>");
        writer.println("<div style='width: 70%; margin: auto;'>");
        writer.println("<div class='navbar-collapse' id='appNavbar-1'>");
        writer.println("<ul class='navbar-nav fs-6'>");
        writer.println("<li class='nav-item pt-1'>");
        writer.println("<a class='nav-link' href='index.jsp'>Страница с заданием</a>");
        writer.println("</li>");

        writer.println("<li class='nav-item pt-1'>");
        writer.println("<a class='nav-link' href='/first-servlet'>Получить дату</a>");
        writer.println("</li>");

        writer.println("<li class='nav-item pt-1'>");
        writer.println("<a class='nav-link' href='/forma01.jsp'>Открыть форму</a>");
        writer.println("</li>");

        writer.println("<li class='nav-item pt-1'>");
        writer.println("<a class='nav-link' href='/third-servlet'>Гаджеты</a>");
        writer.println("</li>");

        writer.println("</ul>");
        writer.println("</div>");
        writer.println("</div>");
        writer.println("</div>");
        writer.println("</nav>");

        writer.println("<main class='container-fluid'>");
        writer.println("<div class='row-sm mt-5 p-3 container-fluid-style'>");
        writer.println("<div class='p-4 bg-white m-3 border-warning-top border-warning-bottom'>");
        writer.println("<div class='container'>");
    }
}
