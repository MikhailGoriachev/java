package org.itstep.pd011.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.itstep.pd011.models.Gadget;
import org.itstep.pd011.models.Store;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/gadgets-list")
public class ShowGadgetsListServlet extends HttpServlet {
    // модель данных сервлета
    private Store store;

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            store = Store.getInstance();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // по get-запросу вернуть страницу с коллекцией гаджетов
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        process(response);
    } // doGet

    // по post-запросу вернуть страницу с коллекцией гаджетов
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

        // получить данные из формы (т.е. из заголовка post-запроса
        String type = request.getParameter("type");
        String manufacturer = request.getParameter("manufacturer");
        int year = Integer.parseInt(request.getParameter("year"));
        String os = request.getParameter("os");
        int price = Integer.parseInt(request.getParameter("price"));

        // добавить новый гаджет в коллекцию
        store.addGaget(new Gadget(type, manufacturer, year, os, price));

        process(response);
    } // doPost

    // формирование страницы с коллекцией гаджетов
    private void process(HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        // начинаем формирование контента
        // TODO: общую часть (заголовок, подвал страниц) вынести в константу отдельного класса
        var content = new StringBuilder("""
            <!DOCTYPE html><html>
            <head>
                <title>ДЗ на 13.02.2023</title>
                <meta charset="utf-8">
            
                <!-- подключение bootstrap -->
                <link href="resources/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
                <script src="resources/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
            
                <!-- подключение собственных стилей -->
                <link href="resources/style.css" rel="stylesheet">
            </head>
            <body>
                <h1 class="m-5">Выполнение ДЗ на 13.02.2023</h1>
                <br>
                
                <div class='mx-5 d-flex w-75'>
                    <h5 class="m-3">Сервлет GadgetsList</h5>
                    <a class="btn btn-secondary m-3" href='index.jsp'>На главную</a>
                    <a class="btn btn-secondary m-3" href='add-gadget-form.jsp'>Добавить</a>
                </div>
                """);

        content.append(store.toTable());
        content.append("</body></html>");

        // Вывод контекста в response
        try (PrintWriter out = response.getWriter()) {
            out.print(content);
        } // try
    }
} // class GadgetsListServlet
