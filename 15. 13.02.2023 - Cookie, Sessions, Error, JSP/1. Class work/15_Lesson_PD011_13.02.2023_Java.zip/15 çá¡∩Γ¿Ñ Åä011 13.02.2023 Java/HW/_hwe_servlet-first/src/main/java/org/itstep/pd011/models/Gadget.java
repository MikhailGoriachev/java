package org.itstep.pd011.models;

// сведения о гаджете:
//     тип
//     производитель
//     год выпуска
//     операционная система
//     цена
public class Gadget {
    // тип
    private String type;

    // производитель
    private String manufacturer;

    // год выпуска
    private int year;

    // операционная система
    private String os;

    // цена
    private int price;

    // конструкторы

    public Gadget() {
        this("смарт-часы", "Samsung", 2015, "Tizen", 12_000);
    } // Gadget

    public Gadget(String type, String manufacturer, int year, String os, int price) {
        setType(type);
        setManufacturer(manufacturer);
        setYear(year);
        setOs(os);
        setPrice(price);
    } // Gadget

    // геттеры и сеттеры

    public String getType() { return type; }
    public void setType(String type) {
        this.type = type;
    }

    public String getManufacturer() {  return manufacturer;  }
    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public int getYear() {  return year; }
    public void setYear(int year) {
        this.year = year;
    }

    public String getOs() { return os; }
    public void setOs(String os) {
        this.os = os;
    }

    public int getPrice() { return price; }
    public void setPrice(int price) {
        this.price = price;
    }

    // строковое представление

    @Override
    public String toString() {  return String.format(
        "Gadget{type='%s', manufacturer='%s', year=%d, os='%s' , price=%d.00 руб.}'",
        type, manufacturer, year, os, price
     );} // toString

    // строка таблицы в HTML
    public String toTableRow(int row) { return String.format(
         "<tr><td>%d</td><td>%s</td><td>%s</td><td>%d</td><td>%s</td><td>%d.00</td></tr>",
         row, type, manufacturer, year, os, price
    );} // toTableRow
} // Gadget
