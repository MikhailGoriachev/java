package org.itstep.pd011.servlets;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

// По get-запросу в странице HTML сервлет возвращает дату и время на сервере
@WebServlet("/date-time")
public class DateTimeServlet extends HttpServlet {

    // модель данных сервлета
    private Date serverDate;

    // рекомендуемый способ инициализации полей сервлета
    @Override
    public void init() {
        serverDate = new Date();
    } // init

    // обработка get-запроса
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        // создать форматтер для даты и времени
        // https://javarush.com/groups/posts/1941-kak-ne-poterjatjhsja-vo-vremeni--datetime-i-calendar
        // https://docs.oracle.com/en/java/javase/18/docs/api/java.base/java/text/SimpleDateFormat.html
        var formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");

        var content = """
            <!DOCTYPE html><html>
            <head>
                <title>ДЗ на 13.02.2023</title>
                <meta charset="utf-8">
            
                <!-- подключение bootstrap -->
                <link href="resources/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
                <script src="resources/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
            
                <!-- подключение собственных стилей -->
                <link href="resources/style.css" rel="stylesheet">
            </head>
            <body>
                <h1 class="m-5">Выполнение ДЗ на 13.02.2023</h1>
                <h4 class="m-5">Сервлет DateTime</h3>
                <h4 class="m-5">Сейчас на сервере: %s</h3>
                <h5 class="m-5"><a class="btn btn-primary" href='index.jsp'>На главную</a></h4>
            </body>
            </html>
            """;

        // Вывод контекста в responsr
        try (PrintWriter out = response.getWriter()) {
            out.printf(content, formatter.format(serverDate));
        } // try
    } // doGet

} // class DateTimeServlet
