package org.itstep.pd011.models;

import java.util.ArrayList;
import java.util.List;

// хранит коллекцию гаджетов
public class Store {
    // название склада
    private String name;

    // коллекция гаджетов на складе
    private List<Gadget> gadgets;

    private Store() {
        initialize();
    } // Store

    // Используем шаблон одиночка
    private static Store instance = null;

    public static synchronized Store getInstance() throws Exception {
        if (instance == null)
            instance = new Store();
        return instance;
    } // getInstance

    public String getName() {  return name;  }

    public List<Gadget> getGadgets() {  return gadgets;  }

    // начальное формирование коллекции
    private void initialize() {
        name = "Склад № 1";
        gadgets = new ArrayList<>(List.of(
            new Gadget(),
            new Gadget("фитнес-браслет", "Ritmix", 2021, "none", 2_110),
            new Gadget("фитнес-браслет", "Xiaomi", 2022, "none", 3_790),
            new Gadget("фитнес-браслет", "Xiaomi", 2020, "none", 1_490),
            new Gadget("фитнес-браслет", "Huawei", 2022, "Tizen", 4_590),
            new Gadget("беспроводные наушники", "Xiaomi", 2022, "none", 3_600),
            new Gadget("умный чайник", "Xiaomi", 2022, "none", 6_100),
            new Gadget("умный чайник", "Kitfort", 2022, "Tizen", 8_320),
            new Gadget("смарт-часы", "Xiaomi", 2022, "Tizen", 14_999),
            new Gadget("смарт-часы", "Realme", 2021, "Android", 3_590),
            new Gadget("весы напольные", "Polaris", 2022, "none", 1_290),
            new Gadget("весы кухонные", "Redmond", 2022, "none", 1_360),
            new Gadget("беспроводные наушники", "Accesstyle", 2021, "none", 1_490),
            new Gadget("проводные наушники", "Xiaomi", 2021, "none", 4_999)
        ));
    } // initialize

    // возвращает представление данных склада (коллекции гаджетов) в табличном виде
    public StringBuilder toTable() {
        // начинаем формирование контента
        var content = new StringBuilder(String.format("""
            <h5 class="m-5">Склад гаджетов "%s"</h5>
            <table class="table table-bordered table-striped w-50 m-5">
            <tr>
                <th>номер<br>п/п</th><th>Название гаджета</th><th>Производитель</th>
                <th>Год выпуска</th><th>Операционная<br>система</th>
                <th>Цена, руб.</th>
            </tr>
        """, name));

        // вывод тела таблицы в контент
        int row = 1;
        for (Gadget gadget : gadgets) {
            content.append(gadget.toTableRow(row++)).append("\n");
        } // for gadget

        // завершение формирования таблицы
        content.append("</table>");
        return content;
    } // toTable

    // делегируем добавление гаджета
    public void addGaget(Gadget gadget) {  gadgets.add(gadget);  }
} // class Store
