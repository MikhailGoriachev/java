package Infrastructure;

import java.util.Random;
import java.util.*;
public class Utils {

    //Генерация значений
    private static Random rand = new Random();

    public Utils() {
    }

    //Получение слуйчаных значений
    public static double getRandom(double lo, double hi) {
        return lo + rand.nextDouble() * (hi - lo);
    }

    public static int getRandom(int lo, int hi) {
        return lo + rand.nextInt(hi - lo);
    }

    //Сфомрировать выпадающий ссписок
    public static StringBuilder createDropDown(int index){
        /*String[] arr = new String[]{};*/

        StringBuilder sb = new StringBuilder();
        String option = "<option value=\"%1$s\">%1$s</option>";
        switch (index) {
            case 0 -> Arrays.stream(brands).forEach(b ->  sb.append( String.format(option,b) ));
            case 1 -> Arrays.stream(models).forEach(m ->  sb.append( String.format(option,m) ));
            case 2 -> Arrays.stream(systems).forEach(s -> sb.append( String.format(option,s) ));
        }

        return sb;
    }

    //Задать строку навигации
    public static String getNavBar(String page){

        page = page.toLowerCase();

        return String.format("""
                <nav class="navbar navbar-expand-sm navbar-dark bg-dark sticky-top shadow">
                      <div class="container-fluid justify-content-center">
                          <a class="navbar-brand">Home work</a>
                  
                          <div class="collapse navbar-collapse">
                              <ul class="navbar-nav">
                  
                                  <li class="nav-item">
                                      <a class="nav-link ms-3" href="to-main-page">Главная</a>
                                  </li>
                  
                                  <li class="nav-item">
                                      <a class="nav-link %s" href="date">Дата и время</a>
                                  </li>
                  
                                  <li class="nav-item">
                                      <a class="nav-link %s" href="cylinderForm.jsp">Цилиндр</a>
                                  </li>
                  
                                  <li class="nav-item">
                                      <a class="nav-link %s" href="gadgets">Гаджеты</a>
                                  </li>
                  
                              </ul>
                          </div>
                      </div>
                  </nav>
                """
                ,page.contains("date") ? "active" :""
                ,page.contains("cylinder") ? "active" :""
                ,page.contains("gadgets") ? "active" :"");
    }


    public static String[] brands = new String[]{
            "Asus","Lenovo","HP","Microsoft","Dell"
    };

    public static String[] models = new String[]{
            "A5","A2","Ideapad","A72","Surface Book","Pavilion"
    };

    public static String[] systems = new String[]{
            "Windows 10",
            "Windows 11",
            "MacOS",
            "IOS",
            "Android",
            "Linux",
    };


    //Бренд ноутбука
    public static String getBrand(){
        return brands[getRandom(0,brands.length)];
    }

    //модель ноутбука
    public static String getModel(){
        return models[getRandom(0,models.length)];
    }


    //Дефект ноутбука
    public static String getSystem(){
        return systems[getRandom(0, systems.length)];
    }



    //Объём накопителя
    public static int getPrice(){
        return getRandom(20,120)*1000;
    }



}
