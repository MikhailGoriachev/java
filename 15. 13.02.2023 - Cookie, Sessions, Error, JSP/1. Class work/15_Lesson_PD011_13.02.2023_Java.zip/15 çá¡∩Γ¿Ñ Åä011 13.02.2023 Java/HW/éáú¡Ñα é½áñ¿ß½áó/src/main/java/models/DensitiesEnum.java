package models;

// ??? кг/м^3 ???
public enum DensitiesEnum {
    COOPER(8.92),BASALT(2.6),ICE(2.6),STEEL(7.9);

    DensitiesEnum(double val) {
        this.value = val;
    } // DensitiesEnum

    // вспомогательных/дополнительное поле для значений перечисления
    private double value;
    public double getValue() { return value; }

}
