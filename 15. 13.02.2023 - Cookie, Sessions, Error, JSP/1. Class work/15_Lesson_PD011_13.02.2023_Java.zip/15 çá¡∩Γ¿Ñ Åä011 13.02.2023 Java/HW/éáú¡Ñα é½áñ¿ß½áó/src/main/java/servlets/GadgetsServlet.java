package servlets;

import Infrastructure.Utils;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import models.gadgets.GadgetsContainer;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/gadgets")
public class GadgetsServlet extends HttpServlet {

    //Гаджеты
    static GadgetsContainer gadgets;
    static {
        gadgets = new GadgetsContainer();
     }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {

        //Настроить параметры ответа
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        //Сформировать ответ
        String responseStr = String.format("""
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Задание на 13.02.23</title>
                    <meta charset="utf-8">
                    <link href="resources/styles.css" rel="stylesheet"/>
                    <link href="resources/bootstrap/css/bootstrap.min.css"/ rel="stylesheet">
                    <script src="resources/bootstrap/js/bootstrap.bundle.min.js"></script>
                </head>
                <body>
                
                %1$s
                
                <section class="ms-3 main-section">
                   %2$s
                </section>
                                
                <footer class="bg-dark ">
                    <b>Разработчик:</b> Вагнер Владислав
                    <b><br>Группа:</b> ПД011
                    <b><br>Город:</b> Донецкая область,Макеевка.
                    <b><br>Год разработки:</b> 2023
                </footer>
                 
               
                </body>
                </html>
                """,
                Utils.getNavBar("gadgets"),
                gadgets.toTable()
                );

        try(PrintWriter pr = response.getWriter()){
            pr.write(responseStr);
            pr.flush();
        }
    } //onGet

    //Добавление элемента
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{
        //Настроить параметры ответа
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        //Производитель
        String brand = request.getParameter("brand");

        //Модель
        String model = request.getParameter("model");

        //ОС
        String os = request.getParameter("system");

        //Год производства
        int produced =  Integer.parseInt(request.getParameter("prod_year"));

        //Стоимость
        int price =  Integer.parseInt(request.getParameter("price"));

        gadgets.addGadget(brand, model, produced, os, price);

        //Сформировать ответ
        String responseStr = String.format("""
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Задание на 13.02.23</title>
                    <meta charset="utf-8">
                    <link href="resources/styles.css" rel="stylesheet"/>
                    <link href="resources/bootstrap/css/bootstrap.min.css"/ rel="stylesheet">
                    <script src="resources/bootstrap/js/bootstrap.bundle.min.js"></script>
                </head>
                <body>
                
                %1$s
                
                <section class="ms-3 main-section">
                   <h2 class="ms-3 mt-2">Добавлен элемент с id %3$d</h2>
                   %2$s
                </section>
                                
                <footer class="bg-dark ">
                    <b>Разработчик:</b> Вагнер Владислав
                    <b><br>Группа:</b> ПД011
                    <b><br>Город:</b> Донецкая область,Макеевка.
                    <b><br>Год разработки:</b> 2023
                </footer>
                 
               
                </body>
                </html>
                """,
                Utils.getNavBar("gadgets"),
                gadgets.toTable(),
                GadgetsContainer.lastId
        );

        try(PrintWriter pr = response.getWriter()){
            pr.write(responseStr);
            pr.flush();
        }

    }

}
