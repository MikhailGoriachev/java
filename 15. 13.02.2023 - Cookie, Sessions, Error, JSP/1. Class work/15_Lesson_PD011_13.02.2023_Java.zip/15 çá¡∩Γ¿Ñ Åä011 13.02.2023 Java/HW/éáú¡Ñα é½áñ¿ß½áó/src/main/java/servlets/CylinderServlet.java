package servlets;

import Infrastructure.Utils;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import models.DensitiesEnum;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;

@WebServlet("/cylinder-calc")
public class CylinderServlet extends HttpServlet {


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

        //Настроить параметры овтета
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        //Получение параметров
        String material = request.getParameter("material");

        String[] accounting = request.getParameterValues("calculation");
        StringBuilder sb = new StringBuilder("""
                <ul>
                """);

        //Добавить значения из массива в string builder
        if (accounting != null && accounting.length > 0)
            Arrays.stream(accounting).forEach(s -> sb.append( String.format("<li>%s</li>",s.toLowerCase()) ));

        sb.append("</ul>");



        double radius = Double.parseDouble(request.getParameter("radius").replace(',','.'));
        double height = Double.parseDouble(request.getParameter("height").replace(',','.'));

        //Сформировать ответ
        String responseStr = String.format("""
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Задание на 13.02.23</title>
                    <meta charset="utf-8">
                    <link href="resources/styles.css" rel="stylesheet"/>
                    <link href="resources/bootstrap/css/bootstrap.min.css"/ rel="stylesheet">
                    <script src="resources/bootstrap/js/bootstrap.bundle.min.js"></script>
                </head>
                <body>
                %1$s
                <section class="ms-3 main-section">
                   
                       <ul class="mx-4 mt-3 list-group">
                           <li class="list-group-item">
                                Материал: %2$s
                           </li>
                           <li class="list-group-item">
                                Что вычислять: %3$s
                           </li>
                           <li class="list-group-item">
                                Радиус: %4$.3f
                           </li>
                           <li class="list-group-item">
                                Высота: %5$.3f
                           </li>
                           <li class="list-group-item">
                           </li>
                           %6$s
                           %7$s
                           %8$s
                       </ul>
                </section>
                                
                <footer class="bg-dark ">
                    <b>Разработчик:</b> Вагнер Владислав
                    <b><br>Группа:</b> ПД011
                    <b><br>Город:</b> Донецкая область,Макеевка.
                    <b><br>Год разработки:</b> 2023
                </footer>
                 
                
                </body>
                </html>
                """,
                Utils.getNavBar("cylinder"),
                material,
                sb,
                radius,
                height,
                sb.toString().contains("объём") ? volume(radius,height) : "",
                sb.toString().contains("масса") ? mass(radius,height,material) : "",
                sb.toString().contains("площадь") ? square(radius,height) : ""
        );

        try(PrintWriter pr = response.getWriter()){
            pr.write(responseStr);
            pr.flush();
        }

    }

    //Рассчитать объем
    private String volume(double r, double h){
        double v = Math.PI * (r*r) * h;

        return String.format("""
                    <li class="list-group-item">
                         Объём: %.3f
                    </li>
                """,!Double.isNaN(v) ? v : 0);
    }

    //Рассчитать массу
    private String mass(double r, double h, String material){
        double v = Math.PI * (r*r) * h;

        //Плотность
        double density = switch (material) {
            case "Copper" -> DensitiesEnum.COOPER.getValue();
            case "Steel" -> DensitiesEnum.STEEL.getValue();
            case "Basalt" -> DensitiesEnum.BASALT.getValue();
            case "Ice" -> DensitiesEnum.ICE.getValue();
            default -> 1;
        };

        double m = v * density;

        return String.format("""
                    <li class="list-group-item">
                         Масса: %.3f
                    </li>
                """,!Double.isNaN(m) ? m : 0);
    }

    //Рассчитать площадь
    private String square(double r, double h){
        double s = 2 * Math.PI * r * (h+r);

        return String.format("""
                    <li class="list-group-item">
                         Площадь: %.3f
                    </li>
                """,!Double.isNaN(s) ? s : 0);
    }

}
