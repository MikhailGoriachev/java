package servlets;

import Infrastructure.Utils;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@WebServlet("/date")
public class DateServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {

        //Настроить параметры овтета
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        //Сформировать ответ
        String responseStr = String.format("""
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Задание на 13.02.23</title>
                    <meta charset="utf-8">
                    <link href="resources/styles.css" rel="stylesheet"/>
                    <link href="resources/bootstrap/css/bootstrap.min.css" rel="stylesheet"/>
                    <script src="resources/bootstrap/js/bootstrap.bundle.min.js"></script>
                </head>
                <body>
                %1$s
                <section class="ms-3 main-section">
                   <h2 class="mt-3">Текущие дата и время: %2$s</h2>
                </section>
                                
                <footer class="bg-dark ">
                    <b>Разработчик:</b> Вагнер Владислав
                    <b><br>Группа:</b> ПД011
                    <b><br>Город:</b> Донецкая область,Макеевка.
                    <b><br>Год разработки:</b> 2023
                </footer>
                 
                
                </body>
                </html>
                """,
                Utils.getNavBar("date"),
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss")));

        try(PrintWriter pr = response.getWriter()){
            pr.write(responseStr);
            pr.flush();
        }

    }

}
