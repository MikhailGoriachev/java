package home_task.models.task2;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;
import java.util.concurrent.Semaphore;


public class StoreSemaphore {

    //Ограничение на количество записей в хранилище
    public int LIMIT;

    //Общий ресурс
    private final String FILE_NAME = "app_data/numbers.txt";

    //Количество записей в файле
    private int valuesInFile = 0;

    //Семафоры
    private Semaphore semaphorePut;
    private Semaphore semaphoreGet;


    public StoreSemaphore(Semaphore semaphoreProd, Semaphore semaphoreCons,int limit) throws Exception {
        this.semaphorePut = semaphoreProd;
        this.semaphoreGet = semaphoreCons;

        LIMIT = limit;


        Path path = Paths.get(FILE_NAME);

        //Создание файла и каталога
        if (!Files.exists(path)){
            File dir = new File("app_data");

            //Создать каталог, если нет
            if (!dir.exists())
                dir.mkdirs();

            //Создать файл
            Files.createFile(path);
        }

        //количество строк в файле
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_NAME))) {

            while (br.readLine() != null)
                valuesInFile++;
        }

        //Если в файле есть данные
        if (valuesInFile > 0) {
            cleanFile();
        }

    }

    //Запись в хранилище
    public void put(Double value) throws Exception {
        try{
            semaphorePut.acquire();

            //Запись в файл
            try (PrintWriter pwr = new PrintWriter(new FileWriter(FILE_NAME, true))) {
                pwr.println(value);
                pwr.flush();

            }

            /*valuesInFile++;*/
        }catch (Exception e){
            throw new Exception(e);
        }
        finally {
            semaphoreGet.release();
        }

    }

    //Чтение из хранилища
    public void get(List<Double> out) throws Exception {
        try{
            semaphoreGet.acquire();

            //Чтение файла
            try (BufferedReader br = new BufferedReader(new FileReader(FILE_NAME))) {

                String line = br.readLine();

                while (line != null) {
                    out.add(Double.parseDouble(line));
                    line = br.readLine();
                }

            }
            //Очистить файл после чтения для записи новых значений
            cleanFile();

        }catch (Exception e){
            throw new Exception(e);
        }
        finally {
            semaphorePut.release();
        }
    }

    private void cleanFile() throws IOException {
        Files.newBufferedWriter(Paths.get(FILE_NAME), StandardOpenOption.TRUNCATE_EXISTING);
        valuesInFile = 0;
    }

}
