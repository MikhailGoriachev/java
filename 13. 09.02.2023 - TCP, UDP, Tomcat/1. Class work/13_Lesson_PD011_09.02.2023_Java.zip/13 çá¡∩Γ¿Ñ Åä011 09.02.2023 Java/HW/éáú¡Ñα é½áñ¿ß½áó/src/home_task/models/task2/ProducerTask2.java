package home_task.models.task2;

import home_task.utils.Utils;

public class ProducerTask2 extends Thread {

    //Количество чисел, которые нужно сгенерировать
    private final int amount = 64;
    private int written;

    //Хранилище на locker - общий ресурс
    private final StoreTask2 store;

    //Хранилище на семафорах
    /*private final StoreSemaphore storeSem;*/

    //Диапазон для генерации
    private final double lo = -10.;
    private final double hi = 20.;

    public ProducerTask2(StoreTask2 store /*StoreSemaphore store*/) {
        this.store = store;
        /*this.storeSem = store;*/
    }

    @Override
    public void run(){
        try {

            while (written < amount){
                    store.put(Utils.getRandom(lo,hi));

                    /*storeSem.put(Utils.getRandom(lo,hi));*/

                    written++;
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
