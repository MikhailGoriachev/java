package home_task.models.task1;

import home_task.utils.Utils;

import javax.swing.*;
import java.util.*;

public class ConsumerTask1 extends Thread {


    //Общий ресурс - хранилище
    private StoreTask1 store;

    //Словарь для вывода результатов
    private Map<Double,ResultTask1> results;

    public ConsumerTask1(StoreTask1 store) {

        this.store = store;
        results = new HashMap<>();
    }

    @Override
    public void run(){
        try {
            //Список значение получаем из get
            List<Double> keys = new ArrayList<>();

            //Обращение к общему ресурсу
            store.get(keys);

            //Запись результатов вычислений z1 и я2 в словарь
            keys.forEach(k -> results.put(k,calc(k)));

            showResults();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    //Вычисление z1, z2
    private ResultTask1 calc(double value){

        double sqrtA = Math.sqrt(value);
        double sqrtTwoA = Math.sqrt(value*2);
        double sqrtTwo = Math.sqrt(2);

        double z1 = ((value + 2)/sqrtTwoA - value/(sqrtTwoA+2) + 2/(value - sqrtTwoA))*((sqrtA - sqrtTwo)/(value+2));
        double z2 = 1/(sqrtA+sqrtTwo);

        return new ResultTask1(z1,z2);
    }

    //Вывод реузльтатов вычислений
    private void showResults(){
        StringBuffer sbf = new StringBuffer(String.format("<html><h3>Поток: <span color='%2$s'>%1$d</span></h3>",Thread.currentThread().threadId(),"#cc0605"));

        Utils.listSbfOutput(sbf, results,"Вычисление z1 и z2");

        //Вывод окна с таблицей.
        Utils.showWindowButtons(sbf.append(Utils.tableHtmlFooter).toString(),"Задача 1",
                new Object[]{"Назад"},"Назад", JOptionPane.DEFAULT_OPTION);
    }
}
