package home_task.models.task1;

import home_task.utils.Utils;

public class ProducerTask1 extends Thread {

    //Количество чисел, которые нужно сгенерировать
    private final int amount;
    private int written;

    //Хранилище - общий ресурс
    private final StoreTask1 store;

    //Диапазон для генерации
    private final double lo = -10.;
    private final double hi = 20.;

    public ProducerTask1(StoreTask1 store, int count) {
        this.store = store;
        this.amount = count;
    }

    @Override
    public void run(){
        try {
            //Запись значений в хранилище
            while (written <= amount){
                    store.put(Utils.getRandom(lo,hi));
                    written++;
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
