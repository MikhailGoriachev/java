package home_task.models.task1;

//Record-класс для сохранения вычисялемых начений z1 и z2
public record ResultTask1(Double z1, Double z2) {
}
