package home_task.models.task2;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class StoreTask2 {

    //Ограничение на кол-во записей в хранилище (как запись, так и чтение)
    public int LIMIT;

    //Общий ресурс
    private final String FILE_NAME = "app_data/numbers.txt";

    //Количество записей в файле
    private int valuesInFile = 0;

    //Количество обработканных значений
    private int processed = 0;

    //Остаток записей в файле
    private int neededQuantity;

    //Блокировщик
    private Lock lock;

    //Управление состоянием потока
    Condition condition ;

    public StoreTask2(Lock lock, int limit) throws Exception {
        this.lock = lock;
        condition = lock.newCondition();

        LIMIT = limit;
        neededQuantity = 64;

        Path path = Paths.get(FILE_NAME);

        //Создание файла
        if (!Files.exists(path)){
            File dir = new File("app_data");

            //Создать каталог, если нет
            if (!dir.exists())
                dir.mkdirs();

            //Создать файл
            Files.createFile(path);
        }

        //количество строк в файле
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_NAME))) {

            while (br.readLine() != null)
                valuesInFile++;
        }

        //Если в файле есть данные, то очистить
        if (valuesInFile > 0) {
            cleanFile();
        }

    }

    //Запись в хранилище
    public void put(Double value) throws Exception {
        lock.lock();

        //Ограничение на запись значений в список, пока кол-во записей в файле > допустимого
        while (valuesInFile >= LIMIT && neededQuantity - processed > LIMIT) {

            //Установить поток в ожидание.
            condition.await();
        }//While

        //Запись в файл
        try (PrintWriter pwr = new PrintWriter(new FileWriter(FILE_NAME,true))) {
            pwr.println(value);
            pwr.flush();

        }
        valuesInFile++;

        //Уведомляем поток Consumer. Уведомляем только тогда, когда запишем нужно кол-во значений/
        if (valuesInFile == LIMIT || neededQuantity - processed < LIMIT)
            condition.signal();

        lock.unlock();
    }

    //Чтение из хранилища
    public void get(List<Double> out, int readNumbers) throws Exception {
        lock.lock();

        //Ограничение чтения, пока количество элементов в файле не увеличится - заморажиаваем поток
        //Второе условие: можно замораживать поток, пока требуемое кол-во — кол-во обработанных > лимита. Иначе поток не выйдет из сна.
        while (valuesInFile < LIMIT && neededQuantity - readNumbers > LIMIT){

            //Установить поток в ожидание.
            condition.await();
        }//While

        //Счётчик обработанных элементов
        processed = readNumbers;

        //Чтение файла - Scanner
        try(BufferedReader br = new BufferedReader(new FileReader(FILE_NAME))){

            String line = br.readLine();

            while (line != null){
                out.add(Double.parseDouble(line));
                line = br.readLine();
            }

        }

        //Очистить файл после чтения для записи новых значений
        // cleanFile();

        condition.signal();

        lock.unlock();
    }

    private void cleanFile() throws IOException {
        Files.newBufferedWriter(Paths.get(FILE_NAME), StandardOpenOption.TRUNCATE_EXISTING);
        valuesInFile = 0;
    }

}
