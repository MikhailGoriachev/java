package home_task.controllers;


import home_task.interfaces.ControllerInterface;
import home_task.models.task2.ConsumerTask2;
import home_task.models.task2.ProducerTask2;
import home_task.models.task2.StoreSemaphore;
import home_task.models.task2.StoreTask2;
import home_task.utils.Utils;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class Task2Controller implements ControllerInterface {


    //Запуск  контроллера
    @Override
    public void start() throws Exception {

        Lock locker = new ReentrantLock();

        //Семафоры. В параметрах семафора-потребителя задан 0 для того, чтобы производителя запустить первым
        /*Semaphore semaphoreProd = new Semaphore(1);
        Semaphore semaphoreCons = new Semaphore(0);*/

        //Максимальное количество значений в файле
        int maxQuantity = Utils.getRandom(12,18);

        //Хранилище на семафорах
        /*StoreSemaphore storeSem = new StoreSemaphore(semaphoreProd,semaphoreCons,maxQuantity);*/

        //Хранилище на Lock
        StoreTask2 store = new StoreTask2(locker,maxQuantity);

        List<Thread> threads = new ArrayList<>();

        threads.add(new ProducerTask2(store/*storeSem*/));
        threads.add(new ConsumerTask2(store /*storeSem*/, maxQuantity));

        //Запуск потоков
        threads.forEach(Thread::start);

        //Установка ожидания
        for (var t: threads) {
            t.join();
        }



    }
}
