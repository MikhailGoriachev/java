package home_task.models.task2;

import java.util.ArrayList;
import java.util.List;

public class ConsumerTask2 extends Thread {

    //Общий рерсурс
    private StoreTask2 store;

    //Необходимое количество данных
    private int LIMIT = 64;

    //Число прочитанных записей
    private int read;

    //Количество значений, которы можно прочитать за 1 раз
    private int maxQuantity;

    //Хранилище на семафорах
    /*private StoreSemaphore storeSem;*/

    private List<Double> numbers;

    public ConsumerTask2(StoreTask2 store /*StoreSemaphore storeSemaphore*/, int valuesCount) {
        this.store = store;
       /*this.storeSem = storeSemaphore;*/
        this.numbers = new ArrayList<>();
        this.maxQuantity = valuesCount;
    }

    @Override
    public void run(){
        try {

            do {
                //Получение записей
                store.get(numbers,read);
                /*storeSem.get(numbers);*/
                read += numbers.size();

                sortAndShow();

                //Очистить список на данной итерации получения данных
                numbers.clear();

            } while (read < LIMIT);


        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }//run

    private void sortAndShow(){

        //Сначала четные
        var sorted = new ArrayList<>(numbers.stream().filter(n -> !isOdd(n)).toList());

        //Добавить нечетные в конец
        sorted.addAll(numbers.stream().filter(this::isOdd).toList());

        System.out.printf("\nИсходная коллекция. Прочитано элементов:\u001b[38;5;16m\u001b[48;5;26m %d \u001b[0m\n",numbers.size());

        numbers.forEach(n -> System.out.printf("%2$s %1$4.3f \u001b[0m",n, isOdd(n) ? "\u001b[38;5;16m\u001b[48;5;14m" : "\u001b[0m"));
        System.out.println("\nОтсортированная коллекция");
        sorted.forEach(ns -> System.out.printf("%2$s %1$4.3f \u001b[0m",ns,isOdd(ns) ? "\u001b[38;5;16m\u001b[48;5;14m" : "\u001b[0m"));

        System.out.println();

    }

    private boolean isOdd(Double value){
        return value.intValue() % 2 != 0;
    }

}
