package home_task.models.task1;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class StoreTask1 {

    //Ограничение на кол-во записей в хранилище (как запись, так и чтение)
    public int LIMIT;

    //Общий ресурс
    private List<Double> numbers;

    //Блокировщик
    private Lock lock;

    //Управление состоянием потока
    Condition condition ;

    public StoreTask1(Lock lock, int limit) {
        this.lock = lock;
        condition = lock.newCondition();

        LIMIT = limit;

        numbers = new ArrayList<>();
    }

    //Запись в хранилище
    public void put(Double value) throws Exception {
        lock.lock();

        //Ограничение на запись значений в список: пока кол-во элементов > допустимого
        while (numbers.size() > LIMIT) {

            //Установить поток в ожидание.
            condition.await();
        }//While

        //После достижения нужного кол-ва записей - изменяем ресурс и пробуждаем потоки consumer из ожидания
        numbers.add(value);

        //Уведомляем поток Consumer
        condition.signal();

        lock.unlock();
    }

    //Чтение из хранилища
    public void get(List<Double> out) throws Exception {
        lock.lock();

        //Ограничение чтения, пока размер списка элементов не увеличится - заморажиаваем поток
        while (numbers.size() <= LIMIT){

            //Установить поток в ожидание.
            condition.await();
        }//While

        out.addAll(numbers);

        numbers.clear();

        lock.unlock();
    }

}
