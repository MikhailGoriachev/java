package home_task.controllers;


import home_task.interfaces.ControllerInterface;
import home_task.models.task1.ConsumerTask1;
import home_task.models.task1.ProducerTask1;
import home_task.models.task1.StoreTask1;
import home_task.utils.Utils;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class Task1Controller implements ControllerInterface {


    //Запуск  контроллера
    @Override
    public void start() throws Exception {

        Lock locker = new ReentrantLock();
        int amountNumbers = Utils.getRandom(10,50);

        StoreTask1 store = new StoreTask1(locker,amountNumbers);

        List<Thread> threads = new ArrayList<>();

        //Создание потоков
        threads.add(new Thread(new ProducerTask1(store,amountNumbers)));
        threads.add(new Thread(new ConsumerTask1(store)));

        threads.add(new Thread(new ProducerTask1(store,amountNumbers)));
        threads.add(new Thread(new ConsumerTask1(store)));

        threads.add(new Thread(new ProducerTask1(store,amountNumbers)));
        threads.add(new Thread(new ConsumerTask1(store)));

        //Запуск потоков
        threads.forEach(Thread::start);

        //Ожидание потоков
        for (var t:threads) {
            t.join();
        }

    }
}
