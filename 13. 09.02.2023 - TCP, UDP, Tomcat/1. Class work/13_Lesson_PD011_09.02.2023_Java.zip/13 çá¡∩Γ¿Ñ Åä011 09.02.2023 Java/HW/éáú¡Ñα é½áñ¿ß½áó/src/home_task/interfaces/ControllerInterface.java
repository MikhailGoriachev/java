package home_task.interfaces;

public interface ControllerInterface {

    //Запуск выполнения задач
    void start() throws Exception;

}
