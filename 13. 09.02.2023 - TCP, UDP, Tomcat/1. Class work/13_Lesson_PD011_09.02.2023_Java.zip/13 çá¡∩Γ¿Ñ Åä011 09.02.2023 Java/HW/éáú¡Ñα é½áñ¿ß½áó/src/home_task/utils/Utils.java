package home_task.utils;

import home_task.models.task1.ResultTask1;

import javax.swing.*;
import java.util.Random;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class Utils {

    //Генерация значений
    private static Random rand = new Random();

    public Utils() {
    }

    //Получение слуйчаных значений
    public static double getRandom(double lo, double hi) {
        return lo + rand.nextDouble() * (hi - lo);
    }

    public static int getRandom(int lo, int hi) {
        return lo + rand.nextInt(hi - lo);
    }


    // вывод окна с кнопками
    public static int showWindowButtons (String message, String title, Object[] buttons, String initialValue, int windowType) {
        return JOptionPane.showOptionDialog(
                null,
                message,
                title,
                JOptionPane.DEFAULT_OPTION,
                windowType,
                null,
                buttons,
                initialValue
        );
    }

    public static String tableHtmlHeader = "<html><table align='center' border='1' cellspacing='0' cellpadding='4'>";
    public static String tableHtmlFooter = "</table>";

    public static void listSbfOutput(StringBuffer sbf, Map<Double, ResultTask1> list, String tableHeader){
        //Заголовок таблицы
        sbf.append(String.format("%s<tr><th colspan='%d'>%s</th></tr>",tableHtmlHeader,15,tableHeader));

        //Список в строку
        AtomicInteger i = new AtomicInteger();
        sbf.append("<tr>");
        list.forEach((key, value) -> {
            i.incrementAndGet();
            sbf.append(String.format("<td><br>%4.2f <br>______<br>Z1 = %3.2f<br>Z2 = %3.2f</td>", key,
                    value.z1().isNaN() ? 0:value.z1(),
                    value.z2().isNaN() ? 0:value.z2()));

            //Перенос каждого 15-го элемента
            if (i.get() % 15 == 0 && i.get() != list.size() - 1)
                sbf.append("</tr><tr>");
        });
        sbf.append("</tr>");
    }



}//Utils
