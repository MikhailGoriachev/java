package org.step.home_work.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.step.home_work.models.Query6;
import org.step.home_work.models.entities.Sale;
import org.step.home_work.models.entities.sellers.Seller;

import java.util.List;

@Repository
public interface SellersRepository extends JpaRepository<Seller, Long> {

    //Запрос 6
    @Query(nativeQuery = true, value = """
    select
        CONCAT(view_sellers.seller_surname,'.',
               substr(view_sellers.seller_name,1,1),'.',
               substr(view_sellers.seller_patronymic,1,1)) as snp,
        ifnull(sum(view_sales.amount),0) as products_amount,
        count(*) as sales_count,
        ifnull(max(view_sales.selling_price),0) as max_sale_price,
        ifnull(min(view_sales.selling_price),0) as min_sale_price
    from
        view_sellers left join view_sales on view_sellers.id = view_sales.seller_id
    group by
        snp
    """)
    //@Query(nativeQuery = true);
    List<Query6> query6();

}
