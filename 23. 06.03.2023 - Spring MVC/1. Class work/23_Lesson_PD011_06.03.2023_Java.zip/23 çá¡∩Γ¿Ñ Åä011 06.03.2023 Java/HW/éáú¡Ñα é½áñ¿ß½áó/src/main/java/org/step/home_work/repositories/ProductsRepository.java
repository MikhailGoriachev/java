package org.step.home_work.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.step.home_work.models.entities.Sale;
import org.step.home_work.models.entities.products.Product;

import java.util.List;

@Repository
public interface ProductsRepository extends JpaRepository<Product, Long> {

    //Запрос 1
    @Query(nativeQuery = true ,value = """
    SELECT
        prod.id,
        prod.pn_id as name_id,
        prod.unit_id,
        prod.purchase_price,
        prod.selling_price
    from
        view_products as prod
    where
            prod.unit like ?1 and prod.purchase_price < ?2
    """)
    List<Product> findProductsBy(String unit, int price);


    //Запрос 2
    @Query(nativeQuery = true ,value = """
    SELECT
        prod.id,
        prod.pn_id as name_id,
        prod.unit_id,
        prod.purchase_price,
        prod.selling_price
    from
        view_products as prod
    where
        prod.purchase_price < ?1
    """)
    List<Product> findProductsBy(int price);
}
