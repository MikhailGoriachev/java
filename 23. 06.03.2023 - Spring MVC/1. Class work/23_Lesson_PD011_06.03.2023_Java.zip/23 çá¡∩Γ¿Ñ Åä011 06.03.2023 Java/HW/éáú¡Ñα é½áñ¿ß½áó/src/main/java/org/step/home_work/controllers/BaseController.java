package org.step.home_work.controllers;

import org.springframework.context.ApplicationContext;
import org.step.home_work.repositories.ProductsRepository;
import org.step.home_work.repositories.SalesRepository;
import org.step.home_work.repositories.SellersRepository;

public abstract class BaseController {

    //Контекст приложения
    private ApplicationContext context;

    //Репозитории
    SalesRepository salesRepository;
    ProductsRepository productsRepository;
    SellersRepository sellersRepository;

    public BaseController(ApplicationContext context) {
        this.context = context;

        salesRepository = context.getBean(SalesRepository.class);
        productsRepository = context.getBean(ProductsRepository.class);
        sellersRepository = context.getBean(SellersRepository.class);
    }

    public abstract void start();
}
