package org.step.home_work.controllers;

import org.springframework.context.ApplicationContext;
import org.step.home_work.models.entities.Sale;
import org.step.home_work.models.entities.products.Product;
import org.step.home_work.models.entities.sellers.Seller;
import org.step.home_work.utils.Utils;

import javax.swing.*;
import java.util.List;

public class CrudController extends BaseController {

    //Репозитории

    public CrudController(ApplicationContext context) {
        super(context);
    }

    @Override
    public void start() {
        try {

            //Вызов методов обработок
            while (true) {
                switch (showMenu()) {
                    case 0 -> addSaleFact();
                    case 1 ->  changeFact();
                    //case 2 -> Utils.showWindowButtons("Удаление записи в разработке!","Spring data",new Object[]{"Выход"},"", JOptionPane.INFORMATION_MESSAGE);
                    case 2 -> deleteFact();

                    default -> {
                        return;
                    }
                }
            }
        } catch (Exception e) {
            Utils.showWindowButtons(e.getMessage() + "\n","Ошибка!",new Object[]{"Выход"},"", JOptionPane.ERROR_MESSAGE);

            System.out.printf("\n Упало исключение:\n%s\n",e.getMessage());
            System.out.println(e.getMessage() + "\n");
            e.printStackTrace();
        }
    }

    //Вывод меню
    public static int showMenu(){

        //Задание значений для окна
        String title = "Spring data";
        String message = "<html><h1>Выберите операцию</h1>";
        Object[] buttons = new Object[]{
                "Добавить факт продажи",
                "Изменить факт продажи",
                "Удалить факт продажи",
                "Выход"
        };


        return Utils.showWindowButtons(message,title,buttons,"Продажи", JOptionPane.DEFAULT_OPTION);
    }//showMenu

    //Добавление записи
    private void addSaleFact() throws Exception {
        List<Product>  products = productsRepository.findAll();
        List<Seller> sellers = sellersRepository.findAll();

        Sale sale = new Sale(
                products.get(Utils.getRandom(0,products.size())),
                sellers.get(Utils.getRandom(0,sellers.size())),
                Utils.getRandom(1,6),

                //Генерация даты
                Utils.dateFormat.parse(String.format("%d.%d.2022",Utils.getRandom(1,31),Utils.getRandom(1,12)))
        );

        sale = salesRepository.saveAndFlush(sale);

        Utils.showSales(salesRepository.findAll(),String.format("Добавлен факт с id %d",sale.getId()));
    }

    //Изменение записи
    private void changeFact(){

        //Получить максимальный id
        long maxId = salesRepository.findAll().stream().mapToLong(Sale::getId).max().getAsLong();

        Sale sale = salesRepository.findById(Utils.getRandom(1,maxId)).get();

        int startAmount = sale.getProductsAmount();

        //Изменить кол-во проданных товаров
        sale.setProductsAmount(startAmount+5);

        salesRepository.save(sale);

        Utils.showSales(salesRepository.findAll(),String.format("Изменена запись с id %d. Начальное значение: %d, текущее: %d",sale.getId(),
                startAmount,sale.getProductsAmount()));

    }//changeFact

    //Удаление записи
    private void deleteFact(){
        //Получить максимальный id - удаляем последний элемент
        long maxId = salesRepository.findAll().stream().mapToLong(Sale::getId).max().getAsLong();
        salesRepository.deleteById(maxId);

        Utils.showSales(salesRepository.findAll(),String.format("Удалена запись с id %d",maxId));
    }


}
