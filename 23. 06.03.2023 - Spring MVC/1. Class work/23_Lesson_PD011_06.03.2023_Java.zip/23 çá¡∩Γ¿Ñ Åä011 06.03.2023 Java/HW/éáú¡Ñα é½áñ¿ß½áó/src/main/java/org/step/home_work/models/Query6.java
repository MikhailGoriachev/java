package org.step.home_work.models;

import javax.persistence.Column;


/*@NamedNativeQuery(name = "Query6.query6", query = """
select
    CONCAT(view_sellers.seller_surname,'.',
           substr(view_sellers.seller_name,1,1),'.',
           substr(view_sellers.seller_patronymic,1,1)) as snp,
    ifnull(sum(view_sales.amount),0) as products_amount,
    ifnull(count(*),0) as sales_count,
    ifnull(max(view_sales.selling_price),0) as max_sale_price,
    ifnull(min(view_sales.selling_price),0) as min_sale_price
from
    view_sellers left join view_sales on view_sellers.id = view_sales.seller_id
group by
    snp
""")*/
public class Query6 {

    @Column(name = "snp")
    private String sellerSnp;

    @Column(name = "products_amount")
    private int productsAmount;

    @Column(name = "sales_count")
    private int salesCount;

    @Column(name = "max_sale_price")
    private int maxSalePrice;

    @Column(name = "min_sale_price")
    private int minSalePrice;

    public Query6() {
    }

    public static String HEADER  = """
            <tr>
            <th>Фио продавца</th>
            <th>Кол-во проданных товаров</th>
            <th>Кол-во продаж</th>
            <th>Максимальная цена продажи</th>
            <th>Минимальная цена продажи</th>
            </tr>
            """;

    //Вывод в строку таблицы
    public String toTableRow(){
        return String.format("<tr><td> %s </td><td> %d </td><td> %d </td><td> %d </td><td> %d </td></tr>",
                sellerSnp,productsAmount,salesCount,maxSalePrice,minSalePrice);
    }//toTableRow

    public String getSellerSnp() {
        return sellerSnp;
    }

    public void setSellerSnp(String sellerSnp) {
        this.sellerSnp = sellerSnp;
    }

    public int getProductsAmount() {
        return productsAmount;
    }

    public void setProductsAmount(int productsAmount) {
        this.productsAmount = productsAmount;
    }

    public int getSalesCount() {
        return salesCount;
    }

    public void setSalesCount(int salesCount) {
        this.salesCount = salesCount;
    }

    public int getMaxSalePrice() {
        return maxSalePrice;
    }

    public void setMaxSalePrice(int maxSalePrice) {
        this.maxSalePrice = maxSalePrice;
    }

    public int getMinSalePrice() {
        return minSalePrice;
    }

    public void setMinSalePrice(int minSalePrice) {
        this.minSalePrice = minSalePrice;
    }
}
