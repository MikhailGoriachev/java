package org.step.home_work;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.step.home_work.controllers.BaseController;
import org.step.home_work.controllers.CrudController;
import org.step.home_work.controllers.QueriesController;
import org.step.home_work.controllers.TablesController;
import org.step.home_work.utils.Utils;

import javax.swing.*;


public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");

        BaseController[] controllers = new BaseController[]{
                new TablesController(context),
                new QueriesController(context),
                new CrudController(context),
        };

        try {

            //Вызов методов обработок
            while (true) {
                switch (showMenu()) {
                    case 0 -> controllers[0].start();
                    case 1 -> controllers[1].start();
                    case 2 -> controllers[2].start();
                    case 3 -> System.exit(0);

                    default -> {
                        return;
                    }
                }
            }
        } catch (Exception e) {
            Utils.showWindowButtons(e.getMessage() + "\n","Ошибка!",new Object[]{"Выход"},"", JOptionPane.ERROR_MESSAGE);

            System.out.printf("\n Упало исключение:\n%s\n",e.getMessage());
            System.out.println(e.getMessage() + "\n");
            e.printStackTrace();
        }
    }//main

    //Вывод меню
    public static int showMenu(){

        //Задание значений для окна
        String title = "Spring beginning";
        String message = "<html><h1>Выбирете пункт меню</h1>";
        Object[] buttons = new Object[]{
                "Таблицы",
                "Запросы",
                "CRUD",
                "Выход"
        };


        return Utils.showWindowButtons(message,title,buttons,"Выход",JOptionPane.DEFAULT_OPTION);
    }//showMenu

}
