package org.step.home_work.models;

import org.step.home_work.utils.Utils;

import javax.persistence.Column;
import java.util.Date;


/*@NamedNativeQuery(name = "Query5.query5", query = """
select
    view_sales.product_name,
    avg(view_sales.purchase_price) as avg_purchase_price,
    count(*) as amount
from
    view_sales
group by
    view_sales.product_name
""")*/
public class Query5 {

    @Column(name = "product_name")
    private String productName;

    @Column(name = "avg_purchase_price")
    private double avgPrice;

    @Column(name = "amount")
    private int amount;

    public Query5(String productName, double avgPrice, int amount) {
        this.productName = productName;
        this.avgPrice = avgPrice;
        this.amount = amount;
    }

    public Query5() {
    }

    public static String HEADER  = "<tr><th>Наименование товара</th><th>Средняя цена закупки</th><th>Количество товаров</th></tr>";

    //Вывод в строку таблицы
    public String toTableRow(){
        return String.format("<tr><td> %s </td><td> %.2f </td><td> %d </td></tr>",
                productName,avgPrice,amount);
    }//toTableRow

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public double getAvgPrice() {
        return avgPrice;
    }

    public void setAvgPrice(double avgPrice) {
        this.avgPrice = avgPrice;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}
