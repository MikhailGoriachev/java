package org.step.home_work.models.entities.products;


import javax.persistence.*;

@Entity
@Table(name = "product_names")
public class ProductName {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "name")
    private String name;

    public ProductName() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static String HEADER  = """
            <tr>
                <th>id</th>
                <th>Наименование</th>
            </tr>
            """;

    public String toTableRow(){
        return String.format("""
                <tr>
                    <td> %d </td>
                    <td> %s </td>
                </tr>
                """,id,name);
    }//toTableRow
}
