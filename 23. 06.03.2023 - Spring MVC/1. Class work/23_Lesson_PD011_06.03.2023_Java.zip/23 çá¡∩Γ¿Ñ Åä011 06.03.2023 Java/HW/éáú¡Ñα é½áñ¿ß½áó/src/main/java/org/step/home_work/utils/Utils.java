package org.step.home_work.utils;

import org.step.home_work.models.Query4;
import org.step.home_work.models.Query5;
import org.step.home_work.models.Query6;
import org.step.home_work.models.entities.Sale;
import org.step.home_work.models.entities.products.Product;
import org.step.home_work.models.entities.sellers.Seller;

import javax.swing.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Random;
import java.util.*;

public class Utils {

    //Генерация значений
    private static Random rand = new Random();

    //Формат вывода чисел
    public static DecimalFormat numbersFormatter = new DecimalFormat("###,###,###");

    //Формат вывода даты
    public static SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");

    public Utils() {
    }

    //Получение случайных значений
    public static double getRandom(double lo, double hi) {
        return lo + rand.nextDouble() * (hi - lo);
    }

    public static int getRandom(int lo, int hi) {
        return lo + rand.nextInt(hi - lo);
    }
    public static long getRandom(long lo, long hi) {
        return lo + rand.nextLong(hi - lo);
    }


    // вывод окна с кнопками
    public static int showWindowButtons (String message, String title, Object[] buttons, String initialValue, int windowType) {
        return JOptionPane.showOptionDialog(
                null,
                message,
                title,
                JOptionPane.DEFAULT_OPTION,
                windowType,
                null,
                buttons,
                initialValue
        );
    }

    public static String tableHtmlHeader = "<html><table align='center' border='1' cellspacing='0' cellpadding='4'>";
    public static String tableHtmlFooter = "</table>";

    //Вывод продаж
    public static int showSales(List<Sale> sales,String title){
        String task = String.format("""
                <html><span>Таблица продавцов</span><br>
                <html><span>%s</span><br><br>
                """,title);

        //Общая строка вывода
        StringBuilder sb = new StringBuilder(task);


        //Создание заголовка таблицы
        sb.append(tableHtmlHeader);
        sb.append(Sale.HEADER);

        //Проверка на валидность
        if (sales == null || sales.size() == 0) {

            sb.append("<tr><td colspan='14'>Что-то пошло не так. Таблица приемов не подгрузилась!</td></tr>");
            sb.append(tableHtmlFooter);


            return somethingGoneWrong("Что-то пошло не так!",sb);
        }

        //Контент таблицы
        sales.forEach((a) -> sb.append(a.toTableRow()));

        sb.append(tableHtmlFooter);

        return showWindowButtons(sb.toString(), "Продажи", new Object[]{"Назад"}, "", JOptionPane.PLAIN_MESSAGE);
    }

    //Вывод товаров
    public static int showProducts(List<Product> products){
        String task = """
                <html><span>Таблица товаров</span><br><br>
                """;

        //Общая строка вывода
        StringBuilder sb = new StringBuilder(task);


        //Создание заголовка таблицы
        sb.append(tableHtmlHeader);
        sb.append(Product.HEADER);

        //Проверка на валидность
        if (products == null || products.size() == 0) {

            sb.append("<tr><td colspan='14'>Что-то пошло не так. Таблица товаров не подгрузилась!</td></tr>");
            sb.append(tableHtmlFooter);

            return somethingGoneWrong("Что-то пошло не так. Таблица товаров не подгрузилась!",sb);
            /*return showWindowButtons(sb.toString(),
                    "Приемы",
                    new Object[]{"Назад"},
                    "", JOptionPane.WARNING_MESSAGE);*/
        }

        //Контент таблицы
        products.forEach((p) -> sb.append(p.toTableRow()));

        sb.append(tableHtmlFooter);

        return showWindowButtons(sb.toString(), "Товары", new Object[]{"Назад"}, "", JOptionPane.PLAIN_MESSAGE);
    }

    //Вывод продавцов
    public static int showSellers(List<Seller> sellers){
        String task = """
                <html><span>Таблица продавцов</span><br><br>
                """;

        //Общая строка вывода
        StringBuilder sb = new StringBuilder(task);


        //Создание заголовка таблицы
        sb.append(tableHtmlHeader);
        sb.append(Seller.HEADER);

        //Проверка на валидность
        if (sellers == null || sellers.size() == 0) {

            sb.append("<tr><td colspan='14'>Что-то пошло не так. Таблица продавцов не подгрузилась!</td></tr>");
            sb.append(tableHtmlFooter);

            return somethingGoneWrong("Что-то пошло не так!",sb);
        }

        //Контент таблицы
        sellers.forEach((seller) -> sb.append(seller.toTableRow()));

        sb.append(tableHtmlFooter);

        return showWindowButtons(sb.toString(), "Продавцы", new Object[]{"Назад"}, "", JOptionPane.PLAIN_MESSAGE);
    }

    //Вывод результатов запроса 4
    public static int showQuery4(List<Query4> result){
        String task = """
                <html><span>Запросы 4 - вычисляемые поля</span><br><br>
                """;

        //Общая строка вывода
        StringBuilder sb = new StringBuilder(task);


        //Создание заголовка таблицы
        sb.append(tableHtmlHeader);
        sb.append(Query4.HEADER);

        //Проверка на валидность
        if (result == null || result.size() == 0) {

            sb.append("<tr><td colspan='14'>Что-то пошло не так. Таблица результатов запроса не подгрузилась!</td></tr>");
            sb.append(tableHtmlFooter);

            return somethingGoneWrong("Что-то пошло не так!",sb);
        }

        //Контент таблицы
        result.forEach((r) -> sb.append(r.toTableRow()));

        sb.append(tableHtmlFooter);

        return showWindowButtons(sb.toString(), "Запрос 4", new Object[]{"Назад"}, "", JOptionPane.PLAIN_MESSAGE);
    }

    //Вывод результатов запроса 5
    public static int showQuery5(List<Query5> result){
        String task = """
                <html><span>Запросы 5 - итоговый</span><br><br>
                """;

        //Общая строка вывода
        StringBuilder sb = new StringBuilder(task);


        //Создание заголовка таблицы
        sb.append(tableHtmlHeader);
        sb.append(Query5.HEADER);

        //Проверка на валидность
        if (result == null || result.size() == 0) {

            sb.append("<tr><td colspan='14'>Что-то пошло не так. Таблица результатов запроса не подгрузилась!</td></tr>");
            sb.append(tableHtmlFooter);

            return somethingGoneWrong("Что-то пошло не так!",sb);
        }

        //Контент таблицы
        result.forEach((r) -> sb.append(r.toTableRow()));

        sb.append(tableHtmlFooter);

        return showWindowButtons(sb.toString(), "Запрос 5", new Object[]{"Назад"}, "", JOptionPane.PLAIN_MESSAGE);
    }

    //Вывод результатов запроса 6
    public static int showQuery6(List<Query6> result){
        String task = """
                <html><span>Запросы 6 - левое соединение</span><br><br>
                """;

        //Общая строка вывода
        StringBuilder sb = new StringBuilder(task);


        //Создание заголовка таблицы
        sb.append(tableHtmlHeader);
        sb.append(Query6.HEADER);

        //Проверка на валидность
        if (result == null || result.size() == 0) {

            sb.append("<tr><td colspan='14'>Что-то пошло не так. Таблица результатов запроса не подгрузилась!</td></tr>");
            sb.append(tableHtmlFooter);

            return somethingGoneWrong("Что-то пошло не так!",sb);
        }

        //Контент таблицы
        result.forEach((r) -> sb.append(r.toTableRow()));

        sb.append(tableHtmlFooter);

        return showWindowButtons(sb.toString(), "Запрос 6", new Object[]{"Назад"}, "", JOptionPane.PLAIN_MESSAGE);
    }

    //Вывод окна с сообщением об ошибке
    private static int somethingGoneWrong(String title, StringBuilder currentResult){
        System.out.println("\n\t\u001b[38;5;9mЧто-то пошло не так! Данные не загрузились\u001b[0m");
        return showWindowButtons(currentResult.toString(),
                title,
                new Object[]{"Назад"},
                "", JOptionPane.WARNING_MESSAGE);
    }

}//Utils
