package org.step.home_work.models;

import org.springframework.data.jpa.repository.Query;
import org.step.home_work.utils.Utils;

import javax.persistence.*;
import java.util.Date;


/*@NamedNativeQuery(name = "Query4.query4", query = """
select
        sales.date,
        sales.id as saleId,
        product_name,
        selling_price,
        purchase_price,
        amount,
        (selling_price - product_name) * sales.amount as profit
    from
        view_sales as sales
    order by
        sales.product_name
""")*/
public class Query4 {


    /*@Column(name = "date")*/
    private Date date;


    /*@Column(name = "saleId")*/
    private long saleId;


    /*@Column(name = "product_name")*/
    private String productName;

    /*@Column(name = "selling_price")*/
    private int sellingPrice;

     /*@Column(name = "purchase_price")*/
    private int purchasePrice;

    /*@Column(name = "amount")*/
    private int amount;

    /*@Column(name = "profit")*/
    private int profit;

    public Query4() {
    }

    public Query4(Date date, long saleId, String productName, int sellingPrice, int purchasePrice, int amount, int profit) {
        this.date = date;
        this.saleId = saleId;
        this.productName = productName;
        this.sellingPrice = sellingPrice;
        this.purchasePrice = purchasePrice;
        this.amount = amount;
        this.profit = profit;
    }

    public static String HEADER  = "<tr><th>Дата продажи</th><th>Наименование товара</th><th>Стоимость продажи</th><th>Стоимость закупки</th><th>Количество товаров</th><th>Прибыль</th></tr>";

    //Вывод в строку таблицы
    public String toTableRow(){
        return String.format("<tr><td> %s </td><td> %s </td><td> %d </td><td> %d </td><td> %d </td><td> %d </td></tr>",
                Utils.dateFormat.format(date),productName,sellingPrice,purchasePrice,amount,profit);
    }//toTableRow

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public long getSaleId() {
        return saleId;
    }

    public void setSaleId(long saleId) {
        this.saleId = saleId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getSellingPrice() {
        return sellingPrice;
    }

    public void setSellingPrice(int sellingPrice) {
        this.sellingPrice = sellingPrice;
    }

    public int getPurchasePrice() {
        return purchasePrice;
    }

    public void setPurchasePrice(int purchasePrice) {
        this.purchasePrice = purchasePrice;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public int getProfit() {
        return profit;
    }

    public void setProfit(int profit) {
        this.profit = profit;
    }
}
