package org.step.home_work.controllers;

import org.springframework.context.ApplicationContext;
import org.step.home_work.utils.Utils;

import javax.swing.*;

public class QueriesController extends BaseController {

    /*@PersistenceContext
    private EntityManager em;*/

    public QueriesController(ApplicationContext context) {
        super(context);

    }

    @Override
    public void start() {
        try {

            //Вызов запросов
            while (true) {
                switch (showMenu()) {
                    case 0 -> Utils.showProducts(productsRepository.findProductsBy("шт",200));
                    case 1 -> Utils.showProducts(productsRepository.findProductsBy(500));
                    case 2 -> {
                        int min = 400;
                        int max = 10000;
                        Utils.showSales(salesRepository.findSalesBy(min, max),
                                String.format("Запрос 3. Диапазон цен продажи: от %d до %s",min,Utils.numbersFormatter.format(max)));
                    }
                    case 3 -> Utils.showWindowButtons("Запрос 4 в разработке!","Spring data",new Object[]{"Выход"},"", JOptionPane.INFORMATION_MESSAGE);
                    //case 3 -> Utils.showQuery4(salesRepository.query4());
                    //case 3 -> query4();
                    case 4 -> Utils.showWindowButtons("Запрос 5 в разработке!","Spring data",new Object[]{"Выход"},"", JOptionPane.INFORMATION_MESSAGE);
                    //case 4 -> Utils.showQuery5(salesRepository.query5());
                    case 5 -> Utils.showWindowButtons("Запрос 6 в разработке!","Spring data",new Object[]{"Выход"},"", JOptionPane.INFORMATION_MESSAGE);
                    //case 5 -> Utils.showQuery6(sellersRepository.query6());

                    default -> {
                        return;
                    }
                }
            }
        } catch (Exception e) {
            Utils.showWindowButtons(e.getMessage() + "\n","Ошибка!",new Object[]{"Выход"},"", JOptionPane.ERROR_MESSAGE);

            System.out.printf("\n Упало исключение:\n%s\n",e.getMessage());
            System.out.println(e.getMessage() + "\n");
            e.printStackTrace();
        }
    }

    //Вывод меню
    public static int showMenu(){

        //Задание значений для окна
        String title = "Spring data";
        String message = "<html><h1>Выберите запрос</h1>";
        Object[] buttons = new Object[]{
                "Запрос 1",
                "Запрос 2",
                "Запрос 3",
                "Запрос 4",
                "Запрос 5",
                "Запрос 6",
                "Выход"
        };

        return Utils.showWindowButtons(message,title,buttons,"Продажи", JOptionPane.DEFAULT_OPTION);
    }//showMenu

    //Запрос 4
    /*private void query4(){
        Query query = em.createNativeQuery("""
        select
            sales.date,
            sales.id as saleId,
            product_name,
            selling_price,
            purchase_price,
            amount,
            (selling_price - product_name) * sales.amount as profit
        from
            view_sales as sales
        order by
        sales.product_name
        """);

        List<Query4> result = query.getResultList();
        Utils.showQuery4(result);
    }*/

}
