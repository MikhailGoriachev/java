package org.step.home_work.controllers;

import org.springframework.context.ApplicationContext;
import org.step.home_work.repositories.ProductsRepository;
import org.step.home_work.repositories.SalesRepository;
import org.step.home_work.repositories.SellersRepository;
import org.step.home_work.utils.Utils;

import javax.swing.*;

public class TablesController extends BaseController {

    //Репозитории
    SalesRepository salesRepository;
    ProductsRepository productsRepository;
    SellersRepository sellersRepository;

    public TablesController(ApplicationContext context) {
        super(context);

        salesRepository = context.getBean(SalesRepository.class);
        productsRepository = context.getBean(ProductsRepository.class);
        sellersRepository = context.getBean(SellersRepository.class);
    }

    @Override
    public void start() {
        try {

            //Вызов методов обработок
            while (true) {
                switch (showMenu()) {
                    case 0 -> Utils.showSales(salesRepository.findAll(),"");
                    case 1 -> Utils.showProducts(productsRepository.findAll());
                    case 2 -> Utils.showSellers(sellersRepository.findAll());

                    default -> {
                        return;
                    }
                }
            }
        } catch (Exception e) {
            Utils.showWindowButtons(e.getMessage() + "\n","Ошибка!",new Object[]{"Выход"},"", JOptionPane.ERROR_MESSAGE);

            System.out.printf("\n Упало исключение:\n%s\n",e.getMessage());
            System.out.println(e.getMessage() + "\n");
            e.printStackTrace();
        }
    }

    //Вывод меню
    public static int showMenu(){

        //Задание значений для окна
        String title = "Spring data";
        String message = "<html><h1>Выберите таблицу</h1>";
        Object[] buttons = new Object[]{
                "Продажи",
                "Товары",
                "Продавцы",
                "Выход"
        };


        return Utils.showWindowButtons(message,title,buttons,"Продажи", JOptionPane.DEFAULT_OPTION);
    }//showMenu

}
