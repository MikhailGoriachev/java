package org.step.home_work.models.entities.products;

import javax.persistence.*;

@Entity
@Table(name = "units")
public class Unit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "unit_name")
    private String unitName;

    public Unit() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUnitName() {
        return unitName;
    }

    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }

    public static String HEADER  = """
            <tr>
                <th>id</th>
                <th>Единица измерения</th>
            </tr>
            """;

    public String toTableRow(){
        return String.format("""
                <tr>
                    <td> %d </td>
                    <td> %s </td>
                </tr>
                """,id,unitName);
    }
}
