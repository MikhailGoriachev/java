CREATE DATABASE  IF NOT EXISTS `sales_account_wagner` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `sales_account_wagner`;
-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: sales_account_wagner
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `persons`
--

DROP TABLE IF EXISTS `persons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `persons` (
  `id` int NOT NULL AUTO_INCREMENT,
  `surname` varchar(50) NOT NULL,
  `name` varchar(60) NOT NULL,
  `patronymic` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `persons`
--

LOCK TABLES `persons` WRITE;
/*!40000 ALTER TABLE `persons` DISABLE KEYS */;
INSERT INTO `persons` VALUES (1,'Юрковский','Марк','Олегович'),(2,'Якубовская','Диана','Павловна'),(3,'Шапиро','Федор','Федорович'),(4,'Вожжаев','Сергей','Денисович'),(5,'Хроменко','Игорь','Владимирович'),(6,'Пелых','Марина','Ульяновна'),(7,'Лапотникова','Тамара','Оскаровна'),(8,'Огородников','Сергей','Иванович'),(9,'Яйло','Екатерина','Николаевна'),(10,'Бутусова','Инна','Александровна'),(11,'Вдыханько','Анна','Валентиновна'),(12,'Тарапата','Михаил','Исаакович'),(13,'Трубихин','Эдуард','Михайлович'),(14,'Чмыхало','Олег','Тарасович'),(15,'Швец','Степан','Сидорович'),(16,'Потемкина','Наталья','Павловна'),(17,'Гритченко','Степан','Романович'),(18,'Селиванов','Александр','Михайлович'),(19,'Любарская','Лариса','Ильинична'),(20,'Яструб','Владимир','Данилович'),(21,'Мелашенко','Александр','Алексеевич'),(22,'Пономаренко','Владислов','Дмитриевич'),(23,'Хавалджи','Любовь','Амировна'),(24,'Пархоменко','Ирина','Владимировна'),(25,'Демидова','Алина','Александровна');
/*!40000 ALTER TABLE `persons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_names`
--

DROP TABLE IF EXISTS `product_names`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_names` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(70) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_names`
--

LOCK TABLES `product_names` WRITE;
/*!40000 ALTER TABLE `product_names` DISABLE KEYS */;
INSERT INTO `product_names` VALUES (1,'чехол для Iphone 13 pro'),(2,'чехол для Iphone 14 '),(3,'чехол для samsung galaxy s22'),(4,'чехол для samsung galaxy s10 plus'),(5,'защитное стекло для Iphone 13 pro'),(6,'защитное стекло для samsung galaxy s22'),(7,'Подставка для ноутбука HIPER BRISA'),(8,'Подставка для ноутбука HIPER TYPHON'),(9,'samsung s22 ultra'),(10,'samsung s21 ultra'),(11,'samsung a53'),(12,'iPhone 13'),(13,'Xiaomi Mi 11 Ultra'),(14,'xiaomi mi 10 ultra'),(15,'Google Pixel 5');
/*!40000 ALTER TABLE `product_names` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name_id` int NOT NULL,
  `unit_id` int NOT NULL,
  `selling_price` int NOT NULL,
  `purchase_price` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_products_product_names_idx` (`name_id`),
  KEY `fk_products_units_idx` (`unit_id`),
  CONSTRAINT `fk_products_product_names` FOREIGN KEY (`name_id`) REFERENCES `product_names` (`id`),
  CONSTRAINT `fk_products_units` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,1,2,6000,3500),(2,1,1,500,250),(3,6,1,450,175),(4,6,2,11000,3500),(5,13,1,65000,44000),(6,12,1,79000,56000),(7,15,1,82000,35000),(8,8,1,1200,450),(9,7,1,950,425),(10,4,1,1600,1100),(11,8,2,6000,4500),(12,5,1,2000,950);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `seller_id` int NOT NULL,
  `products_amount` int NOT NULL,
  `sale_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_sales_products_idx` (`product_id`),
  KEY `fk_sales_sellers_idx` (`seller_id`),
  CONSTRAINT `fk_sales_products` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `fk_sales_sellers` FOREIGN KEY (`seller_id`) REFERENCES `sellers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (1,1,1,5,'2022-10-21'),(2,2,1,11,'2022-10-21'),(4,4,3,7,'2022-10-22'),(5,4,5,5,'2022-04-22'),(6,3,5,5,'2022-01-31'),(7,2,6,2,'2022-12-22'),(8,5,2,14,'2022-10-23'),(9,6,5,12,'2022-10-23'),(10,9,6,15,'2022-10-24'),(11,7,6,6,'2022-12-22'),(12,3,7,17,'2022-10-28'),(13,2,8,8,'2022-10-28'),(14,4,9,4,'2022-10-28'),(15,6,9,5,'2022-11-02'),(19,10,1,3,'2022-10-21'),(20,5,7,3,'2022-11-07');
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sellers`
--

DROP TABLE IF EXISTS `sellers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sellers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `person_id` int NOT NULL,
  `percent` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_sellers_persons_idx` (`person_id`),
  CONSTRAINT `fk_sellers_persons` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sellers`
--

LOCK TABLES `sellers` WRITE;
/*!40000 ALTER TABLE `sellers` DISABLE KEYS */;
INSERT INTO `sellers` VALUES (1,1,5),(2,2,3),(3,3,3.5),(4,4,3.2),(5,5,4.5),(6,6,4.5),(7,7,4),(8,8,3.5),(9,9,5.1),(10,10,4.5),(11,11,3.1),(12,12,6.2);
/*!40000 ALTER TABLE `sellers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `units`
--

DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `units` (
  `id` int NOT NULL AUTO_INCREMENT,
  `unit_name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `units`
--

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
INSERT INTO `units` VALUES (1,'шт'),(2,'ящ'),(3,'кг'),(4,'г');
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `view_products`
--

DROP TABLE IF EXISTS `view_products`;
/*!50001 DROP VIEW IF EXISTS `view_products`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_products` AS SELECT 
 1 AS `product_name`,
 1 AS `unit`,
 1 AS `purchase_price`,
 1 AS `selling_price`,
 1 AS `id`,
 1 AS `pn_id`,
 1 AS `unit_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_sales`
--

DROP TABLE IF EXISTS `view_sales`;
/*!50001 DROP VIEW IF EXISTS `view_sales`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_sales` AS SELECT 
 1 AS `id`,
 1 AS `product_id`,
 1 AS `product_name`,
 1 AS `unit_name`,
 1 AS `purchase_price`,
 1 AS `selling_price`,
 1 AS `seller_id`,
 1 AS `seller_surname`,
 1 AS `seller_name`,
 1 AS `seller_patronymic`,
 1 AS `percent`,
 1 AS `amount`,
 1 AS `date`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_sellers`
--

DROP TABLE IF EXISTS `view_sellers`;
/*!50001 DROP VIEW IF EXISTS `view_sellers`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_sellers` AS SELECT 
 1 AS `id`,
 1 AS `seller_name`,
 1 AS `seller_surname`,
 1 AS `seller_patronymic`,
 1 AS `percent`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `view_products`
--

/*!50001 DROP VIEW IF EXISTS `view_products`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_products` AS select `pn`.`name` AS `product_name`,`un`.`unit_name` AS `unit`,`products`.`purchase_price` AS `purchase_price`,`products`.`selling_price` AS `selling_price`,`products`.`id` AS `id`,`pn`.`id` AS `pn_id`,`un`.`id` AS `unit_id` from ((`products` join `product_names` `pn` on((`products`.`name_id` = `pn`.`id`))) join `units` `un` on((`products`.`unit_id` = `un`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_sales`
--

/*!50001 DROP VIEW IF EXISTS `view_sales`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_sales` AS select `sales`.`id` AS `id`,`sales`.`product_id` AS `product_id`,`product_names`.`name` AS `product_name`,`units`.`unit_name` AS `unit_name`,`products`.`purchase_price` AS `purchase_price`,`products`.`selling_price` AS `selling_price`,`sales`.`seller_id` AS `seller_id`,`persons`.`surname` AS `seller_surname`,`persons`.`name` AS `seller_name`,`persons`.`patronymic` AS `seller_patronymic`,`sellers`.`percent` AS `percent`,`sales`.`products_amount` AS `amount`,`sales`.`sale_date` AS `date` from ((`sales` join ((`products` join `product_names` on((`products`.`name_id` = `product_names`.`id`))) join `units` on((`products`.`unit_id` = `units`.`id`))) on((`sales`.`product_id` = `products`.`id`))) join (`sellers` join `persons` on((`sellers`.`person_id` = `persons`.`id`))) on((`sales`.`seller_id` = `sellers`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_sellers`
--

/*!50001 DROP VIEW IF EXISTS `view_sellers`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_sellers` AS select `sellers`.`id` AS `id`,`persons`.`name` AS `seller_name`,`persons`.`surname` AS `seller_surname`,`persons`.`patronymic` AS `seller_patronymic`,`sellers`.`percent` AS `percent` from (`sellers` join `persons` on((`sellers`.`person_id` = `persons`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-06 14:40:34
