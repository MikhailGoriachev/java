package org.homework.app.repositories;

import org.homework.app.entries.Purchase;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PurchasesRepository extends JpaRepository<Purchase, Long> {
}
