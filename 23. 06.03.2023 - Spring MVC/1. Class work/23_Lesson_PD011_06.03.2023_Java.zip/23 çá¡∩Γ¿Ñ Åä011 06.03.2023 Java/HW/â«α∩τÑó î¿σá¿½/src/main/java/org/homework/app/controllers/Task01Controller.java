package org.homework.app.controllers;

import org.homework.app.entries.*;
import org.homework.app.middleware.Repositories;
import org.homework.app.utils.Utils;

import javax.swing.*;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Date;


// Контроллер Задание 1
public class Task01Controller implements Runnable {

    public Task01Controller() throws Exception {
    }

    // работа по заданию
    public void run() {
        var buttons = new Object[]{
                "Данные",
//                "Запросы",
//                "CRUD",
                "Выход"
        };

        var initialValue = "Выход";
        var imageIcon = new ImageIcon();
        var title = "Задание 1. Учёт продаж";

        Runnable[] commands = new Runnable[]{
                // данные
                this::dataMenu,

//                // запросы
//                this::queriesMenu,
//
//                // CRUD
//                this::crudMenu
        };

        int select;
        while (true) {
            try {
                select = Utils.showWindow("<html><h1 align='center'>Задание 1. Учёт продаж</h1>", title, buttons, initialValue, imageIcon);

                if (select >= commands.length || select == -1)
                    return;

                commands[select].run();
            } catch (Exception exception) {
                Utils.showErrorMessage(exception.getMessage(), "Ошибка...");
            }
        }
    }

    // меню данных
    public void dataMenu() {
        var buttons = new Object[]{
                "Товары",
                "Персоны",
                "Закупки",
                "Продажи",
                "Единицы измерения",
                "Выход"
        };

        var initialValue = "Выход";
        var imageIcon = new ImageIcon();
        var title = "Задание 1. Учёт продаж > Данные";

        Runnable[] commands = new Runnable[]{

                // товары
                () -> sellers(title),
                
                // персоны
                () -> people(title),
                
                // закупки
                () -> purchases(title),
                
                // продажи
                () -> sales(title),
                
                // единицы измерения
                () -> units(title)
        };

        int select;
        while (true) {
            try {
                select = Utils.showWindow("<html><h1 align='center'>Задание 1. Учёт продаж > Данные</h1>", title, buttons, initialValue, imageIcon);

                if (select >= commands.length || select == -1)
                    return;

                commands[select].run();
            } catch (Exception exception) {
                Utils.showErrorMessage(exception.getMessage(), "Ошибка...");
            }
        }
    }

    // вывод таблицы товары
    public void goods(String startTitle) {
        
        var info = "Товары";

        var data = Repositories.getGoodsRepository().findAll();
        
        Utils.showWindow(Goods.toTableHtml(data, info),
                startTitle + " > " + info, 
                new Object[]{"Назад"}, 
                "Выход", 
                new ImageIcon()
        );
    }
    
    // вывод таблицы персоны
    public void people(String startTitle) {
        
        var info = "Персоны";

        var data = Repositories.getPeopleRepository().findAll();
        
        Utils.showWindow(Person.toTableHtml(data, info),
                startTitle + " > " + info, 
                new Object[]{"Назад"}, 
                "Выход", 
                new ImageIcon()
        );
    }
    
    // вывод таблицы закупки
    public void purchases(String startTitle) {
        
        var info = "Закупки";

        var data = Repositories.getPurchasesRepository().findAll();
        
        Utils.showWindow(Purchase.toTableHtml(data, info),
                startTitle + " > " + info, 
                new Object[]{"Назад"}, 
                "Выход", 
                new ImageIcon()
        );
    }
    
    // вывод таблицы продажи
    public void sales(String startTitle) {
        
        var info = "Продажи";

        var data = Repositories.getSalesRepository().findAll();
        
        Utils.showWindow(Sale.toTableHtml(data, info),
                startTitle + " > " + info, 
                new Object[]{"Назад"}, 
                "Выход", 
                new ImageIcon()
        );
    }
    
    // вывод таблицы продавцы
    public void sellers(String startTitle) {
        
        var info = "Продавцы";

        var data = Repositories.getSellersRepository().findAll();
        
        Utils.showWindow(Seller.toTableHtml(data, info),
                startTitle + " > " + info, 
                new Object[]{"Назад"}, 
                "Выход", 
                new ImageIcon()
        );
    }
    
    // вывод таблицы единицы измерения
    public void units(String startTitle) {
        
        var info = "Единицы измерения";

        var data = Repositories.getUnitsRepository().findAll();
        
        Utils.showWindow(Unit.toTableHtml(data, info),
                startTitle + " > " + info, 
                new Object[]{"Назад"}, 
                "Выход", 
                new ImageIcon()
        );
    }
    
//    
//    // запросы
//    public void queriesMenu() {
//        var buttons = new Object[]{
//                "Запрос 1",
//                "Запрос 2",
//                "Запрос 3",
//                "Запрос 4",
//                "Запрос 5",
//                "Запрос 6",
//                "Запрос 7",
//                "Выход"
//        };
//
//        var initialValue = "Выход";
//        var imageIcon = new ImageIcon();
//        var title = "Задание 1. Учёт продаж > Запросы";
//
//        IController[] commands = new IController[]{
//
//                // запрос 01
//                () -> query01(title),
//
//                // запрос 02
//                () -> query02(title),
//
//                // запрос 03
//                () -> query03(title),
//
//                // запрос 04
//                () -> query04(title),
//
//                // запрос 05
//                () -> query05(title),
//
//                // запрос 06
//                () -> query06(title),
//
//                // запрос 07
//                () -> query07(title),
//        };
//
//        int select;
//        while (true) {
//            try {
//                select = Utils.showWindow("<html><h1 align='center'>Задание 1. Учёт продаж > Запросы</h1>", title, buttons, initialValue, imageIcon);
//
//                if (select >= commands.length || select == -1)
//                    return;
//
//                commands[select].run();
//            } catch (Exception exception) {
//                Utils.showErrorMessage(exception.getMessage(), "Ошибка...");
//            }
//        }
//    }
//
//    // CRUD
//    public void crudMenu() {
//        var buttons = new Object[]{
//                "Изменение врача",
//                "Изменение пациента",
//                "Изменение приёма",
//                "Выход"
//        };
//
//        var initialValue = "Выход";
//        var imageIcon = new ImageIcon();
//        var title = "Задание 1. Учёт продаж > CRUD";
//
//        IController[] commands = new IController[]{
//
//                // изменение врача
//                () -> editDoctor(title),
//
//                // изменение пациента
//                () -> editPatient(title),
//
//                // изменение приёма
//                () -> editAppointment(title),
//        };
//
//        int select;
//        while (true) {
//            try {
//                select = Utils.showWindow("<html><h1 align='center'>Задание 1. Учёт продаж > CRUD</h1>", title, buttons, initialValue, imageIcon);
//
//                if (select >= commands.length || select == -1)
//                    return;
//
//                commands[select].run();
//            } catch (Exception exception) {
//                Utils.showErrorMessage(exception.getMessage(), "Ошибка...");
//            }
//        }
//    }
//
//    // 1	Запрос с параметрами	Выбирает информацию о пациентах с фамилиями, начинающимися на заданную
//    //                              последовательность символов
//    public void query01(String startTitle) throws Exception {
//
//        var surname = Utils
//                .getItem(polyclinic.patients())
//                .surname
//                .substring(0, 3);
//
//        var info = "Выбирает информацию о пациентах с фамилиями, начинающимися на \"" + surname + "\"";
//
//        Utils.showWindow(polyclinic.patientsToTable(polyclinic.query01(surname), info),
//                startTitle + " > Запрос 1", new Object[]{"Назад"}, "Выход", new ImageIcon());
//    }
//
//    // 2	Запрос с параметрами	Выбирает информацию о врачах, для которых значение в поле Процент отчисления
//    //                              на зарплату, больше заданного
//    public void query02(String startTitle) throws Exception {
//
//        var percent = (int) (Utils.getItem(polyclinic.doctors()).percent / 1.2);
//
//        var info = "Выбирает информацию о врачах, для которых процент отчисления больше " + percent + "%";
//
//        Utils.showWindow(polyclinic.doctorsToTable(polyclinic.query02(percent), info),
//                startTitle + " > Запрос 2", new Object[]{"Назад"}, "Выход", new ImageIcon());
//    }
//
//    // 3	Запрос с параметрами	Выбирает информацию о приемах за некоторый период
//    public void query03(String startTitle) throws Exception {
//
//        var appointment = Utils.getItem(polyclinic.appointments());
//
//        var date = new Date(appointment.appointmentDate.getTime());
//
//        date.setDate(date.getDate() - 3);
//        var begin = new Date(date.getTime());
//
//        date.setDate(date.getDate() + 6);
//        var end = new Date(date.getTime());
//
//        var info = String.format("Выбирает информацию о приёмах от %1$td.%1$tm.%1$tY до %2$td.%2$tm.%2$tY",
//                begin, end);
//
//        Utils.showWindow(polyclinic.appointmentsToTable(polyclinic.query03(begin, end), info),
//                startTitle + " > Запрос 3", new Object[]{"Назад"}, "Выход", new ImageIcon());
//    }
//
//    // 4	Запрос с параметрами	Выбирает из таблицы информацию о врачах с заданной специальностью
//    public void query04(String startTitle) throws Exception {
//
//        var speciality = Utils
//                .getItem(polyclinic.doctors())
//                .specialityName;
//
//        var info = "Выбирает из таблицы информацию о врачах со специальностью \"" + speciality + "\"";
//
//        Utils.showWindow(polyclinic.doctorsToTable(polyclinic.query04(speciality), info),
//                startTitle + " > Запрос 4", new Object[]{"Назад"}, "Выход", new ImageIcon());
//    }
//
//    // 5	Запрос с вычисляемыми полями	Вычисляет размер заработной платы врача за каждый прием. Включает поля
//    //                                      Фамилия врача, Имя врача, Отчество врача, Специальность врача, Стоимость
//    //                                      приема, Зарплата. Сортировка по полю Специальность врача
//    public void query05(String startTitle) throws SQLException {
//
//        var info = "Вычисляет размер заработной платы врача для каждого приёма";
//
//        Utils.showWindow(polyclinic.query05ToTable(polyclinic.query05(), info),
//                startTitle + " > Запрос 5", new Object[]{"Назад"}, "Выход", new ImageIcon());
//    }
//
//    // 6	Итоговый запрос     Выполняет группировку по полю Дата приема. Для каждой даты вычисляет
//    //                          максимальную стоимость приема
//    public void query06(String startTitle) throws Exception {
//
//        var info = "Вычисляет для каждой даты приёма статистику стоимости";
//
//        Utils.showWindow(polyclinic.query06ToTable(polyclinic.query06(), info),
//                startTitle + " > Запрос 6", new Object[]{"Назад"}, "Выход", new ImageIcon());
//    }
//
//    // 7	Итоговый запрос	    Выполняет группировку по полю Специальность. Для каждой специальности вычисляет средний
//    //                          Процент отчисления на зарплату от стоимости приема
//    public void query07(String startTitle) throws Exception {
//
//        var info = "Вычисляет для специальности статистику процента на зарплату врача";
//
//        Utils.showWindow(polyclinic.query07ToTable(polyclinic.query07(), info),
//                startTitle + " > Запрос 7", new Object[]{"Назад"}, "Выход", new ImageIcon());
//    }
//
//
//    // изменение врача
//    public void editDoctor(String startTitle) throws Exception {
//
//        var doctor = Utils.getItem(polyclinic.doctors());
//
//        var info = "Изменение врача (увеличение платы за прием, процента отчислений). Id: " + doctor.id +
//                   ". Прошлые данные (Плата: " + doctor.price +
//                   ", процент отчисления: " + doctor.percent + "%)";
//
//        doctor.percent = Utils.getInt(5, 10);
//        doctor.price = Utils.getInt(1, 4) * 100;
//
//        new DoctorDaoImpl().update(doctor);
//
//        Utils.showWindow(polyclinic.doctorsToTable(polyclinic.doctors(), info),
//                startTitle + " > Изменение врача", new Object[]{"Назад"}, "Выход", new ImageIcon());
//    }
//
//    // изменение пациента
//    public void editPatient(String startTitle) throws Exception {
//
//        var patient = Utils.getItem(polyclinic.patients());
//
//        var info = "Изменение пациента (изменение фамилии). Id: " + patient.id +
//                   ". Прошлые данные (Фамилия: " + patient.surname + ")";
//
//        patient.personId = Utils.getItem(polyclinic.people()).id();
//
//        new PatientDaoImpl().update(patient);
//
//        Utils.showWindow(polyclinic.patientsToTable(polyclinic.patients(), info),
//                startTitle + " > Изменение пациента", new Object[]{"Назад"}, "Выход", new ImageIcon());
//    }
//
//    // изменение приёма
//    public void editAppointment(String startTitle) throws Exception {
//
//        var appointment = Utils.getItem(polyclinic.appointments());
//
//        var info = "Изменение приёма (изменение даты приема). Id: " + appointment.id +
//                   String.format(". Прошлые данные (Даты приема: %1$td.%1$tm.%1$tY)", appointment.appointmentDate);
//        
//        appointment.appointmentDate.setDate(appointment.appointmentDate.getDate() + 3);
//
//        new AppointmentDaoImpl().update(appointment);
//
//        Utils.showWindow(polyclinic.appointmentsToTable(polyclinic.appointments(), info),
//                startTitle + " > Изменение приёма", new Object[]{"Назад"}, "Выход", new ImageIcon());
//    }
}