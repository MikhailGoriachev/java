package org.homework.app.repositories;

import org.homework.app.entries.Seller;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SellersRepository extends JpaRepository<Seller, Long> {
}
