package org.itstep.pd011.controllers;

import org.itstep.pd011.infrastructure.Utils;
import org.itstep.pd011.models.task3.GenericArray;

import java.util.function.Predicate;

/*
 * Задача 3. Обобщенные классы. Анонимные классы.
 * Разработайте обобщенный класс для обработки массивов. Протестируйте этот
 * класс на числах типа int, double (используйте ссылочные типы-обертки).
 * Требуется выполнение следующих функций:
 *     • Формирование массива из n случайных чисел в диапазоне от -20 до 20;
 *     • Определение максимального по модулю элемента массива;
 *     • Вычисление суммы положительных элементов массива;
 *     • Упорядочивание массива по убыванию модулей элементов, компаратор
 *       реализовать анонимным классом
 *     • Упорядочивание массива по возрастанию модулей элементов, компаратор
 *       реализовать анонимным классом
 * */
public class Task3Controller {
    // массивы данных для обработки
    private GenericArray<Integer> intArr;
    private GenericArray<Double> dblArr;

    public Task3Controller() {
        this(
            Utils.create(Utils.getRandom(12, 20), -20, 20),
            Utils.create(Utils.getRandom(12, 20), -20., 20.)
        );
    } // Task3Controller

    public Task3Controller(Integer data1[], Double[] data2) {
        intArr = new GenericArray<>(data1);
        dblArr = new GenericArray<>(data2);
    } // Task3Controlller

    // установка массивов данных
    public void initialize() {
        intArr.setData(Utils.create(Utils.getRandom(12, 20), -20, 20));
        dblArr.setData(Utils.create(Utils.getRandom(12, 20), -20., 20.));
    } // initialize

    // region предикаты для вывода исходных и упорядоченных массивов - выделяем 0
    private Predicate<Integer> intPredicate = new Predicate<Integer>() {
        @Override
        public boolean test(Integer datum) {
            return datum == 0;
        } // test
    };

    private Predicate<Double> dblPredicate = new Predicate<Double>() {
        @Override
        public boolean test(Double aDouble) {
            return aDouble == 0;
        } // test
    };
    // endregion

    // собственно выполнение задачи
    public void run() {
        System.out.println("\nЗадача 3. Обобщенные классы, анонимные классы");

        // вывести исходные массивы, выделяем цветом положительные элементы массива и элементы, равные 0
        show();

        // определение максимального по модулю элемента массива целых чисел
        maxIntAbs();

        // вычисление и вывод суммы положительных элементов массива целых чисел
        intSumPositives();

        // определение максимального по модулю элемента массива вещественных чисел
        maxDblAbs();

        // вычисление суммы положительных элементов массива вещественных чисел
        dblSumPositives();

        // упорядочивание массивов по убыванию модулей элементов массива;
        intOrderByAbsDesc();
        dblOrderByAbsDesc();

        // упорядочивание массивов по возрастанию модулей элементов массива;
        intOrderByAbs();
        dblOrderByAbs();
    } // run


    // вывести исходные массивы, выделяем цветом положительные элементы массива и элементы, равные 0
    public void show() {
        System.out.println(Utils.arrayToString(intArr.getData(),
                "\nМассив целых чисел для обработки:\n", intPredicate));
        System.out.println(Utils.arrayToString(dblArr.getData(),
                "\n\nМассив вещественных чисел для обработки:\n", dblPredicate));
    } // show

    // определение максимального по модулю элемента массива целых чисел
    public void maxIntAbs() {
        int imax = intArr.getIndexMaxAbs();
        int absMaxInt = Math.abs(intArr.getData()[imax]);
        // вывод с выделением цветом положительных элементов массива и максимальных по модулю
        System.out.println(Utils.arrayToString(intArr.getData(),
                "\n\nВ массиве целых чисел выделены положительные и максимальные по модулю элементы:\n",
                new Predicate<Integer>() {
                    @Override
                    public boolean test(Integer datum) {
                        return Math.abs(datum) == absMaxInt;
                    } // test
                })
        );
    } // maxIntAbs


    // определение максимального по модулю элемента
    public void maxDblAbs() {
        int imax = dblArr.getIndexMaxAbs();
        double absMaxDbl = Math.abs(dblArr.getData()[imax]);
        System.out.println(Utils.arrayToString(dblArr.getData(),
                "\n\nВ массиве вещественных чисел выделены положительные и максимальные по модулю элементы:\n",
                new Predicate<Double>() {
                    @Override
                    public boolean test(Double aDouble) {
                        return Math.abs(aDouble) == absMaxDbl;
                    } // test
                })
        );
    } // maxDblAbs

    // вычисление и вывод суммы положительных в массиве целых чисел
    public void intSumPositives() {
        int sumInt = (int) intArr.calcSumPositive();
        System.out.printf("Сумма положительных элементов массива: %d\n", sumInt);
    } // intSumPositives

    // вычисление и вывод суммы положительных в массиве вещественных чисел
    public void dblSumPositives() {
        double sumDbl = dblArr.calcSumPositive();
        System.out.printf("Сумма положительных элементов массива: %.2f\n", sumDbl);
    } // dblSumPositives

    // упорядочивание массива целых чисел по убыванию модулей элементов массива
    public void intOrderByAbsDesc() {
        intArr.orderByAbsDesc();
        System.out.println(Utils.arrayToString(intArr.getData(),
                "\nМассив целых чисел по убыванию модулей элементов:\n", intPredicate));
    } // intOrderByAbsDesc

    // упорядочивание массива вещественных чисел по убыванию модулей элементов массива
    public void dblOrderByAbsDesc() {
        dblArr.orderByAbsDesc();
        System.out.println(Utils.arrayToString(dblArr.getData(),
                "\n\nМассив вещественных чисел по убыванию модулей элементов:\n", dblPredicate));
    } // dblOrderByAbsDesc()

    // упорядочивание массива целых чисел по возрастанию модулей элементов массива
    public void intOrderByAbs() {
        intArr.orderByAbs();
        System.out.println(Utils.arrayToString(intArr.getData(),
                "\nМассив целых чисел по убыванию модулей элементов:\n", intPredicate));
    } // intOrderByAbs

    // упорядочивание массива вещественных чисел по возрастанию модулей элементов массива
    public void dblOrderByAbs() {
        dblArr.orderByAbs();
        System.out.println(Utils.arrayToString(dblArr.getData(),
                "\n\nМассив вещественных чисел по убыванию модулей элементов:\n", dblPredicate));
    } // dblOrderByAbs()
} // class Task3Controller
