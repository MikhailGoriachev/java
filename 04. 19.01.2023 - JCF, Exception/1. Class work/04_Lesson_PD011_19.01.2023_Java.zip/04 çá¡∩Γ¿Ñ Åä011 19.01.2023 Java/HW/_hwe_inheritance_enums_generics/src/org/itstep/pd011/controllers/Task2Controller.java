package org.itstep.pd011.controllers;

import org.itstep.pd011.models.task2.RectangularEnum;

import java.util.Locale;

/*
 * Задача 2. Перечисления.
 * Разработайте перечисление, задающее виды четырехугольников (прямоугольник,
 * квадрат, ромб и прямоугольная трапеция).
 * Числовые значения для элементов перечислений:
 *     • Прямоугольник: 7000
 *     • Квадрат: 1705
 *     • Ромб: 1425
 *     • Прямоугольная трапеция: 1210
 * В перечислении реализуйте методы расчета периметра и площади
 * четырехугольников с учетом их специфики. Переопределите также метод
 * toString() перечисления для вывода названий четырехугольников на
 * русском языке. Продемонстрируйте работу методов перечисления.
 * */
public class Task2Controller {
    public void run() {
        System.out.println("Задача 2. Перечисления");
        RectangularEnum rect;

        // присвоить значение ПРЯМОУГОЛЬНИК перечислению
        rect = RectangularEnum.RECTANGLE;
        double a = 10, b = 2;
        double p = rect.perimeter(a, b);
        double s = rect.area(a, b);
        System.out.printf(Locale.UK,
                "Фигура: \033[34;1m%s\033[0m, значение константы %d. Размеры %.3f x %.3f. Периметр %.3f и площадь %.3f\n",
                rect, rect.getValue(), a, b, p, s);

        // присвоить значение КВАДРАТ перечислению
        rect = RectangularEnum.SQUARE;
        a = 10;
        p = rect.perimeter(a);
        s = rect.area(a);
        System.out.printf(Locale.UK,
                "Фигура: \033[34;1m%s\033[0m, значение константы %d. Размеры %.3f x %.3f. Периметр %.3f и площадь %.3f\n",
                rect, rect.getValue(), a, a, p, s);

        // присвоить значение РОМБ перечислению
        rect = RectangularEnum.RHOMBUS;
        a = 10;
        double angle = Math.toRadians(45);
        p = rect.perimeter(a);
        s = rect.area(a, angle);
        System.out.printf(Locale.UK,
                "Фигура: \033[34;1m%s\033[0m, значение константы %d. Сторона %.3f, угол %.3f. Периметр %.3f и площадь %.3f\n",
                rect, rect.getValue(), a, Math.toDegrees(angle), p, s);

        // присвоить значение ПРЯМОУГОЛЬНАЯ ТРАПЕЦИЯ перечислению
        rect = RectangularEnum.TRAPEZIUM;
        a = 10;
        b = 20;
        double h = 5;
        p = rect.perimeter(a, b, h);
        s = rect.area(a, b, h);
        System.out.printf(Locale.UK,
                "Фигура: \033[34;1m%s\033[0m, значение константы %d. Размеры %.3f x %.3f x %.3f. Периметр %.3f и площадь %.3f\n",
                rect, rect.getValue(), a, b, h, p, s);

    } // run
} // class Task2Controller
