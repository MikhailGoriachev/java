package org.itstep.pd011.models.task2;

/*
 * Разработайте перечисление, задающее виды четырехугольников (прямоугольник,
 * квадрат, ромб и прямоугольная трапеция).
 * Числовые значения для элементов перечислений:
 *     • Прямоугольник: 7000
 *     • Квадрат: 1705
 *     • Ромб: 1425
 *     • Прямоугольная трапеция: 1210
 * В перечислении реализуйте методы расчета периметра и площади
 * четырехугольников с учетом их специфики. Переопределите также метод
 * toString() перечисления для вывода названий четырехугольников на
 * русском языке.
* */
public enum RectangularEnum {
    // при задании значений перечисления происходит
    // неявный вызов конструктора перечисления
    RECTANGLE(7000),
    SQUARE(1705),
    RHOMBUS(1425),
    TRAPEZIUM(1210);

    // конструктор перечисления - задает значения вспомогательных
    // (дополнительных) полей
    RectangularEnum(int value) {
        this.value = value;
    } // RectangularEnum

    // вспомогательных/дополнительное поле для значений перечисления
    private final int value;
    public int getValue() { return value; }

    // метод вычисления периметра
    // применяем переменное число параметров (у разных фигур - разное количество сторон
    public double perimeter(double... sides) {
        // получить текущее значение перечисления (this)
        return switch (this) {
            case RECTANGLE   -> 2* (sides[0] + sides[1]);
            case SQUARE -> 4. * sides[0];
            case RHOMBUS   -> 4. * sides[0];
            case TRAPEZIUM   -> sides[0] + sides[1] + sides[2] + Math.sqrt(Math.pow(sides[0] - sides[1], 2) + sides[2]*sides[2]);
            default     -> 0;
        };
    } // perimete

    // метод вычисления площади
    // применяем переменное число параметров (у разных фигур - разное количество сторон
    public double area(double... sides) {
        // получить текущее значение перечисления (this)
        return switch (this) {
            case RECTANGLE   -> sides[0] * sides[1];
            case SQUARE -> sides[0] * sides[0];
            // для ромба вторым параметром будем передавать угол между сторонами
            case RHOMBUS   -> sides[0] * sides[0] * Math.sin(sides[1]);
            case TRAPEZIUM   -> 0.5*(sides[0] + sides[1]) * sides[2];
            default     -> 0;
        };
    } // area

    // переопределение toString() - повышаем удобство вывода
    // один из немногих методов с override в перечислении
    @Override public String toString() {

        return switch (this) {
            case RECTANGLE   -> "прямоугольник";
            case SQUARE   -> "квадрат";
            case RHOMBUS -> "ромб";
            case TRAPEZIUM -> "прямоугольная трапеция";
            default     -> "нет данных";
        };
    } // toString
} // enum RectangularEnum
