package org.itstep.pd011.models.task1;

// базовый класс иерархии классов для представления транспортных средств
abstract public class Vehicle {
}
