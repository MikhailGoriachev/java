package org.itstep.pd011.models.task3;

import java.util.Arrays;
import java.util.Comparator;

/*
 * Задача 3.
 * Разработайте обобщенный класс для обработки массивов.
 * Требуется выполнение следующих функций:
 *     • определение максимального по модулю элемента массива;
 *     • вычисление суммы положительных элементов массива;
 *     • Упорядочивание массива по убыванию модулей элементов, компаратор
 *       реализовать анонимным классом
 *     • Упорядочивание массива по возрастанию модулей элементов, компаратор
 *       реализовать анонимным классом
 * */
public class GenericArray <T extends Number & Comparable<T>> {
    // данные для обработки
    private T[] data;

    public GenericArray(T[] data) {
        this.data = data;
    } // GenericArray

    // геттер и сеттер для массива данных
    public T[] getData() { return data; }
    public void setData(T[] data) { this.data = data; }

    // определение максимального по модулю элемента массива
    public int getIndexMaxAbs() {
        int iMaxAbs = 0;
        double maxAbs = Math.abs(data[0].doubleValue());

        for (int i = 0; i < data.length; i++) {
            double temp = Math.abs(data[i].doubleValue());
            if (temp > maxAbs) {
                iMaxAbs = i;
                maxAbs = temp;
            } // if
        } // for i

        return iMaxAbs;
    } // getIndexMaxAbs

    // вычисление суммы положительных элементов массива
    public double calcSumPositive() {
        double sum = 0;

        for (T datum : data) {
            double temp = datum.doubleValue();
            if (temp > 0)
                sum += temp;
        } // for datum

        return sum;
    } // calcSumPositive

    // упорядочивание массива по убыванию модулей элементов массива
    public void orderByAbsDesc() {
        Arrays.sort(data, new Comparator<T>() {
            @Override
            public int compare(T datum1, T datum2) {
                Double d1 = Math.abs(datum1.doubleValue());
                Double d2 = Math.abs(datum2.doubleValue());
                return d2.compareTo(d1);
            } // compare
        });
    } // orderByAbsDesc

    // упорядочивание массива по возрастанию модулей элементов массива
    public void orderByAbs() {
        Arrays.sort(data, new Comparator<T>() {
            @Override
            public int compare(T datum1, T datum2) {
                Double d1 = Math.abs(datum1.doubleValue());
                Double d2 = Math.abs(datum2.doubleValue());
                return d1.compareTo(d2);
            } // compare
        });
    } // orderByAbs

} // class GenericArray
