package org.itstep.pd011.infrastructure;

import java.security.InvalidParameterException;
import java.util.Random;
import java.util.function.Predicate;

public class Utils {
    private static final Random random = new Random();

    // формирование случайных чисел типа int
    public static int getRandom(int lo, int hi) {
        return lo + random.nextInt(hi - lo);
    }  // getRandom

    // формирование случайных чисел типа double
    public static double getRandom(double lo, double hi) {
        return lo + (hi - lo)*random.nextDouble();
    }  // getRandom

    // заполнение массива целых чисел
    public static void fill(Integer[] data, int lo, int hi) {
        for (int i = 0; i < data.length; i++) {
            int temp = getRandom(lo, hi);
            if (Math.abs(temp) <= 5) temp = 0;
            data[i] = temp;
        } // for i
    } // fill

    // создание и заполнение массива целых чисел - класс оболочка Integer
    public static Integer[] create(int n, int lo, int hi) {
        if (n <= 0)
            throw new InvalidParameterException("Отрицательный размер массива");
        Integer[] data = new Integer[n];

        fill(data, lo, hi);
        return data;
    } // create


    // создание и заполнение массива вещественных чисел - класс оболочка Double
    public static Double[] create(int n, double lo, double hi) {
        if (n <= 0)
            throw new InvalidParameterException("Отрицательный размер массива");
        Double[] data = new Double[n];

        fill(data, lo, hi);
        return data;
    } // create

    // заполнение массива вещественных чисел
    public static void fill(Double[] data, double lo, double hi) {

        // заполнение массива
        for (int i = 0; i < data.length; i++) {
            // генерация данных с формированием 0
            double temp = getRandom(lo, hi);
            if (Math.abs(temp) <= 5) temp = 0;
            data[i] = temp;
        } // for i
    } // fill

    // вывод массива в строку, выделяем цветом положительные элементы массива,
    // элементы массива, равные заданному предикатом
    public static String arrayToString(Integer[] arr, String title, Predicate<Integer> predicate) {
        StringBuilder sbr = new StringBuilder(title);

        for (int i = 0; i < arr.length; i++) {
            Integer t = arr[i];
            sbr.append(String.format(" %s  %5d  \033[0m", (predicate.test(t)?"\033[1;34m":t > 0?"\033[1;31m":""), t));
            if ((i+1) % 10 == 0) sbr.append("\n");
        } // for i
        if (arr.length % 10 != 0) sbr.append("\n");

        return sbr.toString();
    } // arrayToString


    // вывод массива в строку, выделяем цветом положительные элементы массива,
    // элементы массива, равные заданному предикатом
    public static String arrayToString(Double[] arr, String title, Predicate<Double> predicate) {
        StringBuilder sbr = new StringBuilder(title);

        for (int i = 0; i < arr.length; i++) {
            double t = arr[i];
            sbr.append(String.format(" %s  %8.2f \033[0m", (predicate.test(t)?"\033[1;34m":t > 0?"\033[1;31m":""), t));
            if ((i+1) % 10 == 0) sbr.append("\n");
        } // for i
        if (arr.length % 10 != 0) sbr.append("\n");

        return sbr.toString();
    } // arrayToString

} // class Utils
