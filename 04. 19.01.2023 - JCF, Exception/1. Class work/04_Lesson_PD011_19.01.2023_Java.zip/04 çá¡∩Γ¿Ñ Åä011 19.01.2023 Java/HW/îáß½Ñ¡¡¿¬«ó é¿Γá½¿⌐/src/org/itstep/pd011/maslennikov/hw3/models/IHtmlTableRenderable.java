package org.itstep.pd011.maslennikov.hw3.models;

public interface IHtmlTableRenderable {
    String toHtmlTableRow(int n);
}
