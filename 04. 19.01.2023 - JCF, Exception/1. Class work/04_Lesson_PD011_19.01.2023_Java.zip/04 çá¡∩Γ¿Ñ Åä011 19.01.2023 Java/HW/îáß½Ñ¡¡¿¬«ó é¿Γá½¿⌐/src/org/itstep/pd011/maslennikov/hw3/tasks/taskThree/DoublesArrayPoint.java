package org.itstep.pd011.maslennikov.hw3.tasks.taskThree;

import org.itstep.pd011.maslennikov.hw3.models.IHtmlTableRenderable;
import org.itstep.pd011.maslennikov.hw3.models.task3.NumbersArray;
import org.itstep.pd011.maslennikov.hw3.services.HtmlTableFormatter;
import org.itstep.pd011.maslennikov.hw3.utils.Utils;

import static org.itstep.pd011.maslennikov.hw3.services.HtmlTableFormatter.*;
import static org.itstep.pd011.maslennikov.hw3.services.HtmlTableFormatter.cell;

public class DoublesArrayPoint {
    private static final NumbersArray<Double> arrayDouble = new NumbersArray<>(Double.class, 10);

    private static final HtmlTableFormatter tableFormatter = new HtmlTableFormatter(
            headerCell("Вещественный массив", arrayDouble.length())
    );


    public static void run() {
        String message = generate();

        while (message != null) {
            message = switch (showMenu(message)) {
                case 0 -> generate();
                case 1 -> orderedByAbs();
                case 2 -> orderedByAbsDesc();
                default -> null;
            };
        }
    }

    public static String generate() {
        arrayDouble.initialize(-20., 20.);

        IHtmlTableRenderable[] rows = new IHtmlTableRenderable[]{
                arrayDouble,
                n -> row(
                        cell("Масимальное по модулю:", "left", arrayDouble.length() / 2),
                        cell(arrayDouble.maxAbs(), "right", 2, arrayDouble.length() / 2)
                ),
                n -> row(
                        cell("Сумма положительных элементов", "left", arrayDouble.length() / 2),
                        cell(arrayDouble.positivesSum(), "right", 2, arrayDouble.length() / 2)
                )
        };

        return tableFormatter.table(rows, "Данные для типа Double:");
    }

    public static String orderedByAbs() {
        IHtmlTableRenderable[] rows = new IHtmlTableRenderable[]{
                arrayDouble.orderByAbs(),
        };

        return tableFormatter.table(rows, "Упорядочено по возрастанию модулей:");
    }

    public static String orderedByAbsDesc() {
        IHtmlTableRenderable[] rows = new IHtmlTableRenderable[]{
                arrayDouble.orderByAbsDesc(),
        };

        return tableFormatter.table(rows, "Упорядочено по убыванию модулей:");
    }

    private static int showMenu(String content) {
        return Utils.showMenu(content,
                "Задача 2",
                new String[]{"Сгенерировать", "По возрастанию модулей", "По убыванию модулей", "Назад"},
                "Выход");
    }
}
