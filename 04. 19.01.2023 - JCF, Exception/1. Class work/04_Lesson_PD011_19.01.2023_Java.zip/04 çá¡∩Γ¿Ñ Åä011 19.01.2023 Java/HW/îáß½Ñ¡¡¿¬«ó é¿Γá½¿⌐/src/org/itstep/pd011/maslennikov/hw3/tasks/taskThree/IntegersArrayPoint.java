package org.itstep.pd011.maslennikov.hw3.tasks.taskThree;

import org.itstep.pd011.maslennikov.hw3.models.IHtmlTableRenderable;
import org.itstep.pd011.maslennikov.hw3.models.task3.NumbersArray;
import org.itstep.pd011.maslennikov.hw3.services.HtmlTableFormatter;
import org.itstep.pd011.maslennikov.hw3.utils.Utils;

import static org.itstep.pd011.maslennikov.hw3.services.HtmlTableFormatter.*;
import static org.itstep.pd011.maslennikov.hw3.services.HtmlTableFormatter.cell;

public class IntegersArrayPoint {
    private static final NumbersArray<Integer> arrayInteger = new NumbersArray<>(Integer.class, 10);

    private static final HtmlTableFormatter tableFormatter = new HtmlTableFormatter(
            headerCell("Целочисленный массив", arrayInteger.length())
    );

    public static void run(){
        String message = generate();

        while(message != null) {
            message = switch (showMenu(message)) {
                case 0 -> generate();
                case 1 -> orderedByAbs();
                case 2 -> orderedByAbsDesc();
                default -> null;
            };
        }
    }

    public static String generate() {
        arrayInteger.initialize(-20, 20);

        IHtmlTableRenderable[] rows = new IHtmlTableRenderable[] {
                arrayInteger,
                n -> row(
                        cell("Масимальное по модулю:", "right", arrayInteger.length() / 2),
                        cell(arrayInteger.maxAbs(), "right", arrayInteger.length() / 2)
                ),
                n -> row(
                        cell("Сумма положительных элементов:", "right", arrayInteger.length() / 2),
                        cell(arrayInteger.positivesSum(), "right", arrayInteger.length() / 2)
                )
        };

        return tableFormatter.table(rows, "Данные для типа Integer:");
    }

    public static String orderedByAbs() {
        IHtmlTableRenderable[] rows = new IHtmlTableRenderable[] {
                arrayInteger.orderByAbs(),
        };

        return tableFormatter.table(rows, "Упорядочено по возрастанию модулей:");
    }

    public static String orderedByAbsDesc() {
        IHtmlTableRenderable[] rows = new IHtmlTableRenderable[] {
                arrayInteger.orderByAbsDesc(),
        };

        return tableFormatter.table(rows, "Упорядочено по убыванию модулей:");
    }

    private static int showMenu(String content) {
        return Utils.showMenu(content,
                "Задача 2",
                new String[]{"Сгенерировать", "По возрастанию модулей", "По убыванию модулей", "Назад"},
                "Выход");
    }
}
