package org.itstep.pd011.maslennikov.hw3.models.task1;

import org.itstep.pd011.maslennikov.hw3.models.IHtmlTableRenderable;
import static org.itstep.pd011.maslennikov.hw3.services.HtmlTableFormatter.*;

import java.awt.geom.Point2D;
import java.security.InvalidParameterException;

public class Ship extends Vehicle implements IHtmlTableRenderable {
    // количество пассажиров
    private int pax;

    // порт приписки
    private String homePort;

    public Ship(Point2D.Double coordinates, String category, int price, int velocity, int year, int pax, String homePort) {
        super(coordinates, category, price, velocity, year);
        this.pax = pax;
        this.homePort = homePort;
    }

    public Ship(double longitude, double latitude, String category, int price, int velocity, int year, int pax, String homePort) {
        super(longitude, latitude, category, price, velocity, year);
        this.pax = pax;
        this.homePort = homePort;
    }

    public int getPax() {
        return pax;
    }

    public void setPax(int pax) {
        if (pax < 0)
            throw new InvalidParameterException("Недопустимое количества пассажиров");

        this.pax = pax;
    }

    public String getHomePort() {
        return homePort;
    }

    public void setHomePort(String homePort) {
        if(homePort.isBlank())
            throw new InvalidParameterException("Не задано название порта приписки");

        this.homePort = homePort;
    }

    @Override
    public String toHtmlTableRow(int rowNum) {
        return row(
                cell(rowNum, "center"),
                cell(category, "left"),
                cell(String.format("%.2f;%.2f", coordinates.x, coordinates.y), "center"),
                cell(price, "right"),
                cell(velocity, "right"),
                cell(year, "right"),
                cell(pax, "right"),
                cell(homePort, "left")
        );
    }
}
