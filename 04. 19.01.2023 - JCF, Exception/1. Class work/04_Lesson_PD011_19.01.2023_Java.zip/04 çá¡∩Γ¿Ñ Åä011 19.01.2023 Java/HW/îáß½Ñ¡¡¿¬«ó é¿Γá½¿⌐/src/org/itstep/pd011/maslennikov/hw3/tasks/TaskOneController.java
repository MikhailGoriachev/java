package org.itstep.pd011.maslennikov.hw3.tasks;

import org.itstep.pd011.maslennikov.hw3.models.task1.VehiclesArray;
import org.itstep.pd011.maslennikov.hw3.utils.Utils;
public class TaskOneController {

    private static VehiclesArray vehiclesArray;

    public static void run() {

        vehiclesArray = new VehiclesArray();

        String message = vehiclesArray.toHtmlTable("Транспортные средства");

        while(message != null) {
            message = switch (showMenu(message)) {
                case 0 -> sourceData();
                case 1 -> oldestVehicles();
                case 2 -> slowestVehicles();
                case 3 -> fastestVehicles();
                default -> null;
            };
        }
    }

    private static String sourceData() {
        return vehiclesArray.toHtmlTable("Транспортные средства");
    }

    private static String oldestVehicles() {
        return vehiclesArray.oldest().toHtmlTable("Самые старые т/с");
    }

    private static String slowestVehicles() {
        return vehiclesArray.slowest().toHtmlTable("Самые медленные т/с");
    }

    private static String fastestVehicles() {
        return vehiclesArray.fastest().toHtmlTable("Самые быстрые т/с");
    }

    private static int showMenu(String content) {
        return Utils.showMenu(
                content,
                "Задача 1",
                new String[]{"Исходные", "Самые старые т/с", "Самые медленные т/с", "Самые быстрые т/с", "Назад"},
                "Выход");

    }
}
