package org.itstep.pd011.maslennikov.hw3.models.task3;

import org.itstep.pd011.maslennikov.hw3.models.IHtmlTableRenderable;
import org.itstep.pd011.maslennikov.hw3.services.HtmlTableFormatter;
import static org.itstep.pd011.maslennikov.hw3.services.HtmlTableFormatter.*;
import org.itstep.pd011.maslennikov.hw3.utils.Utils;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Comparator;

public class NumbersArray<T extends Number> implements IHtmlTableRenderable {
    private T[] array;

    private int length;

    public NumbersArray(Class<T> c, int n) {
        length = n;
        array = (T[]) Array.newInstance(c, n);
    }

    public void initialize(T min, T max) {
        for (int i = 0; i < array.length; i++) {
            if (array instanceof Double[]) {
                array[i] = (T) ((Double) Utils.rand(min.doubleValue(), max.doubleValue()));
            } else if (array instanceof Integer[]) {
                array[i] = (T) ((Integer) Utils.rand((Integer) min, (Integer) max));
            }
        }
    }

    public int length() { return length; }

    public T maxAbs() {
        T max = array[0];

        for (T x: array) {
            if(Math.abs(x.doubleValue()) > max.doubleValue())
                max = x;
        }
        return max;
    }

    public T positivesSum() {
        double sum = 0;

        for (T x: array) {
            if(x.doubleValue() > 0.)
                sum += x.doubleValue();
        }

        if (array instanceof Integer[]) {

            return  (T)((Integer)(int)sum);

        } else if (array instanceof Double[] || array instanceof Float[]) {

            return  (T)((Double)sum);
        }
        return null;
    }

    public NumbersArray<T> orderByAbs() {
        Arrays.sort(array, new Comparator<T>() { // по заданию анонимный класс
            @Override
            public int compare(T v1, T v2) {
                return Double.compare(Math.abs(v1.doubleValue()),Math.abs(v2.doubleValue()));
            }
        });

        return this;
    }

    public NumbersArray<T> orderByAbsDesc() {
        Arrays.sort(array, new Comparator<T>() { // по заданию анонимный класс
            @Override
            public int compare(T v1, T v2) {
                return Double.compare(Math.abs(v2.doubleValue()), Math.abs(v1.doubleValue()));
            }
        });

        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        if (array instanceof Integer[]) {
            for (Object x : array) {
                sb.append(String.format("%4d ", x));
            }
        } else if (array instanceof Double[] || array instanceof Float[]) {
            for (Object x : array) {
                sb.append(String.format("%6.2f ", x));
            }
        }
        return sb.toString();
    }

    @Override
    public String toHtmlTableRow(int n) {
        HtmlTableFormatter.Cell[] cells = new Cell[length];

        if (array instanceof Integer[]) {
            for (int i = 0; i < length; i++) {
                cells[i] = cell((Integer)array[i], "center");
            }
        } else if (array instanceof Double[] || array instanceof Float[]) {
            for (int i = 0; i < length; i++) {
                cells[i] = cell((Double)array[i], "center",2,1);
            }
        }

        return row(cells);
    }
}

