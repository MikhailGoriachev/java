package org.itstep.pd011.maslennikov.hw3.models.task1;

import org.itstep.pd011.maslennikov.hw3.services.HtmlTableFormatter;
import static org.itstep.pd011.maslennikov.hw3.services.HtmlTableFormatter.*;

import java.util.Arrays;

public class VehiclesArray {

    private Vehicle[] vehicles;

    private final HtmlTableFormatter htmlTableFormatter = new HtmlTableFormatter(
            headerCell("№"),
            headerCell("Категория"),
            headerCell("Координаты"),
            headerCell("Цена, руб."),
            headerCell("Скорость, км/ч"),
            headerCell("Год изг."),
            headerCell("Кол-во пассаж."),
            headerCell("Порт приписки / Высота полета")
    );

    public VehiclesArray() {
        initialize();
    }

    public VehiclesArray(Vehicle[] vehicles) {
        this.vehicles = vehicles;
    }

    public void initialize() {
        vehicles = new Vehicle[]{
                new Plane(23.345, -23.345, "самолет", 13_000_000, 980, 2001, 360, 12_1000),
                new Plane(123.123, -123.199, "самолет", 38_000_000, 1180, 2017, 160, 19_1000),
                new Ship(13.123, -13.199, "корабль", 123_000_000, 60, 1998, 460, "Новороссийск"),
                new Ship(-93.3, -123.9, "корабль", 89_000_000, 40, 2012, 120, "Керчь"),
                new Ship(-113.3, 90.9, "корабль", 18_000_000, 20, 1995, 20, "Новоазовск"),
                new Car(-123.3, 100.9, "автомобиль", 30_000, 20, 2012),
                new Car(113.3, 101.9, "автомобиль", 3_100_000, 120, 2019),
                new Car(-129.3, 1.6, "автомобиль", 230_000, 50, 1998),
                new Car(-132.3, 22.7, "автомобиль", 890_000, 90, 2002),
                new Car(33.1, 89.3, "автомобиль", 140_980_000, 1180, 2019),
        };
    }

    public void add(Vehicle vehicle) {
        vehicles = Arrays.copyOf(vehicles, vehicles.length + 1);
        vehicles[vehicles.length - 1] = vehicle;
    }

    public VehiclesArray oldest() {
        VehiclesArray oldestArray = new VehiclesArray();
        int oldestYear = vehicles[0].getYear();

        for (Vehicle v : vehicles) {
            int curYear = v.getYear();

            if (curYear < oldestYear) {
                oldestYear = curYear;
                oldestArray = new VehiclesArray(new Vehicle[]{v});
            } else if (curYear == oldestYear) {
                oldestArray.add(v);
            }
        }

        return oldestArray;
    }

    public VehiclesArray fastest() {
        VehiclesArray fastestsArray = new VehiclesArray();
        int maxVelocity = vehicles[0].getVelocity();

        for (Vehicle v : vehicles) {
            int curVelocity = v.getVelocity();

            if (curVelocity > maxVelocity) {
                maxVelocity = curVelocity;
                fastestsArray = new VehiclesArray(new Vehicle[]{v});
            } else if (curVelocity == maxVelocity) {
                fastestsArray.add(v);
            }
        }

        return fastestsArray;
    }

    public VehiclesArray slowest() {
        VehiclesArray slowestsArray = new VehiclesArray();
        int minVelocity = vehicles[0].getVelocity();

        for (Vehicle v : vehicles) {
            int curVelocity = v.getVelocity();

            if (curVelocity < minVelocity) {
                minVelocity = curVelocity;
                slowestsArray = new VehiclesArray(new Vehicle[]{v});
            } else if (curVelocity == minVelocity) {
                slowestsArray.add(v);
            }
        }

        return slowestsArray;
    }

    public String toHtmlTable(String title) {
        return htmlTableFormatter.table(vehicles, title);
    }
}
