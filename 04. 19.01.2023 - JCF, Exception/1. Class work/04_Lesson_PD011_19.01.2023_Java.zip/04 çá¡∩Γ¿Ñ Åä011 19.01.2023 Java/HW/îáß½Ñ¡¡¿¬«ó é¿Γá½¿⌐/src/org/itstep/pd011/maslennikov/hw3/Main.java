package org.itstep.pd011.maslennikov.hw3;

import org.itstep.pd011.maslennikov.hw3.tasks.TaskOneController;
import org.itstep.pd011.maslennikov.hw3.tasks.taskThree.TaskThreeController;
import org.itstep.pd011.maslennikov.hw3.tasks.TaskTwoController;
import org.itstep.pd011.maslennikov.hw3.utils.Utils;

import javax.swing.*;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        try {
            while (true) {
                switch (showMenu()) {
                    case 0 -> TaskOneController.run();
                    case 1 -> TaskTwoController.run();
                    case 2 -> TaskThreeController.run();
                    default -> {
                        return;
                    }
                }
            }
        }catch (Exception ex) {
            StringWriter sw = new StringWriter();
            ex.printStackTrace(new PrintWriter(sw));

            Utils.errorMessage(sw.toString(), "Ошибка");
        }
    }

    public static int showMenu() {
        return Utils.showMenu(
                "<html><h1>Меню</h1>",
                "Домашняя работа",
                new String[] {"Задача 1", "Задача 2", "Задача 3", "Выход"},
                "Выход"
        );
    }
}