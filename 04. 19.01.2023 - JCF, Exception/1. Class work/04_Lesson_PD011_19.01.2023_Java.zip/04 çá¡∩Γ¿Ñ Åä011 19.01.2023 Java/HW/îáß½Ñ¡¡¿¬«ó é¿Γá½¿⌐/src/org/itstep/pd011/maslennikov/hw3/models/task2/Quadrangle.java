package org.itstep.pd011.maslennikov.hw3.models.task2;

public enum Quadrangle {
    RECTANGLE(7000), SQUARE(1705), RHOMBUS(1425), RECTANGULAR_TRAPEZOID(1210);

    Quadrangle(int value) {}

    private int value;
    public int getValue() { return value; }

    public double perimeter(double... sides) {
        return switch (this) {
            // [0] - сторона а, [1] - сторона b
            case RECTANGLE              -> 2. * (sides[0] + sides[1]);
            // [0] - сторона a
            case SQUARE, RHOMBUS -> 4. * sides[0];
            // [0] - сторона а, [1] - сторона b, [2] - сторона c, [3] - сторона d
            case RECTANGULAR_TRAPEZOID  -> sides[0] + sides[1] + sides[2] + sides[3];
        };
    }

    public double area(double... sides) {
        return switch (this) {
            // [0] - сторона а, [1] - сторона b
            case RECTANGLE              -> sides[0] * sides[1];
            // [0] - сторона a
            case SQUARE -> sides[0] * sides[0];
            // [0] - сторона a, [1] - высота
            case RHOMBUS -> sides[0] * sides[1];
            // [0] - сторона а, [1] - сторона b, [2] - сторона c
            case RECTANGULAR_TRAPEZOID  -> ((sides[0] + sides[1]) * sides[2]) / 2.;
        };
    }

    @Override public String toString() {

        return switch (this) {
            case RECTANGLE   -> "Прямоугольник";
            case SQUARE -> "Квадрат";
            case RHOMBUS -> "Ромб";
            case RECTANGULAR_TRAPEZOID -> "Прямоугольная трапеция";
        };
    }
}
