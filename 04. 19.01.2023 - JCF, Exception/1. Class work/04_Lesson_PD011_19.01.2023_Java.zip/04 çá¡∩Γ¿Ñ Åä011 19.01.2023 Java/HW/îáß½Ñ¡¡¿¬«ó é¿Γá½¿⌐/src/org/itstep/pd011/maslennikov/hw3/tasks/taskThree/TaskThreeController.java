package org.itstep.pd011.maslennikov.hw3.tasks.taskThree;
import org.itstep.pd011.maslennikov.hw3.utils.Utils;


public class TaskThreeController {

    public static void run(){
        while(true) {
            switch (showMenu()) {
                case 0 -> IntegersArrayPoint.run();
                case 1 -> DoublesArrayPoint.run();
                default -> { return; }
            };
        }
    }

    private static int showMenu() {
        return Utils.showMenu("Выберите тип массива",
                "Задача 2",
                new String[]{"int", "double", "Назад"},
                "Выход");
    }
}
