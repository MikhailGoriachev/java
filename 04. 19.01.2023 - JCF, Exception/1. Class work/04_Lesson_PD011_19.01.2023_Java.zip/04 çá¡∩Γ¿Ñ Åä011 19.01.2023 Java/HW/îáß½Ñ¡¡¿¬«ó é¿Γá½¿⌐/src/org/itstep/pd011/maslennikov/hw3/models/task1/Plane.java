package org.itstep.pd011.maslennikov.hw3.models.task1;

import org.itstep.pd011.maslennikov.hw3.models.IHtmlTableRenderable;
import static org.itstep.pd011.maslennikov.hw3.services.HtmlTableFormatter.*;

import java.awt.geom.Point2D;
import java.security.InvalidParameterException;

public class Plane extends Vehicle implements IHtmlTableRenderable {
    // высота полета
    private int altitude;

    // количество пассажиров
    private int pax;


    public Plane(Point2D.Double coordinates, String category, int price, int velocity, int year, int altitude, int pax) {
        super(coordinates, category, price, velocity, year);
        this.altitude = altitude;
        this.pax = pax;
    }

    public Plane(double longitude, double latitude, String category, int price, int velocity, int year, int altitude, int pax) {
        super(longitude, latitude, category, price, velocity, year);
        this.altitude = altitude;
        this.pax = pax;
    }

    public int getAltitude() {
        return altitude;
    }

    public void setAltitude(int altitude) {
        if (altitude < 0)
            throw new InvalidParameterException("Недопустимое значение высоты полета самолета");

        this.altitude = altitude;
    }

    public int getPax() {
        return pax;
    }

    public void setPax(int pax) {
        if (pax < 0)
            throw new InvalidParameterException("Недопустимое количества пассажиров");

        this.pax = pax;
    }

    @Override
    public String toHtmlTableRow(int rowNum) {
        return row(
                cell(rowNum, "center"),
                cell(category, "left"),
                cell(String.format("%.2f;%.2f", coordinates.x, coordinates.y), "center"),
                cell(price, "right"),
                cell(velocity, "right"),
                cell(year, "right"),
                cell(pax, "right"),
                cell(altitude, "right")
        );
    }
}
