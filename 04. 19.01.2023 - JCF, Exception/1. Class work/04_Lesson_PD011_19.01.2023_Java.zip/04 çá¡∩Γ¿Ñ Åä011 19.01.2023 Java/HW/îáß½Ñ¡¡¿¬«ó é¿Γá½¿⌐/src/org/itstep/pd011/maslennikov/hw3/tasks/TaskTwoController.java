package org.itstep.pd011.maslennikov.hw3.tasks;

import org.itstep.pd011.maslennikov.hw3.models.IHtmlTableRenderable;
import org.itstep.pd011.maslennikov.hw3.models.task2.Quadrangle;
import org.itstep.pd011.maslennikov.hw3.services.HtmlTableFormatter;
import static org.itstep.pd011.maslennikov.hw3.services.HtmlTableFormatter.*;
import org.itstep.pd011.maslennikov.hw3.utils.*;

public class TaskTwoController {
    public static final double MIN = 1;
    public static final double MAX = 9;

    private static Quadrangle quadrangle;

    public static void run() {
        String message = generate();

        while(message != null) {
            message = switch (showMenu(message)) {
                case 0 -> generate();
                default -> null;
            };
        }
    }

    private static String generate() {
        HtmlTableFormatter tableFormatter = new HtmlTableFormatter(
                headerCell("№"),
                headerCell("Тип"),
                headerCell("a"),
                headerCell("b"),
                headerCell("c"),
                headerCell("d"),
                headerCell("h"),
                headerCell("Периметр"),
                headerCell("Площадь")
        );

        return tableFormatter.table(new IHtmlTableRenderable[]{
                rectangle(),
                square(),
                rhombus(),
                rectangularTrapezoid()
        }, "Четырехугольники:");
    }

    private static IHtmlTableRenderable rectangle() {
        quadrangle = Quadrangle.RECTANGLE;

        double a = Utils.rand(MIN, MAX);
        double b = Utils.rand(MIN, MAX);

        double perimeter = quadrangle.perimeter(a, b);
        double area = quadrangle.area(a, b);

        return n -> row(
                cell(n, "center"),
                cell(quadrangle.toString(), "left"),
                cell(a, "right", 2),
                cell(b, "right", 2),
                cell(),
                cell(),
                cell(),
                cell(perimeter, "right", 2),
                cell(area, "right", 2)
        );
    }

    private static IHtmlTableRenderable square() {
        quadrangle = Quadrangle.SQUARE;

        double a = Utils.rand(MIN, MAX);

        double perimeter = quadrangle.perimeter(a);
        double area = quadrangle.area(a);

        return n -> row(
                cell(n, "center"),
                cell(quadrangle.toString(), "left"),
                cell(a, "right", 2),
                cell(),
                cell(),
                cell(),
                cell(),
                cell(perimeter, "right", 2),
                cell(area, "right", 2)
        );
    }

    private static IHtmlTableRenderable rhombus() {
        quadrangle = Quadrangle.RHOMBUS;

        double a = Utils.rand(MIN, MAX);
        double h = Utils.rand(MIN, MAX);

        double perimeter = quadrangle.perimeter(a);
        double area = quadrangle.area(a, h);

        return n -> row(
                cell(n, "center"),
                cell(quadrangle.toString(), "left"),
                cell(a, "right", 2),
                cell(),
                cell(),
                cell(),
                cell(h, "right", 2),
                cell(perimeter, "right", 2),
                cell(area, "right", 2));
    }

    private static IHtmlTableRenderable rectangularTrapezoid() {
        quadrangle = Quadrangle.RECTANGULAR_TRAPEZOID;

        double a = Utils.rand(MIN, MAX);
        double b = Utils.rand(MIN, MAX);
        double c = Utils.rand(MIN, MAX);
        double d = Utils.rand(MIN, MAX);

        double perimeter = quadrangle.perimeter(a, b, c , d);
        double area = quadrangle.area(a, b , c);

        return n -> row(
                cell(n, "center"),
                cell(quadrangle.toString(), "left"),
                cell(a, "right", 2),
                cell(b, "right", 2),
                cell(c, "right", 2),
                cell(d, "right", 2),
                cell(),
                cell(perimeter, "right", 2),
                cell(area, "right", 2)
        );
    }

    private static int showMenu(String content) {
        return Utils.showMenu(content,
                "Задача 2",
                new String[]{"Сгенерировать", "Назад"},
                "Выход");
    }
}
