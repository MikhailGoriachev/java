package org.itstep.pd011.maslennikov.hw3.services;

import org.itstep.pd011.maslennikov.hw3.models.IHtmlTableRenderable;

// Сервис для формирования html-таблицы
public class HtmlTableFormatter {
    private int fontSize = 12;
    private String headerColor = "black";
    private String rowsColor = "gray";

    // массив заголовков колонок
    private final Cell[] headers;

    // конструкторы
    public HtmlTableFormatter(Cell ...headers) { this.headers = headers; }

    public HtmlTableFormatter(Cell[] headers, int fontSize, String rowsColor) {
        this.fontSize = fontSize;
        this.rowsColor = rowsColor;
        this.headers = headers;
    }

    // аксессоры настроек таблицы
    public int getFontSize() { return fontSize; }
    public void setFontSize(int fontSize) { this.fontSize = fontSize; }

    public String getRowsColor() { return rowsColor; }
    public void setRowsColor(String rowsColor) { this.rowsColor = rowsColor; }

    public String getHeaderColor() { return headerColor; }
    public void setHeaderColor(String headerColor) { this.headerColor = headerColor; }


    // формирование таблицы по коллекции объектов, реализующих интерфейс вывода в строку таблицы
    public String table(IHtmlTableRenderable[] items, String title) {
        StringBuilder sb = new StringBuilder(header(title));

        for (int i = 0; i < items.length; i++) {
            sb.append(items[i].toHtmlTableRow(i + 1));
        }

        return sb.append(footer()).toString();
    }

    // формирование шапки таблицы
    private String header(String title) {
        StringBuilder sb = new StringBuilder(
                String.format("<html>" +
                        "<h2>%s</h2>" +
                        "<table align='center' border='2' cellspacing='0' cellpadding='8'" +
                        " style='font-size:%dpx;color:%s;margin:0 10px 10px 0'><thead><tr>",
                        title, fontSize, rowsColor));

        for (Cell header : headers) {
            sb.append(String.format("<th style='color:%s' colspan='%d'>%s</th>", headerColor, header.colSpan, header.text));
        }

        return sb.append("</tr></thead><tbody>").toString();
    }

    // закрывающие теги таблицы
    private String footer() { return "</tbody></table>"; }

    // статический метод формирования строки таблицы с данными из параметра переменной длины объектов Cell
    public static String row(Cell... cells) {
        StringBuilder sb = new StringBuilder("<tr>");

        for (Cell cell : cells) {
            sb.append(String.format("<td style='text-align:%s' colspan='%d'>%s</td>", cell.alignment, cell.colSpan, cell.text));
        }

        return sb.append("</tr>").toString();
    }

    // создание объекта ячейки заголовка
    public static Cell headerCell(String text) {
        return new Cell(text, "center", 1);
    }

    // создание объекта ячейки заголовка с объединением по столбцам
    public static Cell headerCell(String text, int colSpan) {
        return new Cell(text, "center", colSpan);
    }

    // создание объекта ячейки по текстовому контенту с объединением по столбцам
    public static Cell cell(String text, String alignment, int colSpan) {
        return new Cell(text, alignment, colSpan);
    }

    // создание объекта ячейки по текстовому контенту
    public static Cell cell(String text, String alignment) {
        return new Cell(text, alignment, 1);
    }

    // создание объекта ячейки по числовому контенту
    public static <T extends Number> Cell cell(T value, String alignment) {
        return new Cell(String.valueOf(value), alignment, 1);
    }

    // создание объекта ячейки по числовому контенту с объединением по столбцам
    public static <T extends Number> Cell cell(T value, String alignment, int colSpan) {
        return new Cell(String.valueOf(value), alignment, colSpan);
    }

    // создание объекта ячейки по вещественному числовому контенту с форматированием точности знаков
    public static <T extends Double> Cell cell(T value, String alignment, int precision) {
        return new Cell(String.format("%." + precision + "f", value), alignment, 1);
    }

    // создание объекта ячейки по вещественному числовому контенту с форматированием точности знаков с объединением по столбцам
    public static <T extends Double> Cell cell(T value, String alignment, int precision, int colSpan) {
        return new Cell(String.format("%." + precision + "f", value), alignment, colSpan);
    }

    // создание объекта пустой ячейки
    public static Cell cell() {
        return new Cell("", "", 1);
    }


    // запись, представляющая ячейку
    public record Cell(String text, String alignment, int colSpan) {}
}
