package org.itstep.pd011.maslennikov.hw3.models.task1;

import org.itstep.pd011.maslennikov.hw3.models.IHtmlTableRenderable;

import java.awt.geom.Point2D;
import java.security.InvalidParameterException;

public abstract class Vehicle implements IHtmlTableRenderable {

    // географические координаты
    protected Point2D.Double coordinates;

    // категория транспортного средства
    protected String category;

    // цена
    protected int price;

    // скорость
    protected int velocity;

    // год выпуска
    protected int year;

    public Vehicle() {
    }

    public Vehicle(Point2D.Double coordinates, String category, int price, int velocity, int year) {
        setCoordinates(coordinates);
        setCategory(category);
        setPrice(price);
        setVelocity(velocity);
        setYear(year);
    }

    public Vehicle(double longitude, double latitude, String category, int price, int velocity, int year) {
        setCoordinates(longitude, latitude);
        setCategory(category);
        setPrice(price);
        setVelocity(velocity);
        setYear(year);;
    }

    public Point2D.Double getCoordinates() {
        return coordinates;
    }

    public void setCoordinates(Point2D.Double coordinates) {
        if (-180 > coordinates.x || coordinates.x > 180)
            throw new InvalidParameterException("Недопустимое значение долготы");

        if (-180 > coordinates.y || coordinates.y > 180)
            throw new InvalidParameterException("Недопустимое значение широты");

        this.coordinates = coordinates;
    }

    public void setCoordinates(double x, double y) {
        if (-180 > x || x > 180)
            throw new InvalidParameterException("Недопустимое значение долготы");

        if (-180 > y || y > 180)
            throw new InvalidParameterException("Недопустимое значение широты");

        this.coordinates = new Point2D.Double(x, y);
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        if(category.isBlank())
            throw new InvalidParameterException("Не задано название категории транспортного средства");

        this.category = category;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        if (price < 0)
            throw new InvalidParameterException("Недопустимое значение цены транспортного средства");

        this.price = price;
    }

    public int getVelocity() {
        return velocity;
    }

    public void setVelocity(int velocity) {
        if (velocity < 0)
            throw new InvalidParameterException("Недопустимое значение скорости транспортного средства");

        this.velocity = velocity;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        if (year < 0)
            throw new InvalidParameterException("Недопустимое значение года изготовления транспортного средства");

        this.year = year;
    }

    public abstract String toHtmlTableRow(int n);
}
