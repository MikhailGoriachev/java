package org.itstep.pd011.maslennikov.hw3.utils;

import javax.swing.*;

public class Utils {
    private static final java.util.Random rand = new java.util.Random();

    // метод, возвращающий случайное вещественное число,
    // передаются нижнее и верхнее значения
    public static double rand(double lo, double hi){
        return lo + rand.nextDouble() * (hi - lo);
    }

    // перегруженный метод, возвращающий случайное целое число,
    // передаются нижнее и верхнее значения
    public static int rand(int lo, int hi) {
        return lo + rand.nextInt(hi - lo + 1);
    }


    public static int showMenu(String content, String title, String[] menu, String initialValue) {
        return JOptionPane.showOptionDialog(
                null,
                content,
                title,
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                menu,
                initialValue
        );
    }

    public static void errorMessage(String message, String title) {
        JOptionPane.showMessageDialog(null, message, title, JOptionPane.ERROR_MESSAGE);
    }
}
