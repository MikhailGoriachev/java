package org.itstep.pd011.maslennikov.hw3.models.task1;

import org.itstep.pd011.maslennikov.hw3.models.IHtmlTableRenderable;
import static org.itstep.pd011.maslennikov.hw3.services.HtmlTableFormatter.*;

import java.awt.geom.Point2D;

public class Car extends Vehicle implements IHtmlTableRenderable {

    public Car(Point2D.Double coordinates, String category, int price, int velocity, int year) {
        super(coordinates, category, price, velocity, year);
    }

    public Car(double longitude, double latitude, String category, int price, int velocity, int year) {
        super(longitude, latitude, category, price, velocity, year);
    }

    @Override
    public String toHtmlTableRow(int rowNum) {
        return row(
                cell(rowNum, "center"),
                cell(category, "left"),
                cell(String.format("%.2f;%.2f", coordinates.x, coordinates.y), "center"),
                cell(price, "right"),
                cell(velocity, "right"),
                cell(year, "right"),
                cell(),
                cell()
        );
    }
}
