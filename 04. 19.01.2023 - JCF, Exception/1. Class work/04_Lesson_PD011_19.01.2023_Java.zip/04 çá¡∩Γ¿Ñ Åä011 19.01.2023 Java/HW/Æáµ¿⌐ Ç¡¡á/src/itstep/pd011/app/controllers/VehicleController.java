package itstep.pd011.app.controllers;

import itstep.pd011.app.models.Plane;
import itstep.pd011.app.models.Ship;
import itstep.pd011.app.models.Car;
import itstep.pd011.app.models.Vehicle;

import itstep.pd011.app.utils.Utils;

public class VehicleController {

    private final Vehicle [] vehicles;

    public VehicleController(Vehicle[] vehicles) {
        this.vehicles = vehicles;
    }

    public VehicleController() {
        this(new Vehicle[] {
                new Plane("55,7522 с. ш., 37,6156 в. д.", 46500000, 700 ,1974, 11000 , 30),
                new Plane("55,8094 с. ш., 37,9581 в. д.", 400000000, 850 ,2015, 11000 , 200),
                new Ship("54,7551 с. ш., 83,0967 в. д.", 6850000, 60, 2007, "Усть-Луга", 18),
                new Ship("56,1366 с. ш., 40,3966 в. д.", 5000000, 50, 1991, "Мурманск", 10),
                new Ship("55,9686 с. ш., 43,0912 в. д.", 5000000, 40, 2001, "Мурманск", 15),
                new Car("57,5913 с. ш., 34,5645 в. д.", 3290000, 260,2015),
                new Car("59,7142 с. ш., 30,3964 в. д.",1350000 , 200 ,2013),
                new Car("66,53 с. ш., 66,6019 в. д.",1390000 , 180, 2018),
                new Car("59,6451 с. ш., 33,5294 в. д.", 595000 ,150  , 2007),
                new Car("52,9771 с. ш., 49,7086 в. д.", 199000, 200, 2010),

        });
    }

    // вывод в таблицу
    private String vehiclesToTable() {
        StringBuilder sb = new StringBuilder();

        for (Vehicle vehicle: vehicles){
            sb.append(vehicle.toString());
        }

        return sb.toString();
    }

    //самое старое транспортное средство
    //Находим самый минимальный год в массиве
    private int findMinYear(){

        int min = Integer.MAX_VALUE;

        for (Vehicle vehicle: vehicles){

            if(vehicle.get_year() < min){
                min = vehicle.get_year();
            }
        }

        return min;
    }

    //Находим самые старые транспортные средства
    private String findOlder(int old) {
        StringBuilder sb = new StringBuilder();

        for (Vehicle vehicle: vehicles){

            if (vehicle.get_year() == old){
                sb.append(vehicle.toString());
            }
        }

        return sb.toString();
    }

    //самое быстрое и самое медленное транспортные средства (может быть найдено больше 1 транспортного средства)
    //Находим минимальную скорость в массиве
    private int findMinSpeed(){

        int min = Integer.MAX_VALUE;

        for (Vehicle vehicle: vehicles){

            if(vehicle.get_speed() < min){
                min = vehicle.get_speed();
            }
        }

        return min;
    }

    //Находим максимальную скорость в массиве
    private int findMaxSpeed(){

        int max = Integer.MIN_VALUE;

        for (Vehicle vehicle: vehicles){

            if(vehicle.get_speed() > max){
                max = vehicle.get_speed();
            }
        }

        return max;
    }

    private String findSlowest0rFastest(int speed) {
        StringBuilder sb = new StringBuilder();

        for (Vehicle vehicle: vehicles){

            if (vehicle.get_speed() == speed){
                sb.append(vehicle.toString());
            }
        }

        return sb.toString();
    }

    // работа по заданию
    public void run() {

        Utils.showMessage(Utils.headerVechicle + vehiclesToTable() + "</tbody></table>", "Вывод массива в формате таблицы");
        Utils.showMessage(Utils.headerVechicle + findOlder(findMinYear()) + "</tbody></table>", "Самые старые транспортные средства");
        Utils.showMessage(Utils.headerVechicle + findSlowest0rFastest(findMinSpeed()) + "</tbody></table>", "Самые медленные транспортные средства");
        Utils.showMessage(Utils.headerVechicle + findSlowest0rFastest(findMaxSpeed()) + "</tbody></table>", "Самые быстрые транспортные средства");
    }
}
