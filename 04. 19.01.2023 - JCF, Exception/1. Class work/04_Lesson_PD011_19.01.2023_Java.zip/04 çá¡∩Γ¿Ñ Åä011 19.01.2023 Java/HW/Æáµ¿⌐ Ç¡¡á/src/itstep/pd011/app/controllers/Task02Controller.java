package itstep.pd011.app.controllers;

import itstep.pd011.app.utils.Utils;
import itstep.pd011.app.enums.Figure;

public class Task02Controller {

    // работа по заданию
    public void run() {

        StringBuilder m = new StringBuilder("<html>");

        double p = 0,s = 0;

        for (Figure figure: Figure.values()){

            double a = Utils.getDouble(5,10);
            double b = Utils.getDouble(5,10);

            m.append(String.format("<ul><li>%s</li><li>Значение: %d </li><li>Сторона A: %.2f</li>",figure,figure.getValue(),a));

            switch (figure) {
                case RECTANGLE -> {
                    p = Figure.RECTANGLE.Perimeter(a, b);
                    s = Figure.RECTANGLE.Area(a, b);
                    m.append(String.format("<li>Сторона B: %.2f</li>", b));
                }
                case SQUARE -> {
                    p = Figure.SQUARE.Perimeter(a);
                    s = Figure.SQUARE.Area(a);
                }
                case RHOMB -> {
                    double h = Utils.getDouble(5, 10);
                    p = Figure.RHOMB.Perimeter(a);
                    s = Figure.RHOMB.Area(a, h);
                    m.append(String.format("<li>Высота H: %.2f</li>", h));
                }
                case TRAPEZE -> {

                    double c = Utils.getDouble(5,10);
                    double d = Utils.getDouble(5,10);

                    double ms = (a + b) * 0.5;
                    p = Figure.TRAPEZE.Perimeter(a, b, c, d);
                    s = Figure.TRAPEZE.Area(c, ms);
                    m.append(String.format("<li>Сторона B: %.2f</li><li>Сторона C: %.2f</li>" +
                                    "<li>Сторона D: %.2f</li><li>Средняя линия M: %.2f</li>",b,c,d, ms));
                }
            }

            m.append(String.format("<li>Периметр: %.2f</li><li>Площадь: %.2f</li></ul>",p,s));
        }

        Utils.showMessage(m.toString(), "Демонстрация работы перечисления");
    }
}
