package itstep.pd011.app.utils;

import javax.swing.*;
import java.util.Random;

// Класс Утилиты
public class Utils {
    
    // случайное целочисленное число
    public static int getInt(int min, int max) {
        return new Random().nextInt(min, max);
    }
    
    // случайное вещественное число
    public static double getDouble(double min, double max) {
        return min + (max - min) * new Random().nextDouble();
    }

    // вывод сообщения об ошибке
    public static void showErrorMessage(String message, String title) {
        JOptionPane.showMessageDialog(null, message, title, JOptionPane.ERROR_MESSAGE);
    }

    // вывод данных в окно
    public static void showMessage(String message, String title) {
        JOptionPane.showOptionDialog(
                null,
                message, //Utils.headerVechicle + message + "</tbody></table>"
                title,
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(),
                new Object[] {"Далее"},
                "Далее"
        );
    }

    public static String headerVechicle =
            "<html><table border='1' >" +
            "<thead><tr>" +
            "<th>Тип транспорта</th>" +
            "<th>Координаты</th>" +
            "<th>Скорость</th>" +
            "<th>Цена</th>" +
            "<th>Год выпуска</th>" +
            "<th>Порт приписки</th>" +
            "<th>Высота</th>" +
            "<th>Кол-во пассажиров</th>" +
            "</tr></thead><tbody>";
}
