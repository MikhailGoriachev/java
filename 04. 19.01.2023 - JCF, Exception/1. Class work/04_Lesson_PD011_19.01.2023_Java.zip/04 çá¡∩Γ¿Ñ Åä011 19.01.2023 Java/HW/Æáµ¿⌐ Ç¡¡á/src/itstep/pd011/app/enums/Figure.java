package itstep.pd011.app.enums;

public enum Figure {
    RECTANGLE( 7000), SQUARE(1705), RHOMB(1425), TRAPEZE(1210);

    // конструктор перечисления - задает значения вспомогательных
    // (дополнительных) полей
    Figure(int value) {
        this.value = value;
    } // Numbers

    // вспомогательных/дополнительное поле для значений перечисления
    private final int value;
    public int getValue() { return value; }

    //В перечислении реализуйте методы расчета периметра и площади
    // четырехугольников с учетом их специфики.
    public double Perimeter(double... sides){
        return switch (this) {
            case RECTANGLE -> 2. * (sides[0] + sides[1]);
            case SQUARE, RHOMB -> 4. * sides[0];
            case TRAPEZE  -> sides[0] + sides[1] + sides[2] + sides[3];
        };
    }

    public double Area(double... sides){
        return switch (this) {
            case RECTANGLE -> sides[0] + sides[1];
            case SQUARE -> sides[0] * sides[0];
            case RHOMB, TRAPEZE -> sides[0] * sides[1];
        };
    }

    // переопределение toString() - повышаем удобство вывода
    // один из немногих методов с override в перечислении
    @Override public String toString() {

        return switch (this) {
            case RECTANGLE -> "Прямоугольник";
            case SQUARE -> "Квадрат";
            case RHOMB -> "Ромб";
            case TRAPEZE -> "Прямоугольная трапеция";
        };
    } // toString
}
