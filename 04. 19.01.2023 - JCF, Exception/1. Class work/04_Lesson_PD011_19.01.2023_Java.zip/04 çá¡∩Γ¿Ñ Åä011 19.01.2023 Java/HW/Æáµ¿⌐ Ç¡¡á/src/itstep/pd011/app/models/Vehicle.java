package itstep.pd011.app.models;

import java.util.Objects;

public abstract class Vehicle {

    protected String coordinates; //географические координаты
    protected int price; //цена
    protected int speed; //скорость
    protected int year; //год выпуска

    // блок инициализации, выполняется перед любым конструктором
    { coordinates = "координаты"; price = 0; speed = 0; year = 2023;}

    public Vehicle(String _coordinates, int _price, int _speed, int _year) {
        this.coordinates = _coordinates;
        this.price = _price;
        this.speed = _speed;
        this.year = _year;
    }

    public String get_coordinates() {
        return coordinates;
    }

    public void set_coordinates(String coordinates) {
        if (Objects.equals(coordinates, "")) throw new IllegalArgumentException("Введите координаты");
        this.coordinates = coordinates;
    }

    public int get_price() {
        return price;
    }

    public void set_price(int price) {
        if (price <= 0) throw new IllegalArgumentException("Цена не может быть отрицательной или равной нулю");
        this.price = price;
    }

    public int get_speed() {
        return speed;
    }

    public void set_speed(int speed) {
        if (speed <= 0) throw new IllegalArgumentException("Скорость не может быть отрицательной или равной нулю");
        this.speed = speed;
    }

    public int get_year() {
        return year;
    }

    public void set_year(int year) {
        if (year < 1900) throw new IllegalArgumentException("Год не может быть меньше 1900");
        if (year > 2023) throw new IllegalArgumentException("Год не может быть больше 2023");
        this.year = year;
    }

    // вывод в строку таблицы
    @Override
    public String toString() {
        return "<tr>" +
                "<td>Авто</td>" +
                "<td>" + coordinates + "</td>" +
                "<td>" + speed + "</td>" +
                "<td>" + price + " &#8381;</td>" +
                "<td>" + year + "</td>" +
                "<td>--</td>" +
                "<td>--</td>" +
                "<td>--</td>" +
                "</tr>";
    }
}
