package itstep.pd011.app.models;

public class Car  extends Vehicle{

    public Car(String _coordinates, int _price, int _speed, int _year) {
        super(_coordinates, _price, _speed, _year);
    }
}
