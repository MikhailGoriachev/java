
package itstep.pd011.app;

import itstep.pd011.app.controllers.Task02Controller;
import itstep.pd011.app.controllers.Task03Controller;
import itstep.pd011.app.controllers.VehicleController;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {

        VehicleController tv = new VehicleController();
        Task02Controller t2 = new Task02Controller();
        Task03Controller t3 = new Task03Controller();

        while (true) {

            switch (showMenu()) {

                case 0 -> tv.run();
                case 1 -> t2.run();
                case 2 -> t3.run();

                // выход
                default -> {
                    return;
                }
            }
        }

    }

    // вывод окна меню
    public static int showMenu() {
        return JOptionPane.showOptionDialog(
                null,
                "<html><h1>Меню</h1>",
                "Домашнее задание на 19.01.2023",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(Main.class.getResource("../../../images/fish.png")),
                new Object[] {"Задание 1", "Задание 2", "Задание 3", "Выход"},
                "Выход"
        );
    }
}