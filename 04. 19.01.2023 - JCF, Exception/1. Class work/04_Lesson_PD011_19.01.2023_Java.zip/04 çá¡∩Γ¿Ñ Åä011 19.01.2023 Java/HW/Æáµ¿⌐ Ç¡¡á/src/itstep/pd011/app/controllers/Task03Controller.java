package itstep.pd011.app.controllers;

import itstep.pd011.app.utils.Utils;
import itstep.pd011.app.models.Generic;

public class Task03Controller {

    // работа по заданию
    public void run() {

        Generic<Double> doubles = new Generic<>(createDoubles(12));
        Generic<Integer> integers = new Generic<>(createIntegers(12));

        int maxAbs = integers.findMaxAbs();
        double positiveSum = integers.findPositiveSum();

        double maxAbsD = doubles.findMaxAbs();
        double positiveSumD = doubles.findPositiveSum();

        Utils.showMessage(integers.show(maxAbs,positiveSum),"Массив Integer");
        Utils.showMessage(doubles.show(maxAbsD,positiveSumD),"Массив Double");

        doubles.orderBy(true);
        integers.orderBy(true);

        Utils.showMessage(integers.show(maxAbs,positiveSum),"Сортировка массива Integer по убыванию модулей");
        Utils.showMessage(doubles.show(maxAbsD,positiveSumD),"Сортировка массива Double по убыванию модулей");

        doubles.orderBy(false);
        integers.orderBy(false);

        Utils.showMessage(integers.show(maxAbs,positiveSum),"Сортировка массива Integer по возрастанию модулей");
        Utils.showMessage(doubles.show(maxAbsD,positiveSumD),"Сортировка массива Double по возрастанию модулей");
    }

    //Создание и заполнение массива Double
    private Double [] createDoubles(int n){

        Double [] doubles = new Double[n];

        for (int i = 0; i < n; i++){
            doubles[i] = Utils.getDouble(-20.,20.);
        }

        return doubles;
    }

    //Создание и заполнение массива Integer
    private Integer [] createIntegers(int n){

        Integer [] integers = new Integer[n];

        for (int i = 0; i < n; i++){
            integers[i] = Utils.getInt(-20,20);
        }

        return integers;
    }

}
