package itstep.pd011.app.models;

import java.util.Objects;

public class Ship  extends Vehicle{

    //для корабля — порт приписки.
    private String port;

    //количество пассажиров
    private int amountPassengers;

    public Ship(String _coordinates, int _price, int _speed, int _year, String port, int amountPassengers) {
        super(_coordinates, _price, _speed, _year);
        this.port = port;
        this.amountPassengers = amountPassengers;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        if (Objects.equals(port, "")) throw new IllegalArgumentException("Введите порт приписки");
        this.port = port;
    }

    public int getAmountPassengers() {
        return amountPassengers;
    }

    public void setAmountPassengers(int amountPassengers) {
        if (amountPassengers <= 0) throw new IllegalArgumentException("Количество пассажиров не может быть отрицательным или равным нулю");
        this.amountPassengers = amountPassengers;
    }

    // вывод в строку таблицы
    @Override
    public String toString() {
        return "<tr>" +
                "<td>Корабль</td>" +
                "<td>" + coordinates + "</td>" +
                "<td>" + speed + "</td>" +
                "<td>" + price + " &#8381;</td>" +
                "<td>" + year + "</td>" +
                "<td>" + port + "</td>" +
                "<td>--</td>" +
                "<td>" + amountPassengers + "</td>" +
                "</tr>";
    }
}
