package itstep.pd011.app.models;

public class Plane extends Vehicle{

    //Дополнительно для самолета должна быть определена высота
    private int height;

    //количество пассажиров
    private int amountPassengers;

    public Plane(String _coordinates, int _price, int _speed, int _year, int height, int amountPassengers) {
        super(_coordinates, _price, _speed, _year);
        this.height = height;
        this.amountPassengers = amountPassengers;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        if (height <= 0) throw new IllegalArgumentException("Высота не может быть отрицательной или равной нулю");
        this.height = height;
    }

    public int getAmountPassengers() {
        return amountPassengers;
    }

    public void setAmountPassengers(int amountPassengers) {
        if (amountPassengers <= 0) throw new IllegalArgumentException("Количество пассажиров не может быть отрицательным или равным нулю");
        this.amountPassengers = amountPassengers;
    }

    // вывод в строку таблицы
    @Override
    public String toString() {
        return "<tr>" +
                "<td>Самолет</td>" +
                "<td>" + coordinates + "</td>" +
                "<td>" + speed + "</td>" +
                "<td>" + price + " &#8381;</td>" +
                "<td>" + year + "</td>" +
                "<td>--</td>" +
                "<td>" + height + "</td>" +
                "<td>" + amountPassengers + "</td>" +
                "</tr>";
    }
}
