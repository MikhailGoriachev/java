package itstep.pd011.app.models;

import itstep.pd011.app.Main;
import itstep.pd011.app.enums.Figure;

import java.util.Arrays;
import java.util.Comparator;

public class Generic <T extends Number> {

    private T[] data;   // данные для обработки

    public Generic(T[] data) {
        this.data = data;
    }

    // геттер для массива
    public T[] getData() { return data; }

    //Определение максимального по модулю элемента массива
    public T findMaxAbs(){

        T max = data[0];

        for (T value: data){

            if(Math.abs(value.doubleValue()) > Math.abs(max.doubleValue())){
                max = value;
            }
        }

        return max;
    }

    //Вычисление суммы положительных элементов массива
    public double findPositiveSum(){

        double sum = 0;

        for (T value: data){

            if(value.doubleValue() > 0){

                // xxxxValue() - получение значения элемента, приведенного к типу xxxx
                sum += value.doubleValue();
            }
        }

        return sum;
    }

    //Вывод массива
    public String show(T max, double sum){

        StringBuilder m = new StringBuilder("<html><table border='1'><tbody><tr>");

        for (T value: data){
            m.append(String.format("<td>%.2f</td>",value.doubleValue()));
        }

        m.append("</tr></tbody></table>");

        m.append(String.format("<p>Максимальный по модулю элемент: %.2f<br>" +
                                "Cумма положительных элементов: %.2f</p>",max.doubleValue(),sum));
        return m.toString();
    }

    //Упорядочивание массива по убыванию модулей элементов
    //Упорядочивание массива по возрастанию модулей элементов
    // desc: true  - по убыванию
    // desc: false - по возрастанию

    public void orderBy(boolean desc) {

        // использование анонимного класса - "быстро, но грязно"
        Arrays.sort(data, new Comparator<T>() {
            @Override
            public int compare(T t1, T t2) {

                double c1 = Math.abs(t1.doubleValue());
                double c2 = Math.abs(t2.doubleValue());
                return desc?  (c2 - c1) > 0 ? 1 : (c2 - c1) < 0 ? -1 : 0 : (c1 - c2) > 0 ? 1 : (c1 - c2) < 0 ? -1 : 0;
            } // compare
        });
    } // orderBy*/

}
