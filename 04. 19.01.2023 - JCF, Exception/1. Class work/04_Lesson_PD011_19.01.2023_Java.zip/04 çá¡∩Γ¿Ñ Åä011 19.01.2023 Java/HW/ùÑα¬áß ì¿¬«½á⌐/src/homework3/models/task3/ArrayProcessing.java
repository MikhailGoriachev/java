package homework3.models.task3;

import homework3.Utils;

import java.util.Arrays;
import java.util.Comparator;


public class ArrayProcessing<T extends Number & Comparable<T>> {

     private T[] data;

    public T[] getData() {
        return data;
    }

    public ArrayProcessing(T[] data) {
        this.data = data;
    }
    public void show(){
        for (var item:data){
            System.out.print(item + " ");
        }
    }
    public T min(){
        T min = data[0];
        for (T item:data){
            if (min.compareTo(item) > 0){
                min = item;
            }
        }
        return min;
    }
    public T max(){
        T min = data[0];
        for (T item:data){
            if (min.compareTo(item) < 0){
                min = item;
            }
        }
        return min;
    }
}
