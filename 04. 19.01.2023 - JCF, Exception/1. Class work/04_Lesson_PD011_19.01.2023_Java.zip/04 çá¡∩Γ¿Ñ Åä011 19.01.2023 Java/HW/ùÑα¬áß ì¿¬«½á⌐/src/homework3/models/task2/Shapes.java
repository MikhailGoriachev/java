package homework3.models.task2;

public enum Shapes {
    RECTANGLE(7000), SQUARE(1705), RHOMB(1425), TRAPEZOID(1210);
    private final int value;
    public int getValue() { return value; }
    Shapes(int i) {
        this.value = i;
    }
    public double perimeter(double ... sides){
        return switch (value) {
            case 7000 -> 2 * (sides[0] + sides[1]);
            case 1705 -> 4 * sides[0];
            case 1425 -> 4 * sides[0];
            case 1210 -> sides[0] + sides[1] + sides[2] + sides[3];
            default -> 0.0;
        };
    }
    // площадь
    public double square(double ... sides){
        return switch (this) {
            case RECTANGLE -> sides[0] * sides[1];
            case SQUARE -> sides[0] * sides[0];
            // сторона высота
            case RHOMB -> sides[0] * sides[1];
            // высота сторона1 сторана2
            case TRAPEZOID -> 0.5 * sides[0] * (sides[1] + sides[2]);
        };
    }

    @Override
    public String toString() {
        return switch (this) {
            case RECTANGLE -> "Прямоугольник";
            case SQUARE -> "Квадрат";
            case RHOMB -> "Ромб";
            case TRAPEZOID -> "Прямоугольная трапеция";
        };
    }
}
