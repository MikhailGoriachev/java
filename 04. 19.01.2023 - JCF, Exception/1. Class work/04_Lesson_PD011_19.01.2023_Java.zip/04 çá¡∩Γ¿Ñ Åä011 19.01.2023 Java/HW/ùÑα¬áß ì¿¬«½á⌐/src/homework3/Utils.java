package homework3;

import java.util.Random;

public class Utils {
    public static Integer getRandInteger(int lo, int hi){
        return (int)(Math.random()*((hi-lo)+1))+lo;
    }
    public static Double getRandDouble(int lo, int hi){
        return Math.random()*((hi-lo)+1)+lo;
    }
    public static Integer[] createArrInteger(){
        Integer[] arr = new Integer[10];
        for (int i = 0; i < arr.length; i++){
            arr[i] = getRandInteger(-20, 20);
        }
        return arr;
    }
    public static Double[] createArrDouble(){
        Double[] arr = new Double[5];
        for (int i = 0; i < arr.length; i++){
            arr[i] = getRandDouble(-20, 20);
        }
        return arr;
    }
}
