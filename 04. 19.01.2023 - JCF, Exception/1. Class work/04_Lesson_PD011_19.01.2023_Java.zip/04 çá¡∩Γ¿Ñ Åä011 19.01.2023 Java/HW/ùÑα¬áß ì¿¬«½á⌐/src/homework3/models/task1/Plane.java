package homework3.models.task1;

public class Plane extends Vehicle {
    // высота
    int height;
    // количество пассажиров
    int countPas;

    public Plane(String title, String coordinates, long price, int speed, int age, int hieght, int countPas) {
        super(title, coordinates, price, speed, age);
        this.height = hieght;
        this.countPas = countPas;
    }

    @Override
    public String toTableRow() {
        return String.format("| %-25s | %25s | %12dl | %8d | %11d | %7d | %10d | %10s |", title, coordinates, price, speed, age, height, countPas, "");
    }
}
