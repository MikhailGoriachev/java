package homework3.controller;

import homework3.Utils;
import homework3.models.task2.Shapes;
import homework3.models.task3.ArrayProcessing;
import java.util.Arrays;
import java.util.Comparator;

public class Task3Controller {
    public void task3(){
        ArrayProcessing<Integer> arr = new ArrayProcessing<>(Utils.createArrInteger());
        System.out.println("\033[34mМассив 1\033[0m");
        arr.show();
        System.out.println("\n\nМинимальное: " + arr.min());
        System.out.println("Максимальное: " + arr.max());

        ArrayProcessing<Double> arr2 = new ArrayProcessing<>(Utils.createArrDouble());
        System.out.println("\n\033[34mМассив 2\033[0m");
        arr2.show();
        System.out.println("\n\nМинимальное: " + arr2.min());
        System.out.println("Максимальное: " + arr2.max());

        Arrays.sort(arr.getData(), new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                return Math.abs(o2) - Math.abs(o1);
            }
        });
        System.out.println("\n\033[34mпо убыванию модулей элементов\033[0m\nМассив 1");
        arr.show();

        System.out.println("\nМассив 2");
        Arrays.sort(arr2.getData(), new Comparator<Double>() {
            @Override
            public int compare(Double o1, Double o2) {
                return (int) (Math.abs(o2) - Math.abs(o1));
            }
        });
        arr2.show();
        // сортировка по возрастанию
        Arrays.sort(arr.getData(), new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                return Math.abs(o1) - Math.abs(o2);
            }
        });
        System.out.println("\n\n\033[34mпо возрастанию модулей элементов\033[0m\nМассив 1");
        arr.show();

        System.out.println("\nМассив 2");
        Arrays.sort(arr2.getData(), new Comparator<Double>() {
            @Override
            public int compare(Double o1, Double o2) {
                return (int) (Math.abs(o1) - Math.abs(o2));
            }
        });
        arr2.show();
    }
}
