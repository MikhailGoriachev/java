package homework3.models.task1;

public class Ship extends Vehicle {
    String port;

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public Ship(String title, String coordinates, long price, int speed, int age, String port) {
        super(title, coordinates, price, speed, age);
        this.port = port;
    }

    @Override
    public String toTableRow() {
        return String.format("| %-25s | %25s | %12dl | %8d | %11d | %7d | %10d | %10s |", title, coordinates, price, speed, age, 0, 0, port);
    }
}
