package homework3.controller;

import homework3.models.task2.Shapes;

public class Task2Controller {
    public void task2(){
        double a = Math.random() * 10;
        double b = Math.random() * 10;
        double c = Math.random() * 10;
        double d = Math.random() * 10;

        System.out.println("\033[34mрасчет периметров\033[0m");
        System.out.printf("%s сторона а: %.3f, сторона b: %.3f \n\033[32mпериметр = %.3f\033[0m\n", Shapes.RECTANGLE, a, b, Shapes.RECTANGLE.perimeter(a, b));
        System.out.printf("%s сторона а: %.3f, \n\033[32mпериметр = %.3f\033[0m\n", Shapes.SQUARE, a, Shapes.SQUARE.perimeter(a));
        System.out.printf("%s сторона а: %.3f, \n\033[32mпериметр = %.3f\033[0m\n", Shapes.RHOMB, a, Shapes.RHOMB.perimeter(a));
        System.out.printf("%s сторона а: %.3f, сторона b: %.3f сторона с: %.3f сторона d: %.3f \n\033[32mпериметр = %.3f\033[0m\n", Shapes.TRAPEZOID, a, b, c, d, Shapes.TRAPEZOID.perimeter(a, b, c, d));

        System.out.println("\033[34mрасчет площади\033[0m");
        System.out.printf("%s сторона а: %.3f, сторона b: %.3f \n\033[32mплощадь = %.3f\033[0m\n", Shapes.RECTANGLE, a, b, Shapes.RECTANGLE.square(a, b));
        System.out.printf("%s сторона а: %.3f, \n\033[32mплощадь = %.3f\033[0m\n", Shapes.SQUARE, a, Shapes.SQUARE.square(a));
        System.out.printf("%s высота а: %.3f, сторона b: %.3f\n\033[32mплощадь = %.3f\033[0m\n", Shapes.RHOMB, a, b, Shapes.RHOMB.square(a, b));
        System.out.printf("%s сторона а: %.3f, сторона b: %.3f сторона с: %.3f\n\033[32mплощадь = %.3f\033[0m\n", Shapes.TRAPEZOID, a, b, c, Shapes.TRAPEZOID.square(a, b, c));

    }
}

