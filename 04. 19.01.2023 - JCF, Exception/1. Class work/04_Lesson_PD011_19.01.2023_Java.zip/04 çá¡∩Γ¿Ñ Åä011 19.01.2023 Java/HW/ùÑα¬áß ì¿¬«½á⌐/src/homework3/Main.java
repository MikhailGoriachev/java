package homework3;

import homework3.controller.Task1Controller;
import homework3.controller.Task2Controller;
import homework3.controller.Task3Controller;

import javax.swing.*;
import java.io.Console;

import static homework3.Menu.showMenu;

public class Main {
    public static void main(String[] args)
    {
        Task1Controller task1 = new Task1Controller();
        Task2Controller task2 = new Task2Controller();
        Task3Controller task3 = new Task3Controller();
        try {
            boolean flag = true;
            while (flag) {
                switch (showMenu()){
                    case 0 -> task1.task1();
                    case 1 -> task2.task2();
                    case 2 -> task3.task3();
                    case 3 -> flag = false;
                   // default -> System.exit(0);
                }
            }
        } catch (Exception exception) {
            System.out.println("poka");
        }

    }

}