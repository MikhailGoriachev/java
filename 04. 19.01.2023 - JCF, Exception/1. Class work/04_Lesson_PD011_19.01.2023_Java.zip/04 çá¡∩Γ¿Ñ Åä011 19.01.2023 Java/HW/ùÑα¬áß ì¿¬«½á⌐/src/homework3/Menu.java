package homework3;

import javax.swing.*;

public class Menu {
    public static int showMenu(){
        return  JOptionPane.showOptionDialog(
                null, "Меню", "Меню",
                JOptionPane.YES_NO_CANCEL_OPTION, 1, null,
                new Object[] {"задача 1", "задача 2", "задача 3", "выход"},
                "задача 1");
    }
    public static int showMenu2(){
        return  JOptionPane.showOptionDialog(
                null, "Меню задача 1", "Меню задача 1",
                JOptionPane.YES_NO_CANCEL_OPTION, 1, null,
                new Object[] {"Коллекция", "Самое старое ", "Самое быстрое ", "Самое медленное", "Основное меню"},
                "Коллекция");
    }
}
