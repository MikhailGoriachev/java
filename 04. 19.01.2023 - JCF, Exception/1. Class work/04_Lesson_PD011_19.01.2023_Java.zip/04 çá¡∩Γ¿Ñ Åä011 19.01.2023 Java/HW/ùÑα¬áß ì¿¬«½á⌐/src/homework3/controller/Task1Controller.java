package homework3.controller;
import homework3.models.task1.Car;
import homework3.models.task1.Plane;
import homework3.models.task1.Ship;
import homework3.models.task1.Vehicle;

import static homework3.Menu.showMenu2;

public class Task1Controller {
    Vehicle[] vehicles;

    public Task1Controller() {
        this.vehicles = new Vehicle[]{
                new Plane("Boeing 737", "N60°33.858' E30° 45.258'", 50_000_000, 5000, 1999, 10000, 150),
                new Plane("Cessna 525A Citation CJ2+", "N30°33.555' E20° 55.100'", 3_100_000, 300, 1998, 2500, 6),
                new Ship("Allure of the Seas", "M10°53.333' A10° 55.150'", 1_500_000_000, 22, 2009, "Ла-Рошель"),
                new Ship("Harmony of the Seas", "M20°53.223' N30° 55.150'", 1_350_000_000, 22, 1978, "Роттердам"),
                new Ship("Oasis of the Seas", "E80°83.220' E30° 85.350'", 1_300_000_000, 22, 1990, "Шанхай"),
                new Car("Ланос", "D20°13.223' F30° 22.150'", 280_000, 150, 2008),
                new Car("Skoda Octavia", "N30°33.888' E20° 45.258'", 800_000, 180, 2008),
                new Car("Kia Sportage", "N80°25.445' M10° 35.258'", 1_870_000, 250, 2016),
                new Car("УАЗ Патриот", "F30°13.223' E50° 22.150'", 485_000, 150, 2011),
                new Car("Fiat 500L", "D20°13.223' F30° 33.333'", 300_000, 150, 2008),
        };
    }

    public void task1(){
        boolean flag = true;
        while (flag){
            switch (showMenu2()) {
                case 0 -> {
                    System.out.println("\033[34mтранспортные средства\033[0m");
                    show(vehicles);   // вывод коллекции
                }
                case 1 -> {
                    System.out.println("\033[34mсамое старое транспортное средство\033[0m");
                    old(vehicles);    // самые старые
                }
                case 2 -> {
                    System.out.println("\033[34mсамое быстрое транспортное средство\033[0m");
                    fast(vehicles);   // самые быстрые
                }
                case 3 -> {
                    System.out.println("\033[34mсамое медленное транспортное средство\033[0m");
                    slow(vehicles);   // самые медленые
                }
                case 4 -> flag = false;
            }
        }
    }
    // шапка таблицы
    public static void topTable(){
        System.out.print("""
                 ------------------------------------------------------------------------------------------------------------------------------------
                |       Транспорт           |      Координаты           |      Цена     | Скорость | Год выпуска |  Высота | Пассажиров |    Порт    |
                 ------------------------------------------------------------------------------------------------------------------------------------
                """);
    }
    public static void bottom(){
        System.out.println("------------------------------------------------------------------------------------------------------------------------------------");
    }
    // вывод коллекции в консоль
    public static void show(Vehicle[] arr){
        topTable();
        for(var item:arr){
            System.out.println(item.toTableRow());
        }
        bottom();
    }
    // находит самое старое
    public static int minOld(Vehicle[] arr){
        int min = arr[0].getAge();
        for (var item:arr){
            if (item.getAge() < min){
               min = item.getAge();
            }
        }
        return min;
    }
    // самое старое транспортное средство
    public static void old(Vehicle[] arr){
        topTable();
        int min = minOld(arr);
        for(var item:arr){
            if (item.getAge() == min){
                System.out.println(item.toTableRow());
            }
        }
        bottom();
    }
    // находит мах скорость
    public static int maxSpeed(Vehicle[] arr){
        int max = arr[0].getSpeed();
        for (var item:arr){
            if (item.getAge() > max){
                max = item.getAge();
            }
        }
        return max;
    }
    // самое быстрое
    public static void fast(Vehicle[] arr){
        topTable();
        int max = maxSpeed(arr);
        for(var item:arr){
            if (item.getSpeed() == max){
                System.out.println(item.toTableRow());
            }
        }
        bottom();
    }
    // находит мин скорость
    public static int minSpeed(Vehicle[] arr) {
        int min = arr[0].getSpeed();
        for (var item : arr) {
            if (item.getSpeed() < min) {
                min = item.getSpeed();
            }
        }
        return min;
    }
    // выводит самое медленное
    public static void slow(Vehicle[] arr){
            topTable();
            int min = minSpeed(arr);
            for(var item:arr){
                if (item.getSpeed() == min){
                    System.out.println(item.toTableRow());
                }
            }
            bottom();
    }
}
