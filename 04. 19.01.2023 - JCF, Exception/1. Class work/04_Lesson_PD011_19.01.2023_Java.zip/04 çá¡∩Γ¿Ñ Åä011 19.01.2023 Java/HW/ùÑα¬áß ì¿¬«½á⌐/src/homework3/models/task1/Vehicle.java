package homework3.models.task1;

public abstract class Vehicle {
    // название
    String title;
    // кординаты
    String coordinates;
    // цена
    long price;
    // скорость
    int speed;
    // год выпуска
    int age;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Vehicle(String title, String coordinates, long price, int speed, int age) {
        this.title = title;
        this.coordinates = coordinates;
        this.price = price;
        this.speed = speed;
        this.age = age;
    }

    public String getCoordinates() {
        return coordinates;
    }

    public void setCoordinates(String coordinates) {
        this.coordinates = coordinates;
    }

    public long getPrice() {
        return price;
    }

    public void setPrice(long price) {
        this.price = price;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public abstract String toTableRow();
}
