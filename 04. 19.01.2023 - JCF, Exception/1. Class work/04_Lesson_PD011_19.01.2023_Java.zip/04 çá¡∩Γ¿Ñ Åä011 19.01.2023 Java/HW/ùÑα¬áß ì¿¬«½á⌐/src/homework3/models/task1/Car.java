package homework3.models.task1;

public class Car extends Vehicle {
    public Car(String title, String coordinates, long price, int speed, int age) {
        super(title, coordinates, price, speed, age);
    }

    @Override
    public String toTableRow() {
        return String.format("| %-25s | %25s | %12dl | %8d | %11d | %7d | %10d | %10s |", title, coordinates, price, speed, age, 0, 0, "");
    }
}
