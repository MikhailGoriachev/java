package org.itstep.pd011.hw003.models;

public enum Quadrilateral {
    RECTANGLE(7000) {
        public double getPerimeter(double[] params) {
            return 2 * (params[0] + params[1]);
        } // getPerimeter
        public double getArea(double[] params) {
            return params[0] * params[1];
        } // getArea
    },
    SQUARE(1705) {
        public double getPerimeter(double[] params) {
            return 4 * params[0];
        } // getPerimeter
        public double getArea(double[] params) {
            return params[0] * params[0];
        } // getArea
    },
    RHOMBUS(1425) {
        public double getPerimeter(double[] params) {
            return 4 * params[0];
        } // getPerimeter
        public double getArea(double[] params) {
            return params[0] * params[0];
        } // getArea
    },
    TRAPEZOID(1210) {
        public double getPerimeter(double[] params) {
            return params[0] + params[1] + 2 * Math.sqrt(params[2] * params[2] + (params[0] - params[1]) * (params[0] - params[1]) / 4);
        } // getPerimeter
        public double getArea(double[] params) {
            return (params[0] + params[1]) * params[2] / 2;
        } // getArea
    };
    private int value;
    Quadrilateral(int value) {this.value = value;}
    public int getValue() {
        return value;
    } // getValue

    public void setValue(int value){
        this.value=value;
    } // setValue

    public abstract double getPerimeter(double[] params);

    public abstract double getArea(double[] params);

    @Override
    public String toString() {
        return switch (this) {
            case RECTANGLE -> "Прямоугольник";
            case SQUARE -> "Квадрат";
            case RHOMBUS -> "Ромб";
            case TRAPEZOID -> "Прямоугольная трапеция";
            default -> "нет данных";
        };
    } // toString
}