
package org.itstep.pd011.hw003;
import javax.swing.*;
import java.security.InvalidParameterException;

public class Main {
    public static void main(String[] args) {
        while (true) {
            String result = (String) JOptionPane.showInputDialog(null,
                    "<html><h3>Выберите <u>пункт</u> меню:</h3>",
                    "Вариант для решения",
                    JOptionPane.QUESTION_MESSAGE,
                    new ImageIcon(Main.class.getResource("comparing.png")),
                    new Object[]{"Наследование", "Перечисления", "Обобщенные классы. Анонимные классы"},
                    "Методы класса Math");
            System.out.printf("\nВы выбрали пункт меню \033[1;4m  %s  \033[0m\n", result == null ? "Выход" : result);
            if (result == null) break;
            switch (result) {
                case "Наследование" -> Tasks.task1();
                case "Перечисления" -> Tasks.task2();
                case "Обобщенные классы. Анонимные классы" -> Tasks.task3();
            } // switch
        } // while
    }
}