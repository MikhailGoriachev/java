
package org.itstep.pd011.hw003;

import org.itstep.pd011.hw003.models.Vehicle;

;

public class Functions {
    public static void showVehicles(Vehicle[] vehicles, String title) {
        System.out.print("\n\n\t "+title+"\n" +
                Vehicle.Header());
        for(int i =0;i<vehicles.length;i++)
            System.out.println(vehicles[i].ToTableRow(vehicles[i].getType()));
        // вывод подвала таблицы
        System.out.print(Vehicle.Footer());
    } // showVehicles

    public static int getMinYearVehicle(Vehicle[] vehicles){
        int year = Integer.MAX_VALUE;
        for(int i = 0;i<vehicles.length;i++)
            if(vehicles[i].getYear()<year)
                year = vehicles[i].getYear();
        return year;
    } // getIndexMinYearVehicle

    public static void showMinYearVehicles(Vehicle[] vehicles){
        System.out.print("\n\n\t Самые старые транспортные средства\n" +
                Vehicle.Header());
        int year = getMinYearVehicle(vehicles);
        for(int i =0;i<vehicles.length;i++)
            if (vehicles[i].getYear() == year)
                System.out.println(vehicles[i].ToTableRow(vehicles[i].getType()));
        // вывод подвала таблицы
        System.out.print(Vehicle.Footer());
    } // showMinYearVehicles

    public static double getMaxSpeedVehicle(Vehicle[] vehicles){
        double speed = 0;
        for(int i = 0;i<vehicles.length;i++)
            if(vehicles[i].getSpeed()>speed)
                speed = vehicles[i].getSpeed();
        return speed;
    } // getMaxSpeedVehicle
    public static double getMinSpeedVehicle(Vehicle[] vehicles){
        double speed = Double.MAX_VALUE;
        for(int i = 0;i<vehicles.length;i++)
            if(vehicles[i].getSpeed()<speed)
                speed = vehicles[i].getSpeed();
        return speed;
    } // getMinSpeedVehicle

    public static void showMaxSpeedVehicles(Vehicle[] vehicles){
        System.out.print("\n\n\t Самые быстрые транспортные средства\n" +
                Vehicle.Header());
        double speed  = getMaxSpeedVehicle(vehicles);
        for(int i =0;i<vehicles.length;i++)
            if (vehicles[i].getSpeed() == speed)
                System.out.println(vehicles[i].ToTableRow(vehicles[i].getType()));
        // вывод подвала таблицы
        System.out.print(Vehicle.Footer());
    } // showMaxSpeedVehicles
    public static void showMinSpeedVehicles(Vehicle[] vehicles){
        System.out.print("\n\n\t Самые медленные транспортные средства\n" +
                Vehicle.Header());
        double speed  = getMinSpeedVehicle(vehicles);
        for(int i =0;i<vehicles.length;i++)
            if (vehicles[i].getSpeed() == speed)
                System.out.println(vehicles[i].ToTableRow(vehicles[i].getType()));
        // вывод подвала таблицы
        System.out.print(Vehicle.Footer());
    } // showMaxSpeedVehicles

} // Functions
