
package org.itstep.pd011.hw003;

import org.itstep.pd011.hw003.models.*;

public class Tasks {

    public static void task1() {
        Vehicle[] vehicles = {
          new Plane(Utils.getRandom(0,90), Utils.getRandom(0,180), Utils.getRandom(60,200), Utils.getRandom(5000,1000000), Utils.getRandom(1992,2023),3000,345),
          new Plane(Utils.getRandom(0,90), Utils.getRandom(0,180), Utils.getRandom(60,200), Utils.getRandom(5000,1000000), Utils.getRandom(1992,2023),2567,250),
          new Ship(Utils.getRandom(0,90), Utils.getRandom(0,180), Utils.getRandom(60,200), Utils.getRandom(5000,1000000), Utils.getRandom(1992,2023), "Маджица", 450),
          new Ship(Utils.getRandom(0,90), Utils.getRandom(0,180), Utils.getRandom(60,200), Utils.getRandom(5000,1000000), Utils.getRandom(1992,2023), "Уругвей", 300),
          new Ship(Utils.getRandom(0,90), Utils.getRandom(0,180), Utils.getRandom(60,200), Utils.getRandom(5000,1000000), Utils.getRandom(1992,2023), "Лоренс", 300),
          new Car(Utils.getRandom(0,90), Utils.getRandom(0,180), Utils.getRandom(60,200), Utils.getRandom(5000,1000000), Utils.getRandom(1992,2023)),
          new Car(Utils.getRandom(0,90), Utils.getRandom(0,180), Utils.getRandom(60,200), Utils.getRandom(5000,1000000), Utils.getRandom(1992,2023)),
          new Car(Utils.getRandom(0,90), Utils.getRandom(0,180), Utils.getRandom(60,200), Utils.getRandom(5000,1000000), Utils.getRandom(1992,2023)),
          new Car(Utils.getRandom(0,90), Utils.getRandom(0,180), Utils.getRandom(60,200), Utils.getRandom(5000,1000000), Utils.getRandom(1992,2023)),
          new Car(Utils.getRandom(0,90), Utils.getRandom(0,180), Utils.getRandom(60,200), Utils.getRandom(5000,1000000), Utils.getRandom(1992,2023))
        };

        Functions.showVehicles(vehicles, "Транспортные средства");
        Functions.showMinYearVehicles(vehicles);
        Functions.showMaxSpeedVehicles(vehicles);
        Functions.showMinSpeedVehicles(vehicles);

    } // task1

    public static void task2() {
        Quadrilateral rectangle = Quadrilateral.RECTANGLE;
        double[] params = {3, 4};
        System.out.println( "Периметр " + rectangle + ": " + rectangle.getPerimeter(params) +
                            "\nПлощадь " + rectangle + ": " + rectangle.getArea(params));

        Quadrilateral square = Quadrilateral.SQUARE;
        System.out.println( "\nПериметр " + square + ": " + square.getPerimeter(params) +
                            "\nПлощадь " + square + ": " + square.getArea(params));

        Quadrilateral rhombus = Quadrilateral.RHOMBUS;
        System.out.println( "\nПериметр " + rhombus + ": " + rhombus.getPerimeter(params) +
                            "\nПлощадь " + rhombus + ": " + rhombus.getArea(params));

        double[] paramsT = {3,4,5};
        Quadrilateral trapezoid = Quadrilateral.TRAPEZOID;
        System.out.println( "\nПериметр " + trapezoid + ": " + trapezoid.getPerimeter(paramsT) +
                            "\nПлощадь " + trapezoid + ": " + trapezoid.getArea(paramsT));
    } // task2

    public static void task3() {
        System.out.println("\n\tВ разработке...");
    } // task3

} // Tasks
