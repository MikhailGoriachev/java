package org.itstep.pd011.hw003.models;

public class Ship extends Vehicle {


    private String _port;   // порт приписки
    private int _countPas;  //  количество пассажиров

    public Ship(double latitude, double longitude, double speed, double price, int year, String port, int countPas) {
        super(latitude,longitude,speed,price,year);
        _port = port;
        _countPas = countPas;
    } // Ship

    public String getPort() { return _port; }
    public void setPort(String port) { this._port = port; }

    public int getCountPas() { return _countPas; }
    public void setCountPas(int countPas) { this._countPas = countPas; }

    @Override // реализация абстрактного метода
    public String getType() {
        return "Корабль";
    } // GetType

    @Override
    public String ToTableRow(String type) {
        return  String.format("\t│ %-9s │ %10.2f │ %10.2f │ %8.2f " +
                "│ %11.2f │ %10d " +
                "│ %8s │ %10s " +
                "│ %12s │", type, _longitude,_latitude,_speed,_price,_year,"-",_countPas,_port);
    } // ToTableRow
} // Car
