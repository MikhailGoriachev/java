package org.itstep.pd011.hw003.models;

public class Plane extends Vehicle {

    private double _height;  // высота полета
    private int _countPas;   //  количество пассажиров

    public Plane(double latitude, double longitude, double speed, double price, int year, double height, int countPas) {
        super(latitude,longitude,speed,price,year);
        _height = height;
        _countPas = countPas;
    } // Plane
    public double getHeight() { return _height; }
    public void setHeight(double height) { this._height = height; }
    public int getCountPas() { return _countPas; }
    public void setCountPas(int countPas) { this._countPas = countPas; }

    @Override // реализация абстрактного метода
    public String getType() {
        return "Самолет";
    } // GetType

    @Override
    public String ToTableRow(String type) {
        return  String.format("\t│ %-9s │ %10.2f │ %10.2f │ %8.2f " +
                "│ %11.2f │ %10d " +
                "│ %8s │ %10s " +
                "│ %12s │", type, _longitude,_latitude,_speed,_price,_year,_height,_countPas,"-");
    } // ToTableRow
} // Plane
