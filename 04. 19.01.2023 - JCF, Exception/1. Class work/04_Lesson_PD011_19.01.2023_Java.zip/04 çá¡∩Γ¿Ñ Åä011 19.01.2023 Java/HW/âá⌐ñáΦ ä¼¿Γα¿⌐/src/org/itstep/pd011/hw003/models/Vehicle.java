package org.itstep.pd011.hw003.models;

import org.itstep.pd011.hw003.Utils;

public abstract class Vehicle {

    protected double _latitude; // широта
    protected double _longitude;// долгота
    protected double _speed;    // Скорость (км/ч)
    protected double _price;    // Цена ($)
    protected int _year;        // Год выпуска

    // блок инициализации, выполняется перед любым конструктором
    { _latitude = Utils.getRandom(0,90); _longitude = Utils.getRandom(0,180); _speed = Utils.getRandom(60,200); _price = Utils.getRandom(5000,1000000); _year = Utils.getRandom(1992,2023);}

    public Vehicle(double latitude, double longitude, double speed, double price, int year) {
        this._latitude = latitude;
        this._longitude = longitude;
        this._speed = speed;
        this._price = price;
        this._year = year;
    } // Vehicle

    public double getLatitude() { return _latitude; }
    public void setLatitude(double latitude) { this._latitude = latitude; }
    public double getLongitude() { return _longitude; }
    public void setLongitude(double longitude) { this._longitude = longitude; }
    public double getSpeed() { return _speed; }
    public void setSpeed(double speed) { this._speed = speed; }
    public double getPrice() { return _price; }
    public void setPrice(double price) { this._price = price; }
    public int getYear() { return _year; }
    public void setYear(int year) { this._year = year; }


    // определение абстрактного метода
    abstract public String getType();
    abstract public String ToTableRow(String type);

    // переопределенный метод суперкласса
    @Override
    public String toString() {
        return  "\n    Координаты: "+_longitude+"\n    Координаты: "+_latitude+"\n    Скорость: "+_speed+"\n" +
                "    Цена: "+_price+"\n    Год: "+_year;
    } // toString


    public static String Header() {
        return  "\t┌───────────┬────────────┬────────────┬──────────┬─────────────┬────────────┬──────────┬────────────┬──────────────┐\n" +
                "\t│    Тип    │ Координаты │ Координаты │ Скорость │    Цена     │    Год     │  Высота  │ Количество │   Приписка   │\n" +
                "\t│    ТС     │  долгота   │  широта    │  (км/ч)  │  валюта($)  │  выпуска   │  полета  │ пассажиров │    порта     │\n" +
                "\t├───────────┼────────────┼────────────┼──────────┼─────────────┼────────────┼──────────┼────────────┼──────────────┤\n";
    }

    public static String Footer() {
        return"\t└───────────┴────────────┴────────────┴──────────┴─────────────┴────────────┴──────────┴────────────┴──────────────┘";
    }
} // class Vehicle
