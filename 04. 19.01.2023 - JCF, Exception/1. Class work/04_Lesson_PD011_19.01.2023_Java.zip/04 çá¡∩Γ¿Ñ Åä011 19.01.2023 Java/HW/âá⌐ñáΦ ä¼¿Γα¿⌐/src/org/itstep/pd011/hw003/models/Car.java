package org.itstep.pd011.hw003.models;

public class Car extends Vehicle {

    public Car(double latitude, double longitude, double speed, double price, int year) {
        super(latitude,longitude,speed,price,year);
    } // Vehicle
    @Override // реализация абстрактного метода
    public String getType() {
       return "Машина";
    } // GetType

    @Override
    public String ToTableRow(String type) {
        return  String.format("\t│ %-9s │ %10.2f │ %10.2f │ %8.2f " +
                "│ %11.2f │ %10d " +
                "│ %8s │ %10s " +
                "│ %12s │", type, _longitude,_latitude,_speed,_price,_year,"-","-","-");
    } // ToTableRow
} // Car
